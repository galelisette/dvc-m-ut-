
#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;

Block<int, double> test_cons_block() {
  return cons_block([](int x) { 
    return pure_process(10.0 * x); 
  });
}

Block<int, long> test_then_block() {
  return test_cons_block()
    .and_then(cons_block([](double x) { 
      return pure_process(static_cast<long>(x)); 
    }));
}

Process<double> test_run_block() {
  return test_cons_block().run(5);
}

Process<double> test_run_block_by_moving() {
  return test_cons_block().run(std::move(5));
}

Block<int, double> test_arr_block() {
  return arr_block([](int x) { 
    return 10.0 * x; 
  });
}

Block<int, double> test_delay_block() {
  return delay_block([]() { 
    return test_arr_block(); 
  });
}

Block<int, Unit> test_terminate_block() {
  return terminate_block<int>();
}

Block<int, Unit> test_transfer_block() {
  return transfer_block<int, Unit>(cons_block([](int x) {
    return transfer_process<int>(pure_process(Unit()))
      .map([](int y) { return Unit(); });
  }));
}

Block<int, double> test_finally_block() {
  return finally_block(test_arr_block(), arr_block([](int x) {
    return 'd';
  }));
}

Block<int, int> test_advance_block() {
  return advance_block<int>(pure_process(Unit()));
}

Block<Transact<int>, Transact<int>> test_queue_block(const QueuePtr& queue) {
  return queue_block<int>(queue);
}

Block<Transact<int>, Transact<int>> test_depart_block(const QueuePtr& queue) {
  return depart_block<int>(queue);
}

Block<Transact<int>, Transact<int>> test_seize_block(const FacilityPtr<int>& facility) {
  return seize_block(facility);
}

Block<Transact<int>, Transact<int>> test_preempt_block(const FacilityPtr<int>& facility, PreemptBlockMode<int>&& mode) {
  return preempt_block(facility, std::move(mode));
}

Block<Transact<int>, Transact<int>> test_return_block(const FacilityPtr<int>& facility) {
  return return_block(facility);
}

Block<Transact<int>, Transact<int>> test_release_block(const FacilityPtr<int>& facility) {
  return release_block(facility);
}

Event<Unit> test_return_within_event(const FacilityPtr<int>& facility, const TransactIdPtr& tid) {
  return return_facility_within_event(facility, tid);
}

Event<Unit> test_release_within_event(const FacilityPtr<int>& facility, const TransactIdPtr& tid) {
  return release_facility_within_event(facility, tid);
}

Block<Transact<int>, Transact<int>> test_enter_block(const StoragePtr<int>& storage) {
  return enter_block(storage, 7);
}

Block<Transact<int>, Transact<int>> test_leave_block(const StoragePtr<int>& storage) {
  return leave_block(storage, 7);
}

Event<Unit> test_leave_within_event(const StoragePtr<int>& storage) {
  return leave_storage_within_event(storage, 7);
}

Block<Transact<int>, Transact<int>> test_assign_block() {
  return assign_block(int { 10 });
}

Block<Transact<int>, Transact<int>> test_assign_block_c() {
  return assign_block_c(pure_event(10));
}

Block<Transact<int>, Transact<int>> test_foreach_block() {
  return foreach_block<int>([](int x) { return; });
}

Block<Transact<int>, Transact<int>> test_foreach_block_c() {
  return foreach_block_c<int>([](int x) { return pure_event(Unit()); });
}

Block<Transact<double>, Transact<double>> test_priority_block() {
  return priority_block<double>(10);
}

Block<Transact<double>, Transact<double>> test_priority_block_c() {
  return priority_block_c<double>(pure_event(10));
}

Block<Transact<int>, Transact<int>> test_split_block() {
  return split_block(terminate_block<Transact<int>>());
}

Block<Transact<int>, Transact<int>> test_spawn_block_with() {
  return spawn_block_with(ProcessCancellation::CancelInIsolation, terminate_block<Transact<int>>());
}

Block<Transact<int>, Transact<int>> test_spawn_block() {
  return spawn_block(terminate_block<Transact<int>>());
}

Block<Transact<int>, Transact<int>> test_assemble_block() {
  return assemble_block<int>(24);
}

Block<Transact<int>, Transact<int>> test_gather_block() {
  return gather_block<int>(24);
}

Block<Transact<int>, Transact<int>> test_concat_blocks() {
  std::vector<Block<Transact<int>, Transact<int>>> comps;

  comps.emplace_back(test_split_block());
  comps.emplace_back(test_assemble_block());
  comps.emplace_back(test_gather_block());

  return concat_blocks(std::move(comps));
}

GeneratorBlock<Transact<int>> test_observable_generator_block(Observable<Arrival<int>>&& obs) {
  return observable_generator_block<int>(std::move(obs));
}

GeneratorBlock<Transact<int>> test_stream_generator_block(Stream<Arrival<int>>&& stream) {
  return stream_generator_block<int>(std::move(stream));
}

int main() {}

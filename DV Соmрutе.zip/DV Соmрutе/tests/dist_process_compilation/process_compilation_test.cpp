
#include "dvcompute/dvcompute.h"

using namespace dvcompute_dist;

Process<int> test_pure_process() {
  return pure_process(5);
}

Process<int> test_pure_process2() {
  return pure_process(std::move(5));
}

Process<int> test_process_await() {
  return process_await(empty_observable<int>());
}

Process<int> test_freeze_process_with_reentering_at(int val) {
  auto impl = [val](internal::process::BoxedContFn<int>&& cont_fn,
    const ProcessIdPtr &pid,
    const Point *p) mutable
  {
    auto frozen_cont { internal::process::freeze_process_with_reentering_at(std::move(cont_fn), 
      pid, std::move(val), internal::process::move_impl(test_freeze_process_with_reentering_at(val)), p) };
    return Result<Unit>(Unit());
  };
  return Process<int, decltype(impl)>(std::move(impl));
}

Process<int> test_process_finally() {
  return finally_process(pure_process(10), pure_process(5.0));
}

Event<Unit> test_cancel_process_by_id() {
  return into_event(new_process_id()).and_then([](const ProcessIdPtr& pid) {
    return cancel_process_by_id(pid);
  });
}

Process<std::vector<int>> test_process_sequence() {
  return process_sequence(std::vector<Process<int>>());
}

Process<Unit> test_process_sequence_() {
  return process_sequence_(std::vector<Process<int>>());
}

Process<std::optional<int>> test_timeout_process() {
  return timeout_process(10.0, pure_process(1));
}

Process<int> test_transfer_process(Process<Unit>&& comp) {
  return transfer_process<int>(std::move(comp));
}

Process<int> test_embed_result_process(Result<int> &&item) {
  return embed_result_process(std::move(item));
}

int main() {}

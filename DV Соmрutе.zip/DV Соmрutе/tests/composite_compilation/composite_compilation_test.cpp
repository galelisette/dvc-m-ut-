
#include "dvcompute/dvcompute.h"

using namespace dvcompute;

Composite<int> test_pure_composite() {
  return pure_composite(10);
}

Composite<double> test_then_composite() {
  return test_pure_composite()
    .and_then([](int x) { return pure_composite(x * 1.0); });
}

Composite<double> test_map_composite() {
  return test_pure_composite()
    .map([](int x) { return x * 1.0; });
}

Event<std::tuple<int, Disposable<>>> test_run_composite() {
  return test_pure_composite().run(empty_disposable());
}

Event<int> test_run_composite_() {
  return test_pure_composite().run_();
}

Composite<int> test_cons_composite() {
  return cons_composite([](Disposable<>&& disposable, const Point* p) {
    return Result<std::tuple<int, Disposable<>>>(std::make_tuple(std::move(7), std::move(disposable)));
  });
}

Composite<int> test_delay_composite() {
  return delay_composite([]() { return test_pure_composite(); });
}

Composite<int> test_into_composite(Composite<int>& comp) {
  return into_composite(std::move(comp));
}

Composite<int> test_into_composite(Event<int>& comp) {
  return into_composite(std::move(comp));
}

Composite<int> test_into_composite(Simulation<int>& comp) {
  return into_composite(std::move(comp));
}

Composite<int> test_into_composite(Parameter<int>& comp) {
  return into_composite(std::move(comp));
}

Composite<Unit> test_disposable_composite() {
  return disposable_composite(empty_disposable());
}

Composite<std::vector<int>> test_composite_sequence() {
  std::vector<Composite<int>> vec;

  vec.emplace_back(test_pure_composite());
  vec.emplace_back(test_pure_composite());
  vec.emplace_back(test_pure_composite());

  return composite_sequence(std::move(vec));
}

Composite<Unit> test_composite_sequence_() {
  std::vector<Composite<int>> vec;

  vec.emplace_back(test_pure_composite());
  vec.emplace_back(test_pure_composite());
  vec.emplace_back(test_pure_composite());

  return composite_sequence_(std::move(vec));
}

int main() {}

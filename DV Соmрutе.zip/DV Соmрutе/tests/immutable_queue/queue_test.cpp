
#include <tuple>
#include <vector>
#include <optional>
#include <stdexcept>

#include "dvcompute/simulator/utils/queue.h"

using namespace dvcompute;

class TestFailed : public std::logic_error {
public:
  explicit TestFailed(const char* what_arg) : std::logic_error(what_arg) {}
  explicit TestFailed(const std::string& what_arg) : std::logic_error(what_arg) {}
};

static void assert_test(bool result, const char* error_message) {
  if (!result) throw TestFailed(error_message);
}

typedef utils::im::Queue<int> queue;
typedef queue::const_iterator const_iterator;
typedef std::vector<int> vector;

static vector expand_queue(const queue& xs) {
  vector res;
  for (auto it = xs.begin(); it != xs.end(); ++ it) {
    res.push_back(*it);
  }
  return res;
}

static bool same_vectors(const vector& xs, const vector& ys) {
  if (xs.size() != ys.size()) {
    return false;
  } else {
    for (size_t i = 0; i < xs.size(); ++ i) {
      if (xs[i] != ys[i]) {
        return false;
      }
    }

    return true;
  }
}

static bool same_as_vector(const queue& xs, const vector& ys) {
  return same_vectors(expand_queue(xs), ys);
}

static queue make_queue(const vector& xs) {
  queue q;
  for (auto &e : xs) {
    q = q.push_back(e);
  }
  return q;
}

static void test_empty() {
  queue xs;
  assert_test(expand_queue(xs).empty(), "The queue must be empty (test_empty)");
}

static void test_create_from_vector() {
  vector vs { 1, 2, 3 };
  queue xs(vs);
  assert_test(same_as_vector(xs, vs), "The queue must be the same (test_create_from_vector)");
}

static void test_remove_first() {
  vector vs { 1, 2, 3 };
  vector ws { 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.erase(1);
  assert_test(ys && same_as_vector(ys.value(), ws), "The queue must be the same (test_remove_first)");
}

static void test_remove_middle() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.erase(2);
  assert_test(ys && same_as_vector(ys.value(), ws), "The queue must be the same (test_remove_middle)");
}

static void test_remove_last() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 2 };
  queue xs = make_queue(vs);
  auto ys = xs.erase(3);
  assert_test(ys && same_as_vector(ys.value(), ws), "The queue must be the same (test_remove_last)");
}

static void test_remove_first_by() {
  vector vs { 1, 2, 3 };
  vector ws { 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.erase_by([](int x) { return x == 1; });
  assert_test(ys && 
    std::get<0>(ys.value()) == 1 &&
    same_as_vector(std::get<1>(ys.value()), ws), 
    "The queue must be the same (test_remove_first_by)");
}

static void test_remove_middle_by() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.erase_by([](int x) { return x == 2; });
  assert_test(ys && 
    std::get<0>(ys.value()) == 2 &&
    same_as_vector(std::get<1>(ys.value()), ws), 
    "The queue must be the same (test_remove_middle_by)");
}

static void test_remove_last_by() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 2 };
  queue xs = make_queue(vs);
  auto ys = xs.erase_by([](int x) { return x == 3; });
  assert_test(ys && 
    std::get<0>(ys.value()) == 3 &&
    same_as_vector(std::get<1>(ys.value()), ws), 
    "The queue must be the same (test_remove_last_by)");
}

static void test_existent() {
  vector vs { 1, 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.exists([](int x) { return x == 3; });
  assert_test(ys, "The item must exist (test_existent)");
}

static void test_non_existent() {
  vector vs { 1, 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.exists([](int x) { return x == 0; });
  assert_test(!ys, "The item must not exist (test_non_existent)");
}

static void test_found() {
  vector vs { 1, 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.find([](int x) { return x == 3; });
  assert_test(ys != xs.end() && *ys == 3, "The item must be found (test_found)");
}

static void test_not_found() {
  vector vs { 1, 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.find([](int x) { return x == 8; });
  assert_test(ys == xs.end(), "The item must not be found (test_not_found)");
}

static void test_empty_iterator() {
  queue xs;
  auto it = xs.begin();
  assert_test(it == xs.end(), "The empty iterator (test_empty_iterator)");
}

static void test_front() {
  vector vs { 1, 2, 3 };
  queue xs = make_queue(vs);
  assert_test(xs.front() == 1, "The queue must have a front element (test_front)");
}

static void test_pop_front() {
  vector vs { 1, 2, 3 };
  vector ws { 2, 3 };
  queue xs = make_queue(vs);
  auto ys = xs.pop_front();
  assert_test(same_as_vector(ys, ws), "We can pop the front element (test_pop_front)");
}

static void test_push_back() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 2, 3, 4 };
  queue xs(vs);
  auto ys = xs.push_back(4);
  assert_test(same_as_vector(ys, ws), "We can push the back element (test_push_back)");
}

static void test_push_back_2() {
  vector ws { 1, 2, 3, 4 };
  queue xs;
  auto ys = xs.push_back(1).push_back(2).push_back(3).push_back(4);
  assert_test(same_as_vector(ys, ws), "We can push the back element (test_push_back_2)");
}

int main() {
  test_empty();
  test_create_from_vector();
  test_remove_first();
  test_remove_middle();
  test_remove_last();
  test_remove_first_by();
  test_remove_middle_by();
  test_remove_last_by();
  test_existent();
  test_non_existent();
  test_found();
  test_not_found();
  test_empty_iterator();
  test_front();
  test_pop_front();
  test_push_back();
  test_push_back_2();
}

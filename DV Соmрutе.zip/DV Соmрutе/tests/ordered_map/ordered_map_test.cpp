
#include <tuple>
#include <vector>
#include <random>
#include <stdexcept>
#include <algorithm>
#include <random>

#include "dvcompute/simulator/utils/ordered_map.h"

using namespace dvcompute;

class TestFailed : public std::logic_error {
public:
  explicit TestFailed(const char* what_arg) : std::logic_error(what_arg) {}
  explicit TestFailed(const std::string& what_arg) : std::logic_error(what_arg) {}
};

static void assert_test(bool result, const char* error_message) {
  if (!result) throw TestFailed(error_message);
}

typedef int key_type;
typedef utils::im::OrderedMap<key_type, int> ordered_map;
typedef ordered_map::const_iterator const_iterator;
typedef std::vector<std::tuple<key_type, int>> expanded_vector;

static expanded_vector expand_vector(const std::vector<const_iterator>& vec) {
  expanded_vector result;
  for (auto& it : vec) {
    result.push_back(std::make_tuple(it.key(), it.value()));
  }
  return result;
}

static void test_map(const std::vector<key_type>& keys) {
  ordered_map xs;

  for (key_type k : keys) {
    xs = xs.emplace(key_type { k }, key_type { k });
  }

  std::size_t n = keys.size();

  assert_test(n == xs.size(), "The map must have the specified size");
  
  if (n > 1) {
    assert_test(log(n) / log(2.0) >= (xs.depth() - 1) / 2, "The map must have the limited depth");
  }

  for (key_type k : keys) {
    auto it = xs.find(k);
    assert_test(it != xs.end(), "The map must contain the added items");
  }

  if (n > 0) {
    auto it_min_1 = xs.find_min();
    auto it_min_2 = std::min_element(keys.begin(), keys.end());

    assert_test(it_min_1.key() == it_min_1.value(), "There must be the minimal element");
    assert_test(it_min_1.key() == *it_min_2, "There must be the minimal element");

    auto it_max_1 = xs.find_max();
    auto it_max_2 = std::max_element(keys.begin(), keys.end());

    assert_test(it_max_1.key() == it_max_1.value(), "There must be the maximal element");
    assert_test(it_max_1.key() == *it_max_2, "There must be the maximal element");
  }
}

static void test_empty() {
  std::vector<key_type> keys;
  test_map(keys);
}

static void test_1() {
  std::vector<key_type> keys;
  keys.push_back(1);
  test_map(keys);
}

static void test_2() {
  std::vector<key_type> keys;
  keys.push_back(1);
  keys.push_back(2);
  test_map(keys);
}

static void test_3() {
  std::vector<key_type> keys;
  keys.push_back(1);
  keys.push_back(2);
  keys.push_back(3);
  test_map(keys);
}

static void test_4() {
  std::vector<key_type> keys;
  keys.push_back(1);
  keys.push_back(2);
  keys.push_back(3);
  keys.push_back(4);
  test_map(keys);
}

static void test_5() {
  std::vector<key_type> keys;
  keys.push_back(1);
  keys.push_back(2);
  keys.push_back(3);
  keys.push_back(4);
  keys.push_back(5);
  test_map(keys);
}

static void test_ordered() {
  std::vector<key_type> keys;
  int n = 1000;
  for (int i = 0; i < n; ++ i) {
    keys.push_back(i);
  }
  test_map(keys);
}

static void test_back_ordered() {
  std::vector<key_type> keys;
  int n = 1000;
  for (int i = n; i > 0; -- i) {
    keys.push_back(i);
  }
  test_map(keys);
}

static void test_erase_empty() {
  ordered_map xs;
  xs = xs.erase(2);

  assert_test(xs.empty(), "The map must be empty (test_erase_empty)");
}

static void test_erase_one() {
  ordered_map xs;
  xs = xs.emplace(2, 20);
  xs = xs.emplace(3, 30);
  xs = xs.emplace(1, 10);
  xs = xs.erase(2);

  expanded_vector ys {
    { 1, 10 },
    { 3, 30 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_erase_one)");
}

static void test_erase_two() {
  ordered_map xs;
  xs = xs.emplace(2, 20);
  xs = xs.emplace(3, 30);
  xs = xs.emplace(1, 10);
  xs = xs.erase(2);
  xs = xs.erase(100);

  expanded_vector ys {
    { 1, 10 },
    { 3, 30 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_erase_two)");
}

static void test_erase_three() {
  ordered_map xs;
  xs = xs.emplace(2, 20);
  xs = xs.emplace(3, 30);
  xs = xs.emplace(1, 10);
  xs = xs.erase(2);
  xs = xs.erase(3);

  expanded_vector ys {
    { 1, 10 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_erase_three)");
}

static void test_erase_four() {
  ordered_map xs;
  xs = xs.emplace(2, 20);
  xs = xs.emplace(3, 30);
  xs = xs.emplace(1, 10);
  xs = xs.emplace(3, 300);
  xs = xs.erase(2);
  xs = xs.erase(3);
  xs = xs.erase(1);

  assert_test(xs.empty(), "The map must be empty (test_erase_four)");
}

static void test_erase_negative() {
  ordered_map xs;
  xs = xs.emplace(2, 20);
  xs = xs.emplace(-5, -50);
  xs = xs.emplace(3, 30);
  xs = xs.emplace(-3, -30);
  xs = xs.emplace(1, 10);
  xs = xs.emplace(-1, -10);
  xs = xs.erase(2);
  xs = xs.erase(3);
  xs = xs.erase(1);
  xs = xs.erase(-1);
  xs = xs.erase(-5);
  xs = xs.erase(-3);

  assert_test(xs.empty(), "The map must be empty (test_erase_negative)");
}

static void test_random() {
  std::vector<key_type> keys;
  std::random_device r;
  std::default_random_engine g(r());
  std::uniform_int_distribution dist(-10000, +10000);
  int n = 1000;

  for (int i = 0; i < n; ++ i) {
    int k = dist(g);
    if (std::find(keys.begin(), keys.end(), k) == keys.end()) {
      keys.push_back(k);
    }
  }

  test_map(keys);
}

static void test_erase_random() {
  std::vector<key_type> keys;
  std::random_device r;
  std::default_random_engine g(r());
  std::uniform_int_distribution dist(-10000, +10000);
  int n = 1000;

  for (int i = 0; i < n; ++ i) {
    int k = dist(g);
    if (std::find(keys.begin(), keys.end(), k) == keys.end()) {
      keys.push_back(k);
    }
  }

  test_map(keys);
}

static void test_clear_random() {
  std::vector<key_type> keys;
  std::random_device r;
  std::default_random_engine g(r());
  std::uniform_int_distribution dist(-10000, +10000);
  int n = 1000;

  for (int i = 0; i < n; ++ i) {
    int k = dist(g);
    if (std::find(keys.begin(), keys.end(), k) == keys.end()) {
      keys.push_back(k);
    }
  }

  ordered_map xs;

  for (std::size_t i = 0; i < keys.size(); ++ i) {
    xs = xs.emplace(int { keys[i] }, int { 10 * keys[i] });
  }

  for (std::size_t i = 0; i < keys.size(); ++ i) {
    xs = xs.erase(keys[i]);
  }

  assert_test(xs.empty(), "The map must be empty (test_clear_random)");
}

static void test_clear_random_reversed() {
  std::vector<key_type> keys;
  std::random_device r;
  std::default_random_engine g(r());
  std::uniform_int_distribution dist(-10000, +10000);
  int n = 1000;

  for (int i = 0; i < n; ++ i) {
    int k = dist(g);
    if (std::find(keys.begin(), keys.end(), k) == keys.end()) {
      keys.push_back(k);
    }
  }

  ordered_map xs;

  for (std::size_t i = 0; i < keys.size(); ++ i) {
    xs = xs.emplace(int { keys[i] }, int { 10 * keys[i] });
  }

  for (std::size_t i = keys.size(); i > 0; -- i) {
    xs = xs.erase(keys[i - 1]);
  }

  assert_test(xs.empty(), "The map must be empty (test_clear_random_reversed)");
}

int main() {
  test_empty();
  test_1();
  test_2();
  test_3();
  test_4();
  test_5();
  test_ordered();
  test_back_ordered();
  test_erase_empty();
  test_erase_one();
  test_erase_two();
  test_erase_three();
  test_erase_four();
  test_erase_negative();
  test_random();
  test_erase_random();
  test_clear_random();
  test_clear_random_reversed();
}

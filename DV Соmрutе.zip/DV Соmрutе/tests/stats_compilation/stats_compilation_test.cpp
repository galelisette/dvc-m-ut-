
#include <optional>

#include "dvcompute/dvcompute.h"

using namespace dvcompute;

SamplingStats<int> test_int_sampling_stats() {

  SamplingStats<int> st1;
  SamplingStats<int> st2;
  
  st1.add(1);
  st1.add(2);
  
  st2.add(10);
  st2.add(20);
  
  return st1.combine(st2);
}

SamplingStats<double> test_double_sampling_stats() {

  SamplingStats<double> st1;
  SamplingStats<double> st2;
  
  st1.add(1.0);
  st1.add(2.0);
  
  st2.add(10.0);
  st2.add(20.0);
  
  return st1.combine(st2);
}

TimingStats<int> test_int_timing_stats() {

  TimingStats<int> st1;
  
  st1.add(1.0, 10);
  st1.add(2.0, 20);
  
  return st1;
}

TimingStats<double> test_double_timing_stats() {

  TimingStats<double> st1;
  
  st1.add(1.0, 10.0);
  st1.add(2.0, 20.0);
  
  return st1;
}

SamplingStats<int> test_int_timing_stats_norm() {
  return test_int_timing_stats().norm(100);
}

SamplingStats<double> test_double_timing_stats_norm() {
  return test_double_timing_stats().norm(100);
}

int main() {}

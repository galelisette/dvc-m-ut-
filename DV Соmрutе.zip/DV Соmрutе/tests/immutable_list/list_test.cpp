
#include <tuple>
#include <vector>
#include <optional>
#include <stdexcept>

#include "dvcompute/simulator/utils/list.h"

using namespace dvcompute;

class TestFailed : public std::logic_error {
public:
  explicit TestFailed(const char* what_arg) : std::logic_error(what_arg) {}
  explicit TestFailed(const std::string& what_arg) : std::logic_error(what_arg) {}
};

static void assert_test(bool result, const char* error_message) {
  if (!result) throw TestFailed(error_message);
}

typedef utils::im::List<int> list;
typedef list::const_iterator const_iterator;
typedef std::vector<int> vector;

static vector expand_list(const list& xs) {
  vector res;
  for (auto it = xs.begin(); it != xs.end(); ++ it) {
    res.push_back(*it);
  }
  return res;
}

static bool same_vectors(const vector& xs, const vector& ys) {
  if (xs.size() != ys.size()) {
    return false;
  } else {
    for (size_t i = 0; i < xs.size(); ++ i) {
      if (xs[i] != ys[i]) {
        return false;
      }
    }

    return true;
  }
}

static bool same_as_vector(const list& xs, const vector& ys) {
  return same_vectors(expand_list(xs), ys);
}

static void test_empty() {
  list xs;
  assert_test(expand_list(xs).empty(), "The list must be empty (test_empty)");
}

static void test_create_from_vector() {
  vector vs { 1, 2, 3 };
  list xs(vs);
  assert_test(same_as_vector(xs, vs), "The list must be the same (test_create_from_vector)");
}

static void test_remove_first() {
  vector vs { 1, 2, 3 };
  vector ws { 2, 3 };
  list xs(vs);
  auto ys = xs.erase(1);
  assert_test(ys && same_as_vector(ys.value(), ws), "The list must be the same (test_remove_first)");
}

static void test_remove_middle() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 3 };
  list xs(vs);
  auto ys = xs.erase(2);
  assert_test(ys && same_as_vector(ys.value(), ws), "The list must be the same (test_remove_middle)");
}

static void test_remove_last() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 2 };
  list xs(vs);
  auto ys = xs.erase(3);
  assert_test(ys && same_as_vector(ys.value(), ws), "The list must be the same (test_remove_last)");
}

static void test_remove_first_by() {
  vector vs { 1, 2, 3 };
  vector ws { 2, 3 };
  list xs(vs);
  auto ys = xs.erase_by([](int x) { return x == 1; });
  assert_test(ys && 
    std::get<0>(ys.value()) == 1 &&
    same_as_vector(std::get<1>(ys.value()), ws), 
    "The list must be the same (test_remove_first_by)");
}

static void test_remove_middle_by() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 3 };
  list xs(vs);
  auto ys = xs.erase_by([](int x) { return x == 2; });
  assert_test(ys && 
    std::get<0>(ys.value()) == 2 &&
    same_as_vector(std::get<1>(ys.value()), ws), 
    "The list must be the same (test_remove_middle_by)");
}

static void test_remove_last_by() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 2 };
  list xs(vs);
  auto ys = xs.erase_by([](int x) { return x == 3; });
  assert_test(ys && 
    std::get<0>(ys.value()) == 3 &&
    same_as_vector(std::get<1>(ys.value()), ws), 
    "The list must be the same (test_remove_last_by)");
}

static void test_existent() {
  vector vs { 1, 2, 3 };
  list xs(vs);
  auto ys = xs.exists([](int x) { return x == 3; });
  assert_test(ys, "The item must exist (test_existent)");
}

static void test_non_existent() {
  vector vs { 1, 2, 3 };
  list xs(vs);
  auto ys = xs.exists([](int x) { return x == 0; });
  assert_test(!ys, "The item must not exist (test_non_existent)");
}

static void test_found() {
  vector vs { 1, 2, 3 };
  list xs(vs);
  auto ys = xs.find([](int x) { return x == 3; });
  assert_test(ys != xs.end() && *ys == 3, "The item must be found (test_found)");
}

static void test_not_found() {
  vector vs { 1, 2, 3 };
  list xs(vs);
  auto ys = xs.find([](int x) { return x == 8; });
  assert_test(ys == xs.end(), "The item must not be found (test_not_found)");
}

static void test_reversed() {
  vector vs { 1, 2, 3 };
  vector ws { 3, 2, 1 };
  list xs(vs);
  auto ys = xs.reversed();
  assert_test(same_as_vector(ys, ws), "The list must be the same (test_reversed)");
}

static void test_append() {
  vector vs1 { 1, 2, 3 };
  vector vs2 { 4, 5, 6 };
  vector ws { 1, 2, 3, 4, 5, 6 };
  list xs1(vs1);
  list xs2(vs2);
  auto ys = xs1.append(xs2);
  assert_test(same_as_vector(ys, ws), "The list must be the same (test_append)");
}

static void test_append_reversed() {
  vector vs { 1, 2, 3 };
  vector ws { 1, 2, 3, 3, 2, 1 };
  list xs(vs);
  auto ys = xs.append(xs.reversed());
  assert_test(same_as_vector(ys, ws), "The list must be the same (test_append_reversed)");
}

static void test_cons() {
  vector ws { 3, 2, 1 };
  list xs;
  auto ys = list(3, list(2, list(1, list())));
  assert_test(same_as_vector(ys, ws), "The list must be the same (test_cons)");
}

int main() {
  test_empty();
  test_create_from_vector();
  test_remove_first();
  test_remove_middle();
  test_remove_last();
  test_remove_first_by();
  test_remove_middle_by();
  test_remove_last_by();
  test_existent();
  test_non_existent();
  test_found();
  test_not_found();
  test_reversed();
  test_append();
  test_append_reversed();
  test_cons();
}
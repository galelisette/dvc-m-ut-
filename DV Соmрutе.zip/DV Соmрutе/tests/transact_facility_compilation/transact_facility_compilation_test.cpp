
#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;

Event<FacilityPtr<int>> test_new_facility() {
  return new_facility<int>();
}

Event<int> test_facility_count() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_count(facility);
    });
}

Event<TimingStats<int>> test_facility_count_stats() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_count_stats(facility);
    });
}

Event<Disposable<>> test_facility_count_changed() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_count_changed(facility)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_facility_count_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_count_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_facility_capture_count() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_capture_count(facility);
    });
}

Event<Disposable<>> test_facility_capture_count_changed() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_capture_count_changed(facility)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_facility_capture_count_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_capture_count_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_facility_util_count() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_util_count(facility);
    });
}

Event<TimingStats<int>> test_facility_util_count_stats() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_util_count_stats(facility);
    });
}

Event<Disposable<>> test_facility_util_count_changed() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_util_count_changed(facility)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_facility_util_count_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_util_count_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_facility_queue_count() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_queue_count(facility);
    });
}

Event<TimingStats<int>> test_facility_queue_count_stats() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_queue_count_stats(facility);
    });
}

Event<Disposable<>> test_facility_queue_count_changed() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_queue_count_changed(facility)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_facility_queue_count_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_queue_count_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<double> test_facility_total_wait_time() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_total_wait_time(facility);
    });
}

Event<SamplingStats<double>> test_facility_wait_time() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_wait_time(facility);
    });
}

Event<Disposable<>> test_facility_wait_time_changed() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_wait_time_changed(facility)
        .subscribe(cons_observer([](const SamplingStats<double>* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_facility_wait_time_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_wait_time_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<double> test_facility_total_holding_time() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_total_holding_time(facility);
    });
}

Event<SamplingStats<double>> test_facility_holding_time() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_holding_time(facility);
    });
}

Event<Disposable<>> test_facility_holding_time_changed() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_holding_time_changed(facility)
        .subscribe(cons_observer([](const SamplingStats<double>* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_facility_holding_time_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_holding_time_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<bool> test_facility_interrupted() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return is_facility_interrupted(facility);
    });
}

Event<Disposable<>> test_facility_changed_() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return facility_changed_(facility)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Unit> test_reset_facility() {
  return test_new_facility()
    .and_then([](const FacilityPtr<int>& facility) {
      return reset_facility(facility);
    });
}

int main() {}

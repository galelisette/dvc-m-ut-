
#include "dvcompute/dvcompute.h"

using namespace dvcompute_branch;

Parameter<int> test_branch_level() {
  return branch_level();
}

Event<int> test_branch_event(Event<int>&& comp) {
  return branch_event(std::move(comp));
}

Event<int> test_future_event(Event<int>&& comp) {
  return future_event(10.0, std::move(comp));
}

Event<double> test_binary_forecast_by_depth(Event<double>&& comp) {
  return binary_forecast_by_depth(std::move(comp), 10);
}

Event<double> test_binary_forecast_by_dt(Event<double>&& comp) {
  return binary_forecast_by_dt(std::move(comp), 0.10);
}

int main() {}

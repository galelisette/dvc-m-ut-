
#include <vector>

#include "dvcompute/dvcompute.h"

using namespace dvcompute_dist;
using namespace dvcompute_dist::block;
using namespace dvcompute_dist::slot;

ObservableSlot<int> test_empty_observable_slot() {
  return empty_observable_slot<int>();
}

ObservableSlot<double> test_map_observable_slot() {
  return test_empty_observable_slot().map([](const int *x) { return static_cast<double>(*x); });
}

ObservableSlot<int> test_hold_observable_slot() {
  return test_empty_observable_slot().hold(10.0);
}

ObservableSlot<int> test_merge_obserable_slots() {
  return test_empty_observable_slot().merge(test_empty_observable_slot());
}

ObservableSlot<int> test_concat_observable_slots(const std::vector<ObservableSlot<int>>& slots) {
  return concat_observable_slots(slots);
}

ObservableSlot<double> test_input_message_slot() {
  return input_message_slot<double>();
}

Composite<Unit> test_observable_slot_to_block_slot(const ObservableSlot<int> &observable, const BlockSlot<Transact<int>, Unit> &block) {
  return observable_slot_to_block_slot(observable, block);
}

std::pair<BlockSlot<Transact<int>, Unit>, ObservableSlot<int>> test_block_slot_to_observable_slot() {
  return block_slot_to_observable_slot<int>();
}

int main() {}

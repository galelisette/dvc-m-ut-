
#include <optional>
#include <vector>
#include <tuple>

#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;

Event<QueuePtr> test_new_queue() {
  return new_queue();
}

Event<bool> test_queue_empty() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_empty(queue);
    });
}

Event<Disposable<>> test_queue_enqueued() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_enqueued(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_queue_dequeued() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_dequeued(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_queue_content() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_content(queue);
    });
}

Event<TimingStats<int>> test_queue_content_stats() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_content_stats(queue);
    });
}

Event<Disposable<>> test_queue_content_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_content_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_queue_content_changed() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_content_changed(queue)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_enqueue_count() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return enqueue_count(queue);
    });
}

Event<Disposable<>> test_enqueue_count_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return enqueue_count_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_enqueue_count_changed() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return enqueue_count_changed(queue)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_enqueue_zero_entry_count() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return enqueue_zero_entry_count(queue);
    });
}

Event<Disposable<>> test_enqueue_zero_entry_count_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return enqueue_zero_entry_count_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_enqueue_zero_entry_count_changed() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return enqueue_zero_entry_count_changed(queue)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<SamplingStats<double>> test_queue_wait_time() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_wait_time(queue);
    });
}

Event<Disposable<>> test_queue_wait_time_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_wait_time_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_queue_wait_time_changed() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_wait_time_changed(queue)
        .subscribe(cons_observer([](const SamplingStats<double>* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<SamplingStats<double>> test_queue_non_zero_entry_wait_time() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_non_zero_entry_wait_time(queue);
    });
}

Event<Disposable<>> test_queue_non_zero_entry_wait_time_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_non_zero_entry_wait_time_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_non_zero_entry_queue_wait_time_changed() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_non_zero_entry_wait_time_changed(queue)
        .subscribe(cons_observer([](const SamplingStats<double>* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<double> test_queue_rate() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_rate(queue);
    });
}

Event<Disposable<>> test_queue_rate_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_rate_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_queue_rate_changed() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_rate_changed(queue)
        .subscribe(cons_observer([](const double* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_queue_changed_() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return queue_changed_(queue)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Unit> test_reset_queue() {
  return test_new_queue()
    .and_then([](const QueuePtr& queue) {
      return reset_queue(queue);
    });
}

Event<Unit> test_enqueue_transact(const QueuePtr& queue, const TransactIdPtr& tid) {
  return enqueue_transact(queue, tid, 1);
}

Event<Unit> test_dequeue_transact(const QueuePtr& queue, const TransactIdPtr& tid) {
  return dequeue_transact(queue, tid, 1);
}

int main() {}

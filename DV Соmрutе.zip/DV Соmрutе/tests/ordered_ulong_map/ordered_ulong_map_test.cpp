
#include <tuple>
#include <vector>
#include <random>
#include <stdexcept>

#include "dvcompute/simulator/utils/ordered_int_map.h"

using namespace dvcompute;

class TestFailed : public std::logic_error {
public:
  explicit TestFailed(const char* what_arg) : std::logic_error(what_arg) {}
  explicit TestFailed(const std::string& what_arg) : std::logic_error(what_arg) {}
};

static void assert_test(bool result, const char* error_message) {
  if (!result) throw TestFailed(error_message);
}

typedef unsigned long key_type;
typedef utils::im::OrderedIntMap<key_type, double> ordered_int_map;
typedef ordered_int_map::const_iterator const_iterator;
typedef std::vector<std::tuple<key_type, double>> expanded_vector;

static expanded_vector expand_vector(const std::vector<const_iterator>& vec) {
  expanded_vector result;
  for (auto& it : vec) {
    result.push_back(std::make_tuple(it.key(), it.value()));
  }
  return result;
}

static void test_empty() {
  ordered_int_map xs;
  assert_test(xs.empty(), "The map must be empty (test_empty)");
}

static void test_emplace_one() {
  ordered_int_map xs;
  xs = xs.emplace(1, 1.0);

  expanded_vector ys {
    { 1, 1.0 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_emplace_one)");
}

static void test_emplace_two() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(1, 1.0);

  expanded_vector ys {
    { 1, 1.0 },
    { 2, 2.0 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_emplace_two)");
}

static void test_emplace_three() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);

  expanded_vector ys {
    { 1, 1.0 },
    { 2, 2.0 },
    { 3, 3.0 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_emplace_three)");
}

static void test_erase_empty() {
  ordered_int_map xs;
  xs = xs.erase(2);

  assert_test(xs.empty(), "The map must be empty (test_erase_empty)");
}

static void test_erase_one() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);
  xs = xs.erase(2);

  expanded_vector ys {
    { 1, 1.0 },
    { 3, 3.0 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_erase_one)");
}

static void test_erase_two() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);
  xs = xs.erase(2);
  xs = xs.erase(100);

  expanded_vector ys {
    { 1, 1.0 },
    { 3, 3.0 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_erase_two)");
}

static void test_erase_three() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);
  xs = xs.erase(2);
  xs = xs.erase(3);

  expanded_vector ys {
    { 1, 1.0 }
  };

  assert_test(expand_vector(xs.to_vector()) == ys, "The vectors must be equal (test_erase_three)");
}

static void test_erase_four() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);
  xs = xs.emplace(3, 30.0);
  xs = xs.erase(2);
  xs = xs.erase(3);
  xs = xs.erase(1);

  assert_test(xs.empty(), "The map must be empty (test_erase_four)");
}

static void test_find_existent() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);

  auto it = xs.find(2);

  assert_test(it != xs.end() && it.value() == 2.0, "The element must be found (test_find_existent)");
}

static void test_cannot_find_nonexistent() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);

  auto it = xs.find(10);

  assert_test(it == xs.end(), "The non-existent element cannot be found (test_cannot_find_nonexistent)");
}

static void test_empty_extrema() {
  ordered_int_map xs;

  auto it_min = xs.find_min();
  auto it_max = xs.find_max();

  assert_test(it_min == xs.end(), "The must be no minimum (test_empty_extrema)");
  assert_test(it_max == xs.end(), "The must be no maximum (test_empty_extrema)");
}

static void test_find_extrema() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(1, 1.0);

  auto it_min = xs.find_min();
  auto it_max = xs.find_max();

  assert_test(it_min != xs.end() && it_min.value() == 1.0, "The minimum element must be found (test_find_extrema)");
  assert_test(it_max != xs.end() && it_max.value() == 3.0, "The maximum element must be found (test_find_extrema)");
}

static void test_random_short() {
  std::vector<key_type> keys;
  std::random_device r;
  std::default_random_engine g(r());
  std::uniform_int_distribution dist(10, 20);
  int n = 1000;

  ordered_int_map xs;

  for (int i = 0; i < n; ++ i) {
    key_type key = dist(g);
    key_type val = key;
    xs = xs.emplace(key, std::move(val));
    keys.push_back(key);
  }

  for (key_type key : keys) {
    xs = xs.erase(key);
  }

  assert_test(xs.empty(), "The map must be empty (test_random_short)");
}

static void test_random_wide() {
  std::vector<key_type> keys;
  std::random_device r;
  std::default_random_engine g(r());
  std::uniform_int_distribution dist(0, 20000);
  int n = 1000;

  ordered_int_map xs;

  for (int i = 0; i < n; ++ i) {
    key_type key = dist(g);
    key_type val = key;
    xs = xs.emplace(key, std::move(val));
    keys.push_back(key);
  }

  for (key_type key : keys) {
    xs = xs.erase(key);
  }

  assert_test(xs.empty(), "The map must be empty (test_random_wide)");
}

static void test_full_traverse() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(13, 13.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(15, 15.0);
  xs = xs.emplace(1, 1.0);
  xs = xs.emplace(17, 17.0);
  xs = xs.emplace(19, 19.0);

  std::vector<std::tuple<key_type, double>> ys;
  std::vector<std::tuple<key_type, double>> zs;

  zs.push_back(std::make_tuple(1, 1.0));
  zs.push_back(std::make_tuple(2, 2.0));
  zs.push_back(std::make_tuple(3, 3.0));
  zs.push_back(std::make_tuple(13, 13.0));
  zs.push_back(std::make_tuple(15, 15.0));
  zs.push_back(std::make_tuple(17, 17.0));
  zs.push_back(std::make_tuple(19, 19.0));

  xs.traverse([&ys](key_type k, double v) {
    ys.push_back(std::make_tuple(k, v));
    return false;
  }, false);

  assert_test(ys == zs, "The map can be traversed (test_full_traverse)");
}

static void test_cut_traverse() {
  ordered_int_map xs;
  xs = xs.emplace(2, 2.0);
  xs = xs.emplace(13, 13.0);
  xs = xs.emplace(3, 3.0);
  xs = xs.emplace(15, 15.0);
  xs = xs.emplace(1, 1.0);
  xs = xs.emplace(17, 17.0);
  xs = xs.emplace(19, 19.0);

  std::vector<std::tuple<key_type, double>> ys;
  std::vector<std::tuple<key_type, double>> zs;

  zs.push_back(std::make_tuple(1, 1.0));
  zs.push_back(std::make_tuple(2, 2.0));
  zs.push_back(std::make_tuple(3, 3.0));

  xs.traverse([&ys](key_type k, double v) {
    if (k >= 10) return true;
    else {
      ys.push_back(std::make_tuple(k, v));
      return false;
    }
  }, false);

  assert_test(ys == zs, "The map can be traversed (test_cut_traverse)");
}

int main() {
  test_empty();
  test_emplace_one();
  test_emplace_two();
  test_emplace_three();
  test_erase_empty();
  test_erase_one();
  test_erase_two();
  test_erase_three();
  test_erase_four();
  test_find_existent();
  test_cannot_find_nonexistent();
  test_empty_extrema();
  test_find_extrema();
  test_random_short();
  test_random_wide();
  test_full_traverse();
  test_cut_traverse();
}
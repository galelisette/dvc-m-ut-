
#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::experiments;
using namespace dvcompute::experiments::rendering;

class TestExecutor : public ExperimentExecutor {
public:

  virtual ~TestExecutor() {}

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)
  
  Result<Unit> execute(std::vector<std::function<Result<Unit>()>>&& models) override {
    throw "NotSupported";
  }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

  Result<Unit> execute(std::vector<std::function<Result<Unit>(LogicalProcessContext* ctx)>>&& models) override {
    throw "NotSupported";
  }

#else
#error "Unknown simulation mode"
#endif  
};

class TestRendering : public ExperimentRendering<Unit, Unit> {
public:

  virtual ~TestRendering() {}

  Result<environment_type> prepare(const Experiment& experiment) override {
    throw "NotSupported";
  }

  Result<Unit> render(const Experiment& experiment,
    const std::vector<std::shared_ptr<ExperimentReporter<context_type>>>& reporters,
    const environment_type& env) override 
  {
    throw "NotSupported";
  }

  Result<Unit> on_completed(const Experiment& experiment,
    const environment_type& env) override
  {
    throw "NotSupported";
  }

  Result<Unit> on_failed(const Experiment& experiment,
    const environment_type& env,
    const Result<Unit>& error) override
  {
    throw "NotSupported";
  }
};

Experiment test_default_experiment() {
  return Experiment();
}

Result<Unit> test_run_experiment() {
  std::vector<std::shared_ptr<ExperimentGenerator<TestRendering>>> generators;
  TestRendering rendering;
  std::function<Simulation<results::ResultSet>()> simulation;
  TestExecutor executor;
  Experiment experiment { test_default_experiment() };

  return experiment.run(std::move(generators), std::move(rendering), std::move(simulation), std::move(executor));
}

WebPageRendering test_web_page_rendering() {
  return WebPageRendering("experiment");
}

int main() {}

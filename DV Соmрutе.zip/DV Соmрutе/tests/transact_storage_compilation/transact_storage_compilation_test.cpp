
#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;

Event<StoragePtr<int>> test_new_storage() {
  return new_storage<int>(15);
}

Event<bool> test_storage_empty() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_empty(storage);
    });
}

Event<bool> test_storage_full() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_full(storage);
    });
}

Event<int> test_storage_content() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_content(storage);
    });
}

Event<TimingStats<int>> test_storage_content_stats() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_content_stats(storage);
    });
}

Event<Disposable<>> test_storage_content_changed() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_content_changed(storage)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_content_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_content_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_storage_use_count() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_use_count(storage);
    });
}

Event<Disposable<>> test_storage_use_count_changed() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_use_count_changed(storage)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_use_count_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_use_count_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_storage_used_content() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_used_content(storage);
    });
}

Event<Disposable<>> test_storage_used_content_changed() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_used_content_changed(storage)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_used_content_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_used_content_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<double> test_storage_average_holding_time() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_average_holding_time(storage);
    });
}

Event<int> test_storage_util_count() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_util_count(storage);
    });
}

Event<TimingStats<int>> test_storage_util_count_stats() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_util_count_stats(storage);
    });
}

Event<Disposable<>> test_storage_util_count_changed() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_util_count_changed(storage)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_util_count_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_util_count_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<int> test_storage_queue_count() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_queue_count(storage);
    });
}

Event<TimingStats<int>> test_storage_queue_count_stats() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_queue_count_stats(storage);
    });
}

Event<Disposable<>> test_storage_queue_count_changed() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_queue_count_changed(storage)
        .subscribe(cons_observer([](const int* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_queue_count_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_queue_count_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<double> test_storage_total_wait_time() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_total_wait_time(storage);
    });
}

Event<SamplingStats<double>> test_storage_wait_time() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_wait_time(storage);
    });
}

Event<Disposable<>> test_storage_wait_time_changed() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_wait_time_changed(storage)
        .subscribe(cons_observer([](const SamplingStats<double>* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_wait_time_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_wait_time_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Disposable<>> test_storage_changed_() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return storage_changed_(storage)
        .subscribe(cons_observer([](const Unit* msg, const Point* p) {
          return Result<Unit>(Unit());
        }));
    });
}

Event<Unit> test_reset_storage() {
  return test_new_storage()
    .and_then([](const StoragePtr<int>& storage) {
      return reset_storage(storage);
    });
}

int main() {}

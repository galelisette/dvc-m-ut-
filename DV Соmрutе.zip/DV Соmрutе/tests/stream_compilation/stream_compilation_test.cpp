
#include <optional>

#include "dvcompute/dvcompute.h"

using namespace dvcompute;

Stream<int> test_empty_stream() {
  return empty_stream<int>();
}

Process<std::pair<int, Stream<int>>> test_run_stream(Stream<int>&& stream) {
  return std::move(stream).run();
}

Stream<double> test_map_stream(Stream<int>&& stream) {
  return std::move(stream).map([](int&& x) {
    return static_cast<double>(x);
  });
}

Stream<double> test_mapc_stream(Stream<int>&& stream) {
  return std::move(stream).mapc([](int&& x) {
    return pure_event(static_cast<double>(x));
  });
}

Stream<int> test_filter_stream(Stream<int>&& stream) {
  return std::move(stream).filter([](int x) {
    return x >= 0;
  });
}

Stream<int> test_filterc_stream(Stream<int>&& stream) {
  return std::move(stream).filterc([](int x) {
    return pure_event(x >= 0);
  });
}

Stream<int> test_take_stream(Stream<int>&& stream) {
  return std::move(stream).take(10);
}

Stream<int> test_take_stream_while(Stream<int>&& stream) {
  return std::move(stream).take_while([](int x) {
    return x >= 0;
  });
}

Stream<int> test_take_stream_while_c(Stream<int>&& stream) {
  return std::move(stream).take_while_c([](int x) {
    return pure_event(x >= 0);
  });
}

Stream<int> test_drop_stream(Stream<int>&& stream) {
  return std::move(stream).drop(10);
}

Stream<int> test_drop_stream_while(Stream<int>&& stream) {
  return std::move(stream).drop_while([](int x) {
    return x >= 0;
  });
}

Stream<int> test_drop_stream_while_c(Stream<int>&& stream) {
  return std::move(stream).drop_while_c([](int x) {
    return pure_event(x >= 0);
  });
}

Stream<int> test_delay_stream(Stream<int>&& stream) {
  return delay_stream([stream{std::move(stream)}]() mutable {
    return std::move(stream);
  });
}

Stream<int> test_iterate_stream() {
  return iterate_stream([](int x) { return 1 + x; }, 0);
}

Stream<Arrival<int>> test_arrival_stream(Stream<int>&& stream) {
  return arrival_stream(std::move(stream));
}

Stream<Arrival<int>> test_random_stream() {
  return random_stream<int>([]() {
    return pure_parameter(std::pair(10.0, 7));
  });
}

Stream<Arrival<double>> test_random_uniform_stream() {
  return random_uniform_stream(1.0, 2.0);
}

Stream<Arrival<int>> test_random_int_uniform_stream() {
  return random_int_uniform_stream(1, 2);
}

Stream<Arrival<double>> test_random_triangular_stream() {
  return random_triangular_stream(1.0, 1.8, 2.0);
}

Stream<Arrival<double>> test_random_normal_stream() {
  return random_normal_stream(1.0, 2.0);
}

Stream<Arrival<double>> test_random_log_normal_stream() {
  return random_log_normal_stream(1.0, 2.0);
}

Stream<Arrival<double>> test_random_exponential_stream() {
  return random_exponential_stream(1.0);
}

Stream<Arrival<double>> test_random_erlang_stream() {
  return random_erlang_stream(1.0, 5);
}

Stream<Arrival<int>> test_random_poisson_stream() {
  return random_poisson_stream(5.0);
}

Stream<Arrival<int>> test_random_binomial_stream() {
  return random_binomial_stream(0.2, 4);
}

Stream<Arrival<double>> test_random_gamma_stream() {
  return random_gamma_stream(0.2, 3.0);
}

Stream<Arrival<double>> test_random_beta_stream() {
  return random_beta_stream(0.2, 3.0);
}

Stream<Arrival<double>> test_random_weibull_stream() {
  return random_weibull_stream(0.2, 3.0);
}

Stream<Arrival<int>> test_random_discrete_stream() {
  SharedPtr<std::vector<std::pair<int, double>>> dpdf { mk_shared(std::vector<std::pair<int, double>>()) };

  dpdf->emplace_back(std::pair(5, 0.1));
  dpdf->emplace_back(std::pair(8, 0.3));
  dpdf->emplace_back(std::pair(9, 0.7));

  return random_discrete_stream(dpdf);
}

int main() {}

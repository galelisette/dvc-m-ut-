
#include <vector>

#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;
using namespace dvcompute::slot;

BlockSlot<int, Unit> test_terminate_block_slot() {
  return terminate_block_slot<int>();
}

BlockSlot<int, double> test_transfer_block_slot(const BlockSlot<int, Unit>& block_slot) {
  return transfer_block_slot<int, double>(block_slot);
}

BlockSlot<int, double> test_arr_block_slot() {
  return arr_block_slot([](int x) { return static_cast<double>(x); });
}

BlockSlot<int, int> test_identity_block_slot() {
  return identity_block_slot<int>();
}

BlockSlot<int, Unit> test_and_then_block_slot() {
  return test_identity_block_slot().and_then(test_terminate_block_slot());
}

BlockSlot<int, int> test_advance_block_slot(double dt) {
  return advance_block_slot<int>(dt);
}

BlockSlot<Transact<int>, Transact<int>> test_queue_block_slot(const QueuePtr& queue, int increment) {
  return queue_block_slot<int>(queue, increment);
}

BlockSlot<Transact<int>, Transact<int>> test_depart_block_slot(const QueuePtr& queue, int decrement) {
  return depart_block_slot<int>(queue, decrement);
}

BlockSlot<Transact<int>, Transact<int>> test_seize_block_slot(const FacilityPtr<int>& facility) {
  return seize_block_slot(facility);
}

BlockSlot<Transact<int>, Transact<int>> test_preempt_block_slot(const FacilityPtr<int>& facility, const PreemptBlockMode<int>& mode) {
  return preempt_block_slot(facility, mode);
}

BlockSlot<Transact<int>, Transact<int>> test_return_block_slot(const FacilityPtr<int>& facility) {
  return return_block_slot(facility);
}

BlockSlot<Transact<int>, Transact<int>> test_release_block_slot(const FacilityPtr<int>& facility) {
  return release_block_slot(facility);
}

BlockSlot<Transact<int>, Transact<int>> test_enter_block_slot(const StoragePtr<int>& storage, int decrement) {
  return enter_block_slot(storage, decrement);
}

BlockSlot<Transact<int>, Transact<int>> test_leave_block_slot(const StoragePtr<int>& storage, int increment) {
  return leave_block_slot(storage, increment);
}

BlockSlot<Transact<int>, Transact<int>> test_assign_block_slot(int item) {
  return assign_block_slot(item);
}

BlockSlot<Transact<int>, Transact<int>> test_foreach_block_slot(const std::function<void(int)>& fn) {
  return foreach_block_slot<int>(fn);
}

BlockSlot<Transact<int>, Transact<int>> test_priority_block_slot(int priority) {
  return priority_block_slot<int>(5);
}

BlockSlot<Transact<int>, Transact<int>> test_split_block_slot(const BlockSlot<Transact<int>, Unit>& block_slot) {
  return split_block_slot(block_slot);
}

BlockSlot<Transact<int>, Transact<int>> test_spawn_block_slot_with(ProcessCancellation cancellation, const BlockSlot<Transact<int>, Unit>& block_slot) {
  return spawn_block_slot_with(cancellation, block_slot);
}

BlockSlot<Transact<int>, Transact<int>> test_spawn_block_slot(const BlockSlot<Transact<int>, Unit>& block_slot) {
  return spawn_block_slot(block_slot);
}

BlockSlot<Transact<int>, Transact<int>> test_assemble_block_slot(int count) {
  return assemble_block_slot<int>(count);
}

BlockSlot<Transact<int>, Transact<int>> test_gather_block_slot(int count) {
  return gather_block_slot<int>(count);
}

BlockSlot<int, int> test_concat_block_slots(std::vector<BlockSlot<int, int>>&& slots) {
  return concat_block_slots(std::move(slots));
}

int main() {}

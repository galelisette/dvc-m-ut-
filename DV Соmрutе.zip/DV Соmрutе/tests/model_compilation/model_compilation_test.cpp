
#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;

RefPtr<int> test_new_ref(Model& model) {
  return model.new_ref<int>(8);
}

RefPtr<int> test_new_ref(Model& model, std::string&& name) {
  return model.new_ref<int>(8, std::move(name));
}

RefPtr<int> test_new_ref(Model& model, std::string&& name, std::string& descr) {
  return model.new_ref<int>(8, std::move(name), std::move(descr));
}

QueuePtr test_new_queue(Model& model) {
  return model.new_queue();
}

QueuePtr test_new_queue(Model& model, std::string&& name) {
  return model.new_queue(std::move(name));
}

QueuePtr test_new_queue(Model& model, std::string&& name, std::string& descr) {
  return model.new_queue(std::move(name), std::move(descr));
}

FacilityPtr<int> test_new_facility(Model& model) {
  return model.new_facility<int>();
}

FacilityPtr<int> test_new_facility(Model& model, std::string&& name) {
  return model.new_facility<int>(std::move(name));
}

FacilityPtr<int> test_new_facility(Model& model, std::string&& name, std::string& descr) {
  return model.new_facility<int>(std::move(name), std::move(descr));
}

StoragePtr<int> test_new_storage(Model& model) {
  return model.new_storage<int>(9);
}

StoragePtr<int> test_new_storage(Model& model, std::string&& name) {
  return model.new_storage<int>(9, std::move(name));
}

StoragePtr<int> test_new_storage(Model& model, std::string&& name, std::string& descr) {
  return model.new_storage<int>(9, std::move(name), std::move(descr));
}

Observable<Arrival<double>> test_new_random_uniform_observable(Model& model) {
  return model.new_random_uniform_observable(1.0, 2.0);
}

Observable<Arrival<int>> test_new_random_int_uniform_observable(Model& model) {
  return model.new_random_int_uniform_observable(1, 2);
}

Observable<Arrival<double>> test_new_random_triangular_observable(Model& model) {
  return model.new_random_triangular_observable(1.0, 1.8, 2.0);
}

Observable<Arrival<double>> test_new_random_normal_observable(Model& model) {
  return model.new_random_normal_observable(1.0, 2.0);
}

Observable<Arrival<double>> test_new_random_log_normal_observable(Model& model) {
  return model.new_random_log_normal_observable(1.0, 2.0);
}

Observable<Arrival<double>> test_new_random_exponential_observable(Model& model) {
  return model.new_random_exponential_observable(1.0);
}

Observable<Arrival<double>> test_new_random_erlang_observable(Model& model) {
  return model.new_random_erlang_observable(1.0, 5);
}

Observable<Arrival<int>> test_new_random_poisson_observable(Model& model) {
  return model.new_random_poisson_observable(5.0);
}

Observable<Arrival<int>> test_new_random_binomial_observable(Model& model) {
  return model.new_random_binomial_observable(0.2, 4);
}

Observable<Arrival<double>> test_new_random_gamma_observable(Model& model) {
  return model.new_random_gamma_observable(0.2, 3.0);
}

Observable<Arrival<double>> test_new_random_beta_observable(Model& model) {
  return model.new_random_beta_observable(0.2, 3.0);
}

Observable<Arrival<double>> test_new_random_weibull_observable(Model& model) {
  return model.new_random_weibull_observable(0.2, 3.0);
}

Observable<Arrival<int>> test_new_random_discrete_observable(Model& model) {
  SharedPtr<std::vector<std::pair<int, double>>> dpdf { mk_shared(std::vector<std::pair<int, double>>()) };

  dpdf->emplace_back(std::pair(5, 0.1));
  dpdf->emplace_back(std::pair(8, 0.3));
  dpdf->emplace_back(std::pair(9, 0.7));

  return model.new_random_discrete_observable(dpdf);
}

void test_register_event(Model& model, const std::function<Event<int>()>& comp_fn, std::string&& name) {
  return model.register_event<int>(comp_fn, std::move(name));
}

void test_register_event(Model& model, const std::function<Event<int>()>& comp_fn, std::string&& name, std::string&& descr) {
  return model.register_event<int>(comp_fn, std::move(name), std::move(descr));
}

int main() {}

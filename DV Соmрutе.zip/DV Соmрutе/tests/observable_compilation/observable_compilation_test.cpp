
#include "dvcompute/dvcompute.h"

using namespace dvcompute;

Event<Unit> test_observable_add(Observable<int>&& signal) {
  return std::move(signal).add(pure_observer<int>(Unit()));
}

Observable<int> test_map_observable(Observable<int>&& signal) {
  return std::move(signal).map([](const int* x) { return 2 * (*x); });
}

Observable<int> test_mapc_observable(Observable<int>&& signal) {
  return std::move(signal).mapc([](const int* x) { return pure_event(2 * (*x)); });
}

Observable<int> test_filter_observable(Observable<int>&& signal) {
  return std::move(signal).filter([](const int* x) { return *x > 0; });
}

Observable<int> test_filterc_observable(Observable<int>&& signal) {
  return std::move(signal).filterc([](const int* x) { return pure_event(*x > 0); });
}

Observable<int> test_hold_observable(Observable<int>&& signal) {
  return std::move(signal).hold(10.0);
}

Observable<int> test_holdc_observable(Observable<int>&& signal) {
  return std::move(signal).holdc(pure_event(10.0));
}

Observable<int> test_delay_observable(Observable<int>&& signal) {
  return delay_observable([signal{std::move(signal)}]() mutable { return std::move(signal); });
}

Observable<Arrival<int>> test_arrival_observable(Observable<int>&& signal) {
  return arrival_observable<int>(std::move(signal));
}

Process<Unit> test_loop_random_observable() {
  SharedPtr<ObservableSource<Arrival<int>>> source { mk_shared(ObservableSource<Arrival<int>>()) };
  return DVCOMPUTE_NS::internal::observable::random::loop_random_observable([]() {
    return pure_parameter(std::pair(10.0, 5));
  }, std::move(source), std::make_optional(3.0));
}

Composite<Observable<Arrival<int>>> test_new_random_observable() {
  return new_random_observable<int>([]() {
    return pure_parameter(std::pair(10.0, 7));
  });
}

Composite<Observable<Arrival<double>>> test_new_random_uniform_observable() {
  return new_random_uniform_observable(1.0, 2.0);
}

Composite<Observable<Arrival<int>>> test_new_random_int_uniform_observable() {
  return new_random_int_uniform_observable(1, 2);
}

Composite<Observable<Arrival<double>>> test_new_random_triangular_observable() {
  return new_random_triangular_observable(1.0, 1.8, 2.0);
}

Composite<Observable<Arrival<double>>> test_new_random_normal_observable() {
  return new_random_normal_observable(1.0, 2.0);
}

Composite<Observable<Arrival<double>>> test_new_random_log_normal_observable() {
  return new_random_log_normal_observable(1.0, 2.0);
}

Composite<Observable<Arrival<double>>> test_new_random_exponential_observable() {
  return new_random_exponential_observable(1.0);
}

Composite<Observable<Arrival<double>>> test_new_random_erlang_observable() {
  return new_random_erlang_observable(1.0, 5);
}

Composite<Observable<Arrival<int>>> test_new_random_poisson_observable() {
  return new_random_poisson_observable(5.0);
}

Composite<Observable<Arrival<int>>> test_new_random_binomial_observable() {
  return new_random_binomial_observable(0.2, 4);
}

Composite<Observable<Arrival<double>>> test_new_random_gamma_observable() {
  return new_random_gamma_observable(0.2, 3.0);
}

Composite<Observable<Arrival<double>>> test_new_random_beta_observable() {
  return new_random_beta_observable(0.2, 3.0);
}

Composite<Observable<Arrival<double>>> test_new_random_weibull_observable() {
  return new_random_weibull_observable(0.2, 3.0);
}

Composite<Observable<Arrival<int>>> test_new_random_discrete_observable() {
  SharedPtr<std::vector<std::pair<int, double>>> dpdf { mk_shared(std::vector<std::pair<int, double>>()) };

  dpdf->emplace_back(std::pair(5, 0.1));
  dpdf->emplace_back(std::pair(8, 0.3));
  dpdf->emplace_back(std::pair(9, 0.7));

  return new_random_discrete_observable(dpdf);
}

Event<SharedPtr<ObservableSource<double>>> test_new_observable_source_in_integ_times() {
  return new_observable_source_in_integ_times();
}

Event<Observable<double>> test_new_observable_in_integ_times() {
  return new_observable_in_integ_times();
}

Event<SharedPtr<ObservableSource<double>>> test_new_observable_source_in_start_time() {
  return new_observable_source_in_start_time();
}

Event<Observable<double>> test_new_observable_in_start_time() {
  return new_observable_in_start_time();
}

Event<SharedPtr<ObservableSource<double>>> test_new_observable_source_in_stop_time() {
  return new_observable_source_in_stop_time();
}

Event<Observable<double>> test_new_observable_in_stop_time() {
  return new_observable_in_stop_time();
}

Event<PredefinedObservableSet> test_new_predefined_observable_set() {
  return new_predefined_observable_set();
}

Composite<SharedPtr<ObservableHistory<int>>> test_new_observable_history(Observable<int>&& signal) {
  return new_observable_history(std::move(signal));
}

Composite<SharedPtr<ObservableHistory<int>>> test_new_observable_history_grid(Observable<int>&& signal) {
  return new_observable_history_grid<int>(std::move(signal), 1, [](int x, int y) { return x + y; });
}

Event<Unit> test_push_to_observable_history(const SharedPtr<ObservableHistory<int>>& hist, int item) {
  return push_to_observable_history(hist, std::move(item));
}

Event<ObservableHistoryData<int>> test_read_observable_history(const SharedPtr<ObservableHistory<int>>& hist) {
  return read_observable_history(hist);
}

Event<Unit> test_reset_observable_history(const SharedPtr<ObservableHistory<int>>& hist) {
  return reset_observable_history(hist);
}

Event<ObservableHistoryData<int>> test_take_observable_history(const SharedPtr<ObservableHistory<int>>& hist) {
  return take_observable_history(hist);
}

Composite<Observable<ObservableHistoryData<int>>> test_new_io_observable_history_with_limit_size(Observable<int>&& obs) {
  return new_io_observable_history_with_limit_size(std::move(obs), 2048, std::make_optional(0));
}

int main() {}

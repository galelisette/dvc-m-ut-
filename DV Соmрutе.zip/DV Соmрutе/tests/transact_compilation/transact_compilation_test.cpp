
#include <optional>
#include <vector>
#include <tuple>

#include "dvcompute/dvcompute.h"

using namespace dvcompute;
using namespace dvcompute::block;

Simulation<Transact<int>> test_new_transact() {
  Arrival<int> arrival {
    123,
    0.345,
    std::nullopt
  };
  return new_transact(std::move(arrival), 10);
}

Event<Transact<int>> test_split_transact() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return split_transact(transact);
    });
}

Event<int> test_transact_priority() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return transact_priority(transact.transact_id);
    });
}

Process<Unit> test_assign_transact_priority() {
  return into_process(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return assign_transact_priority(transact.transact_id, 12345);
    });
}

Event<AssemblySetPtr> test_transact_assembly_set() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return transact_assembly_set(transact.transact_id);
    });
}

Event<Unit> test_begin_transact_preemption() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return begin_transact_preemption(transact.transact_id);
    });
}

Event<Unit> test_end_transact_preemption() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return end_transact_preemption(transact.transact_id);
    });
}

Process<Unit> test_take_transact() {
  return into_process(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return take_transact(transact.transact_id);
    });
}

Process<Unit> test_release_transact() {
  return into_process(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return release_transact(transact.transact_id);
    });
}

Process<Unit> test_transfer_process() {
  return into_process(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return transfer_transact(transact.transact_id, pure_process(Unit()));
    });
}

Event<Unit> test_transfer_process_within_event() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return transfer_transact_within_event(transact.transact_id, pure_process(Unit()));
    });
}

Event<Unit> test_reactivate_transact() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      Process<Unit> comp = pure_process(Unit());
      std::tuple<TransactIdPtr, std::optional<Process<Unit>>> xy(transact.transact_id, std::move(comp));

      return reactivate_transact(std::move(xy));
    });
}

Event<Unit> test_reactivate_transacts() {
  std::vector<std::tuple<TransactIdPtr, std::optional<Process<Unit>>>> xys;
  return reactivate_transacts(xys.begin(), xys.end());
}

Event<Unit> test_reactivate_transacts_by_vector() {
  std::vector<std::tuple<TransactIdPtr, std::optional<Process<Unit>>>> xys;
  return reactivate_transacts(std::move(xys));
}

Process<Unit> test_assemble_transact() {
  return into_process(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return assemble_transact(transact.transact_id, 10);
    });
}

Process<Unit> test_gather_transact() {
  return into_process(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return gather_transacts(transact.transact_id, 10);
    });
}

Event<bool> test_is_transact_assembling() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return is_transact_assembling(transact.transact_id);
    });
}

Event<bool> test_is_transact_gathering() {
  return into_event(test_new_transact())
    .and_then([](Transact<int>&& transact) {
      return is_transact_gathering(transact.transact_id);
    });
}

int main() {}

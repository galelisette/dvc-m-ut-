
#include "dvcompute/dvcompute.h"

using namespace dvcompute_branch;

QueueStorage<double, int>* test_priorityfcfs_strategy() {
  PriorityFCFSStrategy strategy;
  return strategy.create_storage<double>();
};

QueueStorage<double, int>* test_prioritylcfs_strategy() {
  PriorityLCFSStrategy strategy;
  return strategy.create_storage<double>();
};

int main() {}

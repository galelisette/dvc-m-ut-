The model corresponds to the following GPSS model:

MEN     STORAGE 3
NOWON   STORAGE 50

        GENERATE ,,,53
Back1   ENTER NOWON
        ADVANCE 157,25
        LEAVE NOWON
        ENTER MEN
        ADVANCE 7,3
        LEAVE MEN
        TRANSFER ,Back1

        GENERATE 6240
        TERMINATE 1

        START 1

---

SOLUTION

A process-oriented implementation of the model using GPSS-like blocks.
It uses the distributed module of the simulator.

To run, enter `mpiexec -np 2 example2e_dist`.

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/dvcompute.h"

using namespace dvcompute;

const double ack_rate = 1.0 / 1.0;    // reciprocal of the acknowledgement mean time
const double to_period = 0.5;         // timeout period

inline auto timeout(const RefPtr<int>& n_msgs, 
  const RefPtr<int>& n_timeouts,
  const ProcessIdPtr& node_pid) 
{
  return hold_process(to_period)
    .and_then([=](Unit&& unit) {
      return into_process(interrupt_process(node_pid));        
    });
}

static Process<Unit> node(const RefPtr<int>& n_msgs, 
  const RefPtr<int>& n_timeouts,
  const ProcessIdPtr& node_pid) 
{
  return into_process(modify_ref(n_msgs, [](int n) { return 1 + n; }))
    .and_then([=](Unit&& unit) {
      return into_process(new_process_id())
        .and_then([=](const ProcessIdPtr& timeout_pid) {
          return into_process(run_process_using_id(timeout_pid, timeout(n_msgs, n_timeouts, node_pid)))
            .and_then([](Unit&& unit) {
              return random_exponential_process_(1 / ack_rate);
            })
            .and_then([=](Unit&& unit) {
              return into_process(is_process_interrupted(node_pid)
                .and_then([=](bool interrupted) {
                  if (interrupted) {
                    return modify_ref(n_timeouts, [](int n) { return 1 + n; })
                      .into_boxed();
                  } else {
                    return cancel_process_by_id(timeout_pid)
                      .into_boxed();
                  }
                }));
            })
            .and_then([=](Unit&& unit) {
              return node(n_msgs, n_timeouts, node_pid);
            });
        });
    });
}

static void simulate() {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  Specs specs { 0, 10000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };

  RefPtr<int> n_msgs { mk_shared(Ref(0)) };
  RefPtr<int> n_timeouts { mk_shared(Ref(0)) };

  auto model = new_process_id()
    .and_then([=](const ProcessIdPtr& node_pid) {
      return run_process_using_id(node_pid, node(n_msgs, n_timeouts, node_pid))
        .run_in_start_time();
    })
    .and_then([=](Unit&& unit) {
      return read_ref(n_timeouts)
        .and_then([=](double x) {
          return read_ref(n_msgs)
            .map([=](double y) {
              return x / y;
            });
        })
        .run_in_stop_time();
    });

  auto result = std::move(model).run(&specs);
  auto x = expect_result(result);
  
  std::cout << "Stop time: " << specs.stop_time << std::endl;
  std::cout << "The result is " << x << std::endl;
}
  
int main(int argc, char * argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  simulate();
  free_thread_local_objects();

  return 0;
}

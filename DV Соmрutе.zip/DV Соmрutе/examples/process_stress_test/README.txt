This is a stress test for processes to find weak places.

It could not be located in the tests directory, for 
the tests are not optimised by CMake. So, I decided to 
put it in this directory.
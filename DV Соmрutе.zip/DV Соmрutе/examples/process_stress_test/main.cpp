/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>

#if DVCOMPUTE_DISTRIBUTED
#include <mpi.h>
#endif /* DVCOMPUTE_DISTRIBUTED */

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/dvcompute.h"

using namespace DVCOMPUTE_NS;
using namespace DVCOMPUTE_NS::block;

const int process_limit = 1000000;

static Event<Unit> process_test(const RefPtr<int>& process_count, 
                                const SharedPtr<ObservableSource<Arrival<int>>>& source,
                                int count) {
  Arrival<int> arrival(Arrival<int>{
    10,
    0.0,
    std::nullopt
  });
  return run_process(into_process(cons_event([=](const Point* p) {
    int n = process_count->read_at(p);
    process_count->write_at(1 + n, p);
    return Result<Unit>(Unit());
  })))
  .and_then([=](Unit&& unit) {
    return into_event(new_transact(arrival, 10))
      .map([](Transact<int>&& transact) {
        return std::move(transact);
      });
  })
  .and_then([=](Transact<int>&& transact) {
    return run_process(take_transact(transact));
  })
  .and_then([=](Unit&& unit) {
    return source->trigger(Arrival<int>(arrival));
  })
  .and_then([=](Unit&& unit) {
    if (count < process_limit) {
      return event_time()
        .and_then([=](double t) {
          return enqueue_event(t, process_test(process_count, source, 1 + count));
        })
        .into_boxed();
    } else {
      return pure_event(Unit())
        .into_boxed();
    }
  });
}

static Block<Transact<int>, Unit> block_chain(const RefPtr<int>& process_count, 
  const QueuePtr& queue,
  const FacilityPtr<int>& facility) 
{
  return queue_block<int>(queue)
    .and_then(preempt_block(facility, PreemptBlockMode<int> {
      true, std::nullopt, false
    }))
    .and_then(depart_block<int>(queue))
    .and_then(return_block(facility))
    .and_then(terminate_block<Transact<int>>());
}

#ifdef DVCOMPUTE_SEQUENTIAL
static void simulate() {
#elif DVCOMPUTE_DISTRIBUTED
static void simulate(LogicalProcessContext *ctx) {
#else
#error "Unknown simulation mode"
#endif

  Specs specs { 0, process_limit, 0.1, GeneratorSpec() };

  RefPtr<int> process_count { mk_shared(Ref(0)) };
  SharedPtr<ObservableSource<Arrival<int>>> source { mk_shared(ObservableSource<Arrival<int>>()) };

  auto model = process_test(process_count, source, 0)
    .run_in_start_time()
    .and_then([=](Unit&& unit) {
      return new_queue()
        .run_in_start_time()
        .and_then([=](QueuePtr&& queue) {
          return new_facility<int>()
            .run_in_start_time()
            .and_then([=](FacilityPtr<int>&& facility) {
              return new_random_int_uniform_observable(0, 2)
                .run_()
                .run_in_start_time()
                .and_then([=](Observable<Arrival<int>>&& obs) {
                  return run_process(observable_generator_block0<int>(std::move(obs))
                      .run([=]() { return block_chain(process_count, queue, facility); }))
                    .run_in_start_time()
                    .and_then([=](Unit&& unit) {
                      return read_ref(process_count)
                        .run_in_stop_time();
                    });
                });

              /*
              return run_process(observable_generator_block<int>(source->publish(), 1)
                  .run([=]() { return block_chain(process_count, queue, facility); }))
                .run_in_start_time()
                .and_then([=](Unit&& unit) {
                  return read_ref(process_count)
                    .run_in_stop_time();
                });
               */
            });
        });
    });

#ifdef DVCOMPUTE_SEQUENTIAL
  auto result = std::move(model).run(&specs);
#elif DVCOMPUTE_DISTRIBUTED
  auto result = std::move(model).run(&specs, ctx);
#else
#error "Unknown simulation mode"
#endif

  auto x = expect_result(result);

  std::cout << "Stop time: " << specs.stop_time << std::endl;
  std::cout << "The process count is " << x << std::endl;
}
  
#ifdef DVCOMPUTE_SEQUENTIAL
int main(int argc, char * argv[]) {

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  simulate();

  return 0;
}
#elif DVCOMPUTE_DISTRIBUTED

struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 2) {
    std::cerr << "Expected two MPI processes" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);
    
  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }

  free_thread_local_objects();
  
  return 0;
}
#else
#error "Unknown simulation mode"
#endif

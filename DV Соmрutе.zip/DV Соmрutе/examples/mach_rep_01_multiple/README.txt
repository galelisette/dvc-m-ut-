The example is based on model mach_rep_01 described in document
Introduction to Discrete-Event Simulation and the SimPy Language
[http://heather.cs.ucdavis.edu/~matloff/156/PLN/DESimIntro.pdf].
SimPy is available on [http://simpy.sourceforge.net/].

The source model description is as follows.

Two machines, which sometimes break down. Up time is exponentially 
distributed with mean 1.0, and repair time is exponentially 
distributed with mean 0.5. There are two repairpersons, so 
the two machines can be repaired simultaneously if they are 
down at the same time.

Output is long-run proportion of up time. Should get value of about
0.66.

---

SOLUTION

A process-oriented implementation of the model for sequential simulation.
Only we consider thousands of processes instead of two lonely processes as
it was in the source model. The purpose is to see whether the event queue is
scalable and how is it scalable.

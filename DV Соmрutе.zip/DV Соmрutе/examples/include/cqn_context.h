/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef cqn_model_context_h
#define cqn_model_context_h

#include <cstddef>
#include <cmath>
#include <vector>

#include "dvcompute/dvcompute.h"
#include "cqn_config.h"

namespace {

  using namespace DVCOMPUTE_NS;

  inline uint64_t seed(int rank) {
    return 517 * rank;
  }

  inline uint64_t gen_bits(int bits, const RefPtr<uint64_t>& gen, const Point* p) {
    uint64_t x = gen->read_at(p);
    uint64_t y = (x * 0x5deece66dULL + 0xbULL) & ((1ULL << 48) - 1ULL);
    uint64_t z = y;
    gen->write_at(std::move(z), p);
    return y >> (48 - bits);
  }

  inline double gen_uniform01_at(const RefPtr<uint64_t>& gen, const Point* p) {
    uint64_t m1 = gen_bits(26, gen, p);
    uint64_t m2 = gen_bits(27, gen, p);
    double x = static_cast<double>((m1 << 27) + m2);
    double y = 1ULL << 53;
    return x / y;
  }

  inline double gen_exp_at(const RefPtr<uint64_t>& gen, double mu, const Point* p) {
    return - log(gen_uniform01_at(gen, p)) * mu;
  }

  inline int gen_int_uniform_at(const RefPtr<uint64_t>& gen, int min, int max, const Point* p) {
    double x = gen_uniform01_at(gen, p);
    double min2 = min - 0.5;
    double max2 = max + 0.5;
    int z = static_cast<int>(std::round(min2 + x * (max2 - min2)));
    if (z < min) {
      return min;
    } else if (z > max) {
      return max;
    } else {
      return z;
    }
  }

  inline auto gen_exp(const RefPtr<uint64_t>& gen, double mu) {
    return cons_event([=](const Point *p) {
      return Result<double>(gen_exp_at(gen, mu, p));
    });
  }

  inline auto gen_int_uniform(const RefPtr<uint64_t>& gen, int min, int max) {
    return cons_event([=](const Point *p) {
      return Result<int>(gen_int_uniform_at(gen, min, max, p));
    });
  }
}

/** The context of the CQN simulation model. */
class ModelContext {
public:

  /** The model configuration. */
  ModelConfig config;

  /** The simulation model. */
  DVCOMPUTE_NS::Model model;

  explicit ModelContext() {
    using namespace DVCOMPUTE_NS;
    int n = static_cast<int>(config.tandem_queue_count);
    for (int i = 0; i < n; ++ i) {
      gens.emplace_back(mk_shared(Ref<uint64_t>(seed(i))));
    }
  }

  explicit ModelContext(ModelConfig&& config) : config(std::move(config)) {
    using namespace DVCOMPUTE_NS;
    int n = static_cast<int>(config.tandem_queue_count);
    for (int i = 0; i < n; ++ i) {
      gens.emplace_back(mk_shared(Ref<uint64_t>(seed(i))));
    }
  }

  explicit ModelContext(const ModelConfig& config) : config(config) {
    using namespace DVCOMPUTE_NS;
    int n = static_cast<int>(config.tandem_queue_count);
    for (int i = 0; i < n; ++ i) {
      gens.emplace_back(mk_shared(Ref<uint64_t>(seed(i))));
    }
  }

  /** An exponential pseudo-random number within `Event<double>`. */
  inline auto pseudo_random_exponential(double mu, std::size_t tandem_index) {
    using namespace DVCOMPUTE_NS;

    if (config.reproducible) {
      return gen_exp(gens[tandem_index], mu)
        .into_boxed();
    } else {
      return into_event(random_exponential_parameter(mu))
        .into_boxed();
    }
  }

  /** An integer uniform pseudo-random number within `Event<int>`. */
  inline auto pseudo_random_int_uniform(int min, int max, std::size_t tandem_index) {
    using namespace DVCOMPUTE_NS;

    if (config.reproducible) {
      return gen_int_uniform(gens[tandem_index], min, max)
        .into_boxed();
    } else {
      return into_event(random_int_uniform_parameter(min, max))
        .into_boxed();
    }
  }

  /** An exponential delay within `Process<Unit>`. */
  inline auto pseudo_random_exponential_process_(double mu, std::size_t tandem_index) {
    using namespace DVCOMPUTE_NS;

    return into_process(pseudo_random_exponential(mu, tandem_index))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

private:

  /** The pseudo-random number generator seeds. */
  std::vector<DVCOMPUTE_NS::RefPtr<uint64_t>> gens;
};

#endif /* cqn_model_context_h */

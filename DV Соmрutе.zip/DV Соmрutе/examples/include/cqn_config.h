/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef cqn_model_config_h
#define cqn_model_config_h

#include <cstddef>
#include <cctype>
#include <optional>
#include <sstream>
#include <istream>
#include <fstream>
#include <string>

#include "dvcompute/dvcompute.h"

using namespace DVCOMPUTE_NS;

/** The error that occurred when parsing or writing the model configuration settings. */
class ModelConfigError : public std::logic_error {
public:
  explicit ModelConfigError(const char* what_arg) : std::logic_error(what_arg) {}
  explicit ModelConfigError(const std::string& what_arg) : std::logic_error(what_arg) {}
};

/** The CQN model configuration parameters. */
struct ModelConfig {

  /** Whether the simulation results must be reproducible? */
  bool reproducible { true };

  /** The run count (applicable for the simulation experiment only). */
  int run_count { 1 };

  /** The start time. */
  double start_time { 0.0 };

  /** The stop time. */
  double stop_time { 1000.0 };

  /** The tandem queue count. */
  std::size_t tandem_queue_count { 4 };

  /** The initial job count per queue. */
  std::size_t initial_job_count { 100 };

  /** The single server count. */
  std::size_t single_server_count { 10 };

  /** The queue delay. */
  double queue_delay { 1.0 };

  /** The lookahead parameter. */
  double lookahead { 100.0 };

  /** The exponentially distributed service time for each single server. */
  double service_time { 10.0 };

  /** The optional time horizon (applicable for the optimistic method only). */
  std::optional<double> time_horizon { std::nullopt };

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

  /** The thread mode used for running the logical processes. */
  LogicalProcessThread thread_mode { LogicalProcessThread::SingleThread };

#endif

  /** Whether the simulation model can generate output. */
  bool silent { false };

  friend std::istream& operator>>(std::istream& stream, ModelConfig& config);
  
  friend std::ostream& operator<<(std::ostream& stream, const ModelConfig& config);

  /** Load the model configuration settings. */
  void load(const std::string& filename) {
    std::ifstream file(filename);
    if (file.is_open()) {
      file >> *this;
    	
    } else {
      std::string msg = "Could not open input file: ";
      msg += filename;
      throw ModelConfigError(msg); 
    }
  }

  /** Save the model configuration settings. */
  void save(const std::string& filename) const {
    std::ofstream file(filename);
    if (file.is_open()) {
      file << *this;
    	
    } else {
      std::string msg = "Could not open output file: ";
      msg += filename;
      throw ModelConfigError(msg); 
    }
  }

  /** Initialize the model configuration settings. */
  void init(int argc, char* argv[]) {
    bool loaded = false;
    for (int i = 0; i < argc; ++i) {
      std::string arg(argv[i]);
      if ((arg.size() > 0) && (isalpha(arg[0]) || arg[0] == '/' || arg[0] == '\\' || arg[0] == '"')) {
        if ((arg.size() >= 5 && arg.substr(arg.size() - 5) == ".conf") ||
            (arg[0] == '"' && arg.size() >= 6 && arg.substr(arg.size() - 6) == ".conf\"")) {
          if (!loaded) {
            load(arg);
            loaded = true;
          } else {
            std::string msg = "Already loaded the configuration settings";
            throw ModelConfigError(msg);
          }
        }
      }
    }
  }
};

/** Parse the input stream that defines configuration settings. */
std::istream& operator>>(std::istream& stream, ModelConfig& config) {
  int i = 0;
  std::string line;
  while (std::getline(stream, line)) {
    ++i;
    std::istringstream line_stream(line);
    std::string key;
    line_stream >> key;

    if ((key.size() >= 1 && key[0] == '#') || (key == "")) {
      continue;

    } else {
      char ch;
      line_stream >> ch;

      if (ch != '=') {
        std::string msg = "Expected the '=' character";
        msg += " (at line " + std::to_string(i) + ")";
        throw ModelConfigError(msg);
      }

      if (key == "reproducible") {
        bool value;
        line_stream >> value;

        config.reproducible = value;

      } else if (key == "run_count") {
        int value;
        line_stream >> value;

        config.run_count = value;

      } else if (key == "start_time") {
        double value;
        line_stream >> value;

        config.start_time = value;

      } else if (key == "stop_time") {
        double value;
        line_stream >> value;

        config.stop_time = value;

      } else if (key == "tandem_queue_count") {
        std::size_t value;
        line_stream >> value;

        config.tandem_queue_count = value;

      } else if (key == "initial_job_count") {
        std::size_t value;
        line_stream >> value;

        config.initial_job_count = value;

      } else if (key == "single_server_count") {
        std::size_t value;
        line_stream >> value;

        config.single_server_count = value;

      } else if (key == "queue_delay") {
        double value;
        line_stream >> value;

        config.queue_delay = value;

      } else if (key == "lookahead") {
        double value;
        line_stream >> value;

        config.lookahead = value;

      } else if (key == "service_time") {
        double value;
        line_stream >> value;

        config.service_time = value;

      } else if (key == "time_horizon") {
        double value;
        line_stream >> value;

        config.time_horizon = value;

      } else if (key == "thread_mode") {
        int value;
        line_stream >> value;

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)
        if (value == 1) {
          config.thread_mode = LogicalProcessThread::SingleThread;

        } else if (value == 2) {
          config.thread_mode = LogicalProcessThread::FunneledThread;

        } else if (value == 3) {
          config.thread_mode = LogicalProcessThread::MultipleThread;

        } else {
          std::string msg = "Expected either 1, or 2, or 3 as the property value";
          msg += " (at line " + std::to_string(i) + ")";
          throw ModelConfigError(msg);
        }
#endif

      } else if (key == "silent") {
        bool value;
        line_stream >> value;

        config.silent = value;

      } else {
        std::string msg = "Unrecognized property: ";
        msg += key;
        msg += " (at line " + std::to_string(i) + ")";
        msg += ". Use spaces to separate parts if required!";
        throw ModelConfigError(msg);
      }

      if (line_stream) {
        std::string line;
        line_stream >> line;
        
        if ((line.size() >= 1 && line[0] == '#') || (line == "")) {
          continue;

        } else {
          std::string msg = "Expected the comment that must start with the '#' character";
          msg += " (at line " + std::to_string(i) + ")";
          throw ModelConfigError(msg);
        }
      }
    }
  }
  
  return stream;
}

/** Write the model configuration settings. */
std::ostream& operator<<(std::ostream& stream, const ModelConfig& config) {

  stream << "# Whether the simulation results must be reproducible?" << std::endl;
  stream << "reproducible = " << config.reproducible << std::endl;
  stream << std::endl;

  stream << "# The run count (applicable for the simulation experiment only)" << std::endl;
  stream << "run_count = " << config.run_count << std::endl;
  stream << std::endl;

  stream << "# The start time." << std::endl;
  stream << "start_time = " << config.start_time << std::endl;
  stream << std::endl;

  stream << "# The stop time." << std::endl;
  stream << "stop_time = " << config.stop_time << std::endl;
  stream << std::endl;

  stream << "# The tandem queue count." << std::endl;
  stream << "tandem_queue_count = " << config.tandem_queue_count << std::endl;
  stream << std::endl;

  stream << "# The initial job count per queue." << std::endl;
  stream << "initial_job_count = " << config.initial_job_count << std::endl;
  stream << std::endl;

  stream << "# The single server count." << std::endl;
  stream << "single_server_count = " << config.single_server_count << std::endl;
  stream << std::endl;

  stream << "# The queue delay." << std::endl;
  stream << "queue_delay = " << config.queue_delay << std::endl;
  stream << std::endl;

  stream << "# The lookahead parameter." << std::endl;
  stream << "lookahead = " << config.lookahead << std::endl;
  stream << std::endl;

  stream << "# The exponentially distributed service time for each single server." << std::endl;
  stream << "service_time = " << config.service_time << std::endl;
  stream << std::endl;

  if (config.time_horizon.has_value()) {
    stream << "# The optional time horizon (applicable for the optimistic method only)." << std::endl;
    stream << "time_horizon = " << config.time_horizon.value() << std::endl;
    stream << std::endl;
  }

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

  stream << "# The thread mode used for running the logical processes." << std::endl;
  stream << "# (1 - one thread per logical process, 2 - two threads)" << std::endl;
  stream << "thread_mode = ";
  
  if (config.thread_mode == LogicalProcessThread::SingleThread) {
    stream << 1;
  	
  } else if (config.thread_mode == LogicalProcessThread::FunneledThread) {
    stream << 2;
  	
  } else if (config.thread_mode == LogicalProcessThread::MultipleThread) {
    stream << 3;
  	
  } else {
    std::string msg = "Cannot represent the thread_mode parameter as it has unknown value";
    throw ModelConfigError(msg);
  }
  
  stream << std::endl;
  stream << std::endl;

#endif

  stream << "# Whether the simulation model can generate output" << std::endl;
  stream << "silent = " << config.silent << std::endl;
  stream << std::endl;

  return stream;
}

#endif /* cqn_model_config_h */

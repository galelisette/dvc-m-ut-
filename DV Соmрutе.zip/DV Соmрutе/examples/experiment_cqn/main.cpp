/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>
#include <vector>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/dvcompute.h"
#include "../include/cqn_config.h"
#include "../include/cqn_context.h"

using namespace DVCOMPUTE_NS;
using namespace DVCOMPUTE_NS::block;
using namespace DVCOMPUTE_NS::experiments;
using namespace DVCOMPUTE_NS::experiments::rendering;
using namespace DVCOMPUTE_NS::results;

/** Represents a queue tandem. */
template<typename Item>
  using QueueTandem = std::vector<FacilityPtr<Item>>;

/** Represents a vector of queue tandems in case of sequential simulation. */
template<typename Item>
  using QueueTandemArray = std::vector<SharedPtr<QueueTandem<Item>>>;

/** Rerpesents the tandem counter. */
using TandemCounter = Ref<int>;

/** Represents the tandem counters. */
using TandemCounterArray = std::vector<SharedPtr<TandemCounter>>;

/** The transact value. */
using Data = int;

/** Select the next tandem within `Event<std::size_t>`. */
auto select_tandem(const SharedPtr<ModelContext>& ctx, std::size_t tandem_index) {
  int n = static_cast<int>(ctx->config.tandem_queue_count);
  return ctx->pseudo_random_int_uniform(0, n - 1, tandem_index);
}

/** The increasing counter block. */
Block<Transact<Data>, Transact<Data>> increase_counter_block(const SharedPtr<TandemCounter>& transact_counter) {
  return cons_block([=](Transact<Data>&& transact) {
    return into_process(modify_ref(transact_counter, [](int count) {
      return 1 + count;
    }))
    .and_then([transact{std::move(transact)}](Unit&&) mutable {
      return pure_process(std::move(transact));
    });
  });
} 

/** The decreasing counter block. */
Block<Transact<Data>, Transact<Data>> decrease_counter_block(const SharedPtr<TandemCounter>& transact_counter) {
  return cons_block([=](Transact<Data>&& transact) {
    return into_process(modify_ref(transact_counter, [](int count) {
      return count - 1;
    }))
    .and_then([transact{std::move(transact)}](Unit&&) mutable {
      return pure_process(std::move(transact));
    });
  });
} 

/** The single queue block. */
Block<Transact<Data>, Transact<Data>> single_queue_block(const SharedPtr<ModelContext>& ctx,
  const FacilityPtr<Data>& queue,
  std::size_t tandem_index) 
{
  return seize_block(queue)
    .and_then(finally_block(advance_block<Transact<Data>>(ctx->pseudo_random_exponential_process_(ctx->config.service_time, tandem_index))
        .and_then(advance_block<Transact<Data>>(hold_process(ctx->config.queue_delay))), 
      release_block(queue)));
} 

/** The queue tandem block. */
Block<Transact<Data>, Transact<Data>> queue_tandem_block(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandem<Data>>& tandem,
  const SharedPtr<TandemCounter>& transact_counter, 
  std::size_t tandem_index) 
{
  std::vector<Block<Transact<Data>, Transact<Data>>> comps;

  comps.emplace_back(increase_counter_block(transact_counter));
  
  for (std::size_t i = 0; i < ctx->config.single_server_count; ++i) {
    comps.emplace_back(single_queue_block(ctx, (*tandem)[i], tandem_index));
  }

  return finally_block(concat_blocks(std::move(comps)), 
    decrease_counter_block(transact_counter));
} 

/** The queue tandem block chain by the specified number. */
Block<Transact<Data>, Unit> queue_tandem_block_chain(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandemArray<Data>>& tandem_array,
  const SharedPtr<TandemCounterArray>& transact_counters,
  std::size_t tandem_index)
{
  return queue_tandem_block(ctx, (*tandem_array)[tandem_index], (*transact_counters)[tandem_index], tandem_index)
    .and_then(cons_block([=](Transact<Data>&& transact) {
      return into_process(select_tandem(ctx, tandem_index))
        .and_then([ctx, tandem_array, transact_counters, transact{std::move(transact)}](std::size_t next_index) mutable {
          return hold_process(ctx->config.lookahead)
            .and_then([ctx, tandem_array, transact_counters, transact{std::move(transact)}, next_index](Unit&& unit) mutable {
                return queue_tandem_block_chain(ctx, tandem_array, transact_counters, next_index)
                  .run(std::move(transact));
            });
        });
    }));
}

/** Create a queue tandem by the specified index. */
SharedPtr<QueueTandem<Data>> new_queue_tandem(const SharedPtr<ModelContext>& ctx, std::size_t tandem_index) {
  QueueTandem<Data> queues;
  
  for (std::size_t i = 0; i < ctx->config.single_server_count; ++i) {
    queues.emplace_back(ctx->model.new_facility<Data>());
  }

  return mk_shared<QueueTandem<Data>>(QueueTandem<Data>(std::move(queues)));
}

/** Create queue tandems. */
SharedPtr<QueueTandemArray<Data>> new_queue_tandems(const SharedPtr<ModelContext>& ctx) {
  QueueTandemArray<Data> tandems;

  for (std::size_t i = 0; i < ctx->config.tandem_queue_count; ++i) {
    tandems.emplace_back(new_queue_tandem(ctx, i));
  }

  return mk_shared<QueueTandemArray<Data>>(QueueTandemArray<Data>(std::move(tandems)));
}

/** Create a tandem counter by the specified index. */
SharedPtr<TandemCounter> new_tandem_counter(const SharedPtr<ModelContext>& ctx, std::size_t tandem_index) {
  return ctx->model.new_ref<int>(int { 0 }, "transact_count." + std::to_string(1 + tandem_index));
}

/** Create tandem counters. */
SharedPtr<TandemCounterArray> new_tandem_counters(const SharedPtr<ModelContext>& ctx) {
  TandemCounterArray tandem_counters;

  for (std::size_t i = 0; i < ctx->config.tandem_queue_count; ++i) {
    tandem_counters.emplace_back(new_tandem_counter(ctx, i));
  }

  return mk_shared<TandemCounterArray>(TandemCounterArray(std::move(tandem_counters)));
}

/** Initialize the queue tandem. */
void init_queue_tandem(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandemArray<Data>>& tandems,
  const SharedPtr<TandemCounterArray>& tandem_counters,
  std::size_t tandem_index)
{
  int init_count = static_cast<int>(ctx->config.initial_job_count);

  auto data_stream {
    random_int_uniform_stream(0, 0).take(init_count)
  };

  auto tandem_start {
    run_process(stream_generator_block<Data>(std::move(data_stream))
        .run([=]() { 
          return queue_tandem_block_chain(ctx, tandems, tandem_counters, tandem_index); 
        }))
      .run_in_start_time()
  };

  ctx->model.emplace_action(std::move(tandem_start));
}

/** Initialize the queue tandems. */
void init_queue_tandems(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandemArray<Data>>& tandems,
  const SharedPtr<TandemCounterArray>& tandem_counters)
{
  for (std::size_t i = 0; i < ctx->config.tandem_queue_count; ++i) {
    init_queue_tandem(ctx, tandems, tandem_counters, i);
  }
}

/** The queue tandem output within `Event<unsigned int>`. */
auto queue_tandem_output(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandemArray<Data>>& tandems,
  std::size_t tandem_index)
{
  return facility_holding_time((*(*tandems)[tandem_index])[ctx->config.single_server_count - 1])
    .map([](SamplingStats<double>&& stats) {
      return stats.count;
    });
}

/** The total queue tandem output within `Event<std::vector<unsigned int>>`. */
auto total_queue_tandem_output(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandemArray<Data>>& tandems)
{
  std::vector<Event<unsigned int>> comps;

  for (std::size_t i = 0; i < ctx->config.tandem_queue_count; ++ i) {
    comps.emplace_back(queue_tandem_output(ctx, tandems, i).into_boxed());
  }

  return event_sequence(std::move(comps));
}

static void print_results(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandemArray<Data>>& tandems) 
{
  for (std::size_t i = 0; i < ctx->config.tandem_queue_count; ++i) {
    std::function<Event<unsigned int>()> comp_fn = [ctx, tandems, i]() {
      return queue_tandem_output(ctx, tandems, i).into_boxed();
    };

    ctx->model.register_event(comp_fn, "deque_count." + std::to_string(1 + i));
  }
}

static Simulation<ResultSet> simulate(const ModelConfig &config) {
  SharedPtr<ModelContext> ctx { mk_shared(ModelContext(config)) };

  auto tandems { new_queue_tandems(ctx) };
  auto tandem_counters { new_tandem_counters(ctx) };
  init_queue_tandems(ctx, tandems, tandem_counters);
  print_results(ctx, tandems);

  auto comp {
    std::move(ctx->model)
      .init_in_start_time()
      .into_boxed()
  };

  return comp;
}

int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  // initialize the model configuration settings
  ModelConfig config;
  config.init(argc, argv);
  
  Specs specs {
    config.start_time,
    config.stop_time,
    0.1,
    GeneratorSpec()
  };

  WebPageRendering rendering("experiment");
  std::vector<std::shared_ptr<ExperimentGenerator<WebPageRendering>>> generators;

  // std::shared_ptr<LastValues> view1 { new LastValues() };
  // generators.push_back(view1);

  std::shared_ptr<DeviationChart> view2 { new DeviationChart() };
  generators.push_back(view2);
  view2->series = []() { return results_starting_with_name("deque_count."); };
  view2->y_non_negative = true;

  std::shared_ptr<DeviationChart> view3 { new DeviationChart() };
  generators.push_back(view3);
  view3->series = []() { return results_starting_with_name("transact_count."); };

  std::function<Simulation<results::ResultSet>()> simulation = [=]() { return simulate(config); };
  ThreadPoolExecutor executor;
  Experiment experiment;

  experiment.run_count = config.run_count;
  experiment.specs = specs;
  experiment.run(std::move(generators), std::move(rendering), std::move(simulation), std::move(executor));

  return 0;
}

This is a sequential version of the Closed Queue Network (CQN) model.
The version uses the sequential module of DVCompute++ Simulator.

Edit the `../include/cqn_config.h` file to change the settings.

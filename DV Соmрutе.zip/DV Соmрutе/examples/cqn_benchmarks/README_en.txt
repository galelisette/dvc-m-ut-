These are benchmarks for different implementations of the Closed Queue Network (CQN) model.

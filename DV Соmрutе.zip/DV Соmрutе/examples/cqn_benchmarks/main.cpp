/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <stdlib.h>
#include <iostream>
#include <string>

#include <benchmark/benchmark.h>

#include "../include/cqn_config.h"

const char MODEL_CONFIG_NAME[] = "cqn_benchmarks.conf";

static void run_command(const std::string &binary) {
  std::string cmd;
#ifndef _WIN32
  cmd += "./";
#endif
  cmd += binary;
  cmd += " ";
  cmd += MODEL_CONFIG_NAME;
  
  int status = system(cmd.c_str());
  static_cast<void>(status);
}

static void run_mpiexec_command(const std::string &binary, std::size_t n) {
  std::string cmd;

  cmd += "mpiexec -np ";
  cmd += std::to_string(n);
  cmd += " ";
  
#ifndef _WIN32
  cmd += "./";
#endif
  cmd += binary;
  cmd += " ";
  cmd += MODEL_CONFIG_NAME;
  
  int status = system(cmd.c_str());
  static_cast<void>(status);
}

static void init_config(ModelConfig &config) {
  config.stop_time = 1000000;
  config.single_server_count = 50;
  config.silent = true;
}

class cqn_seqL1_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 1;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_seqL10_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);

    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 10;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_seqL100_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);

    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 100;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_distT1L1_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 1;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_distT1L10_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 10;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_distT1L100_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 100;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_distT2L1_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 1;
    config.thread_mode = LogicalProcessThread::FunneledThread;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_distT2L10_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 10;
    config.thread_mode = LogicalProcessThread::FunneledThread;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_distT2L100_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 100;
    config.thread_mode = LogicalProcessThread::FunneledThread;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_consT1L1_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 1;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_consT1L10_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 10;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_consT1L100_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 100;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_consT2L1_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 1;
    config.thread_mode = LogicalProcessThread::FunneledThread;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_consT2L10_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 10;
    config.thread_mode = LogicalProcessThread::FunneledThread;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

class cqn_consT2L100_fixture : public benchmark::Fixture {
public:
  void SetUp(const benchmark::State& state) {
    std::size_t n = state.range(0);
    
    ModelConfig config;
    init_config(config);

    config.tandem_queue_count = n;
    config.lookahead = 100;
    config.thread_mode = LogicalProcessThread::FunneledThread;
    config.save(MODEL_CONFIG_NAME);
  }

  void TearDown(const benchmark::State& state) {
  }
};

BENCHMARK_DEFINE_F(cqn_seqL1_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
    run_command("cqn");
  }
}

BENCHMARK_DEFINE_F(cqn_seqL10_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
    run_command("cqn");
  }
}

BENCHMARK_DEFINE_F(cqn_seqL100_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
    run_command("cqn");
  }
}

BENCHMARK_DEFINE_F(cqn_distT1L1_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_dist", 1 + st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_distT1L10_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_dist", 1 + st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_distT1L100_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_dist", 1 + st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_distT2L1_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_dist", 1 + st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_distT2L10_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_dist", 1 + st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_distT2L100_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_dist", 1 + st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_consT1L1_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_cons", st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_consT1L10_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_cons", st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_consT1L100_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_cons", st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_consT2L1_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_cons", st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_consT2L10_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_cons", st.range(0));
  }
}

BENCHMARK_DEFINE_F(cqn_consT2L100_fixture, simulate)(benchmark::State& st) {
  st.SetComplexityN(st.range(0));
  for (auto _ : st) {
     run_mpiexec_command("cqn_cons", st.range(0));
  }
}

//
// The plan of benchmarks for 16-core computer
//

BENCHMARK_REGISTER_F(cqn_seqL1_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_seqL10_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_seqL100_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_distT1L1_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_distT1L10_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_distT1L100_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_distT2L1_fixture, simulate)->DenseRange(1, 8)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_distT2L10_fixture, simulate)->DenseRange(1, 8)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_distT2L100_fixture, simulate)->DenseRange(1, 8)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_consT1L1_fixture, simulate)->DenseRange(1, 7)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_consT1L10_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_consT1L100_fixture, simulate)->DenseRange(1, 16)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_consT2L1_fixture, simulate)->DenseRange(1, 7)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_consT2L10_fixture, simulate)->DenseRange(1, 7)->Unit(benchmark::kMillisecond);

// BENCHMARK_REGISTER_F(cqn_consT2L100_fixture, simulate)->DenseRange(1, 7)->Unit(benchmark::kMillisecond);

BENCHMARK_MAIN();

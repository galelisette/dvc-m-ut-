/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>
#include <vector>
#include <cstddef>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"
#include "../include/cqn_config.h"
#include "../include/cqn_context.h"

using namespace DVCOMPUTE_NS;
using namespace DVCOMPUTE_NS::block;

/** Represents a queue tandem. */
template<typename Item>
  using QueueTandem = std::vector<FacilityPtr<Item>>;

/** The transact value. */
using Data = int;

struct DataIncome {
  int64_t value;
};

constexpr ExpectedUUID data_income_uuid { 4569578532ULL, "Expected DataIncome" };

static Serializer& operator<<(Serializer& ser, const DataIncome& x) {
  return ser << data_income_uuid << x.value;
}

static Deserializer& operator>>(Deserializer& deser, DataIncome& x) {
  return deser >> data_income_uuid >> x.value;
}

/** Select the next tandem within `Event<std::size_t>`. */
auto select_tandem(const SharedPtr<ModelContext>& ctx, std::size_t tandem_index) {
  int n = static_cast<int>(ctx->config.tandem_queue_count);
  return ctx->pseudo_random_int_uniform(0, n - 1, tandem_index);
}

/** The single queue block. */
Block<Transact<Data>, Transact<Data>> single_queue_block(const SharedPtr<ModelContext>& ctx,
  const FacilityPtr<Data>& queue,
  std::size_t tandem_index) 
{
  return seize_block(queue)
    .and_then(advance_block<Transact<Data>>(ctx->pseudo_random_exponential_process_(ctx->config.service_time, tandem_index)))
    .and_then(advance_block<Transact<Data>>(hold_process(ctx->config.queue_delay)))
    .and_then(release_block(queue));
} 

/** The queue tandem block. */
Block<Transact<Data>, Transact<Data>> queue_tandem_block(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandem<Data>>& tandem,
  std::size_t tandem_index) 
{
  std::vector<Block<Transact<Data>, Transact<Data>>> comps;
  
  for (std::size_t i = 0; i < ctx->config.single_server_count; ++i) {
    comps.emplace_back(single_queue_block(ctx, (*tandem)[i], tandem_index));
  }

  return concat_blocks(std::move(comps));
} 

/** The queue tandem block chain by the specified number. */
Block<Transact<Data>, Unit> queue_tandem_block_chain(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandem<Data>>& tandem,
  std::size_t tandem_index) 
{
  return queue_tandem_block(ctx, tandem, tandem_index)
    .and_then(cons_block([=](Transact<Data>&& transact) {
      return into_process(select_tandem(ctx, tandem_index))
        .and_then([=](std::size_t next_index) {
          if (next_index == tandem_index) {
            return hold_process(ctx->config.lookahead)
              .and_then([ctx, tandem, transact{transact}, next_index](Unit&& unit) mutable {
                  return queue_tandem_block_chain(ctx, tandem, next_index)
                    .run(std::move(transact));
              })
              .into_boxed();

          } else {
            LogicalProcessId pid = static_cast<LogicalProcessId>(next_index);
            return into_process(send_message(pid, ctx->config.lookahead, DataIncome {
              static_cast<int64_t>(transact.value)
            }))
            .into_boxed();
          }
        });
    }));
}

/** Create a queue tandem by the specified index. */
SharedPtr<QueueTandem<Data>> new_queue_tandem(const SharedPtr<ModelContext>& ctx, std::size_t tandem_index) {
  QueueTandem<Data> queues;
  
  for (std::size_t i = 0; i < ctx->config.single_server_count; ++i) {
    queues.emplace_back(ctx->model.new_facility<Data>());
  }

  return mk_shared<QueueTandem<Data>>(QueueTandem<Data>(std::move(queues)));
}

/** Initialize the queue tandem. */
void init_queue_tandem(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandem<Data>>& tandem,
  std::size_t tandem_index)
{
  int init_count = static_cast<int>(ctx->config.initial_job_count);

  auto init_data_stream {
    random_int_uniform_stream(0, 0).take(init_count)
  };

  auto incoming_data {
    arrival_observable<Data>(input_messages<DataIncome>()
      .map([](const DataIncome* x) {
        return static_cast<Data>(x->value);
      }))
  };

  auto tandem_start {
    run_process(stream_generator_block<Data>(std::move(init_data_stream))
        .run([=]() { return queue_tandem_block_chain(ctx, tandem, tandem_index); }))
      .run_in_start_time()
  };

  auto incoming_data_processing {
    run_process(observable_generator_block<Data>(std::move(incoming_data))
        .run([=]() { return queue_tandem_block_chain(ctx, tandem, tandem_index); }))
      .run_in_start_time()
  };

  ctx->model.emplace_action(std::move(tandem_start));
  ctx->model.emplace_action(std::move(incoming_data_processing));
}

/** The queue tandem output within `Event<unsigned int>`. */
auto queue_tandem_output(const SharedPtr<ModelContext>& ctx,
  const SharedPtr<QueueTandem<Data>>& tandem,
  std::size_t tandem_index)
{
  return facility_holding_time((*tandem)[ctx->config.single_server_count - 1])
    .map([](SamplingStats<double>&& stats) {
      return stats.count;
    });
}

static void simulate(const ModelConfig &config, std::size_t tandem_index, LogicalProcessContext* lp_ctx) {
  SharedPtr<ModelContext> ctx { mk_shared(ModelContext(config)) };

  Specs specs {
    ctx->config.start_time,
    ctx->config.stop_time,
    0.1,
    GeneratorSpec()
  };

  auto tandem { new_queue_tandem(ctx, tandem_index) };
  init_queue_tandem(ctx, tandem, tandem_index);

  auto comp {
    std::move(ctx->model)
      .init_in_start_time_()
      .and_then([=](Unit&& unit) {
        return queue_tandem_output(ctx, tandem, tandem_index)
          .run_in_stop_time();
      })
  };

  auto result = std::move(comp).run(&specs, lp_ctx);
  auto x = expect_result(result);

  if (!ctx->config.silent) {
    std::cout << "The result (" << tandem_index << ") is: " << x << std::endl;
  }
}
  
struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif
  
  // initialize the model configuration settings
  ModelConfig config;
  config.init(argc, argv);

  int n = static_cast<int>(config.tandem_queue_count);

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != n) {
    std::cerr << "Expected " << n << " MPI processes" << std::endl;
    return 1;
  }
  
  std::vector<LogicalProcessId> pids;
  for (int i = 0; i < comm.size; ++i) {
    pids.push_back(i);
  }

  std::size_t tandem_index = static_cast<std::size_t>(comm.pid);
  LogicalProcessParameters ps(config.lookahead);
  ps.thread_mode = config.thread_mode;
  run_logical_process(comm, pids, ps, [=](LogicalProcessContext* lp_ctx) { simulate(config, tandem_index, lp_ctx); });

  free_thread_local_objects();

  return 0;
}

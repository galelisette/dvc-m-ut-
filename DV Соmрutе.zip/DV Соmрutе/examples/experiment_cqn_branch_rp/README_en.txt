This is a sequential version of the Closed Queue Network (CQN) model.
The version uses the nested module of DVCompute++ Simulator with
support of the real priority mode.

Gnuplot must be installed. It must be accessible from the command line.

Edit the `../include/cqn_config.h` file to change the settings.

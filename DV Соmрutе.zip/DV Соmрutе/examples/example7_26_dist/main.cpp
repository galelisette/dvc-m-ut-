/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

#include <iostream>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace dvcompute_dist;
using namespace dvcompute_dist::block;
using namespace dvcompute_dist::results;

static Block<Transact<double>, Unit> phone_chain(const QueuePtr& line, const FacilityPtr<double>& prof);

static Block<Transact<double>, Unit> busy_chain();

static Block<Transact<double>, Unit> student_chain(const QueuePtr& line, const FacilityPtr<double>& prof);

static Block<Transact<double>, Unit> let_go_chain(const QueuePtr& line, const FacilityPtr<double>& prof);

static PreemptBlockTransfer<double> add_chain(const QueuePtr& line, const FacilityPtr<double>& prof);

static Block<Transact<double>, Unit> phone_chain(const QueuePtr& line, const FacilityPtr<double>& prof) {
  return cons_block([=](Transact<double>&& a) {
    return into_process(is_facility_interrupted(prof))
      .and_then([a{std::move(a)}](bool f) mutable {
        if (f) {
          return transfer_block<Transact<double>, Transact<double>>(busy_chain())
            .run(std::move(a))
            .into_boxed();
        
        } else {
          return pure_process(std::move(a))
            .into_boxed();
        }
      });
  })
  .and_then(preempt_block(prof, PreemptBlockMode<double> {
    true, std::make_optional(add_chain(line, prof)), false
  }))
  .and_then(advance_block<Transact<double>>(random_exponential_process_(200.0)))
  .and_then(return_block(prof))
  .and_then(busy_chain());
}

static Block<Transact<double>, Unit> busy_chain() {
  return terminate_block<Transact<double>>();
}

static Block<Transact<double>, Unit> student_chain(const QueuePtr& line, const FacilityPtr<double>& prof) {
  return queue_block<double>(line, 1)
    .and_then(seize_block(prof))
    .and_then(depart_block<double>(line, 1))
    .and_then(advance_block<Transact<double>>(random_exponential_process_(1000.0)))
    .and_then(let_go_chain(line, prof));
}

static Block<Transact<double>, Unit> let_go_chain(const QueuePtr& line, const FacilityPtr<double>& prof) {
  return release_block(prof)
    .and_then(terminate_block<Transact<double>>());
}

static PreemptBlockTransfer<double> add_chain(const QueuePtr& line, const FacilityPtr<double>& prof) {
  return [=](const std::optional<double>& dt0) {
    double dt = dt0.has_value() ? dt0.value() : 0.0;
    return advance_block<Transact<double>>(hold_process(dt + 300.0))
      .and_then(transfer_block<Transact<double>, Unit>(let_go_chain(line, prof)));
  };
}

static void simulate(LogicalProcessContext* ctx) {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000000, 0.1, GeneratorSpec() };

  Model model;

  auto total_up_time = model.new_ref<double>(0.0);
  auto line = model.new_queue(std::string("line"));
  auto prof = model.new_facility<double>(std::string("prof"));

  auto phone_obs {
    model.new_random_uniform_observable(2000.0 - 500.0, 2000.0 + 500.0)
  };

  auto student_obs {
    model.new_random_uniform_observable(2000.0 - 500.0, 2000.0 + 500.0)
  };

  auto phone_start {
    run_process(observable_generator_block<double>(std::move(phone_obs))
        .run([=]() { return priority_block<double>(1).and_then(phone_chain(line, prof)); }))
      .run_in_start_time()
  };

  auto student_start {
    run_process(observable_generator_block<double>(std::move(student_obs))
        .run([=]() { return student_chain(line, prof); }))
      .run_in_start_time()
  };

  model.emplace_action(std::move(phone_start));
  model.emplace_action(std::move(student_start));

  auto comp {
    std::move(model).init_in_start_time()
  };

  print_simulation_results_in_stop_time(std::move(comp), &specs, ctx, ResultLocale::en);
}
  
struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

  setlocale(LC_ALL, "Russian");

#ifdef _WIN32
  SetConsoleOutputCP(CP_UTF8);
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 2) {
    std::cerr << "Expected two MPI processes" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);
    
  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }
  
  free_thread_local_objects(); 
  
  return 0;
}
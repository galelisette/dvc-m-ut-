The model corresponds to the following GPSS model:

TATYM   TABLE M1,450,20,20

        GENERATE ,,,1
Back1   MARK
        SEIZE WORKR
        ADVANCE 8,3
        SPLIT 1,Back1
        RELEASE WORKR
        PRIORITY 1
        GATHER 24

        SEIZE WORKR
        ADVANCE 16,3
        RELEASE WORKR
        ASSEMBLE 12
        TABULATE TATYM
        TERMINATE

        GENERATE 100000
        TERMINATE 1

        START 1

---

SOLUTION

A process-oriented implementation of the model using GPSS-like blocks.

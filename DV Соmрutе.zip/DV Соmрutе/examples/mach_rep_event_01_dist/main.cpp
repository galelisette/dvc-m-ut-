/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace DVCOMPUTE_NS;

const double up_time_mean = 1.0;
const double repair_time_mean = 0.5;

static Event<Unit> machine_repaired(const RefPtr<double> total_up_time);

static Event<Unit> machine_broken(const RefPtr<double> total_up_time, double start_up_time) {
  return event_time()
    .and_then([=](double finish_up_time) {
      return modify_ref(total_up_time, [=](double total_up_time) { 
          return total_up_time + (finish_up_time - start_up_time); 
        })
        .and_then([=](Unit&& unit) {
          return into_event(random_exponential_parameter(repair_time_mean))
            .and_then([=](double repair_time) {
              double t = finish_up_time + repair_time;
              return enqueue_event(t, machine_repaired(total_up_time));
            });
        });
    });
}

static Event<Unit> machine_repaired(const RefPtr<double> total_up_time) {
  return event_time()
    .and_then([=](double start_up_time) {
      return into_event(random_exponential_parameter(up_time_mean))
        .and_then([=](double up_time) {
          double t = start_up_time + up_time;
          return enqueue_event(t, machine_broken(total_up_time, start_up_time));
        });
    });
}

static void simulate(LogicalProcessContext *ctx) {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };

  RefPtr<double> total_up_time { mk_shared(Ref(0.0)) };

  auto model = machine_repaired(total_up_time)
    .and_then([=](Unit&& unit) {
      return machine_repaired(total_up_time);
    })
    .run_in_start_time()
    .and_then([=](Unit&& unit) {
      return event_time()
        .and_then([=](double t) {
          return read_ref(total_up_time)
            .map([=](double total_up_time) {
              return total_up_time / (2.0 * t);
            });
        })
        .run_in_stop_time();
    });

  auto result = std::move(model).run(&specs, ctx);
  auto x = expect_result(result);
  
  std::cout << "Stop time: " << specs.stop_time << std::endl;
  std::cout << "The result is " << x << " (~ 0.66)" << std::endl;
}
  
struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 2) {
    std::cerr << "Expected two MPI processes" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);
    
  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }

  free_thread_local_objects();

  return 0;
}

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>
#include <vector>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace dvcompute_cons;

const double up_time_mean = 1.0;
const double repair_time_mean = 0.5;

static Process<Unit> machine_process(const RefPtr<double>& total_up_time) {
  return random_exponential_process(up_time_mean)
    .and_then([=](double up_time) {
      return into_process(modify_ref(total_up_time, [=](double total_up_time) { 
        return total_up_time + up_time; 
      }))
      .and_then([=](Unit&& unit) {
        return random_exponential_process_(repair_time_mean);
      })
      .and_then([=](Unit&& unit) {
        return machine_process(total_up_time);
      });
    });
}

static void simulate(LogicalProcessContext *ctx) {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };

  RefPtr<double> total_up_time { mk_shared(Ref(0.0)) };

  auto model = run_process(machine_process(total_up_time))
    .and_then([=](Unit&& unit) {
      return run_process(machine_process(total_up_time));
    })
    .run_in_start_time()
    .and_then([=](Unit&& unit) {
      return event_time()
        .and_then([=](double t) {
          return read_ref(total_up_time)
            .map([=](double total_up_time) {
              return total_up_time / (2.0 * t);
            });
        })
        .run_in_stop_time();
    });

  auto result = std::move(model).run(&specs, ctx);
  auto x = expect_result(result);

  std::cout << "Stop time: " << specs.stop_time << std::endl;
  std::cout << "The result is " << x << " (~ 0.66)" << std::endl;
}
  
struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 1) {
    std::cerr << "Expected one MPI process" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::vector<LogicalProcessId> pids { 0 };
    LogicalProcessParameters ps(100.0);
    run_logical_process(comm, pids, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }

  free_thread_local_objects();
  
  return 0;
}

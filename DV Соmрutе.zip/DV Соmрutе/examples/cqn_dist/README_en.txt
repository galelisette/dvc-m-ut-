This is a version of the Closed Queue Network (CQN) model based on using
the optimistic Time Warp method of distributed simulation.

The version should be scalable relative to the number of tandems.
Each tandem is simulated by separate logical process. Each logical 
process consumes either one processor core, or two cores, but it 
depends on the settings. By default, one core is used. For that 
case, the number of logical processes should not exceed the number 
of processor cores; otherwise, the simulation will degrade. 
If this rule is satisfied then, in general, you can observe 
a scalable speed up for suitable values of the lookahead parameter.

Edit the `../include/cqn_config.h` file to change the settings.

To run, enter `mpiexec -np 5 cqn_dist`, if you defined 4 (= 5-1) queue tandems. 
The general rule is as follows. If you define n tandems, then you have to start 
n+1 processes in terms of MPI, where there will be n logical processes in terms 
of DVCompute++ Simulator and 1 special process for so called time server.
At least, they will consume either n cores or 2*n cores of the processor, 
but it depends on the settings.

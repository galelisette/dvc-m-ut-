The example corresponds to model timeout_example described in document
Advanced Features of the SimPy Language
[http://heather.cs.ucdavis.edu/~matloff/156/PLN/AdvancedSimPy.pdf].
SimPy is available on [http://simpy.sourceforge.net/].

The model description is as follows.

Introductory example to illustrate the modeling of "competing
events" such as timeouts, especially using the `cancel_process_by_id` 
function. A network node sends a message but also sets a timeout period; 
if the node times out, it assumes the message it had sent was lost, and it
will send again. The time to get an acknowledgement for a message is
exponentially distributed with mean 1.0, and the timeout period is
0.5. Immediately after receiving an acknowledgement, the node sends
out a new message.

We find the proportion of messages which timeout. The output should
be about 0.61.

---

SOLUTION

A process-oriented implementation of the model for sequential simulation.

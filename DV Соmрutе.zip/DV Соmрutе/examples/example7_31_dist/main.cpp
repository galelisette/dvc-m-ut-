/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

#include <iostream>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace dvcompute_dist;
using namespace dvcompute_dist::block;
using namespace dvcompute_dist::results;

using Data = double;

static Block<Transact<Data>, Unit> bottle_chain(const FacilityPtr<Data>& worker,
  const RefPtr<SamplingStats<double>>& stats)
{
  return assign_block_c(event_time())
    .and_then(seize_block(worker))
    .and_then(advance_block<Transact<Data>>(random_uniform_process_(8 - 3, 8 + 3)))
    .and_then(split_block(delay_block([=]() {
      return bottle_chain(worker, stats);
    })))
    .and_then(release_block(worker))
    .and_then(priority_block<Data>(1))
    .and_then(gather_block<Data>(24))

#if defined(_MSC_VER)
    // a workaround for the MSVC compiler error C1060
    .into_boxed()
#endif

    .and_then(seize_block(worker))
    .and_then(advance_block<Transact<Data>>(random_uniform_process_(16 - 3, 16 + 3)))
    .and_then(release_block(worker))
    .and_then(assemble_block<Data>(12))
    .and_then(foreach_block_c<Data>([=](const Data& t0) {
      return event_time()
        .and_then([=](double t) {
          return modify_ref(stats, [=](SamplingStats<double>&& stats) {
            return stats.add(t - t0);
          });
        });
    }))
    .and_then(terminate_block<Transact<Data>>());
}

static void simulate(LogicalProcessContext* ctx) {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000, 0.1, GeneratorSpec() };
  Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000000, 0.1, GeneratorSpec() };

  Model model;

  auto stats = model.new_ref(SamplingStats<double>(), std::string("stats"));
  auto worker = model.new_facility<Data>(std::string("worker"));

  auto bottle_stream {
    random_uniform_stream(0.0, 0.0).take(1)
  };

  auto bottle_start {
    run_process(stream_generator_block<Data>(std::move(bottle_stream))
        .run([=]() { return bottle_chain(worker, stats); }))
      .run_in_start_time()
  };

  model.emplace_action(std::move(bottle_start));

  auto comp {
    std::move(model).init_in_start_time()
  };

  print_simulation_results_in_stop_time(std::move(comp), &specs, ctx, ResultLocale::en);
}
  
struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

  setlocale(LC_ALL, "Russian");

#ifdef _WIN32
  SetConsoleOutputCP(CP_UTF8);
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 2) {
    std::cerr << "Expected two MPI processes" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);
    
  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }
  
  free_thread_local_objects(); 

  return 0;
}
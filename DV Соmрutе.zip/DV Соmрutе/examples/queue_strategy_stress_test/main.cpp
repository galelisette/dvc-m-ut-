/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>

#if DVCOMPUTE_DISTRIBUTED
#include <mpi.h>
#endif /* DVCOMPUTE_DISTRIBUTED */

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/dvcompute.h"

using namespace DVCOMPUTE_NS;

const int event_limit = 10000000;

static Event<Unit> producer(const SharedPtr<PriorityFCFSStorage<double>>& queue, int count) {
  return cons_event([=](const Point *p) {
    queue->push_with_priority(0, double { 123.0 }, p);
    return Result<Unit>(Unit());
  })
  .and_then([=](Unit&& unit) {
    if (count < event_limit) {
      return event_time()
        .and_then([=](double t) {
          return enqueue_event(t + 1.0, producer(queue, 1 + count));
        })
        .into_boxed();
    } else {
      return pure_event(Unit())
        .into_boxed();
    }
  });
}

static Event<Unit> consumer(const SharedPtr<PriorityFCFSStorage<double>>& queue, int count) {
  return cons_event([=](const Point *p) {
    queue->pop(p);
    return Result<Unit>(Unit());
  })
  .and_then([=](Unit&& unit) {
    if (count < event_limit) {
      return event_time()
        .and_then([=](double t) {
          return enqueue_event(t + 1.0, consumer(queue, 1 + count));
        })
        .into_boxed();
    } else {
      return pure_event(Unit())
        .into_boxed();
    }
  });
}

#ifdef DVCOMPUTE_SEQUENTIAL
static void simulate() {
#elif DVCOMPUTE_DISTRIBUTED
static void simulate(LogicalProcessContext *ctx) {
#else
#error "Unknown simulation mode"
#endif

  Specs specs { 0, event_limit, 0.1, GeneratorSpec() };
  SharedPtr<PriorityFCFSStorage<double>> queue { LocalSharedPtrLateInit() };

  queue.late_init(PriorityFCFSStorage<double>());

  auto model = producer(queue, 0)
    .run_in_start_time()
    .and_then([=](Unit&& unit) {
      return consumer(queue, 0)
        .run_in_start_time()
        .and_then([=](Unit&& unit) {
          return pure_event(Unit())
            .run_in_stop_time()
            .map([](Unit&& unit) { 
              return event_limit; 
            });
        });
    });

#ifdef DVCOMPUTE_SEQUENTIAL
  auto result = std::move(model).run(&specs);
#elif DVCOMPUTE_DISTRIBUTED
  auto result = std::move(model).run(&specs, ctx);
#else
#error "Unknown simulation mode"
#endif

  auto x = expect_result(result);

  std::cout << "The event limit is " << x << std::endl;
}
  
#ifdef DVCOMPUTE_SEQUENTIAL
int main(int argc, char * argv[]) {

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  simulate();

  return 0;
}
#elif DVCOMPUTE_DISTRIBUTED

struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 2) {
    std::cerr << "Expected two MPI processes" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);
    
  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }

  free_thread_local_objects();
  
  return 0;
}
#else
#error "Unknown simulation mode"
#endif

The example is simular to model timeout_example and it is described in document
Advanced Features of the SimPy Language
[http://heather.cs.ucdavis.edu/~matloff/156/PLN/AdvancedSimPy.pdf].
SimPy is available on [http://simpy.sourceforge.net/].

The model description is as follows.

Introductory example to illustrate the modeling of "competing
events" such as timeouts, especially using the `timeout_process`
function. A network node starts a process within the specified
timeout and receives a signal that notifies whether the process
has finished successfully within the timeout; if the node
times out, it assumes the message it had sent was lost, and it
will send again. The time to get an acknowledgement for a message is
exponentially distributed with mean 1.0, and the timeout period is
0.5. Immediately after receiving an acknowledgement, the node sends
out a new message.

We find the proportion of messages which timeout. The output should
be about 0.61.

---

SOLUTION

A process-oriented implementation of the model for distributed simulation
by optimistic method Time Warp, although only a single logical process is 
defined here, but you can use the example for building more complex models 
consistings of many logical processes.

To run, pass in options `-np 2` to `mpiexec` like this:

```
mpiexec -np 2 timeout_wait_example_dist
```

Here the total number of MPI processes is 2, where there is 1 
specialised time server process that has little impact on performance. 
The remaining 2 - 1 = 1 MPI process corresponds to logial processes. Every
logical process requires 2 physical cores of the processor. Thus, 
it ideally requires 2 * (2 - 1) = 2 physical cores of the processor.

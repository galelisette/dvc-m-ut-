/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace dvcompute_dist;

const double ack_rate = 1.0 / 1.0;    // reciprocal of the acknowledgement mean time
const double to_period = 0.5;         // timeout period

inline auto timeout(const RefPtr<int>& n_msgs, 
  const RefPtr<int>& n_timeouts,
  const RefPtr<int>& reactivated_code,
  const ProcessIdPtr& node_pid,
  const ProcessIdPtr& ack_pid) 
{
  return hold_process(to_period)
    .and_then([=](Unit&& unit) {
      return into_process(write_ref(reactivated_code, 1)
        .and_then([=](Unit&& unit) {
          return reactivate_process(node_pid);
        })
        .and_then([=](Unit&& unit) {
          return cancel_process_by_id(ack_pid);
        }));
    });
}

inline auto acknowledgement(const RefPtr<int>& n_msgs, 
  const RefPtr<int>& n_timeouts,
  const RefPtr<int>& reactivated_code,
  const ProcessIdPtr& node_pid,
  const ProcessIdPtr& timeout_pid) 
{
  return random_exponential_process_(1 / ack_rate)
    .and_then([=](Unit&& unit) {
      return into_process(write_ref(reactivated_code, 2)
        .and_then([=](Unit&& unit) {
          return reactivate_process(node_pid);
        })
        .and_then([=](Unit&& unit) {
          return cancel_process_by_id(timeout_pid);
        }));
    });
}

static Process<Unit> node(const RefPtr<int>& n_msgs, 
  const RefPtr<int>& n_timeouts,
  const RefPtr<int>& reactivated_code,
  const ProcessIdPtr& node_pid) 
{
  return into_process(modify_ref(n_msgs, [](int n) { return 1 + n; }))
    .and_then([=](Unit&& unit) {
      return into_process(new_process_id())
        .and_then([=](const ProcessIdPtr& timeout_pid) {
          return into_process(new_process_id())
            .and_then([=](const ProcessIdPtr& ack_pid) {
              return into_process(run_process_using_id(timeout_pid, timeout(n_msgs, n_timeouts, reactivated_code, node_pid, ack_pid)))
                .and_then([=](Unit&& unit) {
                  return into_process(run_process_using_id(ack_pid, acknowledgement(n_msgs, n_timeouts, reactivated_code, node_pid, timeout_pid)));
                })
                .and_then([](Unit&& unit) {
                  return passivate_process();
                })
                .and_then([=](Unit&& unit) {
                  return into_process(read_ref(reactivated_code)
                    .and_then([=](int code) {
                      if (code == 1) {
                        return modify_ref(n_timeouts, [](int n) { return 1 + n; })
                          .and_then([=](Unit&& unit) {
                            return write_ref(reactivated_code, 0);
                          })
                          .into_boxed();
                      } else {
                        return write_ref(reactivated_code, 0)
                          .into_boxed();
                      }
                    }));
                })
                .and_then([=](Unit&& unit) {
                  return node(n_msgs, n_timeouts, reactivated_code, node_pid);
                });
            });
        });
    });
}

static void simulate(LogicalProcessContext *ctx) {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  Specs specs { 0, 10000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };

  RefPtr<int> n_msgs { mk_shared(Ref(0)) };
  RefPtr<int> n_timeouts { mk_shared(Ref(0)) };
  RefPtr<int> reactivated_code { mk_shared(Ref(0)) };

  auto model = new_process_id()
    .and_then([=](const ProcessIdPtr& node_pid) {
      return run_process_using_id(node_pid, node(n_msgs, n_timeouts, reactivated_code, node_pid))
        .run_in_start_time();
    })
    .and_then([=](Unit&& unit) {
      return read_ref(n_timeouts)
        .and_then([=](double x) {
          return read_ref(n_msgs)
            .map([=](double y) {
              return x / y;
            });
        })
        .run_in_stop_time();
    });

  auto result = std::move(model).run(&specs, ctx);
  auto x = expect_result(result);
  
  std::cout << "Stop time: " << specs.stop_time << std::endl;
  std::cout << "The result is " << x << std::endl;
}
  
struct MPI_Guard {
public:
  
  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }
  
  ~MPI_Guard() {
    MPI_Finalize();
  }
};
  
int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;
  
  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 2) {
    std::cerr << "Expected two MPI processes" << std::endl;
    return 1;
  }
  
  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);
    
  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate(ctx); });
  }

  free_thread_local_objects();
  
  return 0;
}

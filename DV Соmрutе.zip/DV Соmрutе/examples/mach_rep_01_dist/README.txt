The example corresponds to model mach_rep_01 described in document
Introduction to Discrete-Event Simulation and the SimPy Language
[http://heather.cs.ucdavis.edu/~matloff/156/PLN/DESimIntro.pdf].
SimPy is available on [http://simpy.sourceforge.net/].

The model description is as follows.

Two machines, which sometimes break down. Up time is exponentially 
distributed with mean 1.0, and repair time is exponentially 
distributed with mean 0.5. There are two repairpersons, so 
the two machines can be repaired simultaneously if they are 
down at the same time.

Output is long-run proportion of up time. Should get value of about
0.66.

---

SOLUTION

A process-oriented implementation of the model for distributed simulation
by optimistic method Time Warp, although only a single logical process is 
defined here, but you can use the example for building more complex models 
consistings of many logical processes.

To run, pass in options `-np 2` to `mpiexec` like this:

```
mpiexec -np 2 mach_rep_01_dist
```

Here the total number of MPI processes is 2, where there is 1 
specialised time server process that has little impact on performance. 
The remaining 2 - 1 = 1 MPI process corresponds to logial processes. Every
logical process requires 2 physical cores of the processor. Thus, 
it ideally requires 2 * (2 - 1) = 2 physical cores of the processor.

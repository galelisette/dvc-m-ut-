The reproducible stress-test is based on model mach_rep_01 defined in
Introduction to Discrete-Event Simulation and the SimPy Language
[http://heather.cs.ucdavis.edu/~matloff/156/PLN/DESimIntro.pdf].
SimPy is available on [http://simpy.sourceforge.net/].

The model description is as follows.

Two machines, which sometimes break down. Up time is exponentially 
distributed with mean 1.0, and repair time is exponentially 
distributed with mean 0.5. There are two repairpersons, so 
the two machines can be repaired simultaneously if they are 
down at the same time.

Output is long-run proportion of up time. Should get value of about
0.66.

---

SOLUTION

A reproducible stress-test implementation of the model to test the messaging 
facilities of the distributed simulation module that uses the conservative method.

This is not example for that how the models should be defined. Moreover,
it shows how you should not write models at all. This is a stress test to check 
the implementation!

The successult result is that the distributed simulation terminates at all!
The lookahead parameter is too small so that the conservative method would
be useful for this model. To see the final results, please look at the same 
model, but that one which uses the optimistic Time Warp method, the method
that is suitable for small values of the lookahead parameter.

To run, pass in options `-np 3` to `mpiexec` like this:

```
mpiexec -np 3 mach_rep_01_cons_cascade
```

Here the total number of MPI processes is 3, which is the number of 
parallel logical processes. Every logical process requires 2 physical 
cores of the processor. Thus, it ideally requires 2 * 3 = 6 physical 
cores of the processor.

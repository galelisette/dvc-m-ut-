/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>
#include <cstddef>
#include <cmath>
#include <limits>
#include <vector>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace dvcompute_cons;

const double time_epsilon = 1.0e-6;

/** The lookahead parameter. */
const double lookahead = time_epsilon;

const double up_time_mean = 1.0;
const double repair_time_mean = 0.5;

uint64_t seed(int rank) {
  return 517 * rank;
}

static uint64_t gen_bits(int bits, const std::shared_ptr<Ref<uint64_t>>& gen, const Point* p) {
  uint64_t x = gen->read_at(p);
  uint64_t y = (x * 0x5deece66dULL + 0xbULL) & ((1ULL << 48) - 1ULL);
  uint64_t z = y;
  gen->write_at(std::move(z), p);
  return y >> (48 - bits);
}

static double gen_uniform01(const std::shared_ptr<Ref<uint64_t>>& gen, const Point* p) {
  uint64_t m1 = gen_bits(26, gen, p);
  uint64_t m2 = gen_bits(27, gen, p);
  double x = static_cast<double>((m1 << 27) + m2);
  double y = 1ULL << 53;
  return x / y;
}

static double gen_exp_at(const std::shared_ptr<Ref<uint64_t>>& gen, double mu, const Point* p) {
  return - log(gen_uniform01(gen, p)) * mu;
}

inline auto gen_exp(const std::shared_ptr<Ref<uint64_t>>& gen, double mu) {
  return cons_event([=](const Point *p) {
    return Result<double>(gen_exp_at(gen, mu, p));
  });
}

struct TotalUpTimeChange {
  LogicalProcessId pid;
  double up_time;
};

struct TotalUpTimeChangeResp {};

struct MachinePrepared {
  LogicalProcessId pid;
};

struct MachinePreparedResp {};

constexpr ExpectedUUID total_up_time_change_uuid { 1513571530ULL, "Expected TotalUpTimeChange" };
constexpr ExpectedUUID total_up_time_change_resp_uuid { 1770469373ULL, "Expected TotalUpTimeChangeResp" };
constexpr ExpectedUUID machine_prepared_uuid { 2085862297ULL, "Expected MachinePrepared" };
constexpr ExpectedUUID machine_prepared_resp_uuid { 1076808718ULL, "Expected MachinePreparedResp" };

static Serializer& operator<<(Serializer& ser, const TotalUpTimeChange& x) {
  return ser << total_up_time_change_uuid << x.pid << x.up_time;
}

static Serializer& operator<<(Serializer& ser, const TotalUpTimeChangeResp& x) {
  return ser << total_up_time_change_resp_uuid;
}

static Serializer& operator<<(Serializer& ser, const MachinePrepared& x) {
  return ser << machine_prepared_uuid << x.pid;
}

static Serializer& operator<<(Serializer& ser, const MachinePreparedResp& x) {
  return ser << machine_prepared_resp_uuid;
}

static Deserializer& operator>>(Deserializer& deser, TotalUpTimeChange& x) {
  return deser >> total_up_time_change_uuid >> x.pid >> x.up_time;
}

static Deserializer& operator>>(Deserializer& deser, TotalUpTimeChangeResp& x) {
  return deser >> total_up_time_change_resp_uuid;
}

static Deserializer& operator>>(Deserializer& deser, MachinePrepared& x) {
  return deser >> machine_prepared_uuid >> x.pid;
}

static Deserializer& operator>>(Deserializer& deser, MachinePreparedResp& x) {
  return deser >> machine_prepared_resp_uuid;
}

static Simulation<Unit> auxiliary_simulation(LogicalProcessId main_id, LogicalProcessId self_id, const std::shared_ptr<Ref<uint64_t>>& gen) {

  auto working_machine = [=]() {
    return gen_exp(gen, up_time_mean)
      .and_then([=](double up_time) {
        return event_time()
          .and_then([=](double t) {
            return enqueue_message(main_id, t + up_time, TotalUpTimeChange { self_id, up_time });
          });
      });
  };

  Event<Unit> working_machine_loop =
    input_messages<TotalUpTimeChangeResp>()
      .subscribe(cons_observer([=](const TotalUpTimeChangeResp* msg, const Point* p) {
        return gen_exp(gen, repair_time_mean)
          .and_then([=](double repair_time) {
            return event_time()
              .and_then([=](double t) {
                return enqueue_message(main_id, t + repair_time, MachinePrepared { self_id });
              });
          })(p);
      }))
      .map([](Disposable<>&&) {
        return Unit();
      });

  Event<Unit> machine_preparing_loop =
    input_messages<MachinePreparedResp>()
      .subscribe(cons_observer([=](const MachinePreparedResp* msg, const Point* p) {
        return working_machine()(p);
      }))
      .map([](Disposable<>&&) {
        return Unit();
      });

  return working_machine()
    .run_in_start_time()
    .and_then([working_machine_loop{std::move(working_machine_loop)}](Unit&& unit) mutable {
      return std::move(working_machine_loop).run_in_start_time();
    })
    .and_then([machine_preparing_loop{std::move(machine_preparing_loop)}](Unit&& unit) mutable {
      return std::move(machine_preparing_loop).run_in_start_time();
    });
}

static Simulation<Unit> main_simulation(const RefPtr<double>& total_up_time) {

  Event<Unit> working_machine_loop =
    input_messages<TotalUpTimeChange>()
      .subscribe(cons_observer([=](const TotalUpTimeChange* msg, const Point* p) {
        double up_time = msg->up_time;
        return modify_ref(total_up_time, [up_time](double total_up_time) { 
            return total_up_time + up_time; 
          })
          .and_then([pid{msg->pid}](Unit&& unit) {
            return event_time()
              .and_then([pid](double t) {
                return enqueue_message(pid, t + time_epsilon, TotalUpTimeChangeResp {});
              });
          })(p);
      }))
      .map([](Disposable<>&&) {
        return Unit();
      });

  Event<Unit> machine_preparing_loop =
    input_messages<MachinePrepared>()
      .subscribe(cons_observer([=](const MachinePrepared* msg, const Point* p) {
        return event_time()
          .and_then([pid{msg->pid}](double t) {
            return enqueue_message(pid, t + time_epsilon, MachinePreparedResp {});
          })(p);
      }))
      .map([](Disposable<>&&) {
        return Unit();
      });

  return std::move(working_machine_loop)
    .run_in_start_time()
    .and_then([machine_preparing_loop{std::move(machine_preparing_loop)}](Unit&& unit) mutable {
      return std::move(machine_preparing_loop).run_in_start_time();
    });
}

static Specs get_specs() {
  Specs specs{0, 0.1, 0.1, GeneratorSpec()};
  // Specs specs{0, 1000, 0.1, GeneratorSpec()};
  // Specs specs{0, 5000, 0.1, GeneratorSpec()};
  // Specs specs { 0, 10000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };

  return specs;
}

static void simulate_auxiliary(LogicalProcessContext *ctx, LogicalProcessId main_id, LogicalProcessId self_id) {

  DVCOMPUTELOG_NS::info("Starting the auxiliary logical process...");

  std::shared_ptr<Ref<uint64_t>> gen(new Ref<uint64_t>(seed(self_id)));

  auto model = auxiliary_simulation(main_id, self_id, gen)
    .and_then([](Unit&& unit) {
      return pure_event(Unit())
        .run_in_stop_time();
    });

  Specs specs { get_specs() };
  std::move(model).run(&specs, ctx);

  DVCOMPUTELOG_NS::info("Finished the auxiliary logical process");
}

static void simulate_main(LogicalProcessContext *ctx) {

  DVCOMPUTELOG_NS::info("Starting the main logical process...");

  RefPtr<double> total_up_time { mk_shared(Ref(0.0)) };

  auto model = main_simulation(total_up_time)
    .and_then([=](Unit&& unit) {
      return event_time()
        .and_then([=](double t) {
          return read_ref(total_up_time)
            .map([=](double total_up_time) {
              return total_up_time / (2.0 * t);
            });
        })
        .run_in_stop_time();
    });

  Specs specs { get_specs() };

  auto result = std::move(model).run(&specs, ctx);
  auto x = expect_result(result);

  std::cout << "Stop time: " << specs.stop_time << std::endl;
  // std::cout.precision(std::numeric_limits<double>::max_digits10 - 1);
  // std::cout << "The result is " << x << " (~ 0.6043724652088527)" << std::endl;  // 10
  // std::cout << "The result is " << x << " (~ 0.6682979196097908)" << std::endl;  // 1000
  // std::cout << "The result is " << x << " (~ 0.6703113912238350)" << std::endl;  // 5000
  std::cout << "The result is " << x << ", when indeed expected 0 instead of (~ 0.66)" << std::endl;  // 10000
  std::cout << std::endl;
  std::cout << 
    "The successful result is that the distributed simulation "
    "with such settings terminates at all! Nevertheless, to see "
    "the final results, please look at the same model, but that one "
    "which uses the optimistic Time Warp method, which is suitable "
    "for this task with very small degree of the lookahead parameter." << std::endl;
}

struct MPI_Guard {
public:

  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }

  ~MPI_Guard() {
    MPI_Finalize();
  }
};

int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;

  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 3) {
    std::cerr << "Expected three MPI processes" << std::endl;
    return 1;
  }

  std::vector<LogicalProcessId> pids;
  for (int i = 0; i < comm.size; ++i) {
    pids.push_back(i);
  }

  if (comm.pid == 0) {
    LogicalProcessParameters ps(lookahead);
    run_logical_process(comm, pids, ps, [](LogicalProcessContext* ctx) { simulate_main(ctx); });

  } else {
    LogicalProcessId main_id { 0 };
    LogicalProcessId self_id { comm.pid };
    LogicalProcessParameters ps(lookahead);
    run_logical_process(comm, pids, ps, [main_id, self_id](LogicalProcessContext* ctx) { simulate_auxiliary(ctx, main_id, self_id); });
  }

  free_thread_local_objects();

  return 0;
}

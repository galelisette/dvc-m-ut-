DVCompute++ Simulator Examples

If you want to run an example, then I would recommend to start from the model
of the Closed Queue Network (CQN). This model is often used for testing simulators.

You can find the following versions:

(a) Model `examples/cqn`. This is a sequential mode of simulation;

(b) Model `examples/cqn_pseudo`. It contains a single logical process,
but it uses the optimistic distributed simulation module already. Not all
features of the Time Warp method are used for this model, though. For example, 
this model does not use message passing at all. This model is useful mainly 
for comparison;

(c) Model `examples/cqn_dist`. This is a true distributed simulation
model, where each queue tandem is processed by separate logical process.
The optimistic Time Warp method is used. The logical processes send messages
to each other;

(d) Model `examples/cqn_cons`. This is a true distributed simulation
model too, but it uses the conservative simulation module based on the
Null Message Algorithm. Here we can see how this model strongly depends on
the lookahead parameter, while the optimistic method stronger depends on that
whether the computational capabilities (processor cores) are sufficient for
the very simulation.

If you do not want to use the "Library Code" portions so far, as defined in 
the License Agreement, then you can start from the first model (a). It will 
not require additional settings.

# The Closed Queue Network (CQN) Model

The closed queue network model is described in article "Performance evaluation
of conservative algorithms in parallel simulation languages" (2000) by
R. L. Bagrodia and M. Takai. Also this model is described in article
["Parallel simulation made easy with OMNeT++"](https://www.semanticscholar.org/paper/Parallel-Simulation-Made-Easy-With-OMNeT%2B%2B-Varga/fe5a96d4ca8125e407214d5195c45a65fc543a6d?tab=abstract) (2003)
by Varga, A., Sekercioglu, A.Y.

The model consists of N queue tandems where each tandem consists of a switch and
k single-server queues with exponential service times. The last queues are
looped back to their switches. Each switch randomly chooses the first queue of
one of the tandems as destination, using uniform distribution. The queues and
switches are connected with links that have nonzero propagation delays.

In the mentioned articles the model was used for estimating the conservative
distributed simulation methods and their implementations. Here the same model
can be also used for estimating my own implementation of the optimistic 
Time Warp method added to DVCompute++ Simulator.

The resulting value for each queue tandem is a number of times, when transacts 
return the last queue (facility) in the corresponding tandem. Since the queue 
network is closed, the same transacts pass the tandems again and again. These 
values allow estimating the complexity of operations made within simulation. 
Also we can see that everything is OK.

The model uses a reproducible pseudo-random number generator. Therefore,
all four considered models must always return the same reproducible results. 
This is especially important for the optimistic Time Warp method implementation,
model (c), for it extensively uses roll-backs during simulation.

The corresponding model settings are defined in the `include/cqn_config.h` file.

---
Best regards,

Gale Lisette — galelisette01@gmail.com

This is a sequential version of the Closed Queue Network (CQN) model.
The version uses the optimistic distributed module of DVCompute++ Simulator,
where there is only one logical process that simulates the entire model.

Edit the `../include/cqn_config.h` file to change the settings.

To run, enter `mpiexec -np 2 cqn_pseudo`.

The reproducible stress-test is based on model mach_rep_01 defined in
Introduction to Discrete-Event Simulation and the SimPy Language
[http://heather.cs.ucdavis.edu/~matloff/156/PLN/DESimIntro.pdf].
SimPy is available on [http://simpy.sourceforge.net/].

The model description is as follows.

Two machines, which sometimes break down. Up time is exponentially 
distributed with mean 1.0, and repair time is exponentially 
distributed with mean 0.5. There are two repairpersons, so 
the two machines can be repaired simultaneously if they are 
down at the same time.

Output is long-run proportion of up time. Should get value of about
0.66.

---

SOLUTION

A reproducible stress-test implementation of the model to test the messaging 
facilities of the distributed simulation module that uses optimistic method Time Warp.

This is not example for that how the models should be defined. Moreover,
it shows how you should not write models at all. This is a stress test to check 
the implementation!

Whenever and how many times you run the model, you must receive the same
reproducible results on the same computer architecture. This is the point of
this stress-test.

To run, pass in options `-np 4` to `mpiexec` like this:

```
mpiexec -np 4 mach_rep_01_dist_cascade
```

Here the total number of MPI processes is 4, where there is 1 
specialised time server process that has little impact on performance. 
The remaining 4 - 1 = 3 MPI processes correspond to logial processes. Every
logical process requires 2 physical cores of the processor. Thus, 
it ideally requires 2 * (4 - 1) = 6 physical cores of the processor.

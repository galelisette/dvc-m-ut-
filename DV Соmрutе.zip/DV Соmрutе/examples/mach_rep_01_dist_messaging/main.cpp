/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <iostream>

#include <mpi.h>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#endif

#ifdef USE_SPDLOG
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/support/mpi_support.h"
#include "dvcompute/dvcompute.h"

using namespace dvcompute_dist;

const double time_epsilon = 1.0e-6;

const double up_time_mean = 1.0;
const double repair_time_mean = 0.5;

struct TotalUpTimeChange {
  double up_time;
};

constexpr ExpectedUUID total_up_time_change_uuid { 1513571530ULL, "Expected the TotalUpTimeChange value" };

static Serializer& operator<<(Serializer& ser, const TotalUpTimeChange& x) {
  return ser << total_up_time_change_uuid << x.up_time;
}

static Deserializer& operator>>(Deserializer& deser, TotalUpTimeChange& x) {
  return deser >> total_up_time_change_uuid >> x.up_time;
}

static Process<Unit> auxiliary_process(LogicalProcessId main_id) {
  return random_exponential_process(up_time_mean)
    .and_then([=](double up_time) {
      return into_process(event_time()
        .and_then([=](double t) {
          return enqueue_message(main_id, t + time_epsilon, TotalUpTimeChange { up_time });
      }));
    })
    .and_then([](Unit&& unit) {
      return random_exponential_process_(repair_time_mean);
    })
    .and_then([=](Unit&& unit) {
      return auxiliary_process(main_id);
    });
}

static Process<Unit> main_process(const RefPtr<double>& total_up_time) {
  return into_process(input_messages<TotalUpTimeChange>()
    .subscribe(cons_observer([=](const TotalUpTimeChange* msg, const Point* p) {
      double up_time = msg->up_time;
      return modify_ref(total_up_time, [=](double total_up_time) { 
        return total_up_time + up_time; 
      })(p);
    }))
    .map([](Disposable<>&&) {
      return Unit();
    }));
}

static Specs get_specs() {

  // Specs specs { 0, 1000, 0.1, GeneratorSpec() };
  Specs specs { 0, 10000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 10000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 100000000, 0.1, GeneratorSpec() };
  // Specs specs { 0, 1000000000, 0.1, GeneratorSpec() };

  return specs;
}

static void simulate_auxiliary(LogicalProcessContext *ctx, LogicalProcessId main_id) {

  DVCOMPUTELOG_NS::info("Starting the auxiliary logical process...");

  auto model = run_process(auxiliary_process(main_id))
    .run_in_start_time()
    .and_then([](Unit&& unit) {
      return pure_event(Unit())
        .run_in_stop_time();
    });

  Specs specs { get_specs() };
  std::move(model).run(&specs, ctx);

  DVCOMPUTELOG_NS::info("Finished the auxiliary logical process");
}

static void simulate_main(LogicalProcessContext *ctx) {

  DVCOMPUTELOG_NS::info("Starting the main logical process...");

  RefPtr<double> total_up_time { mk_shared(Ref(0.0)) };

  auto model = run_process(main_process(total_up_time))
    .run_in_start_time()
    .and_then([=](Unit&& unit) {
      return event_time()
        .and_then([=](double t) {
          return read_ref(total_up_time)
            .map([=](double total_up_time) {
              return total_up_time / (2.0 * t);
            });
        })
        .run_in_stop_time();
    });

  Specs specs { get_specs() };

  auto result = std::move(model).run(&specs, ctx);
  auto x = expect_result(result);

  std::cout << "Stop time: " << specs.stop_time << std::endl;
  std::cout << "The result is " << x << " (~ 0.66)" << std::endl;
}

struct MPI_Guard {
public:

  MPI_Guard(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);
  }

  ~MPI_Guard() {
    MPI_Finalize();
  }
};

int main(int argc, char* argv[]) {

#ifdef USE_MIMALLOC
  mi_version();
#endif

#ifdef USE_SPDLOG
  // spdlog::set_level(spdlog::level::debug);
#endif

  MPI_Guard guard(argc, argv);
  MPI_Comm world = MPI_COMM_WORLD;

  LogicalProcessCommunicator comm(std::unique_ptr<NetworkSupport>(new MPISupport(world)));

  if (comm.size != 4) {
    std::cerr << "Expected four MPI processes" << std::endl;
    return 1;
  }

  if (comm.pid == 0) {
    std::size_t init_quorum = comm.size - 1;
    TimeServerParameters ps;
    run_time_server(comm, init_quorum, ps);

  } else if (comm.pid == 1) {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [](LogicalProcessContext* ctx) { simulate_main(ctx); });

  } else {
    LogicalProcessId time_server_id { 0 };
    LogicalProcessId main_id { 1 };
    LogicalProcessParameters ps;
    run_logical_process(comm, time_server_id, ps, [main_id](LogicalProcessContext* ctx) { simulate_auxiliary(ctx, main_id); });
  }

  free_thread_local_objects();

  return 0;
}

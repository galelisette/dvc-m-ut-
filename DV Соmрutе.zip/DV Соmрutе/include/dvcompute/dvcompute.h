/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_simulator_h
#define dvcompute_simulator_h

#include "dvcompute_ns.h"
#include "dvcompute_api.h"

#include "simulator/basic/types.h"
#include "simulator/basic/specs.h"
#include "simulator/basic/result.h"
#include "simulator/basic/generator_primitives.h"
#include "simulator/basic/generator.h"
#include "simulator/basic/parameter.h"
#include "simulator/basic/parameter_random.h"
#include "simulator/basic/simulation.h"
#include "simulator/basic/event.h"
#include "simulator/basic/event_extra.h"
#include "simulator/basic/composite.h"
#include "simulator/basic/process_id.h"
#include "simulator/basic/process.h"
#include "simulator/basic/process_extra.h"
#include "simulator/basic/process_id_impl.h"
#include "simulator/basic/process_random.h"
#include "simulator/basic/event_queue.h"
#include "simulator/basic/ref.h"
#include "simulator/basic/disposable.h"
#include "simulator/basic/observer.h"
#include "simulator/basic/observable.h"
#include "simulator/basic/observable_source.h"
#include "simulator/basic/observable_random.h"
#include "simulator/basic/block.h"
#include "simulator/basic/log_support.h"
#include "simulator/basic/strategy.h"
#include "simulator/basic/stats/sampling_stats.h"
#include "simulator/basic/stats/timing_stats.h"
#include "simulator/basic/arrival.h"
#include "simulator/basic/observable_extra.h"
#include "simulator/basic/observable_slot.h"
#include "simulator/basic/observable_slot_extra.h"
#include "simulator/basic/stream.h"
#include "simulator/basic/stream_random.h"
#include "simulator/basic/stream_extra.h"
#include "simulator/basic/block/transact.h"
#include "simulator/basic/block/transact_ops.h"
#include "simulator/basic/block/queue.h"
#include "simulator/basic/block/queue_ops.h"
#include "simulator/basic/block/assembly_set.h"
#include "simulator/basic/block/assembly_set_ops.h"
#include "simulator/basic/block/facility.h"
#include "simulator/basic/block/storage.h"
#include "simulator/basic/block_extra.h"
#include "simulator/basic/block/generator_block.h"
#include "simulator/basic/block_slot.h"
#include "simulator/basic/block_slot_extra.h"
#include "simulator/basic/observable_slot_adapter.h"
#include "simulator/basic/model.h"
#include "simulator/basic/results/result_source.h"
#include "simulator/basic/results/result_items.h"
#include "simulator/basic/results/result_extra.h"
#include "simulator/basic/results/result_set.h"
#include "simulator/basic/results/result_io.h"
#include "simulator/basic/results/result_utils.h"
#include "simulator/basic/results/stats/sampling_stats.h"
#include "simulator/basic/results/stats/timing_stats.h"
#include "simulator/basic/results/block/facility.h"
#include "simulator/basic/results/block/storage.h"
#include "simulator/basic/results/block/queue.h"
#include "simulator/basic/experiments/experiment.h"
#include "simulator/basic/experiments/rendering/web_page.h"
#include "simulator/basic/experiments/rendering/default_colors.h"
#include "simulator/basic/experiments/rendering/last_values.h"
#include "simulator/basic/experiments/rendering/deviation_chart.h"

#ifdef DVCOMPUTE_SEQUENTIAL

#include "simulator/basic/experiments/executors/basic_executor.h"
#include "simulator/basic/experiments/executors/thread_pool_executor.h"

#elif DVCOMPUTE_DISTRIBUTED

#include "simulator/dist/lp.h"
#include "simulator/dist/lp_context.h"
#include "simulator/dist/time_server.h"

#include "simulator/net/network_support.h"
#include "simulator/net/serialize.h"
#include "simulator/net/messaging.h"

#include "simulator/basic/experiments/executors/lp_executor.h"

#include "simulator/command/command.h"

#elif DVCOMPUTE_CONSERVATIVE

#include "simulator/cons/lp.h"
#include "simulator/cons/lp_context.h"

#include "simulator/net/network_support.h"
#include "simulator/net/serialize.h"
#include "simulator/net/messaging.h"

#include "simulator/basic/experiments/executors/lp_executor.h"

#include "simulator/command/command.h"

#elif DVCOMPUTE_BRANCHED

#include "simulator/branch/branch.h"
#include "simulator/branch/forecast.h"

#include "simulator/basic/experiments/executors/basic_executor.h"
#include "simulator/basic/experiments/executors/thread_pool_executor.h"

#endif

#endif /* dvcompute_simulator_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_mpi_support_h
#define dvcompute_mpi_support_h

#include <exception>
#include <vector>
#include <optional>
#include <memory>

#include <mpi.h>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/net/network_support.h"

namespace DVCOMPUTE_NS {

  /** The abort exit code due to invalid run index. */
  constexpr int32_t mpi_invalid_run_index_exit_code = -6;

  /** Represents an asynchronous MPI request. */
  class MPISupportRequest : public NetworkSupportRequest {

    MPI_Request req;

    friend class MPISupport;

  public:

    explicit MPISupportRequest(std::vector<char>&& buf_arg) :
      NetworkSupportRequest(std::move(buf_arg))
    {}
    
    MPISupportRequest(const MPISupportRequest&) = delete;
    MPISupportRequest(MPISupportRequest&&) = delete;

    MPISupportRequest& operator=(const MPISupportRequest&) = delete;
    MPISupportRequest& operator=(MPISupportRequest&&) = delete;
  };

  /** Supports MPI. */
  class MPISupport : public NetworkSupport {
    
    /** The underlying communicator. */
    MPI_Comm comm;

    /** The run index. */
    int run_index;
    
  public:
    
    explicit MPISupport(const MPI_Comm& comm_arg, int run_index_arg = 0) noexcept : 
      comm(comm_arg), run_index(run_index_arg)
    {}
    
    MPISupport(const MPISupport&) = default;
    MPISupport& operator=(const MPISupport&) = default;
    
    /** Get the size */
    int size() override {
      int size;
      if (MPI_Comm_size(comm, &size) == MPI_SUCCESS) {
        return size;
        
      } else {
        throw NetworkSupportError();
      }
    }
    
    /** Get the rank. */
    int rank() override {
      int rank;
      if (MPI_Comm_rank(comm, &rank) == MPI_SUCCESS) {
        return rank;
        
      } else {
        throw NetworkSupportError();
      }
    }
    
    /** Probes for incomming messages. */
    bool iprobe() override {
      int flag;
      MPI_Status status;
      while (true) {
        if (MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, comm, &flag, &status) == MPI_SUCCESS) {
          if (flag) {
            if (status.MPI_TAG == run_index) {
              return flag;

            } else if (status.MPI_TAG < run_index) {
              return flag;

            } else {
              abort(mpi_invalid_run_index_exit_code);
              throw NetworkSupportError();
            }

          } else {
            return flag;
          }
          
        } else {
          throw NetworkSupportError();
        }
      }
    }
    
    /** Returns a special value that designates any source. */
    int any_source() override {
      return MPI_ANY_SOURCE;
    }
    
    /** Receive the incomming data, the rank of the sender's logical process and a flag whether the operation is successful. */
    bool recv(std::vector<char>& buf, int* src) override {
      MPI_Status status;
      while (true) {
        if (MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, comm, &status) == MPI_SUCCESS) {
          if (status.MPI_TAG <= run_index) {

            int tag = status.MPI_TAG;
            int count = 0;

            if (MPI_Get_count(&status, MPI_BYTE, &count) == MPI_SUCCESS) {
              
              buf.resize(count);
              *src = status.MPI_SOURCE;
              
              if (MPI_Recv(&buf[0], count, MPI_BYTE, status.MPI_SOURCE, status.MPI_TAG, comm, &status) == MPI_SUCCESS) {

                if (tag == run_index) {
                  return true;

                } else {
                  continue;
                }

              } else {
                throw NetworkSupportError();
              }
              
            } else {
              throw NetworkSupportError();
            }

          } else {
            abort(mpi_invalid_run_index_exit_code);
            throw NetworkSupportError();
          }
          
        } else {
          throw NetworkSupportError();
        }
      }
    }
      
    /** Abort the simulation with the specified code. */
    void abort(int32_t code) override {
      MPI_Abort(comm, code);
    }
    
    /** Make an asynchronous request to the specfied destination. */
    std::unique_ptr<NetworkSupportRequest> isend(int dest, std::vector<char>&& buf) override {
      std::unique_ptr<NetworkSupportRequest> async_req { new MPISupportRequest(std::vector<char>()) };
      async_req->buf = std::move(buf);
      MPI_Request *p = &dynamic_cast<MPISupportRequest*>(async_req.get())->req;
      int len = static_cast<int>(async_req->buf.size());

      if (MPI_Isend(&(async_req->buf[0]), len, MPI_BYTE, dest, run_index, comm, p) == MPI_SUCCESS) {
        return async_req;
        
      } else {
        throw NetworkSupportError();
      }
    }
    
    /** Send the message synchronously to the specified destination. */
    void send(int dest, const std::vector<char>& buf) override {
      int len = static_cast<int>(buf.size());
      if (MPI_Send(&buf[0], len, MPI_BYTE, dest, run_index, comm) == MPI_SUCCESS) {
        return;
        
      } else {
        throw NetworkSupportError();
      }
    }
    
    /** Test whether the asynchronous request has been completed. */
    bool test(NetworkSupportRequest* req) override {
      int flag;
      MPI_Status status;
      MPI_Request *p = &dynamic_cast<MPISupportRequest*>(req)->req;

      if (MPI_Test(p, &flag, &status) == MPI_SUCCESS) {
        return flag;
        
      } else {
        throw NetworkSupportError();
      }
    }

    /** Wait until the asynchronous request has been completed. */
    void wait(NetworkSupportRequest* req) override {
      MPI_Status status;
      MPI_Request *p = &dynamic_cast<MPISupportRequest*>(req)->req;

      if (MPI_Wait(p, &status) == MPI_SUCCESS) {
        return;
        
      } else {
        throw NetworkSupportError();
      }
    }

    /** Cancel the asynchronous request. */
    void cancel(NetworkSupportRequest* req) override {
      MPI_Request *p = &dynamic_cast<MPISupportRequest*>(req)->req;

      if (MPI_Cancel(p) == MPI_SUCCESS) {
        return;
        
      } else {
        throw NetworkSupportError();
      }
    }

    /** Block until the barrier has passed by all logical processes. */
    void barrier() override {
      if (MPI_Barrier(comm) == MPI_SUCCESS) {
        return;
        
      } else {
        throw NetworkSupportError();
      }
    }
  };
}

#endif /* dvcompute_mpi_support */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_api_h
#define dvcompute_api_h

#if defined(DVCOMPUTE_SHARED_LIBS)
#if defined(WIN32)
#if defined(DVCOMPUTE_API_EXPORT)
#define DVCOMPUTE_API __declspec(dllexport)
#else
#define DVCOMPUTE_API __declspec(dllimport)
#endif
#else
#define DVCOMPUTE_API __attribute__((visibility("default")))
#endif
#else
#define DVCOMPUTE_API
#endif /* DVCOMPUTE_SHARED_LIBS */

#endif /* dvcompute_api_h */


/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_cons_specs_h
#define dvcompute_cons_specs_h

#include <vector>
#include <utility>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/dvcompute_api.h"
#include "../basic/generator.h"

namespace DVCOMPUTE_NS {

  /** The simulation specs. */
  struct DVCOMPUTE_API Specs {

    /** The start time of simulation. */
    double start_time;

    /** The stop time of simulation. */
    double stop_time;

    /** The time step. */
    double dt;

    /** The generator spec. */
    GeneratorSpec gen_spec;

    /** 
     * Return the indexed time value in the grid by the specified index and size, 
     * where the index changes within `[0, size)`. Index 0 corresponds to the start time,
     * but the index with value `size-1` corresponds to the stop time. 
     */
    double grid_time(unsigned int index, unsigned int size) const;

    /** Get the grid index that would correspond to the specified modeling time. */
    unsigned int grid_index(double t, unsigned int size) const;
  };

  namespace internal {

    namespace event {

      /** @private */
      class EventQueue;

      /** @private */
      class InputMessageQueue;

      /** @private */
      class OutputMessageQueue;
    }

    namespace command {

      /** @private */
      class CommandChannel;
    }
  }

  /** The simulation run. */
  struct Run;

  /** The logical process Context. */
  struct LogicalProcessContext;

  /** The current modeling time point. */
  struct DVCOMPUTE_API Point {

    /** A non-owner pointer to the simulation run. */
    const Run *run;

    /** The current time value. */
    double time;
    
    /** The current time point priority. */
    int priority;

    /** Get the current iteration number. */
    unsigned int iteration() const;
  };

  /** The simulation run. */
  struct DVCOMPUTE_API Run {

    /** A non-owner pointer to the specs. */
    const Specs *specs;

    /** The current run index in the Monte-Carlo experiment. */
    int run_index;

    /** The total run count in the Monte-Carlo experiment. */
    int run_count;

    /** The random number generator. */
    internal::generator::Generator gen;

    /** The event queue. */
    internal::event::EventQueue *event_queue;
    
    /** The logical process context. */
    LogicalProcessContext *lp_context;

    /** The input message queue. */
    internal::event::InputMessageQueue *input_messages;
    
    /** The output message queue. */
    internal::event::OutputMessageQueue *output_messages;

    /** The commands from external environment. */
    internal::command::CommandChannel *commands;

    /** Construct by the specified specs, run index and run count. */
    Run(const Specs *specs_arg, LogicalProcessContext *lp_context_arg, int run_index_arg, int run_count_arg);

    /** Construct by the specified specs for single run simulation. */
    Run(const Specs *specs_arg, LogicalProcessContext *lp_context_arg): Run(specs_arg, lp_context_arg, 0, 1) {}

    /** Destruct the object. */
    ~Run();

    /** Return the point in the start modeling time. */
    Point point_in_start_time() const {
      return Point { this, specs->start_time, 0 };
    }

    /** Return the point in the stop modeling time. */
    Point point_in_stop_time() const {
      return Point { this, specs->stop_time, 0 };
    }

    /** Return the point at the specified modeling time with the given priority. */
    Point point_at(double t, int priority) const {
      return Point { this, t, priority };
    }

    /** Return the point with the specified iteration number. */
    Point point_with_iteration(unsigned int n, int priority) const {
      double t0 = specs->start_time;
      double t2 = specs->stop_time;
      double dt = specs->dt;
      unsigned int n2 = static_cast<unsigned int>(std::floor((t2 - t0) / dt));
      double t = (n == n2) ? t2 : (t0 + n * dt);

      return Point { this, t, priority };
    }

    /** Process the event handlers till the specified time. */
    void process(bool including_current, double time, double* next_time = nullptr);

#ifdef DVCOMPUTE_REAL_PRIORITIES

    /** Process the event handlers till the specified time. */
    void process_with_priority(bool including_current, int priority, double time, double* next_time = nullptr);

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  };

  inline unsigned int Point::iteration() const {
    const Specs* specs = run->specs;
    double t0 = specs->start_time;
    double dt = specs->dt;
    unsigned int n = static_cast<unsigned int>(std::floor((time - t0) / dt));

    return n;
  }

  inline double Specs::grid_time(unsigned int index, unsigned int size) const {
    unsigned int n2 = (size <= 1) ? 1 : size - 1;
    double dt2 = (stop_time - start_time) / (static_cast<double>(n2));
    double t = (index == 0) ? start_time : ((index == n2) ? stop_time : (start_time + index * dt2));

    return t;
  }

  inline unsigned int Specs::grid_index(double t, unsigned int size) const {
    unsigned int n2 = (size <= 1) ? 1 : size - 1;
    if (t == start_time) {
      return 0;
    } else if (t == stop_time) {
      return n2;
    } else {
      double dt2 = (stop_time - start_time) / (static_cast<double>(n2));
      return static_cast<unsigned int>(std::ceil((t - start_time) / dt2));
    }
  }
}

#endif /* dvcompute_cons_specs_h */

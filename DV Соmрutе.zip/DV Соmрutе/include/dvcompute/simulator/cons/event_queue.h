/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_cons_event_queue_h
#define dvcompute_cons_event_queue_h

#include <functional>
#include <exception>
#include <string>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/dvcompute_api.h"
#include "dvcompute/simulator/basic/types.h"
#include "dvcompute/simulator/basic/result.h"

/** C++ Discrete Event Simulation (DES) module for conservative distributed simulation. */
namespace DVCOMPUTE_NS {

  /** Simulation specs. */
  struct Specs;

  /** The modeling time point. */
  struct Point;

  /** The simulation run. */
  struct Run;

  namespace internal {

    namespace event {

      /** @private */
      class EventQueue;

      // /** @private */
      // template<typename Item>
      //   using BoxedImpl = std::function<Result<Item>(const Point*)>;

      // /** @private */
      template<typename Item>
      class BoxedImpl;

      /** @private */
      DVCOMPUTE_API EventQueue* create_event_queue(const Specs &specs);

      /** @private */
      DVCOMPUTE_API void delete_event_queue(EventQueue *queue);

      /** @private */
      DVCOMPUTE_API void enqueue_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p);

      /** @private */
      DVCOMPUTE_API void enqueue_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p);
    
      /** @private */
      DVCOMPUTE_API Point current_event_point(const Run *r, int priority);

      /** @private */
      DVCOMPUTE_API void run_events(bool including_current, const Point *p, double *next_time = nullptr);

#ifdef DVCOMPUTE_REAL_PRIORITIES

      /** @private */
      DVCOMPUTE_API void enqueue_uncancellable_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p);

      /** @private */
      DVCOMPUTE_API void enqueue_uncancellable_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p);

      /** @private */
      DVCOMPUTE_API void enqueue_event_with_cancel(double event_time, int priority, event::BoxedImpl<Unit> &&comp, event::BoxedImpl<Unit> &&cancel_comp, const Point *p);

      /** @private */
      DVCOMPUTE_API void enqueue_io_event_with_cancel(double event_time, int priority, event::BoxedImpl<Unit> &&comp, event::BoxedImpl<Unit> &&cancel_comp, const Point *p);

      /** @private */
      DVCOMPUTE_API void run_events_with_priority(bool including_current, int priority, const Point *p, double *next_time = nullptr);

#endif /* DVCOMPUTE_REAL_PRIORITIES */

    }
  }
}

#endif /* dvcompute_cons_event_queue_h */

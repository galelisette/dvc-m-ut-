/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_cons_lp_context_h
#define dvcompute_cons_lp_context_h

#include <cstddef>
#include <string>
#include <optional>
#include <chrono>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/dvcompute_api.h"

namespace DVCOMPUTE_NS {

  /** The threading mode used for simulation. */
  enum class DVCOMPUTE_API LogicalProcessThread {

    /** 
     * This is the default single threaded mode that corresponds to `MPI_THREAD_SINGLE`. 
     */
    SingleThread,

    /** 
     * This is the two threaded mode that corresponds to `MPI_THREAD_FUNNELED`. 
     */
    FunneledThread,

    /**
     * The is a mode, when one thread receives messages, but another one sends them.
     * This is the two threaded mode that corresponds to `MPI_THREAD_MULTIPLE`.
     */
    MultipleThread
  };

  /** The logical process parameters. */
  struct DVCOMPUTE_API LogicalProcessParameters {
    
    /** The logical process name. */
    std::string name { "LP" };

    /** The lookahead parameter. */
    double lookahead;
    
    /** The threshold to test the lookahead time (single-threaded mode only) */
    std::size_t lookahead_time_test_threshold { 1000 };

    /** The timeout used for synchronizing the operations. */
    std::chrono::milliseconds sync_timeout { 60000 };
    
    /** The timeout used when initializing the logical process. */
    std::chrono::milliseconds initializing_timeout { 10000 };
    
    /** The test interval for network messages. */
    std::chrono::microseconds network_test_interval { 10000 };
    
    /** The idle loop interval when processing the messages (non-applicable on Windows). */
    std::optional<std::chrono::microseconds> idle_loop_interval { std::nullopt };
    
    /** The timeout used when awaiting messages from the logical process for the multiple threaded mode. */
    std::chrono::milliseconds recv_timeout { 250 };
    
    /** The threshold of network requests to test. */
    std::size_t network_test_threshold { 256 };
    
    /** The threshold of network requests to wait. */
    std::size_t network_wait_threshold { 8192 };

    /** The thread mode used for running the logical process. */
    LogicalProcessThread thread_mode { LogicalProcessThread::SingleThread };

    LogicalProcessParameters() = delete;

    explicit LogicalProcessParameters(double lookahead_arg) :
      lookahead(lookahead_arg)
    {}
  };

  /** The logical process context. */
  struct LogicalProcessContext;
}

#endif /* dvcompute_cons_lp_context */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_slot_adapter_h
#define dvcompute_observable_slot_adapter_h

#include <functional>
#include <utility>

#include "../../dvcompute_ns.h"
#include "types.h"
#include "observable_slot.h"
#include "block_slot.h"
#include "block/generator_block.h"

namespace DVCOMPUTE_NS {

  namespace slot {

    /** Connect the `ObservableSlot<Message>` to the specified `BlockSlot<Transact<Message>, Unit>`. */
    template<typename Message>
    Composite<Unit> observable_slot_to_block_slot(const ObservableSlot<Message> &observable, const BlockSlot<DVCOMPUTE_NS::block::Transact<Message>, Unit> &block) {
      return into_composite(new_process_id())
        .and_then([=](ProcessIdPtr &&pid) {
          return into_composite(run_process_using_id(pid, 
            DVCOMPUTE_NS::block::observable_generator_block<Message>(arrival_observable<Message>(observable()))
              .run([=]() {
                return block().into_boxed();
              })))
          .and_then([=](Unit) {
            return disposable_composite(cons_disposable([=](const Point *p) {
              return cancel_process_by_id(pid)(p);
            }));
          });
        });
    }

    /** Create a pair, where the resulting block slot is connected to the observable slot that emits all messages that will be processed by the corresponding block. */
    template<typename Message>
    std::pair<BlockSlot<DVCOMPUTE_NS::block::Transact<Message>, Unit>, ObservableSlot<Message>> block_slot_to_observable_slot() {
      using namespace DVCOMPUTE_NS::block;

      SharedPtr<ObservableSource<Message>> source { mk_shared(ObservableSource<Message>()) };

      BlockSlot<Transact<Message>, Unit> block([=]() {
        return cons_block([=](Transact<Message> &&transact) {
          return into_process(cons_event([source, transact{std::move(transact)}](const Point* p) {
            return source->trigger_at(&(transact.value), p);
          }));
        });
      });

      ObservableSlot<Message> observable([=]() {
        return source->publish();
      });

      return std::make_pair(block, observable);
    }
  }
}

#endif /* dvcompute_observable_slot_adapter_h */

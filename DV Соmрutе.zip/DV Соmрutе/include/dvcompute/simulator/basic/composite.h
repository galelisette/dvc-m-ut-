/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_composite_h
#define dvcompute_composite_h

#include <functional>
#include <vector>
#include <tuple>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "specs.h"
#include "result.h"
#include "parameter.h"
#include "simulation.h"
#include "event.h"
#include "disposable.h"
#include "composite_fn.h"
#include "tuple_traits.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace composite {

      // /** @private */
      // template<typename Item>
      //   using BoxedImpl = std::function<Result<std::tuple<Item, Disposable<>>>(Disposable<>&&, const Point*)>;

      /** @private */
      template<typename Item, typename ThenItem, typename Self, typename BindFn>
      class Then {

        Self comp;
        BindFn k;

      public:

        explicit Then(Self &&comp_arg, BindFn &&k_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(BindFn(std::move(k_arg)))) :
          comp(std::move(comp_arg)), k(std::move(k_arg))
        {}

        Then(Then<Item, ThenItem, Self, BindFn> &&other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(Then<Item, ThenItem, Self, BindFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Item, ThenItem, Self, BindFn> &other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(const Then<Item, ThenItem, Self, BindFn> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<std::tuple<ThenItem, Disposable<>>> operator()(Disposable<>&& disposable, const Point *p) && {
          Result<std::tuple<Item, Disposable<>>> res { std::move(comp)(std::move(disposable), p) };
          if (auto *item = get_result_if<std::tuple<Item, Disposable<>>>(&res)) [[likely]] {
            return k(std::move(std::get<0>(*item)))(std::move(std::get<1>(*item)), p);
          } else {
            return error_result<std::tuple<ThenItem, Disposable<>>>(std::move(res));
          }
        }
      };

      /** @private */
      template<typename Item>
      class Return {

        Item item;

      public:

        explicit Return(const Item &item_arg) : item(item_arg) {}
        explicit Return(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) :
          item(std::move(item_arg))
        {}

        Return(Return<Item> &&other) = default;
        Return<Item>& operator=(Return<Item> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Return(const Return<Item> &other) = default;
        Return<Item>& operator=(const Return<Item> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<std::tuple<Item, Disposable<>>> operator()(Disposable<>&& disposable, const Point *p) && {
          return Result<std::tuple<Item, Disposable<>>>(std::make_tuple(std::move(item), std::move(disposable)));
        }
      };
    }
  }

  /** Represents a `Composite` computation. */
  template<typename Item, typename Impl = internal::composite::BoxedImpl<Item>>
  class Composite;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace composite {

      /** Whether `F` is a function that takes `Arg` and returns a `Composite` computation. */
      template<typename F, typename Arg, typename Item>
      concept CompositeBindFn3 = std::is_invocable_r_v<Composite<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns a `Composite` computation. */
      template<typename F, typename Arg>
      concept CompositeBindFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires CompositeBindFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns a `Composite` computation. */
      template<typename F, typename Item>
      concept CompositeDelayFn2 = std::is_invocable_r_v<Composite<Item>, F>;

      /** Whether `F` is a function that returns a `Composite` computation. */
      template<typename F>
      concept CompositeDelayFn1 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires CompositeDelayFn2<F, typename std::invoke_result_t<F>::item_type>;
      };

      /** Whether `F` is a function that takes the `Disposable` handler and `Point` pointer but then returns a `Result` value. */
      template<typename F, typename Item>
      concept CompositeConsFn4 = std::is_invocable_r_v<Result<std::tuple<Item, Disposable<>>>, F, Disposable<>&&, const Point*>;

      /** Whether `F` is a function that takes the `Disposable` handler and `Point` pointer but then returns a `Result` value. */
      template<typename F, typename Traits>
      concept CompositeConsFn3 = requires {
        typename Traits::template arg<0>::type;
        requires CompositeConsFn4<F, typename Traits::template arg<0>::type>;
      };

      /** Whether `F` is a function that takes the `Disposable` handler and `Point` pointer but then returns a `Result` value. */
      template<typename F, typename Tuple>
      concept CompositeConsFn2 = requires {
        typename tuple_traits<Tuple>;
        requires CompositeConsFn3<F, tuple_traits<Tuple>>;
      };

      /** Whether `F` is a function that takes the `Disposable` handler and `Point` pointer but then returns a `Result` value. */
      template<typename F>
      concept CompositeConsFn1 = requires {
        typename std::invoke_result_t<F, Disposable<>&&, const Point*>::item_type;
        requires CompositeConsFn2<F, typename std::invoke_result_t<F, Disposable<>&&, const Point*>::item_type>;
      };
    }
  }

  /** Whether `Self` is actually an `Composite<Item>` computation. */
  template<typename Self, typename Item>
  concept CompositeLike = std::is_convertible_v<Self, Composite<Item>>;

  /** Whether `F` is a function that takes `Arg` and returns a `Composite` computation. */
  template<typename F, typename Arg>
  concept CompositeBindFn = internal::composite::CompositeBindFn2<F, Arg>;

  /** Whether `F` is a function that returns a `Composite` computation. */
  template<typename F>
  concept CompositeDelayFn = internal::composite::CompositeDelayFn1<F>;

  /** Whether `F` is a function that takes the `Disposable` handler and `Point` pointer but then returns a `Result` value. */
  template<typename F>
  concept CompositeConsFn = internal::composite::CompositeConsFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace composite {

      template<typename Item, typename Impl>
      inline Impl&& move_impl(Composite<Item, Impl>&& comp);
    }
  }

  /** Represents a `Composite` computation. */
  template<typename Item, typename Impl>
  class Composite {

    Impl impl;

    template<typename Item2, typename Impl2>
    friend inline Impl2&& internal::composite::move_impl(Composite<Item2, Impl2>&& comp);

  public:

    using item_type = Item;

    explicit Composite(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) :
      impl(std::move(impl_arg))
    {}

    Composite(Composite<Item, Impl>&& other) = default;
    Composite<Item, Impl>& operator=(Composite<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Composite(const Composite<Item, Impl>& other) = default;
    Composite<Item, Impl>& operator=(const Composite<Item, Impl>& other) = default;

#endif

    /** Call the computation. */
    DVCOMPUTE_ALWAYS_INLINE Result<std::tuple<Item, Disposable<>>> operator()(Disposable<>&& disposable, const Point *p) && {
      return std::move(impl)(std::move(disposable), p);
    }

    /**
     * Bind this with a continuation and return the resulting compound `Composite<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Composite<ThenItem>` computation.
     */
    template<typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && requires CompositeBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::composite::Then<Item, ThenItem, Impl, BindFn>;
      return Composite<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Bind this with a continuation and return the resulting compound `Composite<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Composite<ThenItem>` computation.
     */
    template<typename BindFn>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && requires CompositeBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::composite::Then<Item, ThenItem, Impl, BindFn>;
      return Composite<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Map the computed value and return the resulting compound `Composite<MapItem>`
     * computation, where `MapFn` is a function that takes an `Item` and then transforms it
     * to `MapItem`.
     */
    template<typename MapFn>
    DVCOMPUTE_ALWAYS_INLINE auto map(MapFn&& f) && {
      return std::move(*this).and_then([f{std::move(f)}](Item&& item) mutable {
        using MapItem = std::invoke_result_t<MapFn, Item&&>;
        using MapImpl = internal::composite::Return<MapItem>;
        return Composite<MapItem, MapImpl>(MapImpl(f(std::move(item))));
      });
    }

    /** Convert this to a boxed representation. */
    Composite<Item> into_boxed() && {
      using ResultImpl = internal::composite::BoxedImpl<Item>;
      return Composite<Item>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Composite<Item>() && {
      using ResultImpl = internal::composite::BoxedImpl<Item>;
      return Composite<Item>(ResultImpl(std::move(impl)));
    }

    /** Run the computation by the specified initial disposable handler within `Event<std::tuple<Item, Disposable<>>>`. */
#ifdef DVCOMPUTE_CONCEPTS
    EventLike<std::tuple<Item, Disposable<>>> auto run(Disposable<>&& disposable) && {
#else
    auto run(Disposable<>&& disposable) && {
#endif
      auto fn = [impl{std::move(impl)}, disposable{std::move(disposable)}](const Point* p) mutable {
        return std::move(impl)(std::move(disposable), p);
      };
      return Event<std::tuple<Item, Disposable<>>, decltype(fn)>(std::move(fn));
    }

    /** Run the computation by ignoring disposable handlers within `Event<Item>`. */
#ifdef DVCOMPUTE_CONCEPTS
    EventLike<Item> auto run_() && {
#else
    auto run_() && {
#endif
      return std::move(*this)
        .run(empty_disposable())
        .map([](std::tuple<Item, Disposable<>>&& x) {
          return std::move(std::get<0>(x));
        });
    }
  };

  namespace internal {

    namespace composite {

      /** @private */
      template<typename Item, typename Impl>
      inline Impl&& move_impl(Composite<Item, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /** Create a `Composite` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Item> auto pure_composite(const Item& item) {
#else
  inline auto pure_composite(const Item& item) {
#endif
    using ResultImpl = internal::composite::Return<Item>;
    return Composite<Item, ResultImpl>(ResultImpl(item));
  }

  /** Create a `Composite` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Item> auto pure_composite(Item&& item) {
#else
  inline auto pure_composite(Item&& item) {
#endif
    using ResultImpl = internal::composite::Return<Item>;
    return Composite<Item, ResultImpl>(ResultImpl(std::move(item)));
  }

  /**
   * Delay the `Composite` computation and return the resulting compound `Composite`
   * computation, where `DelayFn` is a function that returns an intermediate `Composite`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_composite(DelayFn&& f) requires CompositeDelayFn<DelayFn> {
#else
  inline auto delay_composite(DelayFn&& f) {
#endif
    return pure_composite(Unit()).and_then([f{std::move(f)}](Unit&& unit) mutable {
      return f();
    });
  }

  /**
   * Construct a new `Composite<Item>` computation by the specified closure `ConsFn`,
   * which must be a function of the `Disposable<>` handler and `Point` pointer that returns 
   * a tuple of `Item` and new `Disposable<>`.
   */
  template<typename ConsFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_composite(ConsFn&& f) requires CompositeConsFn<ConsFn> {
#else
  inline auto cons_composite(ConsFn&& f) {
#endif
    using Tuple = typename std::invoke_result_t<ConsFn, Disposable<>&&, const Point*>::item_type;
    using Traits = tuple_traits<Tuple>;
    using Item = typename Traits::template arg<0>::type;
    auto fn = [f{std::move(f)}](Disposable<>&& disposable, const Point *p) mutable { return f(std::move(disposable), p); };
    return Composite<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Composite<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Item> auto into_composite(Composite<Item, Impl>&& from) {
#else
  inline auto into_composite(Composite<Item, Impl>&& from) {
#endif
    return std::move(from);
  }

  /** Convert the specified computation to `Composite<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Item> auto into_composite(Event<Item, Impl>&& from) {
#else
  inline auto into_composite(Event<Item, Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](Disposable<>&& disposable, const Point *p) mutable { 
      Result<Item> res { std::move(from)(p) };
      if (Item* item = get_result_if(&res)) {
        return Result<std::tuple<Item, Disposable<>>>(std::make_tuple(std::move(*item), std::move(disposable)));
      } else {
        return error_result<std::tuple<Item, Disposable<>>>(std::move(res));
      }
    };
    return Composite<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Composite<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Item> auto into_composite(Simulation<Item, Impl>&& from) {
#else
  inline auto into_composite(Simulation<Item, Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](Disposable<>&& disposable, const Point *p) mutable { 
      Result<Item> res { std::move(from)(p->run) };
      if (Item* item = get_result_if(&res)) {
        return Result<std::tuple<Item, Disposable<>>>(std::make_tuple(std::move(*item), std::move(disposable)));
      } else {
        return error_result<std::tuple<Item, Disposable<>>>(std::move(res));
      }
    };
    return Composite<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Composite<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Item> auto into_composite(Parameter<Item, Impl>&& from) {
#else
  inline auto into_composite(Parameter<Item, Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](Disposable<>&& disposable, const Point *p) mutable { 
      Result<Item> res { std::move(from)(p->run) };
      if (Item* item = get_result_if(&res)) {
        return Result<std::tuple<Item, Disposable<>>>(std::make_tuple(std::move(*item), std::move(disposable)));
      } else {
        return error_result<std::tuple<Item, Disposable<>>>(std::move(res));
      }
    };
    return Composite<Item, decltype(fn)>(std::move(fn));
  }

  /** Add a `Disposable` action within `Composite<Unit>`. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline CompositeLike<Unit> auto disposable_composite(Disposable<Impl>&& action) {
#else
  inline auto disposable_composite(Disposable<Impl>&& action) {
#endif
    auto fn = [action{std::move(action)}](Disposable<>&& disposable, const Point* p) mutable {
      return Result<std::tuple<Unit, Disposable<>>>(std::make_tuple(Unit(), 
        std::move(disposable).merge(std::move(action)).operator Disposable<>()));
    };
    return Composite<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations, where the final computation has
   * type `Composite<std::vector<Item>>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  CompositeLike<std::vector<Item>> auto composite_sequence(std::vector<Composite<Item, Impl>>&& comps) {
#else
  auto composite_sequence(std::vector<Composite<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](Disposable<>&& disposable, const Point *p) mutable {
      std::vector<Item> result;
      Disposable<> disposable2 { std::move(disposable) };
      for (auto& comp : comps) {
        Result<std::tuple<Item, Disposable<>>> res { std::move(comp)(std::move(disposable2), p) };
        if (auto* item = get_result_if(&res)) [[likely]] {
          result.emplace_back(std::move(std::get<0>(*item)));
          disposable2 = std::move(std::get<1>(*item));
        } else {
          return error_result<std::tuple<std::vector<Item>, Disposable<>>>(std::move(res));
        }
      }
      return Result<std::tuple<std::vector<Item>, Disposable<>>>(std::make_tuple(std::move(result), std::move(disposable2)));
    };
    return Composite<std::vector<Item>, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations for performing side effects,
   * when the intermediate results are discarded, but the final computation
   * has type `Composite<Unit>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  CompositeLike<Unit> auto composite_sequence_(std::vector<Composite<Item, Impl>>&& comps) {
#else
  auto composite_sequence_(std::vector<Composite<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](Disposable<>&& disposable, const Point *p) mutable {
      Disposable<> disposable2 { std::move(disposable) };
      for (auto& comp : comps) {
        Result<std::tuple<Item, Disposable<>>> res { std::move(comp)(std::move(disposable2), p) };
        if (auto* item = get_result_if(&res)) [[likely]] {
          disposable2 = std::move(std::get<1>(*item));
        } else {
          return error_result<std::tuple<Unit, Disposable<>>>(std::move(res));
        }
      }
      return Result<std::tuple<Unit, Disposable<>>>(std::make_tuple(Unit(), std::move(disposable2)));
    };
    return Composite<Unit, decltype(fn)>(std::move(fn));
  }
}

#endif /* dvcompute_composite_h */

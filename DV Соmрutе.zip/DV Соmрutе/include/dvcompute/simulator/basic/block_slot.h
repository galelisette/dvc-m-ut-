/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_slot_h
#define dvcompute_block_slot_h

#include <functional>

#include "../../dvcompute_ns.h"
#include "types.h"
#include "block.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace slot {

      namespace block {

        /** The boxed version of the implementation function for the block slot. */
        template<typename Input, typename Output>
          using BoxedImpl = std::function<Block<Input, Output>()>;
      }
    }
  }

  /** A slot to connect blocks that take `Input` and return `Output`. */
  template<typename Input, typename Output, typename Impl = DVCOMPUTE_NS::internal::slot::block::BoxedImpl<Input, Output>>
  class BlockSlot;

#ifdef DVCOMPUTE_CONCEPTS

  /** Whether `Self` is actually a function that returns a `Block<Input, Output>` computation. */
  template<typename Self, typename Input, typename Output>
  concept BlockSlotImpl = std::is_convertible_v<std::invoke_result_t<typename std::remove_reference_t<Self>>, Block<Input, Output>>;

  /** Whether `Self` is actually a `BlockSlot<Input, Output>` computation. */
  template<typename Self, typename Input, typename Output>
  concept BlockSlotLike = std::is_convertible_v<Self, BlockSlot<Input, Output>>;

#endif /* DVCOMPUTE_CONCEPTS */

  /** A slot to connect blocks that take `Input` and return `Output`. */
  template<typename Input, typename Output, typename Impl>
  class BlockSlot {

    /** The function that returns a new block each time it is called. */
    SharedPtr<Impl> impl;

  public:

    /** Create an empty slot. */
    explicit BlockSlot() noexcept {}

    /** Create a slot that will be defined later. */
    explicit BlockSlot(SharedPtrLateInit tag) : impl(tag) {}

    /** Create a new slot by the specified function that returns `Block<Input, Output>` computations. */
#ifdef DVCOMPUTE_CONCEPTS
    explicit BlockSlot(Impl&& impl_arg) requires BlockSlotImpl<Impl, Input, Output> : impl(mk_shared(std::move(impl_arg))) {}
#else
    explicit BlockSlot(Impl&& impl_arg) : impl(mk_shared(std::move(impl_arg))) {}
#endif

    BlockSlot(const BlockSlot&) = default;
    BlockSlot(BlockSlot&&) = default;

    BlockSlot& operator=(const BlockSlot&) = default;
    BlockSlot& operator=(BlockSlot&&) = default;

    /** Return a new `Block<Input, Output>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    BlockLike<Input, Output> auto operator()() const {
#else
    auto operator()() const {
#endif
      return (*impl)();
    }

    /** Combine this computation with the next `BlockSlot<Output, NextOutput>` within the resulting `BlockSlot<Input, NextOutput>`. */
    template<typename NextOutput, typename NextImpl>
#ifdef DVCOMPUTE_CONCEPTS
    BlockSlotLike<Input, NextOutput> auto and_then(const BlockSlot<Output, NextOutput, NextImpl> &next) const {
#else
    auto and_then(const BlockSlot<Output, NextOutput, NextImpl> &next) const {
#endif
      auto fn = [impl{impl}, next{next}]() {
        return (*impl)().and_then(next());
      };
      return BlockSlot<Input, NextOutput, decltype(fn)>(std::move(fn));
    }

    /** Convert to the boxed representation. */
    BlockSlot<Input, Output> to_boxed() const {
      return BlockSlot<Input, Output>([impl{impl}]() {
        return (*impl)().into_boxed();
      });
    }

    operator BlockSlot<Input, Output>() const {
      return to_boxed();
    }

    /** Complete the late initialization. */
    void late_init(Impl&& impl_arg) {
      impl.late_init(std::move(impl_arg));
    }
  };
}

#endif /* dvcompute_block_slot_h */

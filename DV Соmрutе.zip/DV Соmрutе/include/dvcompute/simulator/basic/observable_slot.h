/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_slot_h
#define dvcompute_observable_slot_h

#include <functional>

#include "../../dvcompute_ns.h"
#include "types.h"
#include "observable.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace slot {

      namespace observable {

        /** The boxed version of the implementation function for the observable slot. */
        template<typename Message>
          using BoxedImpl = std::function<Observable<Message>()>;
      }
    }
  }

  /** A slot to connect observables that notify about `Message` events. */
  template<typename Message, typename Impl = DVCOMPUTE_NS::internal::slot::observable::BoxedImpl<Message>>
  class ObservableSlot;

#ifdef DVCOMPUTE_CONCEPTS

  /** Whether `Self` is actually a function that returns an `Observable<Message>` computation. */
  template<typename Self, typename Message>
  concept ObservableSlotImpl = std::is_convertible_v<std::invoke_result_t<typename std::remove_reference_t<Self>>, Observable<Message>>;

  /** Whether `Self` is actually an `ObservableSlot<Message>` computation. */
  template<typename Self, typename Message>
  concept ObservableSlotLike = std::is_convertible_v<Self, ObservableSlot<Message>>;

#endif /* DVCOMPUTE_CONCEPTS */

  /** A slot to connect observables that notify about `Message` events. */
  template<typename Message, typename Impl>
  class ObservableSlot {

    /** The function that returns a new observable each time it is called. */
    SharedPtr<Impl> impl;

  public:

    /** Create an empty slot. */
    explicit ObservableSlot() noexcept {}

    /** Create a slot that will be defined later. */
    explicit ObservableSlot(SharedPtrLateInit tag) : impl(tag) {}

    /** Create a new slot by the specified function that returns `Observable<Message>` computations. */
#ifdef DVCOMPUTE_CONCEPTS
    explicit ObservableSlot(Impl&& impl_arg) requires ObservableSlotImpl<Impl, Message> : impl(mk_shared(std::move(impl_arg))) {}
#else
    explicit ObservableSlot(Impl&& impl_arg) : impl(mk_shared(std::move(impl_arg))) {}
#endif

    ObservableSlot(const ObservableSlot&) = default;
    ObservableSlot(ObservableSlot&&) = default;

    ObservableSlot& operator=(const ObservableSlot&) = default;
    ObservableSlot& operator=(ObservableSlot&&) = default;

    /** Return a new `Observable<Message>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    ObservableLike<Message> auto operator()() const {
#else
    auto operator()() const {
#endif
      return (*impl)();
    }

    /** Transform the messages. */
    template<typename MapFn>
    auto map(const MapFn &f) const {
      using MapMessage = std::invoke_result_t<MapFn, const Message*>;
      auto fn = [impl{impl}, f{f}]() {
        return (*impl)().map(MapFn { f });
      };
      return ObservableSlot<MapMessage, decltype(fn)>(std::move(fn));
    }

    /** Hold the messages for the specified time interval. */
#ifdef DVCOMPUTE_CONCEPTS
    ObservableSlotLike<Message> auto hold(double dt) const {
#else
    auto hold(double dt) const {
#endif
      auto fn = [impl{impl}, dt]() {
        return (*impl)().hold(dt);
      };
      return ObservableSlot<Message, decltype(fn)>(std::move(fn));
    }

    /** Merge two signal slots. */
    template<typename OtherImpl>
#ifdef DVCOMPUTE_CONCEPTS
    ObservableSlotLike<Message> auto merge(const ObservableSlot<Message, OtherImpl> &other) const {
#else
    auto merge(const ObservableSlot<Message, OtherImpl> &other) const {
#endif
      auto fn = [impl{impl}, other{other}]() {
        return (*impl)().merge(other());
      };
      return ObservableSlot<Message, decltype(fn)>(std::move(fn));
    }

    /** Convert to the boxed representation. */
    ObservableSlot<Message> to_boxed() const {
      return ObservableSlot<Message>([impl{impl}]() {
        return (*impl)().into_boxed();
      });
    }

    operator ObservableSlot<Message>() const {
      return to_boxed();
    }

    /** Complete the late initialization. */
    void late_init(Impl&& impl_arg) {
      impl.late_init(std::move(impl_arg));
    }
  };
}

#endif /* dvcompute_observable_slot_h */

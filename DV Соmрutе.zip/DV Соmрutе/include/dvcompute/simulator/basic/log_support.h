/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_log_support_h
#define dvcompute_log_support_h

#if defined(USE_SPDLOG)
#include "spdlog/spdlog.h"
#endif /* USE_SPDLOG */

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTELOG_NS {

#if defined(USE_SPDLOG)

  template<typename... Args>
  inline constexpr void error(fmt::format_string<Args...> fmt, Args&&... args) {
    spdlog::error(fmt, args...);
  }

  template<typename... Args>
  inline constexpr void warn(fmt::format_string<Args...> fmt, Args&&... args) {
    spdlog::warn(fmt, args...);
  }

  template<typename... Args>
  inline constexpr void info(fmt::format_string<Args...> fmt, Args&&... args) {
    spdlog::info(fmt, args...);
  }

  template<typename... Args>
  inline constexpr void debug(fmt::format_string<Args...> fmt, Args&&... args) {
    spdlog::debug(fmt, args...);
  }

#else

  template<typename Fmt, typename... Args>
  inline constexpr void error(const Fmt& fmt, Args&&... args) {}

  template<typename Fmt, typename... Args>
  inline constexpr void warn(const Fmt& fmt, Args&&... args) {}

  template<typename Fmt, typename... Args>
  inline constexpr void info(const Fmt& fmt, Args&&... args) {}

  template<typename Fmt, typename... Args>
  inline constexpr void debug(const Fmt& fmt, Args&&... args) {}

#endif /* USE_SPDLOG */

}

#endif /* dvcompute_log_support_h */

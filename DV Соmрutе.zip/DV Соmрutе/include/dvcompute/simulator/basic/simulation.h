/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_simulation_h
#define dvcompute_simulation_h

#include <functional>
#include <vector>
#include <exception>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "specs.h"
#include "result.h"
#include "parameter.h"
#include "simulation_fn.h"

namespace DVCOMPUTE_NS {

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)
  /** Logical process context. */
  struct LogicalProcessContext;
#endif /* defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE) */

  /** Indicates that the simulation was aborted. */
  class SimulationAbort : public std::exception {
    const char* msg;

  public:

    explicit SimulationAbort() noexcept : msg(nullptr) {}
    explicit SimulationAbort(const char* msg_arg) noexcept : msg(msg_arg) {}

    SimulationAbort(const SimulationAbort&) = default;
    SimulationAbort(SimulationAbort&&) = default;

    SimulationAbort& operator=(const SimulationAbort&) = default;
    SimulationAbort& operator=(SimulationAbort&&) = default;

    const char* what() const noexcept override {
      return msg;
    }
  };

  namespace internal {

    namespace simulation {

      // /** @private */
      // template<typename Item>
      // using BoxedImpl = std::function<Result<Item>(const Run*)>;

      /** @private */
      template<typename Item, typename ThenItem, typename Self, typename BindFn>
      class Then {

        Self comp;
        BindFn k;

      public:

        explicit Then(Self &&comp_arg, BindFn &&k_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(BindFn(std::move(k_arg)))) :
          comp(std::move(comp_arg)), k(std::move(k_arg))
        {}

        Then(Then<Item, ThenItem, Self, BindFn> &&other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(Then<Item, ThenItem, Self, BindFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Item, ThenItem, Self, BindFn> &other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(const Then<Item, ThenItem, Self, BindFn> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<ThenItem> operator()(const Run *r) && {
          Result<Item> res { std::move(comp)(r) };
          if (auto *item = get_result_if<Item>(&res)) [[likely]] {
            return k(std::move(*item))(r);
          } else {
            return error_result<ThenItem>(std::move(res));
          }
        }
      };

      /** @private */
      template<typename Item>
      class Return {

        Item item;

      public:

        explicit Return(const Item &item_arg) : item(item_arg) {}
        explicit Return(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : item(std::move(item_arg)) {}

        Return(Return<Item> &&other) = default;
        Return<Item>& operator=(Return<Item> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Return(const Return<Item> &other) = default;
        Return<Item>& operator=(const Return<Item> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Run *r) && {
          return Result<Item>(std::move(item));
        }
      };

      /** @private */
      template<typename Item, typename Self, typename Finalization>
      class Finally {

        Self comp;
        Finalization final_comp;

      public:

        explicit Finally(Self&& comp_arg, Finalization&& final_comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(Finalization(std::move(final_comp_arg)))) :
          comp(std::move(comp_arg)), final_comp(std::move(final_comp_arg))
        {}

        Finally(Finally<Item, Self, Finalization>&& other) = default;
        Finally<Item, Self, Finalization>& operator=(Finally<Item, Self, Finalization>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Finally(const Finally<Item, Self, Finalization>& other) = default;
        Finally<Item, Self, Finalization>& operator=(const Finally<Item, Self, Finalization>& other) = default;

#endif

        Result<Item> operator()(const Run* r) && {
          Result<Item> item { std::move(comp)(r) };
          Result<Unit> unit { std::move(final_comp)(r) };

          if (get_result_if(&unit)) {
            return item;

          } else if (auto e2 = get_cancel_result_if(&unit)) {

            if (get_result_if<Item>(&item)) {
              return *e2;
            } else if (auto e = get_retry_result_if(&item)) {
              return *e;   // it has a priority
            } else {
              return *e2;
            }

          } else if (auto e2 = get_retry_result_if(&unit)) {
            return *e2;

          } else {
            throw UnknownResult();
          }
        }
      };
    }
  }

  /** Represents a computation that is called within simulation run. */
  template<typename Item, typename Impl = internal::simulation::BoxedImpl<Item>>
  class Simulation;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace simulation {

      /** Whether `F` is a function that takes `Arg` and returns a `Simulation` computation. */
      template<typename F, typename Arg, typename Item>
      concept SimulationBindFn3 = std::is_invocable_r_v<Simulation<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns a `Simulation` computation. */
      template<typename F, typename Arg>
      concept SimulationBindFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires SimulationBindFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns a `Simulation` computation. */
      template<typename F, typename Item>
      concept SimulationDelayFn2 = std::is_invocable_r_v<Simulation<Item>, F>;

      /** Whether `F` is a function that returns a `Simulation` computation. */
      template<typename F>
      concept SimulationDelayFn1 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires SimulationDelayFn2<F, typename std::invoke_result_t<F>::item_type>;
      };

      /** Whether `F` is a function that takes the `Run` pointer and returns a `Result` value. */
      template<typename F, typename Item>
      concept SimulationConsFn2 = std::is_invocable_r_v<Result<Item>, F, const Run*>;

      /** Whether `F` is a function that takes the `Run` pointer and returns a `Result` value. */
      template<typename F>
      concept SimulationConsFn1 = requires {
        typename std::invoke_result_t<F, const Run*>::item_type;
        requires SimulationConsFn2<F, typename std::invoke_result_t<F, const Run*>::item_type>;
      };
    }
  }

  /** Whether `Self` is actually a `Simulation<Item>` computation. */
  template<typename Self, typename Item>
  concept SimulationLike = std::is_convertible_v<Self, Simulation<Item>>;

  /** Whether `F` is a function that takes `Arg` and returns a `Simulation` computation. */
  template<typename F, typename Arg>
  concept SimulationBindFn = internal::simulation::SimulationBindFn2<F, Arg>;

  /** Whether `F` is a function that returns a `Simulation` computation. */
  template<typename F>
  concept SimulationDelayFn = internal::simulation::SimulationDelayFn1<F>;

  /** Whether `F` is a function that takes the `Run` pointer and returns a `Result` value. */
  template<typename F>
  concept SimulationConsFn = internal::simulation::SimulationConsFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace simulation {

      template<typename Item, typename Impl>
      inline Impl&& move_impl(Simulation<Item, Impl>&& comp);
    }
  }

  /** Represents a computation that is called within simulation run. */
  template<typename Item, typename Impl>
  class Simulation {

    Impl impl;

    template<typename Item2, typename Impl2>
    friend inline Impl2&& internal::simulation::move_impl(Simulation<Item2, Impl2>&& comp);

  public:

    using item_type = Item;

    explicit Simulation(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) : impl(std::move(impl_arg)) {}

    Simulation(Simulation<Item, Impl>&& other) = default;
    Simulation<Item, Impl>& operator=(Simulation<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Simulation(const Simulation<Item, Impl>& other) = default;
    Simulation<Item, Impl>& operator=(const Simulation<Item, Impl>& other) = default;

    /** Copy the computation. */
    Simulation<Item, Impl> copy() const {
      return Simulation<Item, Impl>(*this);
    }

#endif

    /** Call the computation. */
    DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Run *r) && {
      return std::move(impl)(r);
    }

    /**
     * Bind this with a continuation and return the compound resulting `Simulation<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Simulation<ThenItem>` computation.
     */
    template<typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && requires SimulationBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::simulation::Then<Item, ThenItem, Impl, BindFn>;
      return Simulation<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Bind this with a continuation and return the compound resulting `Simulation<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Simulation<ThenItem>` computation.
     */
    template<typename BindFn>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && requires SimulationBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::simulation::Then<Item, ThenItem, Impl, BindFn>;
      return Simulation<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Map the computed value and return the compound resulting `Simulation<MapItem>`
     * computation, where `MapFn` is a function that takes an `Item` and then transforms it
     * to `MapItem`.
     */
    template<typename MapFn>
    DVCOMPUTE_ALWAYS_INLINE auto map(MapFn&& f) && {
      return std::move(*this).and_then([f{std::move(f)}](Item&& item) mutable {
        using MapItem = std::invoke_result_t<MapFn, Item&&>;
        using MapImpl = internal::simulation::Return<MapItem>;
        return Simulation<MapItem, MapImpl>(MapImpl(f(std::move(item))));
      });
    }

    /** Convert this to a boxed representation. */
    Simulation<Item> into_boxed() && {
      using ResultImpl = internal::simulation::BoxedImpl<Item>;
      return Simulation<Item>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Simulation<Item>() && {
      using ResultImpl = internal::simulation::BoxedImpl<Item>;
      return Simulation<Item>(ResultImpl(std::move(impl)));
    }

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)

    /** Run the simulation by the specified specs. */
    Result<Item> run(const Specs* specs) && {
      Run r(specs);
      return std::move(impl)(&r);
    }

    /** Run the simulation by the specified specs, run index and run count. */
    Result<Item> run_by_index(const Specs* specs, int run_index, int run_count) && {
      Run r(specs, run_index, run_count);
      return std::move(impl)(&r);
    }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** Run the simulation by the specified specs. */
    Result<Item> run(const Specs* specs, LogicalProcessContext* lp_context) && {
      Run r(specs, lp_context);
      return std::move(impl)(&r);
    }

    /** Run the simulation by the specified specs, run index and run count. */
    Result<Item> run_by_index(const Specs* specs, LogicalProcessContext* lp_context, int run_index, int run_count) && {
      Run r(specs, lp_context, run_index, run_count);
      return std::move(impl)(&r);
    }

#endif /* DVCOMPUTE_SEQUENTIAL || DVCOMPUTE_DISTRIBUTED || DVCOMPUTE_BRANCHED || DVCOMPUTE_CONSERVATIVE */
  };

  namespace internal {

    namespace simulation {

      /** @private */
      template<typename Item, typename Impl>
      inline Impl&& move_impl(Simulation<Item, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /** Create a `Simulation` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline SimulationLike<Item> auto pure_simulation(const Item& item) {
#else
  inline auto pure_simulation(const Item& item) {
#endif
    using ResultImpl = internal::simulation::Return<Item>;
    return Simulation<Item, ResultImpl>(ResultImpl(item));
  }

  /** Create a `Simulation` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline SimulationLike<Item> auto pure_simulation(Item&& item) {
#else
  inline auto pure_simulation(Item&& item) {
#endif
    using ResultImpl = internal::simulation::Return<Item>;
    return Simulation<Item, ResultImpl>(ResultImpl(std::move(item)));
  }

  /**
   * Delay the `Simulation` computation and return the resulting compound `Simulation<Item>`
   * computation, where `DelayFn` is a function that returns an intermediate `Simulation`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_simulation(DelayFn&& f) requires SimulationDelayFn<DelayFn> {
#else
  inline auto delay_simulation(DelayFn&& f) {
#endif
    return pure_simulation(Unit()).and_then([f{std::move(f)}](Unit&& unit) mutable {
      return f();
    });
  }

  /**
   * Construct a new `Simulation<Item>` computation by the specified closure `ConsFn`,
   * which must be a function of the `Run` pointer that returns an `Item`.
   */
  template<typename ConsFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_simulation(ConsFn&& f) requires SimulationConsFn<ConsFn> {
#else
  inline auto cons_simulation(ConsFn&& f) {
#endif
    using Item = typename std::invoke_result_t<ConsFn, const Run*>::item_type;
    auto fn = [f{std::move(f)}](const Run *r) mutable { return f(r); };
    return Simulation<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Simulation<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline SimulationLike<Item> auto into_simulation(Simulation<Item, Impl>&& from) {
#else
  inline auto into_simulation(Simulation<Item, Impl>&& from) {
#endif
    return std::move(from);
  }

  /** Convert the specified computation to `Simulation<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline SimulationLike<Item> auto into_simulation(Parameter<Item, Impl>&& from) {
#else
  inline auto into_simulation(Parameter<Item, Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](const Run *r) mutable { return from(r); };
    return Simulation<Item, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations, where the final computation has
   * type `Simulation<std::vector<Item>>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  SimulationLike<std::vector<Item>> auto simulation_sequence(std::vector<Simulation<Item, Impl>>&& comps) {
#else
  auto simulation_sequence(std::vector<Simulation<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Run *r) mutable {
      std::vector<Item> result;
      for (auto& comp : comps) {
        Result<Item> res { std::move(comp)(r) };
        if (auto item = get_result_if<Item>(&res)) [[likely]] {
          result.emplace_back(std::move(*item));
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<std::vector<Item>>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<std::vector<Item>>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<std::vector<Item>>(std::move(result));
    };
    return Simulation<std::vector<Item>, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations for performing side effects,
   * when the intermediate results are discarded, but the final computation
   * has type `Simulation<Unit>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  SimulationLike<Unit> auto simulation_sequence_(std::vector<Simulation<Item, Impl>>&& comps) {
#else
  auto simulation_sequence_(std::vector<Simulation<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Run *r) mutable {
      for (auto& comp : comps) {
        Result<Item> res { std::move(comp)(r) };
        if (get_result_if<Item>(&res)) [[likely]] {
          continue;
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<Unit>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<Unit>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<Unit>(Unit());
    };
    return Simulation<Unit, decltype(fn)>(std::move(fn));
  }

  /** Call the specified finalization block within the resulting compound `Simulation<Item>` computation. */
  template<typename Item, typename Impl, typename FinalImpl>
#ifdef DVCOMPUTE_CONCEPTS
  SimulationLike<Item> auto finally_simulation(Simulation<Item, Impl>&& comp, Simulation<Unit, FinalImpl>&& final_comp) {
#else
  auto finally_simulation(Simulation<Item, Impl>&& comp, Simulation<Unit, FinalImpl>&& final_comp) {
#endif
    using ResultImpl = internal::simulation::Finally<Item, Impl, FinalImpl>;
    return Simulation<Item, ResultImpl>(ResultImpl(internal::simulation::move_impl(std::move(comp)), internal::simulation::move_impl(std::move(final_comp))));
  }
}

#endif /* dvcompute_simulation_h */

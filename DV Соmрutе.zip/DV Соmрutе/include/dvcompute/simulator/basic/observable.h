/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_h
#define dvcompute_observable_h

#include <functional>
#include <vector>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "specs.h"
#include "disposable.h"
#include "event.h"
#include "observer.h"
#include "ref.h"
#include "observable_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace observable {

      // /** @private */
      // template<typename Message>
      //   using BoxedImpl = std::function<Event<Disposable<>>(Observer<Message, Unit>&&)>;

      /** @private */
      template<typename Message, typename MapMessage, typename Self, typename MapFn>
      class Map {

        Self comp;
        MapFn f;

      public:

        explicit Map(Self &&comp_arg, MapFn &&f_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(MapFn(std::move(f_arg)))) :
          comp(std::move(comp_arg)), f(std::move(f_arg))
        {}

        Map(Map<Message, MapMessage, Self, MapFn> &&other) = default;
        Map<Message, MapMessage, Self, MapFn>& operator=(Map<Message, MapMessage, Self, MapFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Map(const Map<Message, MapMessage, Self, MapFn> &other) = default;
        Map<Message, MapMessage, Self, MapFn>& operator=(const Map<Message, MapMessage, Self, MapFn> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          auto fn = [f{std::move(f)}, obs{std::move(obs)}](const Message *msg, const Point *p) {
            MapMessage msg2(f(msg));
            return obs(&msg2, p);
          };
          Observer<Message, Unit, decltype(fn)> obs2(std::move(fn));
          return std::move(comp)(std::move(obs2));
        }
      };

      /** @private */
      template<typename Message, typename MapMessage, typename Self, typename MapCFn>
      class MapC {

        Self comp;
        MapCFn f;

      public:

        explicit MapC(Self &&comp_arg, MapCFn &&f_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(MapCFn(std::move(f_arg)))) :
          comp(std::move(comp_arg)), f(std::move(f_arg))
        {}

        MapC(MapC<Message, MapMessage, Self, MapCFn> &&other) = default;
        MapC<Message, MapMessage, Self, MapCFn>& operator=(MapC<Message, MapMessage, Self, MapCFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        MapC(const MapC<Message, MapMessage, Self, MapCFn> &other) = default;
        MapC<Message, MapMessage, Self, MapCFn>& operator=(const MapC<Message, MapMessage, Self, MapCFn> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          auto fn = [f{std::move(f)}, obs{std::move(obs)}](const Message *msg, const Point *p) {
            Result<MapMessage> x { f(msg)(p) };
            if (MapMessage* msg2 = get_result_if<MapMessage>(&x)) [[likely]] {
              return obs(msg2, p);
            } else {
              return error_result<Unit>(std::move(x));
            }
          };
          Observer<Message, Unit, decltype(fn)> obs2(std::move(fn));
          return std::move(comp)(std::move(obs2));
        }
      };

      /** @private */
      template<typename Message, typename Self, typename PredFn>
      class Filter {

        Self comp;
        PredFn pred;

      public:

        explicit Filter(Self &&comp_arg, PredFn &&pred_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(PredFn(std::move(pred_arg)))) :
          comp(std::move(comp_arg)), pred(std::move(pred_arg))
        {}

        Filter(Filter<Message, Self, PredFn> &&other) = default;
        Filter<Message, Self, PredFn>& operator=(Filter<Message, Self, PredFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Filter(const Filter<Message, Self, PredFn> &other) = default;
        Filter<Message, Self, PredFn>& operator=(const Filter<Message, Self, PredFn> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          auto fn = [pred{std::move(pred)}, obs{std::move(obs)}](const Message *msg, const Point *p) {
            if (pred(msg)) {
              return obs(msg, p);
            } else {
              return Result<Unit>(Unit());
            }
          };
          Observer<Message, Unit, decltype(fn)> obs2(std::move(fn));
          return std::move(comp)(std::move(obs2));
        }
      };

      /** @private */
      template<typename Message, typename Self, typename PredCFn>
      class FilterC {

        Self comp;
        PredCFn pred;

      public:

        explicit FilterC(Self &&comp_arg, PredCFn &&pred_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(PredCFn(std::move(pred_arg)))) :
          comp(std::move(comp_arg)), pred(std::move(pred_arg))
        {}

        FilterC(FilterC<Message, Self, PredCFn> &&other) = default;
        FilterC<Message, Self, PredCFn>& operator=(FilterC<Message, Self, PredCFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        FilterC(const FilterC<Message, Self, PredCFn> &other) = default;
        FilterC<Message, Self, PredCFn>& operator=(const FilterC<Message, Self, PredCFn> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          auto fn = [pred{std::move(pred)}, obs{std::move(obs)}](const Message *msg, const Point *p) {
            Result<bool> x { pred(msg)(p) };
            if (bool* f = get_result_if<bool>(&x)) [[likely]] {
              if (*f) {
                return obs(msg, p);
              } else {
                return Result<Unit>(Unit());
              }
            } else {
              return error_result<Unit>(std::move(x));
            }
          };
          Observer<Message, Unit, decltype(fn)> obs2(std::move(fn));
          return std::move(comp)(std::move(obs2));
        }
      };

      /** @private */
      template<typename Message, typename Left, typename Right>
      class Merge {

        Left left;
        Right right;

      public:

        explicit Merge(Left &&left_arg, Right &&right_arg)
          noexcept(noexcept(Left(std::move(left_arg))) && noexcept(Right(std::move(right_arg)))) :
          left(std::move(left_arg)), right(std::move(right_arg))
        {}

        Merge(Merge<Message, Left, Right> &&other) = default;
        Merge<Message, Left, Right>& operator=(Merge<Message, Left, Right> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Merge(const Merge<Message, Left, Right> &other) = default;
        Merge<Message, Left, Right>& operator=(const Merge<Message, Left, Right> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          SharedPtr<Obs> x { mk_shared(Obs(std::move(obs))) };

          auto h1 = std::move(left)(cons_observer([=](const Message* msg, const Point* p) {
            return x->operator()(msg, p);
          }));
          auto h2 = std::move(right)(cons_observer([=](const Message* msg, const Point* p) {
            return x->operator()(msg, p);
          }));

          return std::move(h1).and_then([h2{std::move(h2)}](Disposable<>&& y1) mutable {
            return std::move(h2).and_then([y1{std::move(y1)}](Disposable<>&& y2) mutable {
              return pure_event(std::move(y1).merge(std::move(y2)).operator Disposable<>());
            });
          });
       }
      };

      /** @private */
      template<typename Message>
      class Empty {
      public:

        explicit Empty() noexcept {}

        Empty(Empty<Message> &&other) = default;
        Empty<Message>& operator=(Empty<Message> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Empty(const Empty<Message> &other) = default;
        Empty<Message>& operator=(const Empty<Message> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          Disposable<> comp = empty_disposable();
          return pure_event(std::move(comp));
        }
      };

      /** @private */
      template<typename Message, typename Self>
      class Hold {

        Self comp;
        double dt;

      public:

        explicit Hold(Self &&comp_arg, double dt_arg)
          noexcept(noexcept(Self(std::move(comp_arg)))) :
          comp(std::move(comp_arg)), dt(dt_arg)
        {}

        Hold(Hold<Message, Self> &&other) = default;
        Hold<Message, Self>& operator=(Hold<Message, Self> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Hold(const Hold<Message, Self> &other) = default;
        Hold<Message, Self>& operator=(const Hold<Message, Self> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          RefPtr<bool> r { mk_shared(Ref<bool>(false)) };
          auto fn = [obs{std::move(obs)}, dt{dt}, r](const Message *msg, const Point *p) mutable {
            auto comp { 
              cons_event([obs{std::move(obs)}, r, msg{*msg}](const Point* p) mutable {
                bool x = r->read_at(p);
                if (!x) {
                  return obs.operator()(&msg, p);
                } else {
                  return Result<Unit>(Unit());
                }
              })
            };
            return enqueue_event(p->time + dt, std::move(comp))
              .operator()(p);
          };

          Observer<Message, Unit, decltype(fn)> obs2(std::move(fn));
          auto h { std::move(comp)(std::move(obs2)) };
          Disposable<> h2 = cons_disposable([r, h{std::move(h)}](const Point* p) mutable {
            r->write_at(true, p);
            auto x { std::move(h).operator()(p) };
            if (Disposable<>* disposable = get_result_if<Disposable<>>(&x)) [[likely]] {
              return std::move(*disposable).operator()(p);
            } else {
              return error_result<Unit>(std::move(x));
            }
          });

          return pure_event(std::move(h2));
        }
      };

      /** @private */
      template<typename Message, typename Self, typename IntervalImpl>
      class HoldC {

        Self comp;
        Event<double, IntervalImpl> dt_comp;

      public:

        explicit HoldC(Self &&comp_arg, Event<double, IntervalImpl> && dt_comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(Event<double, IntervalImpl>(std::move(dt_comp_arg)))) :
          comp(std::move(comp_arg)), dt_comp(std::move(dt_comp_arg))
        {}

        HoldC(HoldC<Message, Self, IntervalImpl> &&other) = default;
        HoldC<Message, Self, IntervalImpl>& operator=(HoldC<Message, Self, IntervalImpl> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        HoldC(const HoldC<Message, Self, IntervalImpl> &other) = default;
        HoldC<Message, Self, IntervalImpl>& operator=(const HoldC<Message, Self, IntervalImpl> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          RefPtr<bool> r { mk_shared(Ref<bool>(false)) };
          auto fn = [obs{std::move(obs)}, dt_comp{std::move(dt_comp)}, r](const Message *msg, const Point *p) mutable {
            auto comp { 
              cons_event([obs{std::move(obs)}, r, msg{*msg}](const Point* p) mutable {
                bool x = r->read_at(p);
                if (!x) {
                  return obs.operator()(&msg, p);
                } else {
                  return Result<Unit>(Unit());
                }
              })
            };

            auto x { std::move(dt_comp).operator()(p) };
            if (double* dt = get_result_if(&x)) [[likely]] {
              return enqueue_event(p->time + *dt, std::move(comp))
                .operator()(p);
            } else {
              return error_result<Unit>(std::move(x));
            }
          };

          Observer<Message, Unit, decltype(fn)> obs2(std::move(fn));
          auto h { std::move(comp)(std::move(obs2)) };
          Disposable<> h2 = cons_disposable([r, h{std::move(h)}](const Point* p) mutable {
            r->write_at(true, p);
            auto x { std::move(h).operator()(p) };
            if (Disposable<>* disposable = get_result_if<Disposable<>>(&x)) [[likely]] {
              return std::move(*disposable).operator()(p);
            } else {
              return error_result<Unit>(std::move(x));
            }
          });

          return pure_event(std::move(h2));
        }
      };

      /** @private */
      template<typename Fn>
      class Delay {

        Fn fn;

      public:

        explicit Delay(Fn &&fn_arg)
          noexcept(noexcept(Fn(std::move(fn_arg)))) :
          fn(std::move(fn_arg))
        {}

        Delay(Delay<Fn> &&other) = default;
        Delay<Fn>& operator=(Delay<Fn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Delay(const Delay<Fn> &other) = default;
        Delay<Fn>& operator=(const Delay<Fn> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          return std::move(fn)().subscribe(std::move(obs));
        }
      };
    }
  }

  /** The computation that allows notifying about events. */
  template<typename Message, typename Impl = internal::observable::BoxedImpl<Message>>
  class Observable;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace observable {

      /** Whether `F` is a function that takes `const Arg*` and returns an `Event` computation. */
      template<typename F, typename Arg, typename Message>
      concept ObservableMapCFn3 = std::is_invocable_r_v<Event<Message>, F, const Arg*>;

      /** Whether `F` is a function that takes `const Arg*` and returns an `Event` computation. */
      template<typename F, typename Arg>
      concept ObservableMapCFn2 = requires {
        typename std::invoke_result_t<F, const Arg*>::item_type;
        requires ObservableMapCFn3<F, Arg, typename std::invoke_result_t<F, const Arg*>::item_type>;
      };

      /** Whether `F` is a function that returns an `Observable` computation. */
      template<typename F, typename Message>
      concept ObservableDelayFn2 = std::is_invocable_r_v<Observable<Message>, F>;

      /** Whether `F` is a function that returns an `Observable` computation. */
      template<typename F>
      concept ObservableDelayFn1 = requires {
        typename std::invoke_result_t<F>::message_type;
        requires ObservableDelayFn2<F, typename std::invoke_result_t<F>::message_type>;
      };
    }
  }

  /** Whether `Self` is actually an `Observable<Message>` computation. */
  template<typename Self, typename Message>
  concept ObservableLike = std::is_convertible_v<Self, Observable<Message>>;

  /** Whether `F` is a function that takes `const Arg*` and returns an `Event` computation. */
  template<typename F, typename Arg>
  concept ObservableMapCFn = internal::observable::ObservableMapCFn2<F, Arg>;

  /** Whether `F` is a function that takes `const Arg*` and returns a boolean flag. */
  template<typename F, typename Arg>
  concept ObservablePredFn = std::is_invocable_r_v<bool, F, const Arg*>;

  /** Whether `F` is a function that takes `const Arg*` and returns an `Event<bool>` computation. */
  template<typename F, typename Arg>
  concept ObservablePredCFn = std::is_invocable_r_v<Event<bool>, F, const Arg*>;

  /** Whether `F` is a function that returns an `Observable` computation. */
  template<typename F>
  concept ObservableDelayFn = internal::observable::ObservableDelayFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace observable {

      template<typename Message, typename Impl>
      inline Impl&& move_impl(Observable<Message, Impl>&& comp);
    }
  }

  /** The computation that allows notifying about events. */
  template<typename Message, typename Impl>
  class Observable {

    Impl impl;

    template<typename Message2, typename Impl2>
    friend inline Impl2&& internal::observable::move_impl(Observable<Message2, Impl2>&& comp);

  public:

    using message_type = Message;

    explicit Observable(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) :
      impl(std::move(impl_arg))
    {}

    Observable(Observable<Message, Impl>&& other) = default;
    Observable<Message, Impl>& operator=(Observable<Message, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Observable(const Observable<Message, Impl>& other) = default;
    Observable<Message, Impl>& operator=(const Observable<Message, Impl>& other) = default;

    /** Copy the computation. */
    Observable<Message, Impl> copy() const {
      return Observable<Message, Impl>(*this);
    }

#endif

    /**
     * Subscribe the specified `Observer<Message, Unit>` and return an `Event<Disposable<>>` computation
     * that can be used later for unsubscribing from receiving events.
     */
    template<typename Obs>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE EventLike<Disposable<>> auto subscribe(Obs &&obs) && requires ObserverLike<Obs, Message, Unit> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto subscribe(Obs &&obs) && {
#endif
      return std::move(impl)(std::move(obs));
    }

    /**
     * Subscribe the specified `Observer<Message, Unit>` and return an `Event<Unit>` computation
     * without ability to unsubscribe from receiving events.
     */
    template<typename Obs>
#ifdef DVCOMPUTE_CONCEPTS
    EventLike<Unit> auto add(Obs &&obs) && requires ObserverLike<Obs, Message, Unit> {
#else
    auto add(Obs &&obs) && {
#endif
      return std::move(*this)
        .subscribe(std::move(obs))
        .map([](Disposable<>&&) { return Unit(); });
    }

    /**
     * Map the computed value and return the resulting compound `Observable<MapMessage>`
     * computation, where `MapFn` is a function that takes a `const Message` pointer and then transforms it
     * to `MapMessage`.
     */
    template<typename MapFn>
    auto map(MapFn&& f) && {
      using MapMessage = std::invoke_result_t<MapFn, const Message*>;
      using MapImpl = internal::observable::Map<Message, MapMessage, Impl, MapFn>;
      return Observable<MapMessage, MapImpl>(MapImpl(std::move(impl), std::move(f)));
    }

    /**
     * Map the computed value and return the resulting compound `Observable<MapMessage>`
     * computation, where `MapCFn` is a function that takes a `const Message` pointer and then transforms it
     * to `Event<MapMessage>` computation.
     */
    template<typename MapCFn>
#ifdef DVCOMPUTE_CONCEPTS
    auto mapc(MapCFn&& f) && requires ObservableMapCFn<MapCFn, Message> {
#else
    auto mapc(MapCFn&& f) && {
#endif
      using MapMessage = typename std::invoke_result_t<MapCFn, const Message*>::item_type;
      using MapImpl = internal::observable::MapC<Message, MapMessage, Impl, MapCFn>;
      return Observable<MapMessage, MapImpl>(MapImpl(std::move(impl), std::move(f)));
    }

    /**
     * Filter the messages by the specified predicate and return the resulting compound `Observable<Message>`
     * computation, where `PredFn` is a function that takes a `const Message` pointer and then returns a boolean flag
     * whether the message is satisfied to the predicate criteria.
     */
    template<typename PredFn>
#ifdef DVCOMPUTE_CONCEPTS
    ObservableLike<Message> auto filter(PredFn&& pred) && requires ObservablePredFn<PredFn, Message> {
#else
    auto filter(PredFn&& pred) && {
#endif
      using ResultImpl = internal::observable::Filter<Message, Impl, PredFn>;
      return Observable<Message, ResultImpl>(ResultImpl(std::move(impl), std::move(pred)));
    }

    /**
     * Filter the messages by the specified predicate and return the resulting compound `Observable<Message>`
     * computation, where `PredCFn` is a function that takes a `const Message` pointer and then returns an `Event<bool>`
     * computation of the boolean flag indicating whether the message is satisfied to the predicate criteria.
     */
    template<typename PredCFn>
#ifdef DVCOMPUTE_CONCEPTS
    ObservableLike<Message> auto filterc(PredCFn&& pred) && requires ObservablePredCFn<PredCFn, Message> {
#else
    auto filterc(PredCFn&& pred) && {
#endif
      using ResultImpl = internal::observable::FilterC<Message, Impl, PredCFn>;
      return Observable<Message, ResultImpl>(ResultImpl(std::move(impl), std::move(pred)));
    }

    /**
     * Hold the observable signal for the specified time interval.
     */
#ifdef DVCOMPUTE_CONCEPTS
    inline ObservableLike<Message> auto hold(double dt) && {
#else
    inline auto hold(double dt) && {
#endif
      using ResultImpl = internal::observable::Hold<Message, Impl>;
      return Observable<Message, ResultImpl>(ResultImpl(std::move(impl), dt));
    }

    /**
     * Hold the observable signal for time intervals calculated by the specified `Event<double>` computation.
     */
    template<typename IntervalImpl>
#ifdef DVCOMPUTE_CONCEPTS
    ObservableLike<Message> auto holdc(Event<double, IntervalImpl>&& dt_comp) && {
#else
    auto holdc(Event<double, IntervalImpl>&& dt_comp) && {
#endif
      using ResultImpl = internal::observable::HoldC<Message, Impl, IntervalImpl>;
      return Observable<Message, ResultImpl>(ResultImpl(std::move(impl), std::move(dt_comp)));
    }

    /**
     * Merge this computation with another `Observable<Message>` one and then return
     * the resulting compound `Observable<Message>` computation.
     */
    template<typename OtherImpl>
#ifdef DVCOMPUTE_CONCEPTS
    ObservableLike<Message> auto merge(Observable<Message, OtherImpl>&& other) && {
#else
    auto merge(Observable<Message, OtherImpl>&& other) && {
#endif
      using ResultImpl = internal::observable::Merge<Message, Impl, OtherImpl>;
      return Observable<Message, ResultImpl>(ResultImpl(std::move(impl), internal::observable::move_impl(std::move(other))));
    }

    /** Convert this to a boxed representation. */
    Observable<Message> into_boxed() && {
      using ResultImpl = internal::observable::BoxedImpl<Message>;
      return Observable<Message>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Observable<Message>() && {
      using ResultImpl = internal::observable::BoxedImpl<Message>;
      return Observable<Message>(ResultImpl(std::move(impl)));
    }
  };

  namespace internal {

    namespace observable {

      /** @private */
      template<typename Message, typename Impl>
      inline Impl&& move_impl(Observable<Message, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /** Create an `Observable` computation that trigers nothing. */
  template<typename Message>
#ifdef DVCOMPUTE_CONCEPTS
  ObservableLike<Message> auto empty_observable() {
#else
  auto empty_observable() {
#endif
    using ResultImpl = internal::observable::Empty<Message>;
    return Observable<Message, ResultImpl>(ResultImpl());
  }

  /**
   * Delay the `Observable` computation and return the resulting compound `Observable<Message>`
   * computation, where `DelayFn` is a function that returns an intermediate `Observable`
   * computation, but `Message == std::invoke_result_t<DelayFn>::message_type`.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  auto delay_observable(DelayFn&& fn) requires ObservableDelayFn<DelayFn> {
#else
  auto delay_observable(DelayFn&& fn) {
#endif
    using Message = typename std::invoke_result_t<DelayFn>::message_type;
    using ResultImpl = internal::observable::Delay<DelayFn>;
    return Observable<Message, ResultImpl>(ResultImpl(std::move(fn)));
  }
}

#endif /* dvcompute_observable_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_h
#define dvcompute_block_h

#include <functional>
#include <vector>
#include <exception>
#include <stdexcept>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "function_traits.h"
#include "types.h"
#include "specs.h"
#include "result.h"
#include "process.h"
#include "block_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace block {

      // /** @private */
      // template<typename Input, typename Output>
      // using BoxedImpl = std::function<Result<Unit>(Input&& input,
      //   process::BoxedContFn<Output>&&,
      //   const ProcessIdPtr&,
      //   Point*)>;

      /** @private */
      template<typename Input, typename Output, typename ThenOutput, typename Self, typename ThenNext>
      class Then {

        Self comp;
        ThenNext next;

      public:

        explicit Then(Self&& comp_arg, ThenNext&& next_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(ThenNext(std::move(next_arg)))) :
          comp(std::move(comp_arg)), next(std::move(next_arg))
        {}

        Then(Then<Input, Output, ThenOutput, Self, ThenNext>&& other) = default;
        Then<Input, Output, ThenOutput, Self, ThenNext>& operator=(Then<Input, Output, ThenOutput, Self, ThenNext>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Input, Output, ThenOutput, Self, ThenNext>& other) = default;
        Then<Input, Output, ThenOutput, Self, ThenNext>& operator=(const Then<Input, Output, ThenOutput, Self, ThenNext>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {

            auto fn = [next{std::move(next)}, cont_fn{std::move(cont_fn)}](Result<Output>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
              if (Output* output = get_result_if<Output>(&item)) [[likely]] {
                return std::move(next)(std::move(*output), std::move(cont_fn), pid, p);
              } else {
                return DVCOMPUTE_NS::internal::process::error_process(std::move(cont_fn), std::move(item), pid, p);
              }
            };

            return std::move(comp)(std::move(input), std::move(fn), pid, p);
          }
        }
      };

      /** @private */
      template<typename Input, typename Output, typename Self>
      class Run {

        Self comp;
        Input input;

      public:

        explicit Run(Self&& comp_arg, Input&& input_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(Input(std::move(input_arg)))) :
          comp(std::move(comp_arg)), input(std::move(input_arg))
        {}

        Run(Run<Input, Output, Self>&& other) = default;
        Run<Input, Output, Self>& operator=(Run<Input, Output, Self>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Run(const Run<Input, Output, Self>& other) = default;
        Run<Input, Output, Self>& operator=(const Run<Input, Output, Self>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          return std::move(comp)(std::move(input), std::move(cont_fn), pid, p);
        }
      };

      /** @private */
      template<typename Input, typename Output, typename Fn>
      class Cons {

        Fn fn;

      public:

        explicit Cons(Fn&& fn_arg) noexcept(noexcept(Fn(std::move(fn_arg)))) : fn(std::move(fn_arg)) {}

        Cons(Cons<Input, Output, Fn>&& other) = default;
        Cons<Input, Output, Fn>& operator=(Cons<Input, Output, Fn>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Cons(const Cons<Input, Output, Fn>& other) = default;
        Cons<Input, Output, Fn>& operator=(const Cons<Input, Output, Fn>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          return fn(std::move(input)).operator()(std::move(cont_fn), pid, p);
        }
      };

      /** @private */
      template<typename Input, typename Output, typename Fn>
      class Arr {

        Fn fn;

      public:

        explicit Arr(Fn&& fn_arg) noexcept(noexcept(Fn(std::move(fn_arg)))) : fn(std::move(fn_arg)) {}

        Arr(Arr<Input, Output, Fn>&& other) = default;
        Arr<Input, Output, Fn>& operator=(Arr<Input, Output, Fn>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Arr(const Arr<Input, Output, Fn>& other) = default;
        Arr<Input, Output, Fn>& operator=(const Arr<Input, Output, Fn>& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {
            return std::move(cont_fn)(fn(std::move(input)), pid, p);
          }
        }
      };

      /** @private */
      template<typename Input, typename Output, typename Fn>
      class Delay {

        Fn fn;

      public:

        explicit Delay(Fn&& fn_arg) noexcept(noexcept(Fn(std::move(fn_arg)))) : fn(std::move(fn_arg)) {}

        Delay(Delay<Input, Output, Fn>&& other) = default;
        Delay<Input, Output, Fn>& operator=(Delay<Input, Output, Fn>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Delay(const Delay<Input, Output, Fn>& other) = default;
        Delay<Input, Output, Fn>& operator=(const Delay<Input, Output, Fn>& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          return fn().operator()(std::move(input), std::move(cont_fn), pid, p);
        }
      };

      /** @private */
      template<typename Input>
      class Terminate {
      public:

        explicit Terminate() noexcept {}

        Terminate(Terminate<Input>&& other) = default;
        Terminate<Input>& operator=(Terminate<Input>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Terminate(const Terminate<Input>& other) = default;
        Terminate<Input>& operator=(const Terminate<Input>& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {
            return std::move(cont_fn)(Result<Unit>(Unit()), pid, p);
          }
        }
      };

      /** @private */
      template<typename Input, typename Output, typename Self, typename FinalOutput, typename FinalImpl>
      class Finally {

        Self comp;
        FinalImpl final_comp;

      public:

        explicit Finally(Self&& comp_arg, FinalImpl&& final_comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(FinalImpl(std::move(final_comp_arg)))) :
          comp(std::move(comp_arg)), final_comp(std::move(final_comp_arg))
        {}

        Finally(Finally<Input, Output, Self, FinalOutput, FinalImpl>&& other) = default;
        Finally<Input, Output, Self, FinalOutput, FinalImpl>& operator=(Finally<Input, Output, Self, FinalOutput, FinalImpl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Finally(const Finally<Input, Output, Self, FinalOutput, FinalImpl>& other) = default;
        Finally<Input, Output, Self, FinalOutput, FinalImpl>& operator=(const Finally<Input, Output, Self, FinalOutput, FinalImpl>& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {

            auto fn = [final_comp{std::move(final_comp)}, cont_fn{std::move(cont_fn)}, input{input}](Result<Output>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
              auto fn = [cont_fn{std::move(cont_fn)}, item{std::move(item)}](Result<FinalOutput>&& anything, const ProcessIdPtr& pid, const Point* p) mutable {

                if (get_result_if<FinalOutput>(&anything)) [[likely]] {
                  return std::move(cont_fn)(std::move(item), pid, p);

                } else if (auto e2 = get_cancel_result_if(&anything)) {

                  if (get_result_if<Output>(&item)) {
                    return std::move(cont_fn)(std::move(*e2), pid, p);
                  } else if (auto e = get_retry_result_if(&item)) {
                    return std::move(cont_fn)(std::move(*e), pid, p);   // it has a priority
                  } else {
                    return std::move(cont_fn)(std::move(*e2), pid, p);
                  }

                } else if (auto e2 = get_retry_result_if(&anything)) {
                  return std::move(cont_fn)(std::move(*e2), pid, p);

                } else {
                  throw UnknownResult();
                }
              };

              return std::move(final_comp)(std::move(input), std::move(fn), pid, p);
            };

            return std::move(comp)(std::move(input), std::move(fn), pid, p);
          }
        }
      };

      /** @private */
      template<typename Input, typename Self>
      class Transfer {

        Self comp;

      public:

        explicit Transfer(Self&& comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg)))) :
          comp(std::move(comp_arg))
        {}

        Transfer(Transfer<Input, Self>&& other) = default;
        Transfer<Input, Self>& operator=(Transfer<Input, Self>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Transfer(const Transfer<Input, Self>& other) = default;
        Transfer<Input, Self>& operator=(const Transfer<Input, Self>& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(Input&& input,
          ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {

            auto fn = [](Result<Unit>&& item, const ProcessIdPtr& pid, const Point* p) {
              return Result<Unit>(std::move(item));
            };

            return std::move(comp)(std::move(input), std::move(fn), pid, p);
          }
        }
      };
    }
  }

  /** 
   * Represents a block computation that takes input and 
   * generates output within the discontinuous process.
   */
  template<typename Input, typename Output, typename Impl = internal::block::BoxedImpl<Input, Output>>
  class Block;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace block {

      /** Whether `F` is a function that takes `Input` and returns `Output`. */
      template<typename F, typename Traits, typename FirstArg, typename Input, typename Output>
      concept BlockArrFn5 = std::is_invocable_r_v<Output, F, Input&&>;

      /** Whether `F` is a function that takes `Input` and returns `Output`. */
      template<typename F, typename Traits, typename FirstArg, typename Input>
      concept BlockArrFn4 = requires {
        requires BlockArrFn5<F, Traits, FirstArg, Input, std::invoke_result_t<F, Input&&>>;
      };

      /** Whether `F` is a function that takes `Input` and returns `Output`. */
      template<typename F, typename Traits, typename FirstArg>
      concept BlockArrFn3 = requires {
        requires BlockArrFn4<F, Traits, FirstArg, typename std::remove_reference_t<FirstArg>>;
      };

      /** Whether `F` is a function that takes `Input` and returns `Output`. */
      template<typename F, typename Traits>
      concept BlockArrFn2 = requires {
        typename Traits::template arg<0>::type;
        requires BlockArrFn3<F, Traits, typename Traits::template arg<0>::type>;
      };

      /** Whether `F` is a function that takes `Input` and returns `Output`. */
      template<typename F>
      concept BlockArrFn1 = requires {
        typename function_traits<F>;
        requires BlockArrFn2<F, function_traits<F>>;
      };

      /** Whether `F` is a function that takes `Input` and returns a `Process<Output>` computation. */
      template<typename F, typename Traits, typename FirstArg, typename Input, typename Output>
      concept BlockConsFn5 = std::is_invocable_r_v<Process<Output>, F, Input&&>;

      /** Whether `F` is a function that takes `Input` and returns a `Process<Output>` computation. */
      template<typename F, typename Traits, typename FirstArg, typename Input>
      concept BlockConsFn4 = requires {
        typename std::invoke_result_t<F, Input&&>::item_type;
        requires BlockConsFn5<F, Traits, FirstArg, Input, typename std::invoke_result_t<F, Input&&>::item_type>;
      };

      /** Whether `F` is a function that takes `Input` and returns a `Process<Output>` computation. */
      template<typename F, typename Traits, typename FirstArg>
      concept BlockConsFn3 = requires {
        requires BlockConsFn4<F, Traits, FirstArg, typename std::remove_reference_t<FirstArg>>;
      };

      /** Whether `F` is a function that takes `Input` and returns a `Process<Output>` computation. */
      template<typename F, typename Traits>
      concept BlockConsFn2 = requires {
        typename Traits::template arg<0>::type;
        requires BlockConsFn3<F, Traits, typename Traits::template arg<0>::type>;
      };

      /** Whether `F` is a function that takes `Input` and returns a `Process<Output>` computation. */
      template<typename F>
      concept BlockConsFn1 = requires {
        typename function_traits<F>;
        requires BlockConsFn2<F, function_traits<F>>;
      };

      /** Whether `F` is a function that returns a `Block<Input, Output>` computation. */
      template<typename F, typename Input, typename Output>
      concept BlockDelayFn3 = std::is_invocable_r_v<Block<Input, Output>, F>;

      /** Whether `F` is a function that returns a `Block<Input, Output>` computation. */
      template<typename F, typename Input>
      concept BlockDelayFn2 = requires {
        typename std::invoke_result_t<F>::output_type;
        requires BlockDelayFn3<F, Input, typename std::invoke_result_t<F>::output_type>;
      };

      /** Whether `F` is a function that returns a `Block<Input, Output>` computation. */
      template<typename F>
      concept BlockDelayFn1 = requires {
        typename std::invoke_result_t<F>::input_type;
        requires BlockDelayFn2<F, typename std::invoke_result_t<F>::input_type>;
      };
    }
  }

  /** Whether `Self` is actually a `Block<Input, Output>` computation. */
  template<typename Self, typename Input, typename Output>
  concept BlockLike = std::is_convertible_v<Self, Block<Input, Output>>;

  /** Whether `F` is a function that takes `Input` and returns `Output`. */
  template<typename F>
  concept BlockArrFn = internal::block::BlockArrFn1<F>;

  /** Whether `F` is a function that takes `Input` and returns a `Process<Output>` computation. */
  template<typename F>
  concept BlockConsFn = internal::block::BlockConsFn1<F>;

  /** Whether `F` is a function that returns a `Block<Input, Output>` computation. */
  template<typename F>
  concept BlockDelayFn = internal::block::BlockDelayFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace block {

      template<typename Input, typename Output, typename Impl>
      inline Impl&& move_impl(Block<Input, Output, Impl>&& comp);
    }
  }

  /** 
   * Represents a block computation that takes input and 
   * generates output within the discontinuous process.
   */
  template<typename Input, typename Output, typename Impl>
  class Block {

    Impl impl;

    template<typename Input2, typename Output2, typename Impl2>
    friend inline Impl2&& internal::block::move_impl(Block<Input2, Output2, Impl2>&& comp);

  public:

    using input_type = Input;
    using output_type = Output;
    using impl_type = Impl;

    explicit Block(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) : impl(std::move(impl_arg)) {}

    Block(Block<Input, Output, Impl>&& other) = default;
    Block<Input, Output, Impl>& operator=(Block<Input, Output, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Block(const Block<Input, Output, Impl>& other) = default;
    Block<Input, Output, Impl>& operator=(const Block<Input, Output, Impl>& other) = default;

    /** Copy the computation. */
    Block<Input, Output, Impl> copy() const {
      return Block<Input, Output, Impl>(*this);
    }

#endif

    /** @private */
    template<typename ContFn>
    DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(Input&& input,
      ContFn&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) &&
    {
      return std::move(impl)(std::move(input), std::move(cont_fn), pid, p);
    }

    /**
     * A composition that binds this with the next computation within 
     * the resulting `Block<Input, ThenOutput>` computation.
     */
    template<typename ThenOutput, typename ThenNext>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE BlockLike<Input, ThenOutput> auto and_then(Block<Output, ThenOutput, ThenNext>&& next) && {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(Block<Output, ThenOutput, ThenNext>&& next) && {
#endif
      using ThenImpl = internal::block::Then<Input, Output, ThenOutput, Impl, ThenNext>;
      return Block<Input, ThenOutput, ThenImpl>(ThenImpl(std::move(impl), internal::block::move_impl(std::move(next))));
    }

    /**
     * A composition that binds this with the next computation within 
     * the resulting `Block<Input, ThenOutput>` computation.
     */
    template<typename ThenOutput, typename ThenNext>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE BlockLike<Input, ThenOutput> auto then(Block<Output, ThenOutput, ThenNext>&& next) && {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(Block<Output, ThenOutput, ThenNext>&& next) && {
#endif
      using ThenImpl = internal::block::Then<Input, Output, ThenOutput, Impl, ThenNext>;
      return Block<Input, ThenOutput, ThenImpl>(ThenImpl(std::move(impl), internal::block::move_impl(std::move(next))));
    }

    /**
     * Run this by the specified input within the resulting `Process<Output>` computation.
     */
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE ProcessLike<Output> auto run(Input&& input) && {
#else
    DVCOMPUTE_ALWAYS_INLINE auto run(Input&& input) && {
#endif
      using ThenImpl = internal::block::Run<Input, Output, Impl>;
      return Process<Output, ThenImpl>(ThenImpl(std::move(impl), std::move(input)));
    }

    /** Convert this to a boxed representation. */
    Block<Input, Output> into_boxed() && {
      using ResultImpl = internal::block::BoxedImpl<Input, Output>;
      return Block<Input, Output>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Block<Input, Output>() && {
      using ResultImpl = internal::block::BoxedImpl<Input, Output>;
      return Block<Input, Output>(ResultImpl(std::move(impl)));
    }
  };

  namespace internal {

    namespace block {

      /** @private */
      template<typename Input, typename Output, typename Impl>
      inline Impl&& move_impl(Block<Input, Output, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /**
   * Construct a new `Block<Input, Output>` computation by the specified closure `ConsFn`,
   * which must be a function of `Input&&` that returns a `Process<Output>` computation.
   */
  template<typename ConsFn, typename StdFn = decltype(std::function(std::forward<ConsFn>(std::declval<ConsFn>())))>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_block(ConsFn&& fn) requires BlockConsFn<StdFn> {
#else
  inline auto cons_block(ConsFn&& fn) {
#endif
    using Traits = function_traits<StdFn>;
    using FirstArg = typename Traits::template arg<0>::type;
    using Input = typename std::remove_reference_t<FirstArg>;
    using Output = typename std::invoke_result_t<ConsFn, Input&&>::item_type;
    using ResultImpl = internal::block::Cons<Input, Output, ConsFn>;
    return Block<Input, Output, ResultImpl>(ResultImpl(std::move(fn)));
  }

  /** 
   * Create a `Block<Input, Output>` computation by the specified function that
   * takes `Input&&` and returns `Output`.
   */
  template<typename ArrFn, typename StdFn = decltype(std::function(std::forward<ArrFn>(std::declval<ArrFn>())))>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto arr_block(ArrFn&& fn) requires BlockArrFn<StdFn> {
#else
  inline auto arr_block(ArrFn&& fn) {
#endif
    using Traits = function_traits<StdFn>;
    using FirstArg = typename Traits::template arg<0>::type;
    using Input = typename std::remove_reference_t<FirstArg>;
    using Output = std::invoke_result_t<ArrFn, Input&&>;
    using ResultImpl = internal::block::Arr<Input, Output, ArrFn>;
    return Block<Input, Output, ResultImpl>(ResultImpl(std::move(fn)));
  }

  /**
   * Delay the `Block` computation and return the resulting compound `Block`
   * computation, where `DelayFn` is a function that returns an intermediate `Block`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_block(DelayFn&& fn) requires BlockDelayFn<DelayFn> {
#else
  inline auto delay_block(DelayFn&& fn) {
#endif
    using Input = typename std::invoke_result_t<DelayFn>::input_type;
    using Output = typename std::invoke_result_t<DelayFn>::output_type;
    using ResultImpl = internal::block::Delay<Input, Output, DelayFn>;
    return Block<Input, Output, ResultImpl>(ResultImpl(std::move(fn)));
  }

  /**
   * Terminate the control flow within the `Block<Input, Unit>` computation.
   */
  template<typename Input>
#ifdef DVCOMPUTE_CONCEPTS
  inline BlockLike<Input, Unit> auto terminate_block() {
#else
  inline auto terminate_block() {
#endif
    using ResultImpl = internal::block::Terminate<Input>;
    return Block<Input, Unit, ResultImpl>(ResultImpl());
  }

  /** 
   * Transfer the control flow to the specified block within `Block<Input, Output>` computation. 
   */
  template<typename Input, typename Output, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline BlockLike<Input, Output> auto transfer_block(Block<Input, Unit, Impl>&& comp) {
#else
  inline auto transfer_block(Block<Input, Unit, Impl>&& comp) {
#endif
    using ThenImpl = internal::block::Transfer<Input, Impl>;
    return Block<Input, Output, ThenImpl>(ThenImpl(internal::block::move_impl(std::move(comp))));
  }

  /** Call the specified finalization block within the resulting compound `Block<Input, Output>` computation. */
  template<typename Input, typename Output, typename Impl, typename FinalOutput, typename FinalImpl>
#ifdef DVCOMPUTE_CONCEPTS
  BlockLike<Input, Output> auto finally_block(Block<Input, Output, Impl>&& comp, Block<Input, FinalOutput, FinalImpl>&& final_comp) {
#else
  auto finally_block(Block<Input, Output, Impl>&& comp, Block<Input, FinalOutput, FinalImpl>&& final_comp) {
#endif
    using ResultImpl = internal::block::Finally<Input, Output, Impl, FinalOutput, FinalImpl>;
    return Block<Input, Output, ResultImpl>(ResultImpl(internal::block::move_impl(std::move(comp)), internal::block::move_impl(std::move(final_comp))));
  }
}

#endif /* dvcompute_block_h */

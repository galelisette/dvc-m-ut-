/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_process_id_impl_h
#define dvcompute_process_id_impl_h

#include <limits>
#include <vector>
#include <variant>

#include "../../dvcompute_ns.h"
#include "types.h"
#include "process_id.h"
#include "process_extra.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace process {

      /** The Process operations. */
      class ProcessOps {
      public:

        /** Whether the process is preempted. */
        static bool is_preempted_at(const ProcessIdPtr &pid, const Point* p) {
          return pid->preemption_count.read_at(p) > 0;
        }

        /** Deactivate the flag that the process is canceled. */
        static void deactivate_cancel(const ProcessIdPtr &pid, const Point* p) {
          pid->cancel_activated.write_at(false, p);
        }

        /** Initiate the cancellation. */
        static Result<Unit> initiate_cancel_at(const ProcessIdPtr &pid, const Point* p) {
          return pid->initiate_cancel_at(p);
        }

        /** Interrupt the process if it is held by computation `hold_process`. */
        static void interrupt_at(const ProcessIdPtr &pid, const Point* p) {
          auto cont { pid->interrupt_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
          if (cont) {
            int v = pid->interrupt_version.read_at(p);
            int priority = pid->interrupt_priority.read_at(p);
            pid->interrupt_version.write_at(1 + v, p);
            pid->interrupt_flag.write_at(std::make_optional(true), p);

    #ifndef DVCOMPUTE_REAL_PRIORITIES
            internal::event::enqueue_event(p->time, priority, 
    #else
            internal::event::enqueue_uncancellable_event(p->time, priority, 
    #endif
              [pid, cont{std::move(cont)}](const Point* p) mutable {
                return internal::process::resume_process(std::move(cont), pid, Unit(), p);
              }, p);
          }
        }

        static bool is_cancel_initiated_at(const ProcessIdPtr& pid, const Point* p) {
          return pid->cancel_initiated.read_at(p);
        }

        static bool is_interrupted_at(const ProcessIdPtr &pid, const Point* p) {
          std::optional<bool> f = pid->interrupt_flag.read_at(p);
          return f.has_value() && f.value();
        }

        static std::optional<double> interruption_time_at(const ProcessIdPtr &pid, const Point* p) {
          std::optional<bool> f = pid->interrupt_flag.read_at(p);
          if (f.has_value() && !f.value()) {
            return std::make_optional(pid->interrupt_time.read_at(p));
          } else {
            return std::nullopt;
          }
        }

        static Result<Unit> passivate(internal::process::BoxedContFn<Unit>&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p)
        {
          std::optional<bool> f = pid->react_flag.read_at(p);
          if (f.has_value() && f.value()) {
            return Result<Unit>(RetryResult("Cannot passivate the process twice"));

          } else {
            auto cont_fn_0 { pid->react_cont_fn.swap_at(std::move(cont_fn), p) };
            if (cont_fn_0) {
              throw PanicResult("The reactivation continuation has diverged");
            } else {
              int priority = p->priority;
              pid->react_priority.write_at(std::move(priority), p);
              pid->react_flag.write_at(std::make_optional(true), p);
              return Result<Unit>(Unit());
            }
          }
        }

        static Result<Unit> passivate_before(internal::event::BoxedImpl<Unit>&& fn,
          internal::process::BoxedContFn<Unit>&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p)
        {
          std::optional<bool> f = pid->react_flag.read_at(p);
          if (f.has_value() && f.value()) {
            return Result<Unit>(RetryResult("Cannot passivate the process twice"));

          } else {
            auto cont_fn_0 { pid->react_cont_fn.swap_at(std::move(cont_fn), p) };
            if (cont_fn_0) {
              throw PanicResult("The reactivation continuation has diverged");
            } else {
              int priority = p->priority;
              pid->react_priority.write_at(std::move(priority), p);
              pid->react_flag.write_at(std::make_optional(true), p);
              return std::move(fn)(p);
            }
          }
        }

        static bool is_passivated_at(const ProcessIdPtr &pid, const Point* p) {
          std::optional<bool> f = pid->react_flag.read_at(p);
          return f.has_value() && f.value();
        }

        static void reactivate_at(const ProcessIdPtr &pid, const Point* p) {
          auto cont { pid->react_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
          if (cont) {
            std::optional<bool> f = pid->react_flag.swap_at(std::nullopt, p);
            if (f.has_value() && f.value()) {
              int priority = pid->react_priority.read_at(p);
    #ifndef DVCOMPUTE_REAL_PRIORITIES
              internal::event::enqueue_event(p->time, priority, 
    #else
              internal::event::enqueue_uncancellable_event(p->time, priority, 
    #endif
                ([pid, cont{std::move(cont)}](const Point* p) mutable {
                  return internal::process::resume_process(std::move(cont), pid, Unit(), p);
                }), p);

            } else {
              throw PanicResult("The reactivation continuation has diverged");
            }
          }
        }

        static Result<Unit> reactivate_immediately_at(const ProcessIdPtr &pid, const Point* p) {
          auto cont { pid->react_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
          if (cont) {
            std::optional<bool> f = pid->react_flag.swap_at(std::nullopt, p);
            if (f.has_value() && f.value()) {
              int priority = pid->react_priority.read_at(p);
              if (priority == p->priority) {
                return internal::process::resume_process(std::move(cont), pid, Unit(), p);
              } else {
                return enqueue_uncancellable_event_with_priority(p->time, priority, 
                  cons_event([pid, cont{std::move(cont)}](const Point* p) mutable {
                    return internal::process::resume_process(std::move(cont), pid, Unit(), p);
                  }))
                .operator()(p);
              }

            } else {
              throw PanicResult("The reactivation continuation has diverged");
            }
          } else {
            return Result<Unit>(Unit());
          }
        }
        
        static Result<Unit> reactivate_many_immediately_at(std::vector<ProcessIdPtr>&& pids, std::size_t index, const Point* p) {
          if (index >= pids.size()) {
            return Result<Unit>(Unit());
          } else {
            return cons_event([pid{pids[index]}](const Point* p) mutable {
              return reactivate_immediately_at(pid, p);
            })
            .and_then([pids{std::move(pids)}, index](Unit unit) mutable {
              return yield_uncancellable_event(cons_event([pids{std::move(pids)}, index](const Point* p) mutable {
                return reactivate_many_immediately_at(std::move(pids), 1 + index, p);
              }));
            }).operator()(p);
          }
        }

        /** Hold the corresponding process for the specified time interval. */
        static void hold(double dt,
          internal::process::BoxedContFn<Unit>&& cont_fn,
          const ProcessIdPtr &pid,
          const Point* p)
        {
          double t = p->time + dt;
          int priority = p->priority;
          pid->interrupt_cont_fn.write_at(std::move(cont_fn), p);
          pid->interrupt_flag.write_at(std::make_optional(false), p);
          pid->interrupt_time.write_at(std::move(t), p);
          pid->interrupt_priority.write_at(std::move(priority), p);
          int v = pid->interrupt_version.read_at(p);

    #ifndef DVCOMPUTE_REAL_PRIORITIES
          internal::event::enqueue_event(t, p->priority, 
            [pid, v](const Point *p) {
              int v2 = pid->interrupt_version.read_at(p);
              if (v == v2) [[likely]] {
                pid->interrupt_flag.write_at(std::nullopt, p);
                auto cont_fn { pid->interrupt_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
                return internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
              } else {
                return Result<Unit>(Unit());
              }
            }, p);
    #else
          internal::event::enqueue_event_with_cancel(t, p->priority, 
            [pid, v](const Point *p) {
              int v2 = pid->interrupt_version.read_at(p);
              if (v == v2) [[likely]] {
                pid->interrupt_flag.write_at(std::nullopt, p);
                auto cont_fn { pid->interrupt_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
                return internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
              } else {
                return Result<Unit>(Unit());
              }
            }, 
            [pid, v](const Point* p) {
              TRY_RESULT(internal::process::cancel_process_at(pid, p));
              if (pid->is_cancelled(p)) {
                int v2 = pid->interrupt_version.read_at(p);
                if (v == v2) [[likely]] {
                  pid->interrupt_flag.write_at(std::nullopt, p);
                  auto cont_fn { pid->interrupt_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
                  return internal::process::revoke_process(std::move(cont_fn), pid, p);
                } else {
                  return Result<Unit>(Unit());
                }
              } else {
                return Result<Unit>(Unit());
              }
            }, p);
    #endif
        }

        /** Prepare the process identifier. */
        static Result<Unit> prepare_at(const ProcessIdPtr &pid, const Point* p) {
          if (pid->started.read_at(p)) {
            throw PanicResult("The process has been started already");
          } else {
            pid->started.write_at(true, p);
            WeakPtr<ProcessId> weak_pid(pid);
            Result<Disposable<>> disposable { 
              pid->observable()
                .subscribe(cons_observer([weak_pid{std::move(weak_pid)}](const ProcessEvent* msg, const Point* p) {
                  ProcessIdPtr pid(weak_pid.lock());
                  if (pid.get() == nullptr) {
                    throw PanicResult("The process is in illegal state");
                  } else {
                    switch (*msg) {
                    case ProcessEvent::CancelInitiating:
                      if (pid->is_cancelled(p)) {
                        ProcessOps::interrupt_at(pid, p);
                        ProcessOps::reactivate_at(pid, p);
                        return Result<Unit>(Unit());
                      } else {
                        return Result<Unit>(Unit());
                      }
                    case ProcessEvent::PreemptionInitiating:
                      return ProcessOps::on_preempted_at(pid, p);
                    case ProcessEvent::PreemptionEnding:
                      return Result<Unit>(Unit());
                    default:
                      throw PanicResult("Unexhaustive switch");
                    }
                  }
                }))
                .operator()(p)
            };
            if (get_result_if<Disposable<>>(&disposable)) {
              return Result<Unit>(Unit());
            } else {
              return error_result<Unit>(std::move(disposable));
            }
          }
        }

        /** Launch the computation with the specified priority. */ 
        static Result<Unit> with_priority(int priority, 
          internal::process::BoxedContFn<Unit>&& cont_fn,
          const ProcessIdPtr &pid,
          const Point* p)
        {
          if (pid->is_cancelled(p)) {
            return internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else if (priority == p->priority) {
            return std::move(cont_fn)(Unit(), pid, p);
          } else {
            return enqueue_uncancellable_event_with_priority(p->time, priority, 
              cons_event([cont_fn{std::move(cont_fn)}, pid](const Point* p) mutable {
                return internal::process::resume_process<Unit>(std::move(cont_fn), pid, Unit(), p);
              }))
            .operator()(p);
          }
        }

        static Result<Disposable<>> connect_cancel(const ProcessIdPtr& parent,
          ProcessCancellation cancellation,
          const ProcessIdPtr& child,
          const Point* p)
        {
          WeakPtr<ProcessId> weak_child(child);
          WeakPtr<ProcessId> weak_parent(parent);

          Result<Disposable<>> r1 {
            (cancellation == ProcessCancellation::CancelTogether) || (cancellation == ProcessCancellation::CancelChildAfterParent) ?
              parent->cancel_initiating()
                .subscribe(cons_observer([weak_child](const Unit* unit, const Point* p) {
                  ProcessIdPtr child(weak_child.lock());
                  if (child) {
                    return child->initiate_cancel_at(p);
                  } else {
                    return Result<Unit>(Unit());
                  }
                }))
                .operator()(p) :
              (cancellation == ProcessCancellation::CancelParentAfterChild) || (cancellation == ProcessCancellation::CancelInIsolation) ?
                Result<Disposable<>>(empty_disposable().operator Disposable<>()) :
                throw PanicResult("Unexhaustive switch")
          };

          if (Disposable<> *h1 = get_result_if<Disposable<>>(&r1)) {
            Result<Disposable<>> r2 { 
              (cancellation == ProcessCancellation::CancelTogether) || (cancellation == ProcessCancellation::CancelParentAfterChild) ?
                child->cancel_initiating()
                  .subscribe(cons_observer([weak_parent](const Unit* unit, const Point* p) {
                    ProcessIdPtr parent(weak_parent.lock());
                    if (parent) {
                      return parent->initiate_cancel_at(p);
                    } else {
                      return Result<Unit>(Unit());
                    }
                  }))
                  .operator()(p) :
                (cancellation == ProcessCancellation::CancelChildAfterParent) || (cancellation == ProcessCancellation::CancelInIsolation) ?
                  Result<Disposable<>>(empty_disposable().operator Disposable<>()) :
                  throw PanicResult("Unexhaustive switch")
            };

            if (Disposable<> *h2 = get_result_if<Disposable<>>(&r2)) {
              return Result<Disposable<>>(std::move(*h1).merge(std::move(*h2)).operator Disposable<>());
            } else {
              std::move(*h1)(p);
              return r2;
            }

          } else {
            return r1;
          }
        }

        static Result<Unit> spawn(internal::process::BoxedContFn<Unit>&& cont_fn,
          const ProcessIdPtr &pid,
          ProcessCancellation cancellation,
          const ProcessIdPtr &child_pid,
          internal::process::BoxedImpl<Unit>&& child_fn,
          const Point* p)
        {
          if (pid->is_cancelled(p)) {
            return internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {
            Result<Unit> r1 { prepare_at(child_pid, p) };
            if (get_result_if<Unit>(&r1)) {
              Result<Disposable<>> r2 { connect_cancel(pid, cancellation, child_pid, p) };
              if (Disposable<> *h = get_result_if<Disposable<>>(&r2)) {
                return enqueue_uncancellable_event(p->time,
                  cons_event([child_fn{std::move(child_fn)}, child_pid, h{std::move(*h)}](const Point* p) mutable {
                    auto fn = [h{std::move(h)}](const Result<Unit>& item, const ProcessIdPtr& pid, const Point* p) mutable {
                      Result<Unit> r3 { std::move(h)(p) };
                      if (get_result_if<Unit>(&r3)) {
                        if (get_result_if<Unit>(&item)) {
                          return Result<Unit>(Unit());
                        } else if (get_cancel_result_if(&item)) {
                          return Result<Unit>(Unit());
                        } else {
                          return item;
                        }

                      } else {
                        return r3;
                      }
                    };

                    return std::move(child_fn)(std::move(fn), child_pid, p);
                  }))
                .and_then([cont_fn{std::move(cont_fn)}, pid](Unit&& unit) mutable {
                  return cons_event([cont_fn{std::move(cont_fn)}, pid](const Point* p) mutable {
                    return internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
                  });
                })
                .operator()(p);

              } else if (auto e = get_cancel_result_if(&r2)) {
                return Result<Unit>(*e);
              } else if (auto e = get_retry_result_if(&r2)) {
                return Result<Unit>(*e);
              } else {
                throw UnknownResult();
              }

            } else {
              return r1;
            }
          }
        }

      private:

        /** Define a reaction when the process with the specified identifier is preempted. */
        static Result<Unit> on_preempted_at(const ProcessIdPtr& pid, const Point *p) {
          auto cont_fn { pid->interrupt_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
          if (cont_fn) {
            double t = pid->interrupt_time.read_at(p);
            double dt = t - p->time;
            int v = pid->interrupt_version.read_at(p);
            int priority = pid->interrupt_priority.read_at(p);
            pid->interrupt_flag.write_at(std::make_optional(true), p);
            pid->interrupt_version.write_at(1 + v, p);
            internal::process::BoxedContFn<Unit> inner_cont_fn {
              internal::process::substitute_process<Unit>(std::move(cont_fn), 
                [priority, dt](internal::process::BoxedContFn<Unit>&& cont_fn, const ProcessIdPtr& pid, Unit&& unit, const Point* p) mutable {
                  return restore_process_priority(priority, hold_process(dt))
                    .operator()(std::move(cont_fn), pid, p);
                })
            };
            return internal::process::reenter_process_at(std::move(inner_cont_fn), pid, Unit(), p);

          } else {
            auto cont_fn { pid->react_cont_fn.swap_at(internal::process::BoxedContFn<Unit>(), p) };
            if (cont_fn) {
              internal::process::BoxedContFn<Unit> inner_cont_fn {
                internal::process::substitute_process<Unit>(std::move(cont_fn), 
                  [](internal::process::BoxedContFn<Unit>&& cont_fn, const ProcessIdPtr& pid, Unit&& unit, const Point* p) mutable {
                    return internal::process::reenter_process_at(std::move(cont_fn), pid, Unit(), p);
                  })
              };
              pid->react_cont_fn.write_at(std::move(inner_cont_fn), p);
              return Result<Unit>(Unit());

            } else {
              return Result<Unit>(Unit());
            }
          }
        }
      };

      /** Create a new process identifier by the specified simulation run. */
      inline ProcessIdPtr new_process_id_by_run(const Run* r) {
        return ProcessIdPtr(SharedPtrFn {}, [=](ProcessId* address) {
          new(address) ProcessId(r);
        });
      }

      /** Deactivate the flag that the process is canceled. */
      inline void deactivate_process_cancelled(const ProcessIdPtr& pid, const Point* p) {
        ProcessOps::deactivate_cancel(pid, p);
      }

      /** Whether the process cancel is initiated. */
      inline bool is_process_cancel_initiated_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::is_cancel_initiated_at(pid, p);
      }

      /** Whether the process is preempted. */
      inline bool is_process_preempted_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::is_preempted_at(pid, p);
      }

      /** Prepare the process by the specified identifier at the specified modeling time point. */
      inline Result<Unit> prepare_process_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::prepare_at(pid, p);
      }

      /** Cancel the process by the specified identifier at the specified modeling time point. */
      inline Result<Unit> cancel_process_at(const ProcessIdPtr& pid, const Point* p) {
        return pid->initiate_cancel_at(p);
      }

      /** Preempt the process by the specified identifier at the specified modeling time point. */
      inline Result<Unit> begin_process_preemption_at(const ProcessIdPtr& pid, const Point* p) {
        return pid->begin_preemption_at(p);
      }

      /** Proceed with the process after it was preempted before. */
      inline Result<Unit> end_process_preemption_at(const ProcessIdPtr& pid, const Point* p) {
        return pid->end_preemption_at(p);
      }

      /** Hold the corresponding process for the specified time interval. */
      inline void hold_process_at(double dt,
        process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr &pid,
        const Point* p)
      {
        ProcessOps::hold(dt, std::move(cont_fn), pid, p);
      }

      /** Interrupt the process if it is held by computation `hold_process`. */
      inline void interrupt_process_at(const ProcessIdPtr& pid, const Point* p) {
        ProcessOps::interrupt_at(pid, p);
      }

      /** Whether the process is interrupted. */
      inline bool is_process_interrupted_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::is_interrupted_at(pid, p);
      }

      inline std::optional<double> process_interruption_time_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::interruption_time_at(pid, p);
      }

      inline Result<Unit> passivate_process_at(process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        return ProcessOps::passivate(std::move(cont_fn), pid, p);
      }

      inline Result<Unit> passivate_process_before_at(event::BoxedImpl<Unit>&& fn,
        process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        return ProcessOps::passivate_before(std::move(fn), std::move(cont_fn), pid, p);
      }

      /** Whether the process is passivated. */
      inline bool is_process_passivated_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::is_passivated_at(pid, p);
      }

      inline void reactivate_process_at(const ProcessIdPtr& pid, const Point* p) {
        ProcessOps::reactivate_at(pid, p);
      }

      inline Result<Unit> reactivate_process_immediately_at(const ProcessIdPtr& pid, const Point* p) {
        return ProcessOps::reactivate_immediately_at(pid, p);
      }

      inline Result<Unit> reactivate_processes_immediately_at(std::vector<ProcessIdPtr>&& pids, const Point* p) {
        return ProcessOps::reactivate_many_immediately_at(std::move(pids), 0, p);
      }

      inline Result<Unit> process_with_priority(int priority, 
        process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr &pid,
        const Point* p)
      {
        return ProcessOps::with_priority(priority, std::move(cont_fn), pid, p);
      }

      inline Result<Unit> spawn_process(process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr &pid,
        ProcessCancellation cancellation,
        const ProcessIdPtr &child_pid,
        process::BoxedImpl<Unit>&& child_fn,
        const Point* p)
      {
        return ProcessOps::spawn(std::move(cont_fn), pid, cancellation, child_pid, std::move(child_fn), p);
      }
    }
  }
}

#endif /* dvcompute_process_id_impl_h */

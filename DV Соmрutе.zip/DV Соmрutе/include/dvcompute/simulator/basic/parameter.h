/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_parameter_h
#define dvcompute_parameter_h

#include <functional>
#include <vector>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "specs.h"
#include "result.h"
#include "types.h"
#include "parameter_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace parameter {

      // /** @private */
      // template<typename Item>
      // using BoxedImpl = std::function<Result<Item>(const Run*)>;

      /** @private */
      template<typename Item, typename ThenItem, typename Self, typename BindFn>
      class Then {

        Self comp;
        BindFn k;

      public:

        explicit Then(Self &&comp_arg, BindFn &&k_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(BindFn(std::move(k_arg)))) :
          comp(std::move(comp_arg)), k(std::move(k_arg))
        {}

        Then(Then<Item, ThenItem, Self, BindFn> &&other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(Then<Item, ThenItem, Self, BindFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Item, ThenItem, Self, BindFn> &other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(const Then<Item, ThenItem, Self, BindFn> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<ThenItem> operator()(const Run *r) && {
          Result<Item> res { std::move(comp)(r) };
          if (auto *item = get_result_if<Item>(&res)) [[likely]] {
            return k(std::move(*item))(r);
          } else {
            return error_result<ThenItem>(std::move(res));
          }
        }
      };

      /** @private */
      template<typename Item>
      class Return {

        Item item;

      public:

        explicit Return(const Item &item_arg) : item(item_arg) {}
        explicit Return(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : item(std::move(item_arg)) {}

        Return(Return<Item> &&other) = default;
        Return<Item>& operator=(Return<Item> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Return(const Return<Item> &other) = default;
        Return<Item>& operator=(const Return<Item> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Run *r) && {
          return Result<Item>(std::move(item));
        }
      };
    }
  }

  /** Represents a computation that depends on external parameters. */
  template<typename Item, typename Impl = internal::parameter::BoxedImpl<Item>>
  class Parameter;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace parameter {

      /** Whether `F` is a function that takes `Arg` and returns a `Parameter` computation. */
      template<typename F, typename Arg, typename Item>
      concept ParameterBindFn3 = std::is_invocable_r_v<Parameter<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns a `Parameter` computation. */
      template<typename F, typename Arg>
      concept ParameterBindFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires ParameterBindFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns a `Parameter` computation. */
      template<typename F, typename Item>
      concept ParameterDelayFn2 = std::is_invocable_r_v<Parameter<Item>, F>;

      /** Whether `F` is a function that returns a `Parameter` computation. */
      template<typename F>
      concept ParameterDelayFn1 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires ParameterDelayFn2<F, typename std::invoke_result_t<F>::item_type>;
      };

      /** Whether `F` is a function that takes the `Run` pointer and returns a `Result` value. */
      template<typename F, typename Item>
      concept ParameterConsFn2 = std::is_invocable_r_v<Result<Item>, F, const Run*>;

      /** Whether `F` is a function that takes the `Run` pointer and returns a `Result` value. */
      template<typename F>
      concept ParameterConsFn1 = requires {
        typename std::invoke_result_t<F, const Run*>::item_type;
        requires ParameterConsFn2<F, typename std::invoke_result_t<F, const Run*>::item_type>;
      };
    }
  }

  /** Whether `Self` is actually a `Parameter<Item>` computation. */
  template<typename Self, typename Item>
  concept ParameterLike = std::is_convertible_v<Self, Parameter<Item>>;

  /** Whether `F` is a function that takes `Arg` and returns a `Parameter` computation. */
  template<typename F, typename Arg>
  concept ParameterBindFn = internal::parameter::ParameterBindFn2<F, Arg>;

  /** Whether `F` is a function that returns a `Parameter` computation. */
  template<typename F>
  concept ParameterDelayFn = internal::parameter::ParameterDelayFn1<F>;

  /** Whether `F` is a function that takes the `Run` pointer and returns a `Result` value. */
  template<typename F>
  concept ParameterConsFn = internal::parameter::ParameterConsFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace parameter {

      template<typename Item, typename Impl>
      inline Impl&& move_impl(Parameter<Item, Impl>&& comp);
    }
  }

  /** Represents a computation that depends on external parameters. */
  template<typename Item, typename Impl>
  class Parameter {

    Impl impl;

    template<typename Item2, typename Impl2>
    friend inline Impl2&& internal::parameter::move_impl(Parameter<Item2, Impl2>&& comp);

  public:

    using item_type = Item;

    explicit Parameter(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) : impl(std::move(impl_arg)) {}

    Parameter(Parameter<Item, Impl>&& other) = default;
    Parameter<Item, Impl>& operator=(Parameter<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Parameter(const Parameter<Item, Impl>& other) = default;
    Parameter<Item, Impl>& operator=(const Parameter<Item, Impl>& other) = default;

    /** Copy the computation. */
    Parameter<Item, Impl> copy() const {
      return Parameter<Item, Impl>(*this);
    }

#endif

    /** Call the computation. */
    DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Run *r) && {
      return std::move(impl)(r);
    }

    /**
     * Bind this with a continuation and return the compound resulting `Parameter<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Parameter<ThenItem>` computation.
     */
    template<typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && requires ParameterBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::parameter::Then<Item, ThenItem, Impl, BindFn>;
      return Parameter<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Bind this with a continuation and return the compound resulting `Parameter<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Parameter<ThenItem>` computation.
     */
    template<typename BindFn>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && requires ParameterBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::parameter::Then<Item, ThenItem, Impl, BindFn>;
      return Parameter<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Map the computed value and return the compound resulting `Parameter<MapItem>`
     * computation, where `MapFn` is a function that takes an `Item` and then transforms it
     * to `MapItem`.
     */
    template<typename MapFn>
    DVCOMPUTE_ALWAYS_INLINE auto map(MapFn&& f) && {
      return std::move(*this).and_then([f{std::move(f)}](Item&& item) mutable {
        using MapItem = std::invoke_result_t<MapFn, Item&&>;
        using MapImpl = internal::parameter::Return<MapItem>;
        return Parameter<MapItem, MapImpl>(MapImpl(f(std::move(item))));
      });
    }

    /** Convert this to a boxed representation. */
    Parameter<Item> into_boxed() && {
      using ResultImpl = internal::parameter::BoxedImpl<Item>;
      return Parameter<Item>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Parameter<Item>() && {
      using ResultImpl = internal::parameter::BoxedImpl<Item>;
      return Parameter<Item>(ResultImpl(std::move(impl)));
    }
  };

  namespace internal {

    namespace parameter {

      /** @private */
      template<typename Item, typename Impl>
      inline Impl&& move_impl(Parameter<Item, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /** Create a `Parameter` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<Item> auto pure_parameter(const Item& item) {
#else
  inline auto pure_parameter(const Item& item) {
#endif
    using ResultImpl = internal::parameter::Return<Item>;
    return Parameter<Item, ResultImpl>(ResultImpl(item));
  }

  /** Create a `Parameter` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<Item> auto pure_parameter(Item&& item) {
#else
  inline auto pure_parameter(Item&& item) {
#endif
    using ResultImpl = internal::parameter::Return<Item>;
    return Parameter<Item, ResultImpl>(ResultImpl(std::move(item)));
  }

  /**
   * Delay the `Parameter` computation and return the resulting compound `Parameter`
   * computation, where `DelayFn` is a function that returns an intermediate `Parameter`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_parameter(DelayFn&& f) requires ParameterDelayFn<DelayFn> {
#else
  inline auto delay_parameter(DelayFn&& f) {
#endif
    return pure_parameter(Unit()).and_then([f{std::move(f)}](Unit&& unit) mutable {
      return f();
    });
  }

  /**
   * Construct a new `Parameter<Item>` computation by the specified closure `ConsFn`,
   * which must be a function of the `Run` pointer that returns an `Item`.
   */
  template<typename ConsFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_parameter(ConsFn&& f) requires ParameterConsFn<ConsFn> {
#else
  inline auto cons_parameter(ConsFn&& f) {
#endif
    using Item = typename std::invoke_result_t<ConsFn, const Run*>::item_type;
    auto fn = [f{std::move(f)}](const Run *r) mutable { return f(r); };
    return Parameter<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Parameter<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<Item> auto into_parameter(Parameter<Item, Impl>&& from) {
#else
  inline auto into_parameter(Parameter<Item, Impl>&& from) {
#endif
    return std::move(from);
  }

  /** Return the simulation specs within `Parameter<const Specs*>`. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<const Specs*> auto simulation_specs() {
#else
  inline auto simulation_specs() {
#endif
    auto fn = [](const Run *r) { return r->specs; };
    return Parameter<const Specs*, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations, where the final computation has
   * type `Parameter<std::vector<Item>>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ParameterLike<std::vector<Item>> auto parameter_sequence(std::vector<Parameter<Item, Impl>>&& comps) {
#else
  auto parameter_sequence(std::vector<Parameter<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Run *r) mutable {
      std::vector<Item> result;
      for (auto& comp : comps) {
        Result<Item> res { std::move(comp)(r) };
        if (auto item = get_result_if<Item>(&res)) [[likely]] {
          result.emplace_back(std::move(*item));
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<std::vector<Item>>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<std::vector<Item>>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<std::vector<Item>>(std::move(result));
    };
    return Parameter<std::vector<Item>, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations for performing side effects,
   * when the intermediate results are discarded, but the final computation
   * has type `Parameter<Unit>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ParameterLike<Unit> auto parameter_sequence_(std::vector<Parameter<Item, Impl>>&& comps) {
#else
  auto parameter_sequence_(std::vector<Parameter<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Run *r) mutable {
      for (auto& comp : comps) {
        Result<Item> res { std::move(comp)(r) };
        if (get_result_if<Item>(&res)) [[likely]] {
          continue;
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<Unit>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<Unit>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<Unit>(Unit());
    };
    return Parameter<Unit, decltype(fn)>(std::move(fn));
  }
}

#endif /* dvcompute_parameter_h */

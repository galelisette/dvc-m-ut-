/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_event_fn2_h
#define dvcompute_event_fn2_h

#include <functional>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "types.h"
#include "specs.h"
#include "result.h"
#include "event_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace event {

      /** @private */
      struct UncancellableTag {};

      /** @private */
      class UnitBoxedImpl2 {

        int tag;

        struct FnPair {
          BoxedImpl<Unit> fn;
          BoxedImpl<Unit> cancel_fn;

          FnPair(BoxedImpl<Unit>&& fn_arg, BoxedImpl<Unit>&& cancel_fn_arg) noexcept :
            fn(std::move(fn_arg)), cancel_fn(std::move(cancel_fn_arg))
          {}

          void swap(FnPair& other) noexcept {
            fn.swap(other.fn);
            cancel_fn.swap(other.cancel_fn);
          }
        };

        union {
          BoxedImpl<Unit> cancellable_fn;     // tag = 0
          BoxedImpl<Unit> uncancellable_fn;   // tag = 1
          FnPair fn_pair;                     // tag = 2
        };

      public:

        explicit UnitBoxedImpl2() noexcept :
          tag(0), cancellable_fn()
        {}

        UnitBoxedImpl2(BoxedImpl<Unit>&& cancellable_fn_arg) noexcept :
          tag(0), cancellable_fn(std::move(cancellable_fn_arg))
        {}

        UnitBoxedImpl2(UncancellableTag, BoxedImpl<Unit>&& uncancellable_fn_arg) noexcept :
          tag(1), uncancellable_fn(std::move(uncancellable_fn_arg))
        {}

        UnitBoxedImpl2(BoxedImpl<Unit>&& fn_arg, BoxedImpl<Unit>&& cancel_fn_arg) noexcept :
          tag(2), fn_pair(std::move(fn_arg), std::move(cancel_fn_arg))
        {}

        ~UnitBoxedImpl2() {
          switch(tag) {
            case 0:
              cancellable_fn.~BoxedImpl<Unit>();
              break;

            case 1:
              uncancellable_fn.~BoxedImpl<Unit>();
              break;

            case 2:
              fn_pair.~FnPair();
              break;
          }
        }

        UnitBoxedImpl2(UnitBoxedImpl2&& other) noexcept :
          tag(other.tag)
        {
          switch(tag) {
            case 0:
              new(&cancellable_fn) BoxedImpl<Unit>(std::move(other.cancellable_fn));
              break;

            case 1:
              new(&uncancellable_fn) BoxedImpl<Unit>(std::move(other.uncancellable_fn));
              break;

            case 2:
              new(&fn_pair) FnPair(std::move(other.fn_pair));
              break;
          }
        }

        UnitBoxedImpl2& operator=(UnitBoxedImpl2&& other) noexcept {
          UnitBoxedImpl2 tmp { std::move(other) };
          swap(tmp);
          return *this;
        }

#ifdef DVCOMPUTE_COPY_CTOR

        UnitBoxedImpl2(const UnitBoxedImpl2& other) :
          tag(other.tag)
        {
          switch(tag) {
            case 0:
              new(&cancellable_fn) BoxedImpl<Unit>(other.cancellable_fn);
              break;

            case 1:
              new(&uncancellable_fn) BoxedImpl<Unit>(other.uncancellable_fn);
              break;

            case 2:
              new(&fn_pair) FnPair(other.fn_pair);
              break;
          }
        }

        UnitBoxedImpl2& operator=(const UnitBoxedImpl2& other) {
          UnitBoxedImpl2 tmp(other);
          swap(tmp);
          return *this;
        }

#endif /* DVCOMPUTE_COPY_CTOR */

        Result<Unit> operator()(const Point* p) && {
          switch(tag) {
            case 0:
              return std::move(cancellable_fn)(p);

            case 1:
              return std::move(uncancellable_fn)(p);

            default:
              return std::move(fn_pair.fn)(p);
          }
        }

        Result<Unit> cancel(const Point* p) && {
          switch(tag) {
            case 0:
              return Result<Unit>(Unit());

            case 1:
              return std::move(uncancellable_fn)(p);

            default:
              return std::move(fn_pair.cancel_fn)(p);
          }
        }

        void swap(UnitBoxedImpl2& other) noexcept {
          switch(tag) {
            case 0:
              {
                switch(other.tag) {
                  case 0:
                    cancellable_fn.swap(other.cancellable_fn);
                    break;

                  case 1:
                    {
                      BoxedImpl<Unit> tmp { std::move(other.uncancellable_fn) };
                      other.uncancellable_fn.~BoxedImpl<Unit>();
                      new(&other.cancellable_fn) BoxedImpl<Unit>(std::move(cancellable_fn));
                      cancellable_fn.~BoxedImpl<Unit>();
                      new(&uncancellable_fn) BoxedImpl<Unit>(std::move(tmp));
                    }
                    break;

                  case 2:
                    {
                      FnPair tmp { std::move(other.fn_pair) };
                      other.fn_pair.~FnPair();
                      new(&other.cancellable_fn) BoxedImpl<Unit>(std::move(cancellable_fn));
                      cancellable_fn.~BoxedImpl<Unit>();
                      new(&fn_pair) FnPair(std::move(tmp));
                    }
                    break;
                }
              }
              break;

            case 1:
              {
                switch(other.tag) {
                  case 0:
                    {
                      BoxedImpl<Unit> tmp { std::move(other.cancellable_fn) };
                      other.cancellable_fn.~BoxedImpl<Unit>();
                      new(&other.uncancellable_fn) BoxedImpl<Unit>(std::move(uncancellable_fn));
                      uncancellable_fn.~BoxedImpl<Unit>();
                      new(&cancellable_fn) BoxedImpl<Unit>(std::move(tmp));
                    }
                    break;

                  case 1:
                    uncancellable_fn.swap(other.uncancellable_fn);
                    break;

                  case 2:
                    {
                      FnPair tmp { std::move(other.fn_pair) };
                      other.fn_pair.~FnPair();
                      new(&other.uncancellable_fn) BoxedImpl<Unit>(std::move(uncancellable_fn));
                      uncancellable_fn.~BoxedImpl<Unit>();
                      new(&fn_pair) FnPair(std::move(tmp));
                    }
                    break;
                }
              }
              break;

            case 2:
              {
                switch(other.tag) {
                  case 0:
                    {
                      BoxedImpl<Unit> tmp { std::move(other.cancellable_fn) };
                      other.cancellable_fn.~BoxedImpl<Unit>();
                      new(&other.fn_pair) FnPair(std::move(fn_pair));
                      fn_pair.~FnPair();
                      new(&cancellable_fn) BoxedImpl<Unit>(std::move(tmp));
                    }
                    break;

                  case 1:
                    {
                      BoxedImpl<Unit> tmp { std::move(other.uncancellable_fn) };
                      other.uncancellable_fn.~BoxedImpl<Unit>();
                      new(&other.fn_pair) FnPair(std::move(fn_pair));
                      fn_pair.~FnPair();
                      new(&uncancellable_fn) BoxedImpl<Unit>(std::move(tmp));
                    }
                    break;

                  case 2:
                    fn_pair.swap(other.fn_pair);
                    break;
                }
              }
              break;
          }

          int tmp_tag = other.tag;
          other.tag = tag;
          tag = tmp_tag;
        }
      };
    }
  }
}

#endif /* dvcompute_event_fn2_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_storage_h
#define dvcompute_block_storage_h

#include <cstdint>
#include <optional>
#include <functional>

#include "../../../dvcompute_ns.h"
#include "../macros.h"
#include "../types.h"
#include "../ref.h"
#include "../simulation.h"
#include "../process.h"
#include "../strategy.h"
#include "../result.h"
#include "../observable.h"
#include "../observable_source.h"

namespace DVCOMPUTE_NS {

  namespace block {

    namespace internal {

      namespace storage {

        /** Identifies a transact item that was delayed. */
        template<typename Item>
        struct StorageDelayedItem {

          /** The transact identifier. */
          TransactIdPtr transact_id;

          /** The time of delaying the transact. */
          double time;

          /** The corresponding content decrement. */
          int decrement;

          /** The continuation of the corresponding process. */
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont;
        };
      }
    }

    /** Represents a storage. */
    template<typename Item>
    class Storage;

    /** The shared reference for the storage. */
    template<typename Item>
      using StoragePtr = SharedPtr<Storage<Item>>;

    /** Represents a storage. */
    template<typename Item>
    class Storage {

      /** The storage capacity. */
      int init_capacity;

      /** The content. */
      Ref<int> content;

      /** The content statistics. */
      Ref<TimingStats<int>> content_stats;

      /** The content observable source. */
      ObservableSource<int> content_source;

      /** The use count. */
      Ref<int> use_count;

      /** The use count observable source. */
      ObservableSource<int> use_count_source;

      /** The used content. */
      Ref<int> used_content;

      /** The used content observable source. */
      ObservableSource<int> used_content_source;

      /** The utilization. */
      Ref<int> util_count;

      /** The utilization statistics. */
      Ref<TimingStats<int>> util_count_stats;

      /** The utilization count observable source. */
      ObservableSource<int> util_count_source;

      /** The queue length. */
      Ref<int> queue_count;

      /** The queue count statistics. */
      Ref<TimingStats<int>> queue_count_stats;

      /** The queue count observable source. */
      ObservableSource<int> queue_count_source;

      /** The total wait time. */
      Ref<double> total_wait_time;

      /** The wait time. */
      Ref<SamplingStats<double>> wait_time;

      /** The wait time observable source. */
      ObservableSource<SamplingStats<double>> wait_time_source;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

      /** The Delay chain. */
      PriorityFCFSStorage<internal::storage::StorageDelayedItem<Item>> delay_chain;

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

      /** The Delay chain. */
      PriorityFCFSStorage<SharedPtr<internal::storage::StorageDelayedItem<Item>>> delay_chain;

#else
#error "Unknown simulation mode"
#endif

      explicit Storage(double time_arg, int init_capacity_arg) :
        init_capacity(init_capacity_arg),
        content(init_capacity),
        content_stats(TimingStats<int>::from_sample(time_arg, init_capacity)),
        content_source(),
        use_count(0),
        use_count_source(),
        used_content(0),
        used_content_source(),
        util_count(0),
        util_count_stats(TimingStats<int>::from_sample(time_arg, 0)),
        util_count_source(),
        queue_count(0),
        queue_count_stats(TimingStats<int>::from_sample(time_arg, 0)),
        queue_count_source(),
        total_wait_time(0.0),
        wait_time(SamplingStats<double>()),
        wait_time_source(),
        delay_chain()
      {}

    public:

      Storage(const Storage<Item>&) = delete;
      Storage<Item>& operator=(const Storage<Item>&) = delete;

      Storage(Storage<Item>&&) = delete;
      Storage<Item>& operator=(Storage<Item>&&) = delete;

      /** Return the storage capacity. */
      int capacity() const noexcept {
        return init_capacity;
      }

    private:

      /** Update the available content. */
      Result<Unit> update_content(int delta, const Point* p) {
        int a = content.read_at(p);
        int a2 = a + delta;
        const auto& stats = content_stats.read_at(p);
        content.write_at(int { a2 }, p);
        content_stats.write_at(stats.add(p->time, a2), p);
        return content_source.trigger_at(&a2, p);
      }

      /** Update the total storage use count. */
      Result<Unit> update_use_count(int delta, const Point* p) {
        int a = use_count.read_at(p);
        int a2 = a + delta;
        use_count.write_at(int { a2 }, p);
        return use_count_source.trigger_at(&a2, p);
      }

      /** Update the total used storage content. */
      Result<Unit> update_used_content(int delta, const Point* p) {
        int a = used_content.read_at(p);
        int a2 = a + delta;
        used_content.write_at(int { a2 }, p);
        return used_content_source.trigger_at(&a2, p);
      }

      /** Update the queue count. */
      Result<Unit> update_queue_count(int delta, const Point* p) {
        int a = queue_count.read_at(p);
        int a2 = a + delta;
        const auto& stats = queue_count_stats.read_at(p);
        queue_count.write_at(int { a2 }, p);
        queue_count_stats.write_at(stats.add(p->time, a2), p);
        return queue_count_source.trigger_at(&a2, p);
      }

      /** Update the utilization count. */
      Result<Unit> update_util_count(int delta, const Point* p) {
        int a = util_count.read_at(p);
        int a2 = a + delta;
        const auto& stats = util_count_stats.read_at(p);
        util_count.write_at(int { a2 }, p);
        util_count_stats.write_at(stats.add(p->time, a2), p);
        return util_count_source.trigger_at(&a2, p);
      }

      /** Update the wait time. */
      Result<Unit> update_wait_time(double delta, const Point* p) {
        double a = total_wait_time.read_at(p);
        double a2 = a + delta;
        const auto& stats = wait_time.read_at(p);
        total_wait_time.write_at(double { a2 }, p);
        wait_time.write_at(stats.add(delta), p);
        SamplingStats<double> stats2 { wait_time.read_at(p) };
        return wait_time_source.trigger_at(&stats2, p);
      }

      template<typename ContFn>
      static Result<Unit> enter_free(const StoragePtr<Item>& storage,
        const TransactIdPtr& tid,
        int decrement,
        ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        auto t = p->time;
        int a = storage->content.read_at(p);

        if (a < decrement) {
          auto res { 
            DVCOMPUTE_NS::internal::process::freeze_process_with_reentering_at<Unit>(std::move(cont_fn), pid, Unit(), 
              DVCOMPUTE_NS::internal::process::move_impl(enter_storage(storage, tid, decrement)), p)
          };
  
          if (auto *cont_fn = get_result_if(&res)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
            internal::storage::StorageDelayedItem<Item> item {
              tid, t, decrement, std::move(*cont_fn)
            };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
            SharedPtr<internal::storage::StorageDelayedItem<Item>> item(mk_shared(internal::storage::StorageDelayedItem<Item> {
              tid, t, decrement, std::move(*cont_fn)
            }));
#else
#error "Unknown simulation mode"
#endif

            int init_priority = tid->get_priority_at(p);
            storage->delay_chain.push_with_priority(init_priority, std::move(item), p);
            TRY_RESULT(storage->update_queue_count(1, p));
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }

        } else {
          TRY_RESULT(storage->update_wait_time(0.0, p));
          TRY_RESULT(storage->update_content(- decrement, p));
          TRY_RESULT(storage->update_use_count(1, p));
          TRY_RESULT(storage->update_used_content(decrement, p));
          TRY_RESULT(storage->update_util_count(decrement, p));
          return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
        }
      }

      template<typename ContFn>
      static Result<Unit> enter(const StoragePtr<Item>& storage,
        const TransactIdPtr& tid,
        int decrement,
        ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        auto t = p->time;
        bool f = storage->delay_chain.empty(p);

        if (f) {
          return Storage<Item>::enter_free(storage, tid, decrement, std::move(cont_fn), pid, p);
        
        } else {
          auto res { 
            DVCOMPUTE_NS::internal::process::freeze_process_with_reentering_at<Unit>(std::move(cont_fn), pid, Unit(), 
              DVCOMPUTE_NS::internal::process::move_impl(enter_storage(storage, tid, decrement)), p)
          };
  
          if (auto *cont_fn = get_result_if(&res)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
            internal::storage::StorageDelayedItem<Item> item {
              tid, t, decrement, std::move(*cont_fn)
            };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
            SharedPtr<internal::storage::StorageDelayedItem<Item>> item(mk_shared(internal::storage::StorageDelayedItem<Item> {
              tid, t, decrement, std::move(*cont_fn)
            }));
#else
#error "Unknown simulation mode"
#endif

            int init_priority = tid->get_priority_at(p);
            storage->delay_chain.push_with_priority(init_priority, std::move(item), p);
            TRY_RESULT(storage->update_queue_count(1, p));
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }
        }
      }

      static Result<Unit> leave(const StoragePtr<Item>& storage,
        int increment,
        const Point* p)
      {
        auto t = p->time;

        TRY_RESULT(storage->update_util_count(- increment, p));
        TRY_RESULT(storage->update_content(increment, p));
        TRY_RESULT(enqueue_uncancellable_event(t, Storage<Item>::try_enter(storage))(p));

        return Result<Unit>(Unit());
      }

      /** Try to enter the storage within `Event<Unit>`. */
      static auto try_enter(const StoragePtr<Item>& storage) {
        return cons_event([=](const Point* p) {
          int a = storage->content.read_at(p);
          if (a > 0) {
            return let_enter(storage, p);
          } else {
            return Result<Unit>(Unit());
          }
        });
      }

      /** Let enter the storage. */
      static Result<Unit> let_enter(const StoragePtr<Item>& storage, const Point* p) {
        auto t = p->time;
        int a = storage->content.read_at(p);

        if (a > storage->init_capacity) {
          return RetryResult("The storage content cannot exceed the limited capacity");

        } else if (!storage->delay_chain.empty(p)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

          std::optional<internal::storage::StorageDelayedItem<Item>> item_cont {
            storage->delay_chain.remove_by([a](const internal::storage::StorageDelayedItem<Item> &item) {
              return item.decrement <= a;
            }, p)
          };
          if (!item_cont.has_value()) {
            return Result<Unit>(Unit());
          }
          auto *item = &item_cont.value();

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

          std::optional<SharedPtr<internal::storage::StorageDelayedItem<Item>>> item_cont {
            storage->delay_chain.remove_by([a](const SharedPtr<internal::storage::StorageDelayedItem<Item>> &item) {
              return item->decrement <= a;
            }, p)
          };
          if (!item_cont.has_value()) {
            return Result<Unit>(Unit());
          }
          const auto *item = item_cont.value().get();

#else
#error "Unknown simulation mode"
#endif

          TransactIdPtr tid { item->transact_id };
          auto t0 = item->time;
          int decrement0 = item->decrement;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont0 { std::move(item->cont) };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont0 { item->cont };
#else
#error "Unknown simulation mode"
#endif

          TRY_RESULT(storage->update_queue_count(-1, p));

          auto res { DVCOMPUTE_NS::internal::process::unfreeze_process_at(std::move(cont0), p) };
          if (auto *cont_fn = get_result_if(&res)) {

            if (!(*cont_fn)) {
              return Storage<Item>::let_enter(storage, p);

            } else {
              auto res { tid->require_process_id(p) };
              if (auto *pid = get_result_if(&res)) {

                TRY_RESULT(storage->update_content(- decrement0, p));
                TRY_RESULT(storage->update_wait_time(t - t0, p));
                TRY_RESULT(storage->update_util_count(decrement0, p));
                TRY_RESULT(storage->update_use_count(1, p));
                TRY_RESULT(storage->update_used_content(decrement0, p));
                
                return enqueue_uncancellable_event(t,
                  cons_event([cont_fn{std::move(*cont_fn)}, pid{*pid}](const Point *p) mutable {
                    return DVCOMPUTE_NS::internal::process::reenter_process_at(std::move(cont_fn), pid, Unit(), p);
                  }))(p);

              } else {
                return error_result<Unit>(std::move(res));
              }
            }
            
          } else {
            return error_result<Unit>(std::move(res));
          }

        } else {
          return Result<Unit>(Unit());
        }
      }

      /** @private */
      class Enter {

        StoragePtr<Item> storage;
        TransactIdPtr tid;
        int decrement;

      public:

        explicit Enter(const StoragePtr<Item>& storage_arg, 
          const TransactIdPtr& tid_arg, 
          int decrement_arg) noexcept :
            storage(storage_arg), tid(tid_arg), decrement(decrement_arg)
        {}

        Enter(Enter&& other) = default;
        Enter& operator=(Enter&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Enter(const Enter& other) = default;
        Enter& operator=(const Enter& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          return Storage<Item>::enter(storage, tid, decrement, std::move(cont_fn), pid, p);
        }
      };

      /** @private */
      class EnterWeak {

        WeakPtr<Storage<Item>> weak_storage;
        TransactIdPtr tid;
        int decrement;

      public:

        explicit EnterWeak(const WeakPtr<Storage<Item>>& weak_storage_arg, 
          const TransactIdPtr& tid_arg, 
          int decrement_arg) noexcept :
            weak_storage(weak_storage_arg), tid(tid_arg), decrement(decrement_arg)
        {}

        EnterWeak(EnterWeak&& other) = default;
        EnterWeak& operator=(EnterWeak&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        EnterWeak(const EnterWeak& other) = default;
        EnterWeak& operator=(const EnterWeak& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          StoragePtr<Item> storage { weak_storage.lock() };
          if (storage) {
            return Storage<Item>::enter(storage, tid, decrement, std::move(cont_fn), pid, p);
          } else {
            throw PanicResult("The storage was removed.");
          }
        }
      };

      /** @private */
      class Leave {

        StoragePtr<Item> storage;
        int increment;

      public:

        explicit Leave(const StoragePtr<Item>& storage_arg, int increment_arg) noexcept :
          storage(storage_arg), increment(increment_arg)
        {}

        Leave(Leave&& other) = default;
        Leave& operator=(Leave&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Leave(const Leave& other) = default;
        Leave& operator=(const Leave& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          TRY_RESULT(Storage<Item>::leave(storage, increment, p));
          return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
        }
      };

      template<typename Item2>
      friend auto new_storage(int capacity);

      template<typename Item2>
      friend auto late_init_storage(int capacity, StoragePtr<Item2>& dest);

      template<typename Item2>
      friend auto storage_empty(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_full(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_content(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_content_stats(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_content_changed(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_content_changed_(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_use_count(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_use_count_changed(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_use_count_changed_(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_used_content(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_used_content_changed(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_used_content_changed_(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_average_holding_time(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_util_count(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_util_count_stats(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_util_count_changed(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_util_count_changed_(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_queue_count(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_queue_count_stats(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_queue_count_changed(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_queue_count_changed_(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_total_wait_time(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_wait_time(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_wait_time_changed(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto storage_wait_time_changed_(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto reset_storage(const StoragePtr<Item2>& storage);

      template<typename Item2>
      friend auto enter_storage(const StoragePtr<Item2>& storage, const TransactIdPtr& tid, int decrement);

      template<typename Item2>
      friend auto enter_storage_weak(const WeakPtr<Storage<Item2>>& weak_storage, const TransactIdPtr& tid, int decrement);

      template<typename Item2>
      friend auto leave_storage(const StoragePtr<Item2>& storage, int decrement);

      template<typename Item2>
      friend auto leave_storage_within_event(const StoragePtr<Item2>& storage, int decrement);
    };

    /** Create a new storage within `Event<StoragePtr<Item>>` computation. */
    template<typename Item>
    auto new_storage(int capacity) {
      auto fn = [=](const Point* p) {
        return Result<StoragePtr<Item>>(StoragePtr<Item>(SharedPtrFn {}, [t{p->time}, capacity](Storage<Item> *address) {
          new(address) Storage<Item>(t, capacity);
        }));
      };
      return Event<StoragePtr<Item>, decltype(fn)>(std::move(fn));
    }

    /** Create a new storage within `Event<Unit>` computation by the specified destination. */
    template<typename Item>
    auto late_init_storage(int capacity, StoragePtr<Item>& dest) {
      auto fn = [=](const Point* p) mutable {
        dest.late_init(SharedPtrFn {}, [t{p->time}, capacity](Storage<Item> *address) {
          new(address) Storage<Item>(t, capacity);
        });
        return Result<Unit>(Unit());
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Return within `Event<bool>` the flag indicating whether the storage is empty. */
    template<typename Item>
    auto storage_empty(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<bool>(storage->content.read_at(p) == storage->capacity());
      };
      return Event<bool, decltype(fn)>(std::move(fn));
    }

    /** Return within `Event<bool>` the flag indicating whether the storage is full. */
    template<typename Item>
    auto storage_full(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<bool>(storage->content.read_at(p) == 0);
      };
      return Event<bool, decltype(fn)>(std::move(fn));
    }

    /** Return the current available content of the storage within `Event<int>`. */
    template<typename Item>
    auto storage_content(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<int>(storage->content.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for available content of the storage within `Event<TimingStats<int>>`. */
    template<typename Item>
    auto storage_content_stats(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(storage->content_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the content property changes. */
    template<typename Item>
    auto storage_content_changed(const StoragePtr<Item>& storage) {
      return storage->content_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the content property changes. */
    template<typename Item>
    auto storage_content_changed_(const StoragePtr<Item>& storage) {
      return storage_content_changed(storage)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the current storage use count within `Event<int>`. */
    template<typename Item>
    auto storage_use_count(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<int>(storage->use_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the storage use count property changes. */
    template<typename Item>
    auto storage_use_count_changed(const StoragePtr<Item>& storage) {
      return storage->use_count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the storage use count property changes. */
    template<typename Item>
    auto storage_use_count_changed_(const StoragePtr<Item>& storage) {
      return storage_use_count_changed(storage)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the current storage used content within `Event<int>`. */
    template<typename Item>
    auto storage_used_content(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<int>(storage->used_content.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the storage used content property changes. */
    template<typename Item>
    auto storage_used_content_changed(const StoragePtr<Item>& storage) {
      return storage->used_content_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the storage used content property changes. */
    template<typename Item>
    auto storage_used_content_changed_(const StoragePtr<Item>& storage) {
      return storage_used_content_changed(storage)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the average holding time of the storage within `Event<double>`. */
    template<typename Item>
    auto storage_average_holding_time(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        TimingStats<int> s { storage->util_count_stats.read_at(p) };
        int n = storage->util_count.read_at(p);
        int m = storage->used_content.read_at(p);
        double t = p->time;
        TimingStats<int> s2 { s.add(t, n) };
        return Result<double>(s2.sum / static_cast<double>(m));
      };
      return Event<double, decltype(fn)>(std::move(fn));
    }

    /** Return the current utilization count of the storage within `Event<int>`. */
    template<typename Item>
    auto storage_util_count(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<int>(storage->util_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for utilization count of the storage within `Event<TimingStats<int>>`. */
    template<typename Item>
    auto storage_util_count_stats(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(storage->util_count_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the utilization count property changes. */
    template<typename Item>
    auto storage_util_count_changed(const StoragePtr<Item>& storage) {
      return storage->util_count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the utilization count property changes. */
    template<typename Item>
    auto storage_util_count_changed_(const StoragePtr<Item>& storage) {
      return storage_util_count_changed(storage)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the current queue length of the storage within `Event<int>`. */
    template<typename Item>
    auto storage_queue_count(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<int>(storage->queue_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for queue length of the storage within `Event<TimingStats<int>>`. */
    template<typename Item>
    auto storage_queue_count_stats(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(storage->queue_count_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the queue length property changes. */
    template<typename Item>
    auto storage_queue_count_changed(const StoragePtr<Item>& storage) {
      return storage->queue_count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the queue length property changes. */
    template<typename Item>
    auto storage_queue_count_changed_(const StoragePtr<Item>& storage) {
      return storage_queue_count_changed(storage)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the total wait time of the storage within `Event<double>`. */
    template<typename Item>
    auto storage_total_wait_time(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<double>(storage->total_wait_time.read_at(p));
      };
      return Event<double, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for wait time of the storage within `Event<SamplingStats<double>>`. */
    template<typename Item>
    auto storage_wait_time(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        return Result<SamplingStats<double>>(storage->wait_time.read_at(p));
      };
      return Event<SamplingStats<double>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<SamplingStats<double>>` when the wait time property changes. */
    template<typename Item>
    auto storage_wait_time_changed(const StoragePtr<Item>& storage) {
      return storage->wait_time_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the wait time property changes. */
    template<typename Item>
    auto storage_wait_time_changed_(const StoragePtr<Item>& storage) {
      return storage_wait_time_changed(storage)
        .map([](const SamplingStats<double>* message) {
          return Unit();
        });
    }

    /** Triggered within `Observable<Unit>` when one of the storage properties changes. */
    template<typename Item>
    auto storage_changed_(const StoragePtr<Item>& storage) {
      return storage_content_changed_(storage)
        .merge(storage_used_content_changed_(storage))
        .merge(storage_util_count_changed_(storage))
        .merge(storage_queue_count_changed_(storage));
    }

    /** Reset the storage statistics within `Event<Unit>`. */
    template<typename Item>
    auto reset_storage(const StoragePtr<Item>& storage) {
      auto fn = [=](const Point* p) {
        double t = p->time;
        int content = storage->content.read_at(p);
        int used_content = storage->capacity() - content;
        int util_count = storage->util_count.read_at(p);
        int queue_count = storage->queue_count.read_at(p);
        
        storage->content_stats.write_at(TimingStats<int>::from_sample(t, content), p);
        storage->use_count.write_at(0, p);
        storage->used_content.write_at(int { used_content }, p);
        storage->util_count_stats.write_at(TimingStats<int>::from_sample(t, util_count), p);
        storage->queue_count_stats.write_at(TimingStats<int>::from_sample(t, queue_count), p);
        storage->total_wait_time.write_at(0.0, p);
        storage->wait_time.write_at(SamplingStats<double>(), p);

        int zero = 0;
        SamplingStats<double> empty_stats;
        
        TRY_RESULT(storage->content_source.trigger_at(&content, p));
        TRY_RESULT(storage->use_count_source.trigger_at(&zero, p));
        TRY_RESULT(storage->used_content_source.trigger_at(&used_content, p));
        TRY_RESULT(storage->util_count_source.trigger_at(&util_count, p));
        TRY_RESULT(storage->queue_count_source.trigger_at(&queue_count, p));
        TRY_RESULT(storage->wait_time_source.trigger_at(&empty_stats, p));

        return Result<Unit>(Unit());
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Enter the storage within `Process<Unit>`. */
    template<typename Item>
    auto enter_storage(const StoragePtr<Item>& storage, const TransactIdPtr& tid, int decrement = 1) {
      using ResultImpl = typename Storage<Item>::Enter;
      return Process<Unit, ResultImpl>(ResultImpl(storage, tid, decrement));
    }

    /** Try to enter the storage within `Process<Unit>`. */
    template<typename Item>
    auto enter_storage_weak(const WeakPtr<Storage<Item>>& weak_storage, const TransactIdPtr& tid, int decrement = 1) {
      using ResultImpl = typename Storage<Item>::EnterWeak;
      return Process<Unit, ResultImpl>(ResultImpl(weak_storage, tid, decrement));
    }

    /** Leave the storage within `Process<Unit>`. */
    template<typename Item>
    auto leave_storage(const StoragePtr<Item>& storage, int increment = 1) {
      using ResultImpl = typename Storage<Item>::Leave;
      return Process<Unit, ResultImpl>(ResultImpl(storage, increment));
    }

    /** Leave the storage within `Event<Unit>`. */
    template<typename Item>
    auto leave_storage_within_event(const StoragePtr<Item>& storage, int increment = 1) {
      auto impl = [storage, increment](const Point *p) {
        return Storage<Item>::leave(storage, increment, p);
      };
      return Event<Unit, decltype(impl)>(std::move(impl));
    }
  }
}

#endif /* dvcompute_block_storage_h */

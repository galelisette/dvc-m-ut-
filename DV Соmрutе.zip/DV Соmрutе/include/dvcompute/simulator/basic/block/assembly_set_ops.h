/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_assembly_set_ops_h
#define dvcompute_block_assembly_set_ops_h

#include <vector>

#include "../macros.h"
#include "assembly_set.h"
#include "transact.h"
#include "transact_ops.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace transact {

      /** @private */
      class Assemble {

        using TransactIdPtr = DVCOMPUTE_NS::block::TransactIdPtr;

        using AssemblySet = DVCOMPUTE_NS::block::AssemblySet;

        using AssemblySetPtr = SharedPtr<AssemblySet>;

        TransactIdPtr tid;
        int count;

      public:

        Assemble(const TransactIdPtr& tid_arg, int count_arg) noexcept : tid(tid_arg), count(count_arg) {}
        Assemble(TransactIdPtr&& tid_arg, int count_arg) noexcept : tid(std::move(tid_arg)), count(count_arg) {}

        Assemble(Assemble&& other) = default;
        Assemble& operator=(Assemble&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Assemble(const Assemble& other) = default;
        Assemble& operator=(const Assemble& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {
            auto res { transact_assembly_set(tid)(p) };
            if (AssemblySetPtr *s = get_result_if<AssemblySetPtr>(&res)) {
              int a = (*s)->assembling_count.read_at(p);
              if (a == 0) {
                int count2 = count - 1;
                if (count2 < 0) {
                  return RetryResult("The number of transacts must be positive");
                } else if (count2 == 0) {
                  return Result<Unit>(Unit());
                } else {
                  auto res { tid->require_process_id(p) };
                  if (ProcessIdPtr *pid0 = get_result_if<ProcessIdPtr>(&res)) {
                    (*s)->assembling_transact.write_at(ProcessIdPtr(*pid0), p);
                    (*s)->assembling_count.write_at(std::move(count2), p);
                    return passivate_process()(std::move(cont_fn), pid, p);
                  } else {
                    return error_result<Unit>(std::move(res));
                  }
                }

              } else {
                int a2 = a - 1;
                if (a2 == 0) {
                  auto pid0 { (*s)->assembling_transact.swap_at(ProcessIdPtr(), p) };
                  (*s)->assembling_count.write_at(std::move(a2), p);
                  auto res { reactivate_process_immediately(pid0)(p) };
                  if (get_result_if<Unit>(&res)) {
                    return cancel_process<Unit>()(std::move(cont_fn), pid, p);
                  } else {
                    return error_result<Unit>(std::move(res));
                  }

                } else {
                  (*s)->assembling_count.write_at(std::move(a2), p);
                  return cancel_process<Unit>()(std::move(cont_fn), pid, p);
                }
             }

            } else {
              return error_result<Unit>(std::move(res));
            }
          }
        }
      };

      /** @private */
      class Gather {

        using TransactIdPtr = DVCOMPUTE_NS::block::TransactIdPtr;

        using AssemblySet = DVCOMPUTE_NS::block::AssemblySet;

        using AssemblySetPtr = SharedPtr<AssemblySet>;

        TransactIdPtr tid;
        int count;

      public:

        Gather(const TransactIdPtr& tid_arg, int count_arg) noexcept : tid(tid_arg), count(count_arg) {}
        Gather(TransactIdPtr&& tid_arg, int count_arg) noexcept : tid(std::move(tid_arg)), count(count_arg) {}

        Gather(Gather&& other) = default;
        Gather& operator=(Gather&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Gather(const Gather& other) = default;
        Gather& operator=(const Gather& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);
          } else {
            auto res { transact_assembly_set(tid)(p) };
            if (AssemblySetPtr *s = get_result_if<AssemblySetPtr>(&res)) {
              int a = (*s)->gathering_count.read_at(p);
              if (a == 0) {
                int count2 = count - 1;
                if (count2 < 0) {
                  return RetryResult("The number of transacts must be positive");
                } else if (count2 == 0) {
                  return Result<Unit>(Unit());
                } else {
                  auto res { tid->require_process_id(p) };
                  if (ProcessIdPtr *pid0 = get_result_if<ProcessIdPtr>(&res)) {
                    int priority = tid->get_priority_at(p);
                    (*s)->gathering_transacts.push_with_priority(priority, ProcessIdPtr(*pid0), p);
                    (*s)->gathering_count.write_at(std::move(count2), p);
                    return passivate_process()(std::move(cont_fn), pid, p);
                  } else {
                    return error_result<Unit>(std::move(res));
                  }
                }

              } else {
                int a2 = a - 1;
                int priority = tid->get_priority_at(p);
                auto res { tid->require_process_id(p) };
                if (ProcessIdPtr *pid0 = get_result_if<ProcessIdPtr>(&res)) {
                  (*s)->gathering_transacts.push_with_priority(priority, ProcessIdPtr(*pid0), p);
                  (*s)->gathering_count.write_at(int(a2), p);
                  if (a2 == 0) {
                    auto comp {
                      cons_event([s{*s}](const Point* p) {
                        std::vector<ProcessIdPtr> pids;
                        auto pid0 = s->gathering_transacts.pop(p);
                        while (pid0.has_value()) {
                          pids.push_back(pid0.value());
                          pid0 = s->gathering_transacts.pop(p);
                        }
                        return reactivate_processes_immediately(std::move(pids))(p);
                      })
                    };
                    return passivate_process_before(std::move(comp))(std::move(cont_fn), pid, p);

                  } else {
                    return passivate_process()(std::move(cont_fn), pid, p);
                  }

                } else {
                  return error_result<Unit>(std::move(res));
                }
             }

            } else {
              return error_result<Unit>(std::move(res));
            }
          }
        }
      };
    }
  }

  namespace block {

    /** Assemble the transact by the specified number within `Process<Unit>` computation. */
    inline auto assemble_transact(const TransactIdPtr& tid, int count) {
      using ResultImpl = internal::transact::Assemble;
      return Process<Unit, ResultImpl>(ResultImpl(tid, count));
    }

    /** Gather the transacts by the specified number within `Process<Unit>` computation. */
    inline auto gather_transacts(const TransactIdPtr& tid, int count) {
      using ResultImpl = internal::transact::Gather;
      return Process<Unit, ResultImpl>(ResultImpl(tid, count));
    }

    /** 
     * Test within `Event<bool>` computation whether another transact is being assembled 
     * for the corresponding assembly set.
     */
    inline auto is_transact_assembling(const TransactIdPtr& tid) {
      auto fn = [=](const Point* p) {
        auto res { transact_assembly_set(tid)(p) };
        if (AssemblySetPtr *s = get_result_if<AssemblySetPtr>(&res)) {
          return Result<bool>((*s)->assembling_count.read_at(p) > 0);
        } else {
          return error_result<bool>(std::move(res));
        }
      };
      return Event<bool, decltype(fn)>(std::move(fn));
    }

    /** 
     * Test within `Event<bool>` computation whether the transacts are being gathered 
     * for the corresponding assembly set.
     */
    inline auto is_transact_gathering(const TransactIdPtr& tid) {
      auto fn = [=](const Point* p) {
        auto res { transact_assembly_set(tid)(p) };
        if (AssemblySetPtr *s = get_result_if<AssemblySetPtr>(&res)) {
          return Result<bool>((*s)->gathering_count.read_at(p) > 0);
        } else {
          return error_result<bool>(std::move(res));
        }
      };
      return Event<bool, decltype(fn)>(std::move(fn));
    }
  }
}

#endif /* dvcompute_block_assembly_set_ops_h */

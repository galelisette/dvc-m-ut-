/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_facility_h
#define dvcompute_block_facility_h

#include <cstdint>
#include <optional>
#include <functional>

#include "../../../dvcompute_ns.h"
#include "../macros.h"
#include "../types.h"
#include "../ref.h"
#include "../simulation.h"
#include "../process.h"
#include "../strategy.h"
#include "../result.h"
#include "../observable.h"
#include "../observable_source.h"

namespace DVCOMPUTE_NS {

  namespace block {

    /** 
     * Proceed with the computation by the specified preempted transact
     * and remaining time from the process holding computation such as
     * the Advance block.
     */
    template<typename Item>
      using FacilityPreemptTransfer = std::function<Process<Unit>(const Transact<Item>&,
        const std::optional<double>&)>;

    /** The facility preemption mode. */
    template<typename Item>
    struct FacilityPreemptMode {

      /** The Priority mode; otherwise, the Interrupt mode. */
      bool priority_mode;

      /** 
       * Where to transfer the preempted transact, passing the remaing time
       * from the process holding computation such as the Advance block.
       */
      std::optional<FacilityPreemptTransfer<Item>> transfer;

      /** The Remove mode. */
      bool remove_mode;
    };

    namespace internal {

      namespace facility {

        /** Identifies a transact item that owns the facility. */
        template<typename Item>
        struct FacilityOwnerItem {

          /** The transact. */
          Transact<Item> transact;

          /** The initial transact priority. */
          int init_priority;

          /** The time when gaining the ownership. */
          double time;

          /** The preempting flag. */
          bool preempting;

          /** The interrupting flag. */
          bool interrupting;

          /** The accumulated holding time. */
          double acc_holding_time;
        };

        /** Identifies a transact item that was delayed. */
        template<typename Item>
        struct FacilityDelayedItem {

          /** The transact. */
          Transact<Item> transact;

          /** The initial transact priority. */
          int init_priority;

          /** The time of delaying the transact. */
          double time;

          /** The preempting flag. */
          bool preempting;

          /** The interrupting flag. */
          bool interrupting;

          /** The continuation of the corresponding process. */
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont;
        };

        /** Identifies a transact item that was interrupted. */
        template<typename Item>
        struct FacilityInterruptedItem {

          /** The transact. */
          Transact<Item> transact;

          /** The initial transact priority. */
          int init_priority;

          /** The time of interrupting the transact. */
          double time;

          /** The preempting flag. */
          bool preempting;

          /** The interrupting flag. */
          bool interrupting;

          /** The remaining time. */
          std::optional<double> remaining_time;

          /** Where to transfer the computation. */
          std::optional<FacilityPreemptTransfer<Item>> transfer;

          /** The accumulated holding time. */
          double acc_holding_time;
        };

        /** Identifies a transact item which is pending. */
        template<typename Item>
        struct FacilityPendingItem {

          /** The transact. */
          Transact<Item> transact;

          /** The initial transact priority. */
          int init_priority;

          /** The time of pending the transact. */
          double time;

          /** The preempting flag. */
          bool preempting;

          /** The interrupting flag. */
          bool interrupting;

          /** The continuation of the corresponding process. */
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont;
        };
      }
    }

    /** Represents a facility. */
    template<typename Item>
    class Facility;

    /** The shared reference for the facility. */
    template<typename Item>
      using FacilityPtr = SharedPtr<Facility<Item>>;

    /** Represents a facility. */
    template<typename Item>
    class Facility {

      /** The count. */
      Ref<int> count;

      /** The count statistics. */
      Ref<TimingStats<int>> count_stats;

      /** The count observable source. */
      ObservableSource<int> count_source;

      /** The capture count. */
      Ref<int> capture_count;

      /** The capture count observable source. */
      ObservableSource<int> capture_count_source;

      /** The utilization. */
      Ref<int> util_count;

      /** The utilization statistics. */
      Ref<TimingStats<int>> util_count_stats;

      /** The utilization count observable source. */
      ObservableSource<int> util_count_source;

      /** The queue length. */
      Ref<int> queue_count;

      /** The queue count statistics. */
      Ref<TimingStats<int>> queue_count_stats;

      /** The queue count observable source. */
      ObservableSource<int> queue_count_source;

      /** The total wait time. */
      Ref<double> total_wait_time;

      /** The wait time. */
      Ref<SamplingStats<double>> wait_time;

      /** The wait time observable source. */
      ObservableSource<SamplingStats<double>> wait_time_source;

      /** The total holding time. */
      Ref<double> total_holding_time;

      /** The holding time. */
      Ref<SamplingStats<double>> holding_time;

      /** The holding time observable source. */
      ObservableSource<SamplingStats<double>> holding_time_source;

      /** The owner. */
      Ref<SharedPtr<internal::facility::FacilityOwnerItem<Item>>> owner;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

      /** The Delay chain. */
      PriorityFCFSStorage<internal::facility::FacilityDelayedItem<Item>> delay_chain;

      /** The Interrupt chain. */
      PriorityLCFSStorage<internal::facility::FacilityInterruptedItem<Item>> interrupt_chain;

      /** The pending chain. */
      PriorityFCFSStorage<internal::facility::FacilityPendingItem<Item>> pending_chain;

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

      /** The Delay chain. */
      PriorityFCFSStorage<SharedPtr<internal::facility::FacilityDelayedItem<Item>>> delay_chain;

      /** The Interrupt chain. */
      PriorityLCFSStorage<SharedPtr<internal::facility::FacilityInterruptedItem<Item>>> interrupt_chain;

      /** The pending chain. */
      PriorityFCFSStorage<SharedPtr<internal::facility::FacilityPendingItem<Item>>> pending_chain;

#else
#error "Unknown simulation mode"
#endif

      explicit Facility(double time_arg) :
        count(1),
        count_stats(TimingStats<int>::from_sample(time_arg, 1)),
        count_source(),
        capture_count(0),
        capture_count_source(),
        util_count(0),
        util_count_stats(TimingStats<int>::from_sample(time_arg, 0)),
        util_count_source(),
        queue_count(0),
        queue_count_stats(TimingStats<int>::from_sample(time_arg, 0)),
        queue_count_source(),
        total_wait_time(0.0),
        wait_time(SamplingStats<double>()),
        wait_time_source(),
        total_holding_time(0.0),
        holding_time(SamplingStats<double>()),
        holding_time_source(),
        owner(SharedPtr<internal::facility::FacilityOwnerItem<Item>>()),
        delay_chain(),
        interrupt_chain(),
        pending_chain()
      {}

    public:

      Facility(const Facility<Item>&) = delete;
      Facility<Item>& operator=(const Facility<Item>&) = delete;

      Facility(Facility<Item>&&) = delete;
      Facility<Item>& operator=(Facility<Item>&&) = delete;

    private:

      /** Update the available count. */
      Result<Unit> update_count(int delta, const Point* p) {
        int a = count.read_at(p);
        int a2 = a + delta;
        const auto& stats = count_stats.read_at(p);
        count.write_at(int { a2 }, p);
        count_stats.write_at(stats.add(p->time, a2), p);
        return count_source.trigger_at(&a2, p);
      }

      /** Update the capture count. */
      Result<Unit> update_capture_count(int delta, const Point* p) {
        int a = capture_count.read_at(p);
        int a2 = a + delta;
        capture_count.write_at(int { a2 }, p);
        return capture_count_source.trigger_at(&a2, p);
      }

      /** Update the queue count. */
      Result<Unit> update_queue_count(int delta, const Point* p) {
        int a = queue_count.read_at(p);
        int a2 = a + delta;
        const auto& stats = queue_count_stats.read_at(p);
        queue_count.write_at(int { a2 }, p);
        queue_count_stats.write_at(stats.add(p->time, a2), p);
        return queue_count_source.trigger_at(&a2, p);
      }

      /** Update the utilization count. */
      Result<Unit> update_util_count(int delta, const Point* p) {
        int a = util_count.read_at(p);
        int a2 = a + delta;
        const auto& stats = util_count_stats.read_at(p);
        util_count.write_at(int { a2 }, p);
        util_count_stats.write_at(stats.add(p->time, a2), p);
        return util_count_source.trigger_at(&a2, p);
      }

      /** Update the wait time. */
      Result<Unit> update_wait_time(double delta, const Point* p) {
        double a = total_wait_time.read_at(p);
        double a2 = a + delta;
        const auto& stats = wait_time.read_at(p);
        total_wait_time.write_at(double { a2 }, p);
        wait_time.write_at(stats.add(delta), p);
        SamplingStats<double> stats2 { wait_time.read_at(p) };
        return wait_time_source.trigger_at(&stats2, p);
      }

      /** Update the holding time. */
      Result<Unit> update_holding_time(double delta, const Point* p) {
        double a = total_holding_time.read_at(p);
        double a2 = a + delta;
        const auto& stats = holding_time.read_at(p);
        total_holding_time.write_at(double { a2 }, p);
        holding_time.write_at(stats.add(delta), p);
        SamplingStats<double> stats2 { holding_time.read_at(p) };
        return holding_time_source.trigger_at(&stats2, p);
      }

      template<typename ContFn>
      static Result<Unit> seize_free(const FacilityPtr<Item>& facility,
        const Transact<Item>& transact,
        ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        auto t = p->time;
        int init_priority = transact.transact_id->get_priority_at(p);
        const auto& owner = facility->owner.read_at(p);

        if (!owner) {
          SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
            transact, init_priority, t, false, false, 0.0 
          }));
          facility->owner.write_at(std::move(item), p);
          TRY_RESULT(facility->update_wait_time(0.0, p));
          TRY_RESULT(facility->update_count(-1, p));
          TRY_RESULT(facility->update_capture_count(1, p));
          TRY_RESULT(facility->update_util_count(1, p));
          return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);

        } else {
          auto res { 
            DVCOMPUTE_NS::internal::process::freeze_process_with_reentering_at<Unit>(std::move(cont_fn), pid, Unit(), 
              DVCOMPUTE_NS::internal::process::move_impl(seize_facility(facility, transact)), p)
          };
  
          if (auto *cont_fn = get_result_if(&res)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
            internal::facility::FacilityDelayedItem<Item> item {
              transact, init_priority, t, false, false, std::move(*cont_fn)
            };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
            SharedPtr<internal::facility::FacilityDelayedItem<Item>> item(mk_shared(internal::facility::FacilityDelayedItem<Item> {
              transact, init_priority, t, false, false, std::move(*cont_fn)
            }));
#else
#error "Unknown simulation mode"
#endif

            facility->delay_chain.push_with_priority(init_priority, std::move(item), p);
            TRY_RESULT(facility->update_queue_count(1, p));
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }
        }
      }

      template<typename ContFn>
      static Result<Unit> seize(const FacilityPtr<Item>& facility,
        const Transact<Item>& transact,
        ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        auto t = p->time;
        bool f = facility->delay_chain.empty(p) 
          && facility->interrupt_chain.empty(p)
          && facility->pending_chain.empty(p);

        if (f) {
          return Facility<Item>::seize_free(facility, transact, std::move(cont_fn), pid, p);
        
        } else {
          auto res { 
            DVCOMPUTE_NS::internal::process::freeze_process_with_reentering_at<Unit>(std::move(cont_fn), pid, Unit(), 
              DVCOMPUTE_NS::internal::process::move_impl(seize_facility(facility, transact)), p)
          };
  
          if (auto *cont_fn = get_result_if(&res)) {
            int init_priority = transact.transact_id->get_priority_at(p);

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
            internal::facility::FacilityDelayedItem<Item> item {
              transact, init_priority, t, false, false, std::move(*cont_fn)
            };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
            SharedPtr<internal::facility::FacilityDelayedItem<Item>> item(mk_shared(internal::facility::FacilityDelayedItem<Item> {
              transact, init_priority, t, false, false, std::move(*cont_fn)
            }));
#else
#error "Unknown simulation mode"
#endif

            facility->delay_chain.push_with_priority(init_priority, std::move(item), p);
            TRY_RESULT(facility->update_queue_count(1, p));
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }
        }
      }

      template<typename ContFn>
      static Result<Unit> preempt(const FacilityPtr<Item>& facility,
        const Transact<Item>& transact,
        FacilityPreemptMode<Item>&& mode,
        ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        auto t = p->time;
        int init_priority = transact.transact_id->get_priority_at(p);
        SharedPtr<internal::facility::FacilityOwnerItem<Item>> owner { facility->owner.read_at(p) };

        if (!owner) {
          SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
            transact, init_priority, t, true, false, 0.0 
          }));
          facility->owner.write_at(std::move(item), p);
          TRY_RESULT(facility->update_wait_time(0.0, p));
          TRY_RESULT(facility->update_count(-1, p));
          TRY_RESULT(facility->update_capture_count(1, p));
          TRY_RESULT(facility->update_util_count(1, p));
          return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);

        } else if (!mode.priority_mode && owner->interrupting) {

          auto res { 
            DVCOMPUTE_NS::internal::process::freeze_process_with_reentering_at<Unit>(std::move(cont_fn), pid, Unit(), 
              DVCOMPUTE_NS::internal::process::move_impl(preempt_facility(facility, transact, std::move(mode))), p)
          };
  
          if (auto *cont_fn = get_result_if(&res)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
            internal::facility::FacilityPendingItem<Item> item {
              transact, init_priority, t, true, true, std::move(*cont_fn)
            };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
            SharedPtr<internal::facility::FacilityPendingItem<Item>> item(mk_shared(internal::facility::FacilityPendingItem<Item> {
              transact, init_priority, t, true, true, std::move(*cont_fn)
            }));
#else
#error "Unknown simulation mode"
#endif

            facility->pending_chain.push_with_priority(init_priority, std::move(item), p);
            TRY_RESULT(facility->update_queue_count(1, p));
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }

        } else if (mode.priority_mode && init_priority <= owner->init_priority) {

          auto res { 
            DVCOMPUTE_NS::internal::process::freeze_process_with_reentering_at<Unit>(std::move(cont_fn), pid, Unit(), 
              DVCOMPUTE_NS::internal::process::move_impl(preempt_facility(facility, transact, std::move(mode))), p)
          };
  
          if (auto *cont_fn = get_result_if(&res)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
            internal::facility::FacilityDelayedItem<Item> item {
              transact, init_priority, t, true, true, std::move(*cont_fn)
            };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
            SharedPtr<internal::facility::FacilityDelayedItem<Item>> item(mk_shared(internal::facility::FacilityDelayedItem<Item> {
              transact, init_priority, t, true, true, std::move(*cont_fn)
            }));
#else
#error "Unknown simulation mode"
#endif

            facility->delay_chain.push_with_priority(init_priority, std::move(item), p);
            TRY_RESULT(facility->update_queue_count(1, p));
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }

        } else if (!mode.remove_mode) {

          SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
            transact, init_priority, t, true, true, 0.0
          }));

          facility->owner.write_at(std::move(item), p);
          auto res { owner->transact.transact_id->require_process_id(p) };
          if (auto *pid0 = get_result_if(&res)) {

            auto res { process_interruption_time(*pid0)(p) };
            if (auto *t2 = get_result_if(&res)) {

              std::optional<double> dt0 = t2->has_value() ? std::make_optional(t2->value() - t) : std::nullopt;
              int priority0 = owner->init_priority;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
              internal::facility::FacilityInterruptedItem<Item> item {
                owner->transact, priority0, t, owner->preempting, owner->interrupting, dt0, 
                std::move(mode.transfer), (owner->acc_holding_time + (t - owner->time))
              };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
              SharedPtr<internal::facility::FacilityInterruptedItem<Item>> item(mk_shared(internal::facility::FacilityInterruptedItem<Item> {
                owner->transact, priority0, t, owner->preempting, owner->interrupting, dt0, 
                std::move(mode.transfer), (owner->acc_holding_time + (t - owner->time))
              }));
#else
#error "Unknown simulation mode"
#endif

              facility->interrupt_chain.push_with_priority(priority0, std::move(item), p);
              TRY_RESULT(facility->update_queue_count(1, p));
              TRY_RESULT(facility->update_wait_time(0.0, p));
              TRY_RESULT(facility->update_capture_count(1, p));
              TRY_RESULT(begin_transact_preemption(owner->transact.transact_id)(p));
              return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);

            } else {
              return error_result<Unit>(std::move(res));
            }

          } else {
            return error_result<Unit>(std::move(res));
          }
        
        } else {

          SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
            transact, init_priority, t, true, true, 0.0
          }));

          facility->owner.write_at(std::move(item), p);
          auto res { owner->transact.transact_id->require_process_id(p) };
          if (auto *pid0 = get_result_if(&res)) {

            auto res { process_interruption_time(*pid0)(p) };
            if (auto *t2 = get_result_if(&res)) {

              std::optional<double> dt0 = t2->has_value() ? std::make_optional(t2->value() - t) : std::nullopt;
              TRY_RESULT(facility->update_wait_time(0.0, p));
              TRY_RESULT(facility->update_capture_count(1, p));
              TRY_RESULT(facility->update_holding_time(owner->acc_holding_time + (t - owner->time), p));
              
              if (!mode.transfer.has_value()) {
                return RetryResult("The destination is not specified for the removed preempted transact");

              } else {

                TRY_RESULT(transfer_transact_within_event(owner->transact.transact_id, mode.transfer.value()(owner->transact, dt0))(p));
                return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
              }

            } else {
              return error_result<Unit>(std::move(res));
            }

          } else {
            return error_result<Unit>(std::move(res));
          }
        }
      }

      static Result<Unit> release(const FacilityPtr<Item>& facility,
        const TransactIdPtr& tid,
        const std::optional<bool>& preempting,
        const Point* p)
      {
        auto t = p->time;
        SharedPtr<internal::facility::FacilityOwnerItem<Item>> owner { facility->owner.read_at(p) };

        if (!owner) {
          return RetryResult("There is no owner of the facility");

        } else if ((owner->transact.transact_id == tid) && owner->preempting != preempting.value_or(owner->preempting)) {
          return RetryResult("Mismatch use of returning and releasing the facility");

        } else if (owner->transact.transact_id == tid) {

          facility->owner.write_at(SharedPtr<internal::facility::FacilityOwnerItem<Item>>(), p);
          TRY_RESULT(facility->update_util_count(-1, p));
          TRY_RESULT(facility->update_holding_time(owner->acc_holding_time + (t - owner->time), p));
          TRY_RESULT(facility->update_count(1, p));
          TRY_RESULT(enqueue_uncancellable_event(t, Facility<Item>::try_capture(facility))(p));

          return Result<Unit>(Unit());

        } else {
          return RetryResult("The facility has another owner");
        }
      }

      /** Try to capture the facility within `Event<Unit>`. */
      static auto try_capture(const FacilityPtr<Item>& facility) {
        return cons_event([=](const Point* p) {
          const auto& owner = facility->owner.read_at(p);
          if (!owner) {
            return capture(facility, p);
          } else {
            return Result<Unit>(Unit());
          }
        });
      }

      /** Capture the facility. */
      static Result<Unit> capture(const FacilityPtr<Item>& facility, const Point* p) {
        auto t = p->time;
        
        if (!facility->pending_chain.empty(p)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          internal::facility::FacilityPendingItem<Item> item_cont {
            facility->pending_chain.pop(p).value()
          };
          auto *item = &item_cont;
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          SharedPtr<internal::facility::FacilityPendingItem<Item>> item_cont {
            facility->pending_chain.pop(p).value()
          };
          const auto *item = item_cont.get();
#else
#error "Unknown simulation mode"
#endif

          Transact<Item> transact { item->transact };
          int init_priority = item->init_priority;
          auto t0 = item->time;
          bool preempting = item->preempting;
          bool interrupting = item->interrupting;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont0 { std::move(item->cont) };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont0 { item->cont };
#else
#error "Unknown simulation mode"
#endif

          TRY_RESULT(facility->update_queue_count(-1, p));

          auto res { DVCOMPUTE_NS::internal::process::unfreeze_process_at(std::move(cont0), p) };
          if (auto *cont_fn = get_result_if(&res)) {

            if (!(*cont_fn)) {
              return Facility<Item>::capture(facility, p);

            } else {
              auto res { transact.transact_id->require_process_id(p) };
              if (auto *pid = get_result_if(&res)) {

                SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
                  transact, init_priority, t, preempting, interrupting, 0.0
                }));

                facility->owner.write_at(std::move(item), p);
                
                TRY_RESULT(facility->update_wait_time(t - t0, p));
                TRY_RESULT(facility->update_util_count(1, p));
                TRY_RESULT(facility->update_capture_count(1, p));
                TRY_RESULT(facility->update_count(-1, p));
                
                return enqueue_uncancellable_event(t,
                  cons_event([cont_fn{std::move(*cont_fn)}, pid{*pid}](const Point *p) mutable {
                    return DVCOMPUTE_NS::internal::process::reenter_process_at(std::move(cont_fn), pid, Unit(), p);
                  }))(p);

              } else {
                return error_result<Unit>(std::move(res));
              }
            }
            
          } else {
            return error_result<Unit>(std::move(res));
          }

        } else if (!facility->interrupt_chain.empty(p)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          internal::facility::FacilityInterruptedItem<Item> item_cont {
            facility->interrupt_chain.pop(p).value()
          };
          auto *item = &item_cont;
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          SharedPtr<internal::facility::FacilityInterruptedItem<Item>> item_cont {
            facility->interrupt_chain.pop(p).value()
          };
          const auto *item = item_cont.get();
#else
#error "Unknown simulation mode"
#endif

          Transact<Item> transact { item->transact };
          int init_priority = item->init_priority;
          auto t0 = item->time;
          bool preempting = item->preempting;
          bool interrupting = item->interrupting;
          auto dt0 = item->remaining_time;
          auto acc0 = item->acc_holding_time;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          auto transfer0 { std::move(item->transfer) };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          auto transfer0 { item->transfer };
#else
#error "Unknown simulation mode"
#endif

          TRY_RESULT(facility->update_queue_count(-1, p));

          auto res { transact.transact_id->require_process_id(p) };
          if (auto *pid = get_result_if(&res)) {

            if (DVCOMPUTE_NS::internal::process::is_process_cancel_initiated_at(*pid, p)) {
              return Facility<Item>::capture(facility, p);

            } else {
              SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
                transact, init_priority, t, preempting, interrupting, acc0
              }));

              facility->owner.write_at(std::move(item), p);
              
              TRY_RESULT(facility->update_wait_time(t - t0, p));
              TRY_RESULT(facility->update_util_count(1, p));
              TRY_RESULT(facility->update_count(-1, p));

              if (transfer0.has_value()) {
                TRY_RESULT(transfer_transact_within_event(transact.transact_id, transfer0.value()(transact, dt0))(p));
              }

              return end_transact_preemption(transact.transact_id)(p);
            }
            
          } else {
            return error_result<Unit>(std::move(res));
          }

        } else if (!facility->delay_chain.empty(p)) {

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          internal::facility::FacilityDelayedItem<Item> item_cont {
            facility->delay_chain.pop(p).value()
          };
          auto *item = &item_cont;
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          SharedPtr<internal::facility::FacilityDelayedItem<Item>> item_cont {
            facility->delay_chain.pop(p).value()
          };
          const auto *item = item_cont.get();
#else
#error "Unknown simulation mode"
#endif

          Transact<Item> transact { item->transact };
          int init_priority = item->init_priority;
          auto t0 = item->time;
          bool preempting = item->preempting;
          bool interrupting = item->interrupting;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont0 { std::move(item->cont) };
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          DVCOMPUTE_NS::internal::process::FrozenProcess<Unit> cont0 { item->cont };
#else
#error "Unknown simulation mode"
#endif

          TRY_RESULT(facility->update_queue_count(-1, p));

          auto res { DVCOMPUTE_NS::internal::process::unfreeze_process_at(std::move(cont0), p) };
          if (auto *cont_fn = get_result_if(&res)) {

            if (!(*cont_fn)) {
              return Facility<Item>::capture(facility, p);

            } else {
              auto res { transact.transact_id->require_process_id(p) };
              if (auto *pid = get_result_if(&res)) {

                SharedPtr<internal::facility::FacilityOwnerItem<Item>> item(mk_shared(internal::facility::FacilityOwnerItem<Item> {
                  transact, init_priority, t, preempting, interrupting, 0.0
                }));

                facility->owner.write_at(std::move(item), p);
                
                TRY_RESULT(facility->update_wait_time(t - t0, p));
                TRY_RESULT(facility->update_util_count(1, p));
                TRY_RESULT(facility->update_capture_count(1, p));
                TRY_RESULT(facility->update_count(-1, p));
                
                return enqueue_uncancellable_event(t,
                  cons_event([cont_fn{std::move(*cont_fn)}, pid{*pid}](const Point *p) mutable {
                    return DVCOMPUTE_NS::internal::process::reenter_process_at(std::move(cont_fn), pid, Unit(), p);
                  }))(p);

              } else {
                return error_result<Unit>(std::move(res));
              }
            }
            
          } else {
            return error_result<Unit>(std::move(res));
          }

        } else {
          return Result<Unit>(Unit());
        }
      }

      /** @private */
      class Seize {

        FacilityPtr<Item> facility;
        Transact<Item> transact;

      public:

        explicit Seize(const FacilityPtr<Item>& facility_arg, const Transact<Item>& transact_arg) :
          facility(facility_arg), transact(transact_arg)
        {}

        Seize(Seize&& other) = default;
        Seize& operator=(Seize&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Seize(const Seize& other) = default;
        Seize& operator=(const Seize& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          return Facility<Item>::seize(facility, transact, std::move(cont_fn), pid, p);
        }
      };

      /** @private */
      class SeizeWeak {

        WeakPtr<Facility<Item>> weak_facility;
        Transact<Item> transact;

      public:

        explicit SeizeWeak(const WeakPtr<Facility<Item>>& weak_facility_arg, const Transact<Item>& transact_arg) :
          weak_facility(weak_facility_arg), transact(transact_arg)
        {}

        SeizeWeak(SeizeWeak&& other) = default;
        SeizeWeak& operator=(SeizeWeak&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        SeizeWeak(const SeizeWeak& other) = default;
        SeizeWeak& operator=(const SeizeWeak& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          FacilityPtr<Item> facility { weak_facility.lock() };
          if (facility) {
            return Facility<Item>::seize(facility, transact, std::move(cont_fn), pid, p);
          } else {
            throw PanicResult("The facility was removed.");
          }
        }
      };

      /** @private */
      class Preempt {

        FacilityPtr<Item> facility;
        Transact<Item> transact;
        FacilityPreemptMode<Item> mode;

      public:

        explicit Preempt(const FacilityPtr<Item>& facility_arg, const Transact<Item>& transact_arg, FacilityPreemptMode<Item>&& mode_arg) :
          facility(facility_arg), transact(transact_arg), mode(std::move(mode_arg))
        {}

        Preempt(Preempt&& other) = default;
        Preempt& operator=(Preempt&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Preempt(const Preempt& other) = default;
        Preempt& operator=(const Preempt& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          return Facility<Item>::preempt(facility, transact, std::move(mode), std::move(cont_fn), pid, p);
        }
      };

      /** @private */
      class PreemptWeak {

        WeakPtr<Facility<Item>> weak_facility;
        Transact<Item> transact;
        FacilityPreemptMode<Item> mode;

      public:

        explicit PreemptWeak(const WeakPtr<Facility<Item>>& weak_facility_arg, const Transact<Item>& transact_arg, FacilityPreemptMode<Item>&& mode_arg) :
          weak_facility(weak_facility_arg), transact(transact_arg), mode(std::move(mode_arg))
        {}

        PreemptWeak(PreemptWeak&& other) = default;
        PreemptWeak& operator=(PreemptWeak&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        PreemptWeak(const PreemptWeak& other) = default;
        PreemptWeak& operator=(const PreemptWeak& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          FacilityPtr<Item> facility { weak_facility.lock() };
          if (facility) {
            return Facility<Item>::preempt(facility, transact, std::move(mode), std::move(cont_fn), pid, p);
          } else {
            throw PanicResult("The facility was removed.");
          }
        }
      };

      /** @private */
      class Release {

        FacilityPtr<Item> facility;
        TransactIdPtr tid;
        std::optional<bool> preempting;

      public:

        explicit Release(const FacilityPtr<Item>& facility_arg, const TransactIdPtr& tid_arg, const std::optional<bool>& preempting_arg) 
          noexcept(noexcept(std::optional<bool>(preempting_arg))) :
          facility(facility_arg), tid(tid_arg), preempting(preempting_arg)
        {}

        Release(Release&& other) = default;
        Release& operator=(Release&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Release(const Release& other) = default;
        Release& operator=(const Release& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          TRY_RESULT(Facility<Item>::release(facility, tid, preempting, p));
          return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
        }
      };

      template<typename Item2>
      friend auto new_facility();

      template<typename Item2>
      friend auto late_init_facility(FacilityPtr<Item2>& dest);

      template<typename Item2>
      friend auto facility_count(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_count_stats(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_count_changed(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_count_changed_(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_capture_count(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_capture_count_changed(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_capture_count_changed_(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_util_count(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_util_count_stats(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_util_count_changed(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_util_count_changed_(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_queue_count(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_queue_count_stats(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_queue_count_changed(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_queue_count_changed_(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_total_wait_time(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_wait_time(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_wait_time_changed(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_wait_time_changed_(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_total_holding_time(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_holding_time(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_holding_time_changed(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto facility_holding_time_changed_(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto is_facility_interrupted(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto reset_facility(const FacilityPtr<Item2>& facility);

      template<typename Item2>
      friend auto seize_facility(const FacilityPtr<Item2>& facility, const Transact<Item2>& transact);

      template<typename Item2>
      friend auto seize_facility_weak(const WeakPtr<Facility<Item2>>& weak_facility, const Transact<Item2>& transact);

      template<typename Item2>
      friend auto preempt_facility(const FacilityPtr<Item2>& facility, const Transact<Item2>& transact, FacilityPreemptMode<Item2>&& mode);

      template<typename Item2>
      friend auto preempt_facility_weak(const WeakPtr<Facility<Item2>>& weak_facility, const Transact<Item2>& transact, FacilityPreemptMode<Item2>&& mode);

      template<typename Item2>
      friend auto return_facility(const FacilityPtr<Item2>& facility, const TransactIdPtr& tid);

      template<typename Item2>
      friend auto release_facility(const FacilityPtr<Item2>& facility, const TransactIdPtr& tid);

      template<typename Item2>
      friend auto return_facility_within_event(const FacilityPtr<Item2>& facility, const TransactIdPtr& tid);

      template<typename Item2>
      friend auto release_facility_within_event(const FacilityPtr<Item2>& facility, const TransactIdPtr& tid);
    };

    /** Create a new facility within `Event<FacilityPtr<Item>>` computation. */
    template<typename Item>
    auto new_facility() {
      auto fn = [](const Point* p) {
        return Result<FacilityPtr<Item>>(FacilityPtr<Item>(SharedPtrFn {}, [t{p->time}](Facility<Item> *address) {
          new(address) Facility<Item>(t);
        }));
      };
      return Event<FacilityPtr<Item>, decltype(fn)>(std::move(fn));
    }

    /** Create a new facility within `Event<Unit>` computation by the specified destination. */
    template<typename Item>
    auto late_init_facility(FacilityPtr<Item>& dest) {
      auto fn = [=](const Point* p) mutable {
        dest.late_init(SharedPtrFn {}, [t(p->time)](Facility<Item> *address) {
          new(address) Facility<Item>(t);
        });
        return Result<Unit>(Unit());
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Return the current available count of the facility within `Event<int>`. */
    template<typename Item>
    auto facility_count(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<int>(facility->count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for available count of the facility within `Event<TimingStats<int>>`. */
    template<typename Item>
    auto facility_count_stats(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(facility->count_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the count property changes. */
    template<typename Item>
    auto facility_count_changed(const FacilityPtr<Item>& facility) {
      return facility->count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the count property changes. */
    template<typename Item>
    auto facility_count_changed_(const FacilityPtr<Item>& facility) {
      return facility_count_changed(facility)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the current capture count of the facility within `Event<int>`. */
    template<typename Item>
    auto facility_capture_count(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<int>(facility->capture_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the capture count property changes. */
    template<typename Item>
    auto facility_capture_count_changed(const FacilityPtr<Item>& facility) {
      return facility->capture_count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the capture count property changes. */
    template<typename Item>
    auto facility_capture_count_changed_(const FacilityPtr<Item>& facility) {
      return facility_capture_count_changed(facility)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the current utilization count of the facility within `Event<int>`. */
    template<typename Item>
    auto facility_util_count(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<int>(facility->util_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for utilization count of the facility within `Event<TimingStats<int>>`. */
    template<typename Item>
    auto facility_util_count_stats(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(facility->util_count_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the utilization count property changes. */
    template<typename Item>
    auto facility_util_count_changed(const FacilityPtr<Item>& facility) {
      return facility->util_count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the utilization count property changes. */
    template<typename Item>
    auto facility_util_count_changed_(const FacilityPtr<Item>& facility) {
      return facility_util_count_changed(facility)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the current queue length of the facility within `Event<int>`. */
    template<typename Item>
    auto facility_queue_count(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<int>(facility->queue_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for queue length of the facility within `Event<TimingStats<int>>`. */
    template<typename Item>
    auto facility_queue_count_stats(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(facility->queue_count_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<int>` when the queue length property changes. */
    template<typename Item>
    auto facility_queue_count_changed(const FacilityPtr<Item>& facility) {
      return facility->queue_count_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the queue length property changes. */
    template<typename Item>
    auto facility_queue_count_changed_(const FacilityPtr<Item>& facility) {
      return facility_queue_count_changed(facility)
        .map([](const int* message) {
          return Unit();
        });
    }

    /** Return the total wait time of the facility within `Event<double>`. */
    template<typename Item>
    auto facility_total_wait_time(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<double>(facility->total_wait_time.read_at(p));
      };
      return Event<double, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for wait time of the facility within `Event<SamplingStats<double>>`. */
    template<typename Item>
    auto facility_wait_time(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<SamplingStats<double>>(facility->wait_time.read_at(p));
      };
      return Event<SamplingStats<double>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<SamplingStats<double>>` when the wait time property changes. */
    template<typename Item>
    auto facility_wait_time_changed(const FacilityPtr<Item>& facility) {
      return facility->wait_time_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the wait time property changes. */
    template<typename Item>
    auto facility_wait_time_changed_(const FacilityPtr<Item>& facility) {
      return facility_wait_time_changed(facility)
        .map([](const SamplingStats<double>* message) {
          return Unit();
        });
    }

    /** Return the total holding time of the facility within `Event<double>`. */
    template<typename Item>
    auto facility_total_holding_time(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<double>(facility->total_holding_time.read_at(p));
      };
      return Event<double, decltype(fn)>(std::move(fn));
    }

    /** Return the statistics for holding time of the facility within `Event<SamplingStats<double>>`. */
    template<typename Item>
    auto facility_holding_time(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        return Result<SamplingStats<double>>(facility->holding_time.read_at(p));
      };
      return Event<SamplingStats<double>, decltype(fn)>(std::move(fn));
    }

    /** Notifies within `Observable<SamplingStats<double>>` when the holding time property changes. */
    template<typename Item>
    auto facility_holding_time_changed(const FacilityPtr<Item>& facility) {
      return facility->holding_time_source.publish();
    }

    /** Notifies within `Observable<Unit>` when the holding time property changes. */
    template<typename Item>
    auto facility_holding_time_changed_(const FacilityPtr<Item>& facility) {
      return facility_holding_time_changed(facility)
        .map([](const SamplingStats<double>* message) {
          return Unit();
        });
    }

    /** Whether the facility is currently interrupted within `Event<bool>`. */
    template<typename Item>
    auto is_facility_interrupted(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        const auto& owner = facility->owner.read_at(p);
        if (owner) {
          return Result<bool>(owner->preempting);
        } else {
          return Result<bool>(false);
        }
      };
      return Event<bool, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when one of the facility properties changes. */
    template<typename Item>
    auto facility_changed_(const FacilityPtr<Item>& facility) {
      return facility_count_changed_(facility)
        .merge(facility_capture_count_changed_(facility))
        .merge(facility_util_count_changed_(facility))
        .merge(facility_queue_count_changed_(facility));
    }

    /** Reset the facility statistics within `Event<Unit>`. */
    template<typename Item>
    auto reset_facility(const FacilityPtr<Item>& facility) {
      auto fn = [=](const Point* p) {
        double t = p->time;
        int count = facility->count.read_at(p);
        int util_count = facility->util_count.read_at(p);
        int queue_count = facility->queue_count.read_at(p);
        
        facility->count_stats.write_at(TimingStats<int>::from_sample(t, count), p);
        facility->capture_count.write_at(0, p);
        facility->util_count_stats.write_at(TimingStats<int>::from_sample(t, util_count), p);
        facility->queue_count_stats.write_at(TimingStats<int>::from_sample(t, queue_count), p);
        facility->total_wait_time.write_at(0.0, p);
        facility->wait_time.write_at(SamplingStats<double>(), p);
        facility->total_holding_time.write_at(0.0, p);
        facility->holding_time.write_at(SamplingStats<double>(), p);
        
        int zero = 0;
        SamplingStats<double> empty_stats;

        TRY_RESULT(facility->count_source.trigger_at(&count, p));
        TRY_RESULT(facility->capture_count_source.trigger_at(&zero, p));
        TRY_RESULT(facility->util_count_source.trigger_at(&util_count, p));
        TRY_RESULT(facility->queue_count_source.trigger_at(&queue_count, p));
        TRY_RESULT(facility->wait_time_source.trigger_at(&empty_stats, p));
        TRY_RESULT(facility->holding_time_source.trigger_at(&empty_stats, p));

        return Result<Unit>(Unit());
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Seize the facility within `Process<Unit>`. */
    template<typename Item>
    auto seize_facility(const FacilityPtr<Item>& facility, const Transact<Item>& transact) {
      using ResultImpl = typename Facility<Item>::Seize;
      return Process<Unit, ResultImpl>(ResultImpl(facility, transact));
    }

    /** Try to seize the facility within `Process<Unit>`. */
    template<typename Item>
    auto seize_facility_weak(const WeakPtr<Facility<Item>>& weak_facility, const Transact<Item>& transact) {
      using ResultImpl = typename Facility<Item>::SeizeWeak;
      return Process<Unit, ResultImpl>(ResultImpl(weak_facility, transact));
    }

    /** Preempt the facility within `Process<Unit>`. */
    template<typename Item>
    auto preempt_facility(const FacilityPtr<Item>& facility, const Transact<Item>& transact, FacilityPreemptMode<Item>&& mode) {
      using ResultImpl = typename Facility<Item>::Preempt;
      return Process<Unit, ResultImpl>(ResultImpl(facility, transact, std::move(mode)));
    }

    /** Try to preempt the facility within `Process<Unit>`. */
    template<typename Item>
    auto preempt_facility_weak(const WeakPtr<Facility<Item>>& weak_facility, const Transact<Item>& transact, FacilityPreemptMode<Item>&& mode) {
      using ResultImpl = typename Facility<Item>::PreemptWeak;
      return Process<Unit, ResultImpl>(ResultImpl(weak_facility, transact, std::move(mode)));
    }

    /** Return the facility within `Process<Unit>`. */
    template<typename Item>
    auto return_facility(const FacilityPtr<Item>& facility, const TransactIdPtr& tid) {
      using ResultImpl = typename Facility<Item>::Release;
      return Process<Unit, ResultImpl>(ResultImpl(facility, tid, std::make_optional(true)));
    }

    /** Release the facility within `Process<Unit>`. */
    template<typename Item>
    auto release_facility(const FacilityPtr<Item>& facility, const TransactIdPtr& tid) {
      using ResultImpl = typename Facility<Item>::Release;
      return Process<Unit, ResultImpl>(ResultImpl(facility, tid, std::make_optional(false)));
    }

    /** Return the facility within `Event<Unit>`. */
    template<typename Item>
    auto return_facility_within_event(const FacilityPtr<Item>& facility, const TransactIdPtr& tid) {
      auto impl = [facility, tid](const Point *p) {
        return Facility<Item>::release(facility, tid, std::make_optional(true), p);
      };
      return Event<Unit, decltype(impl)>(std::move(impl));
    }

    /** Release the facility within `Event<Unit>`. */
    template<typename Item>
    auto release_facility_within_event(const FacilityPtr<Item>& facility, const TransactIdPtr& tid) {
      auto impl = [facility, tid](const Point *p) {
        return Facility<Item>::release(facility, tid, std::make_optional(false), p);
      };
      return Event<Unit, decltype(impl)>(std::move(impl));
    }
  }
}

#endif /* dvcompute_block_facility_h */

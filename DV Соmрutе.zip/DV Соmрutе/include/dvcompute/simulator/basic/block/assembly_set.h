/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_assembly_set_h
#define dvcompute_block_assembly_set_h

#include <cstdint>

#include "../../../dvcompute_ns.h"
#include "../types.h"
#include "../ref.h"
#include "../simulation.h"
#include "../process.h"
#include "../strategy.h"
#include "../result.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace transact {

      /** @private */
      class Assemble;

      /** @private */
      class Gather;
    }
  }

  namespace block {

    /** The transact identifier. */
    class TransactId;

    /** The shared pointer for the transact identifier. */
    using TransactIdPtr = SharedPtr<TransactId>;

    /** Defines an assembly set. */
    class AssemblySet;

    /** The shared reference for the assembly set. */
    using AssemblySetPtr = SharedPtr<AssemblySet>;

    /** Defines an assembly set. */
    class AssemblySet {

      /** The sequence number. */
      uint64_t sequence_no;

      /** The assembling transact. */
      Ref<ProcessIdPtr> assembling_transact;

      /** The assembling count. */
      Ref<int> assembling_count;

      /** The gathering transacts. */
      PriorityFCFSStorage<ProcessIdPtr> gathering_transacts;

      /** The gathering count. */
      Ref<int> gathering_count;

      explicit AssemblySet(uint64_t sequence_no_arg) :
        sequence_no(sequence_no_arg),
        assembling_transact(ProcessIdPtr()),
        assembling_count(0),
        gathering_transacts(),
        gathering_count(0)
      {}

    public:

      AssemblySet(AssemblySet&&) = delete;
      AssemblySet(const AssemblySet&) = delete;

      AssemblySet& operator=(AssemblySet&&) = delete;
      AssemblySet& operator=(const AssemblySet&) = delete;

      /** Get the sequence number. */
      uint64_t get_sequence_no() const noexcept {
        return sequence_no;
      }

      /** Compare for equality. */
      bool operator==(const AssemblySet& other) const {
        return assembling_transact == other.assembling_transact;
      }

      /** Compare for inequality. */
      bool operator!=(const AssemblySet& other) const {
        return !(*this == other);
      }

    private:

      friend auto new_assembly_set();

      friend class internal::transact::Assemble;
      friend class internal::transact::Gather;

      friend inline auto is_transact_assembling(const TransactIdPtr& tid);
      friend inline auto is_transact_gathering(const TransactIdPtr& tid);
    };

    /** A computation that creates an assembly set within `Simulation<AssemblySetPtr>`. */
    inline auto new_assembly_set() {
      auto fn = [](const Run* r) {
        auto sequence_no = r->gen.random_sequence_no();
        AssemblySetPtr x(SharedPtrFn {}, [sequence_no](AssemblySet *address) {
          new(address) AssemblySet(sequence_no);
        });
        return Result<AssemblySetPtr>(std::move(x));
      };

      return Simulation<AssemblySetPtr, decltype(fn)>(std::move(fn));
    }
  }
}

#endif /* dvcompute_block_assembly_set_h */

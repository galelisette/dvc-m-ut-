/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_queue_ops_h
#define dvcompute_block_queue_ops_h

#include "queue.h"
#include "transact.h"

namespace DVCOMPUTE_NS {

  namespace block {

    /** Enqueue the transact within `Event<Unit>`. */
    inline auto enqueue_transact(const QueuePtr& queue, const TransactIdPtr& tid, int increment) {
      auto fn = [=](const Point* p) {
        double t = p->time;
        int n = queue->enqueue_count.read_at(p);
        int c = queue->content.read_at(p);
        const auto& stats = queue->content_stats.read_at(p);
        queue->enqueue_count.write_at(n + 1, p);
        queue->content.write_at(c + increment, p);
        queue->content_stats.write_at(stats.add(t, c + increment), p);
        Result<Unit> res { tid->register_queue_entry(QueueEntry { queue, t }, p) };
        if (get_result_if<Unit>(&res)) [[likely]] {
          Unit msg;
          return queue->enqueued.trigger_at(&msg, p);
        } else {
          return res;
        }
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Dequeue the transact within `Event<Unit>`. */
    inline auto dequeue_transact(const QueuePtr& queue, const TransactIdPtr& tid, int decrement) {
      auto fn = [=](const Point* p) {
        Result<QueueEntry> res { tid->unregister_queue_entry(*queue, p) };
        if (QueueEntry *e = get_result_if<QueueEntry>(&res)) [[likely]] {
          double t = p->time;
          double t0 = e->enqueue_time;
          double dt = t - t0;
          int c = queue->content.read_at(p);
          const auto& stats = queue->content_stats.read_at(p);
          const auto& wait_time = queue->wait_time.read_at(p);
          queue->content.write_at(c - decrement, p);
          queue->content_stats.write_at(stats.add(t, c - decrement), p);
          queue->wait_time.write_at(wait_time.add(dt), p);
          if (t == t0) {
            int c2 = queue->enqueue_zero_entry_count.read_at(p);
            queue->enqueue_zero_entry_count.write_at(c2 + 1, p);
          } else {
            const auto& wait_time2 = queue->non_zero_entry_wait_time.read_at(p);
            queue->non_zero_entry_wait_time.write_at(wait_time2.add(dt), p);
          }
          Unit msg;
          return queue->dequeued.trigger_at(&msg, p);
        } else {
          return error_result<Unit>(std::move(res));
        }
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }
  }
}

#endif /* dvcompute_block_queue_ops_h */

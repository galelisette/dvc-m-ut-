/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_transact_ops_h
#define dvcompute_block_transact_ops_h

#include <cstdint>
#include <optional>
#include <map>
#include <tuple>
#include <vector>

#include "../../../dvcompute_ns.h"
#include "../macros.h"
#include "../arrival.h"
#include "../simulation.h"
#include "../event.h"
#include "../process.h"
#include "../process_extra.h"
#include "../ref.h"
#include "../types.h"
#include "transact.h"

namespace DVCOMPUTE_NS {

  namespace block {

    /** Take the transact within `Process<Unit>` computation. */
    inline auto take_transact(const TransactIdPtr& tid);

    /** Try to take the transact within `Process<Unit>` computation. */
    inline auto take_transact_weak(const WeakPtr<TransactId>& tid);

    /** Release the transact within `Process<Unit>` computation. */
    inline auto release_transact(const TransactIdPtr& tid);
  }

  namespace internal {

    namespace transact {

      /** @private */
      class Take {

        using TransactIdPtr = DVCOMPUTE_NS::block::TransactIdPtr;

        TransactIdPtr tid;

      public:

        explicit Take(const TransactIdPtr& tid_arg) noexcept : tid(tid_arg) {}
        explicit Take(TransactIdPtr&& tid_arg) noexcept : tid(std::move(tid_arg)) {}

        Take(Take&& other) = default;
        Take& operator=(Take&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Take(const Take& other) = default;
        Take& operator=(const Take& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (tid->process_id.read_at(p)) [[unlikely]] {
            return RetryResult("The transact is acquired by another process");
          } else {
            tid->process_id.write_at(ProcessIdPtr(pid), p);
            int priority = tid->priority.read_at(p);
            int n = tid->preemption_count.read_at(p);
            if (n == 0) {
              if (p->priority == priority) {
                return internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
              
              } else {
                return enqueue_uncancellable_event_with_priority(p->time, priority, 
                  cons_event([cont_fn{std::move(cont_fn)}, pid](const Point* p) mutable {
                    return internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
                  }))
                .operator()(p);
              }

            } else {
              internal::process::BoxedContFn<Unit> fn {
                internal::process::substitute_process_priority<Unit>(priority, std::move(cont_fn))
              };
              auto res { 
                internal::process::freeze_process_with_reentering_at<Unit>(std::move(fn),
                  pid, Unit(), Take(tid), p)
              };
              if (internal::process::FrozenProcess<Unit> *c = get_result_if<internal::process::FrozenProcess<Unit>>(&res)) {
                tid->process_cont_fn.write_at(std::move(*c), p);
                for (int i = 0; i < n; ++i) {
                  auto res { begin_process_preemption(pid)(p) };
                  if (get_result_if<Unit>(&res)) {
                    continue;
                  } else {
                    return error_result<Unit>(std::move(res));
                  }
                }
                return Result<Unit>(Unit());
              } else {
                return error_result<Unit>(std::move(res));
              }
            }
          }
        }
      };

      /** @private */
      class TakeWeak {

        using TransactId = DVCOMPUTE_NS::block::TransactId;
        using TransactIdPtr = DVCOMPUTE_NS::block::TransactIdPtr;

        WeakPtr<TransactId> weak_tid;

      public:

        explicit TakeWeak(const WeakPtr<TransactId>& weak_tid_arg) noexcept : weak_tid(weak_tid_arg) {}
        explicit TakeWeak(WeakPtr<TransactId>&& weak_tid_arg) noexcept : weak_tid(std::move(weak_tid_arg)) {}

        TakeWeak(TakeWeak&& other) = default;
        TakeWeak& operator=(TakeWeak&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        TakeWeak(const TakeWeak& other) = default;
        TakeWeak& operator=(const TakeWeak& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          TransactIdPtr tid { weak_tid.lock() };
          if (tid) {
            return Take(tid)(std::move(cont_fn), pid, p);
          } else {
            throw PanicResult("The transact was removed.");
          }
        }
      };

      /** @private */
      class Release {

        using TransactIdPtr = DVCOMPUTE_NS::block::TransactIdPtr;

        TransactIdPtr tid;

      public:

        explicit Release(const TransactIdPtr& tid_arg) noexcept : tid(tid_arg) {}
        explicit Release(TransactIdPtr&& tid_arg) noexcept : tid(std::move(tid_arg)) {}

        Release(Release&& other) = default;
        Release& operator=(Release&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Release(const Release& other) = default;
        Release& operator=(const Release& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          auto &pid0 = tid->process_id.read_at(p);
          if (!pid0) {
            return RetryResult("The transact is not acquired by any process");
          } else if (pid0 != pid) {
            return RetryResult("The transact is acquired by another process");
          } else {
            tid->process_id.write_at(ProcessIdPtr(), p);
            tid->process_cont_fn.write_at(std::nullopt, p);
            return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
          }
        }
      };
    }
  }

  namespace block {

    /** Create a new transact within `Simulation<Transact<Item>>` computation. */
    template<typename Item>
    inline auto new_transact(Arrival<Item>&& arrival, int priority) {
      auto fn = [arrival{std::move(arrival)}, priority](const Run* r) mutable {
        auto sequence_no = r->gen.random_sequence_no();
        auto arrival_delay = arrival.delay;
        auto arrival_time = arrival.time;

        TransactIdPtr tid(SharedPtrFn {}, [sequence_no, arrival_delay, arrival_time, priority](TransactId *address) mutable {
          new(address) TransactId(sequence_no,
            arrival_delay,
            arrival_time,
            priority,
            AssemblySetPtr()); 
        });
        
        return Result<Transact<Item>>(Transact<Item> {
          tid, std::move(arrival.value)
        });
      };

      return Simulation<Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** Split the transact within `Event<Transact<Item>>` computation. */
    template<typename Item>
    inline auto split_transact(const Transact<Item>& transact) {
      auto fn = [transact](const Point* p) mutable {
        auto sequence_no = p->run->gen.random_sequence_no();
        TransactIdPtr tid(SharedPtrFn {}, [sequence_no, transact, p](TransactId *address) {
          new(address) TransactId(sequence_no,
            transact.transact_id->get_arrival_delay(),
            transact.transact_id->get_arrival_time(),
            transact.transact_id->get_priority_at(p),
            transact.transact_id->assembly_set);
        });
        
        return Result<Transact<Item>>(Transact<Item> {
          tid, transact.value
        });
      };

      return Event<Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** Get the transact priority within `Event<int>` computation. */
    inline auto transact_priority(const TransactIdPtr& tid) {
      auto fn = [=](const Point* p) {
        return Result<int>(tid->get_priority_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Assign the transact priority within `Process<Unit>` computation. */
    inline auto assign_transact_priority(const TransactIdPtr& tid, int priority) {
      return into_process(cons_event([tid, priority](const Point* p) mutable {
        tid->priority.write_at(std::move(priority), p);
        return Result<Unit>(Unit());
      })).and_then([priority](Unit&& unit) {
        return process_with_priority(priority);
      });
    }

    /** Get the transact assembly set within `Event<AssemblySetPtr>`. */
    inline auto transact_assembly_set(const TransactIdPtr& tid) {
      auto fn = [=](const Point *p) {
        const auto &x = tid->assembly_set->read_at(p);
        if (x) {
          return Result<AssemblySetPtr>(x);
        } else {
          return into_event(new_assembly_set())
            .map([=](AssemblySetPtr&& x) {
              tid->assembly_set->write_at(AssemblySetPtr(x), p);
              return std::move(x);
            })
            .operator()(p);
        }
      };
      return Event<AssemblySetPtr, decltype(fn)>(std::move(fn)); 
    }

    /** Preempt within `Event<Unit>` the computation that handles the transact. */
    inline auto begin_transact_preemption(const TransactIdPtr& tid) {
      auto fn = [=](const Point *p) {
        return tid->begin_preemption_at(p);
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }
    
    /** Proceed with the computation within `Event<Unit>` after the transcat was preempted earlier. */
    inline auto end_transact_preemption(const TransactIdPtr& tid) {
      auto fn = [=](const Point *p) {
        return tid->end_preemption_at(p);
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Take the transact within `Process<Unit>` computation. */
    inline auto take_transact(const TransactIdPtr& tid) {
      using ResultImpl = internal::transact::Take;
      return Process<Unit, ResultImpl>(ResultImpl(tid));
    }

    /** Try to take the transact within `Process<Unit>` computation. */
    inline auto take_transact_weak(const WeakPtr<TransactId>& weak_tid) {
      using ResultImpl = internal::transact::TakeWeak;
      return Process<Unit, ResultImpl>(ResultImpl(weak_tid));
    }

    /** Release the transact within `Process<Unit>` computation. */
    inline auto release_transact(const TransactIdPtr& tid) {
      using ResultImpl = internal::transact::Release;
      return Process<Unit, ResultImpl>(ResultImpl(tid));
    }

    /** Like the GOTO statement, it associates the transact with another process within `Process<Unit>`. */
    template<typename Impl>
    auto transfer_transact(const TransactIdPtr& tid, Process<Unit, Impl>&& comp) {
      return into_process(cons_event([tid](const Point* p) mutable {
        const auto &pid = tid->process_id.read_at(p);
        if (pid) {
          auto res { cancel_process_by_id(pid)(p) };
          if (!get_result_if<Unit>(&res)) {
            return error_result<Unit>(std::move(res));
          }
        }
        
        tid->process_id.write_at(ProcessIdPtr(), p);
        tid->process_cont_fn.write_at(std::nullopt, p);

        return Result<Unit>(Unit());
      }))
      .and_then([tid](Unit&& unit) {
        return take_transact(tid);
      })
      .and_then([comp{std::move(comp)}](Unit&& unit) mutable {
        return transfer_process<Unit>(std::move(comp));
      });
    }

    /** Like the GOTO statement, it associates the transact with another process within `Event<Unit>`. */
    template<typename Impl>
    auto transfer_transact_within_event(const TransactIdPtr& tid, Process<Unit, Impl>&& comp) {
      auto fn = [tid, comp{std::move(comp)}](const Point* p) mutable {
        const auto &pid = tid->process_id.read_at(p);
        if (pid) {
          auto res { cancel_process_by_id(pid)(p) };
          if (!get_result_if<Unit>(&res)) {
            return error_result<Unit>(std::move(res));
          }
        }
        
        tid->process_id.write_at(ProcessIdPtr(), p);
        tid->process_cont_fn.write_at(std::nullopt, p);

        return run_process(take_transact(tid)
          .and_then([comp{std::move(comp)}](Unit&& unit) mutable {
            return transfer_process<Unit>(std::move(comp));
          })).operator()(p);
      };

      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Reactivate the transact within `Event<Unit>` or transfer it to the specified computation. */
    template<typename Impl>
    auto reactivate_transact(std::tuple<TransactIdPtr, 
      std::optional<Process<Unit, Impl>>>&& xy) 
    {
      auto fn = [xy{std::move(xy)}](const Point* p) mutable {
        const auto &tid = std::get<0>(xy);
        auto &comp = std::get<1>(xy);
        if (comp.has_value()) {
          return transfer_transact_within_event(tid, std::move(comp.value()))(p);

        } else {
          auto res { tid->require_process_id(p) };
          if (ProcessIdPtr *pid = get_result_if<ProcessIdPtr>(&res)) {
            return reactivate_process(*pid)(p);
          } else {
            return error_result<Unit>(std::move(res));
          }
        }
      };

      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** 
     * Reactivate the transacts within `Event<Unit>` or transfer them to the specified computations. 
     * 
     * The `Iter` type is expected to be an iterator of 
     * `std::tuple<TransactIdPtr, std::optional<Process<Unit>>>`.
     */
    template<typename Iter>
    auto reactivate_transacts(Iter begin, Iter end) {
      auto fn = [begin{std::move(begin)}, end{std::move(end)}](const Point *p) {
        for (Iter it = begin; it != end; ++it) {
          auto res { reactivate_transact(std::move(*it))(p) };
          if (get_result_if<Unit>(&res)) {
            continue;
          } else {
            return error_result<Unit>(std::move(res));
          }
        }
      
        return Result<Unit>(Unit());
      };

      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Reactivate the transacts within `Event<Unit>` or transfer them to the specified computations. */
    template<typename Impl>
    inline auto reactivate_transacts(std::vector<std::tuple<TransactIdPtr, 
      std::optional<Process<Unit, Impl>>>>&& xys) 
    {
      return reactivate_transacts(xys.begin(), xys.end());
    }
  }
}

#endif /* dvcompute_block_transact_ops_h */

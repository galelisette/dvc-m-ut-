/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_transact_h
#define dvcompute_block_transact_h

#include <cstdint>
#include <optional>
#include <map>

#include "../../../dvcompute_ns.h"
#include "../ref.h"
#include "../types.h"
#include "../process.h"
#include "../process_extra.h"
#include "../../utils/ordered_int_map.h"
#include "queue.h"
#include "assembly_set.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace transact {

      /** @private */
      class Take;

      /** @private */
      class Release;

      /** @private */
      class Assemble;

      /** @private */
      class Gather;
    }
  }

  namespace block {

    /** The transact identifier. */
    class TransactId;

    /** The shared reference for the transact identifier. */
    using TransactIdPtr = SharedPtr<TransactId>;

    /** The transact data type. */
    template<typename Item>
    struct Transact {

      /** The transact identifier. */
      TransactIdPtr transact_id;

      /** The transact value. */
      Item value;
    };

    /** The transact identifier. */
    class TransactId {

      /** The sequence no. */
      uint64_t sequence_no;

      /** The delay between transacts generated. */
      std::optional<double> arrival_delay;

      /** The time at which the transact was generated. */
      double arrival_time;

      /** The transact priority. */
      Ref<int> priority;

      /** The assembly set. */
      RefPtr<AssemblySetPtr> assembly_set;

      /** How many times that transact is preempted. */
      Ref<int> preemption_count;

      /** An identifier of the process that handles the transact at present. */
      Ref<ProcessIdPtr> process_id;

      /** A continuation of the process that tried to handle the transact. */
      Ref<std::optional<internal::process::FrozenProcess<Unit>>> process_cont_fn;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

      /** The queue entries registered by the transact. */
      std::map<uint64_t, QueueEntry> queue_entries;    

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

      /** The queue entries registered by the transact. */
      Ref<utils::im::OrderedIntMap<uint64_t, QueueEntry>> queue_entries;    

#else
#error "Unknown simulation mode"
#endif  

      TransactId(uint64_t sequence_no_arg,
        const std::optional<double>& arrival_delay_arg,
        double arrival_time_arg,
        int priority_arg,
        AssemblySetPtr&& assembly_set_arg) :
          sequence_no(sequence_no_arg),
          arrival_delay(arrival_delay_arg),
          arrival_time(arrival_time_arg),
          priority(priority_arg),
          assembly_set(mk_shared(Ref(std::move(assembly_set_arg)))),
          preemption_count(0),
          process_id(ProcessIdPtr()),
          process_cont_fn(std::nullopt),
#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          queue_entries()
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          queue_entries(utils::im::OrderedIntMap<uint64_t, QueueEntry>())
#else
#error "Unknown simulation mode"
#endif  
      {}

      TransactId(uint64_t sequence_no_arg,
        const std::optional<double>& arrival_delay_arg,
        double arrival_time_arg,
        int priority_arg,
        const RefPtr<AssemblySetPtr>& assembly_set_arg) :
          sequence_no(sequence_no_arg),
          arrival_delay(arrival_delay_arg),
          arrival_time(arrival_time_arg),
          priority(priority_arg),
          assembly_set(assembly_set_arg),
          preemption_count(0),
          process_id(ProcessIdPtr()),
          process_cont_fn(std::nullopt),
#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
          queue_entries()
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
          queue_entries(utils::im::OrderedIntMap<uint64_t, QueueEntry>())
#else
#error "Unknown simulation mode"
#endif  
      {}

    public:

      TransactId(const TransactId&) = delete;
      TransactId& operator=(const TransactId&) = delete;

      TransactId(TransactId&&) = delete;
      TransactId& operator=(TransactId&&) = delete;

      /** Compare for equality. */
      bool operator==(const TransactId& other) const noexcept {
        return process_id == other.process_id;
      }

      /** Get the sequence no. */
      uint64_t get_sequence_no() const noexcept {
        return sequence_no;
      }

      /** Get the delay between transacts generated. */
      std::optional<double> get_arrival_delay() const {
        return arrival_delay;
      }

      /** Get the time at which the transact was generated. */
      double get_arrival_time() const noexcept {
        return arrival_time;
      }

    private:

      /** Get the transact priority at the specified time point. */
      int get_priority_at(const Point* p) const {
        return priority.read_at(p);
      }

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

      /** Register the queue entry in the transact. */
      Result<Unit> register_queue_entry(QueueEntry&& entry, const Point* p) {
        auto seq_no = entry.queue->get_sequence_no();
        auto &entries = queue_entries;
        if (entries.find(seq_no) != entries.end()) {
          return RetryResult("There is another entry for the specified queue");
        } else {
          entries.emplace(seq_no, std::move(entry));
          return Result<Unit>(Unit());
        }
      }

      /** Unregister the queue entry from the transact. */
      Result<QueueEntry> unregister_queue_entry(const Queue& queue, const Point* p) {
        auto seq_no = queue.get_sequence_no();
        auto &entries = queue_entries;
        auto it = entries.find(seq_no);
        if (it == entries.end()) {
          return RetryResult("There must be entry for the specified queue");
        } else {
          QueueEntry entry { it->second };
          entries.erase(it);
          return Result<QueueEntry>(std::move(entry));
        }
      }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

      /** Register the queue entry in the transact. */
      Result<Unit> register_queue_entry(QueueEntry&& entry, const Point* p) {
        auto seq_no = entry.queue->get_sequence_no();
        const auto &entries = queue_entries.read_at(p);
        if (entries.find(seq_no) != entries.end()) {
          return RetryResult("There is another entry for the specified queue");
        } else {
          queue_entries.write_at(entries.emplace(seq_no, std::move(entry)), p);
          return Result<Unit>(Unit());
        }
      }

      /** Unregister the queue entry from the transact. */
      Result<QueueEntry> unregister_queue_entry(const Queue& queue, const Point* p) {
        auto seq_no = queue.get_sequence_no();
        const auto& entries = queue_entries.read_at(p);
        auto it = entries.find(seq_no);
        if (it == entries.end()) {
          return RetryResult("There must be entry for the specified queue");
        } else {
          QueueEntry entry { it.value() };
          queue_entries.write_at(entries.erase(seq_no), p);
          return Result<QueueEntry>(std::move(entry));
        }
      }

#else
#error "Unknown simulation mode"
#endif

      /** Preempt the computation that handles the transact. */
      Result<Unit> begin_preemption_at(const Point* p) {
        int n = preemption_count.read_at(p);
        preemption_count.write_at(1 + n, p);
        auto &pid = process_id.read_at(p);
        if (pid) {
          return begin_process_preemption(pid)(p);
        } else {
          return Result<Unit>(Unit());
        }
      }

      /** Proceed with the computation after the transact was preempted earlier. */
      Result<Unit> end_preemption_at(const Point* p) {
        int n = preemption_count.read_at(p);
        if (n <= 0) {
          return RetryResult("The transact preemption count cannot be negative");
        } else {
          preemption_count.write_at(n - 1, p);
          ProcessIdPtr pid = process_id.read_at(p);
          if (!pid) [[unlikely]] {
            return Result<Unit>(Unit());
          } else {
            Result<Unit> res { end_process_preemption(pid)(p) };
            if (get_result_if<Unit>(&res)) {
              auto cont_fn { process_cont_fn.swap_at(std::nullopt, p) };
              if (cont_fn.has_value()) {
                auto res { unfreeze_process_at(std::move(cont_fn.value()), p) };
                if (DVCOMPUTE_NS::internal::process::BoxedContFn<Unit> *cont_fn = get_result_if<DVCOMPUTE_NS::internal::process::BoxedContFn<Unit>>(&res)) {
                  if (cont_fn) {
                    return enqueue_uncancellable_event(p->time,
                      cons_event([pid, cont_fn{std::move(*cont_fn)}](const Point* p) mutable {
                        return DVCOMPUTE_NS::internal::process::resume_process(std::move(cont_fn), pid, Unit(), p);
                      }))(p);
                  } else {
                    return Result<Unit>(Unit());
                  }
                } else {
                  return error_result<Unit>(std::move(res));
                }
              } else {
                return Result<Unit>(Unit());
              }
            } else {
              return error_result<Unit>(std::move(res));
            }
          }
        }
      }

      /** Require to return an identifier of the process associated with the transact. */
      Result<ProcessIdPtr> require_process_id(const Point* p) {
        auto &pid = process_id.read_at(p);
        if (pid) {
          return Result<ProcessIdPtr>(pid);
        } else {
          return RetryResult("The transact must be associated with some process");
        }
      }

      template<typename Item2>
      friend inline auto new_transact(Arrival<Item2>&& arrival, int priority);

      template<typename Item2>
      friend inline auto split_transact(const Transact<Item2>& transact);

      friend inline auto transact_priority(const TransactIdPtr& tid);

      friend inline auto assign_transact_priority(const TransactIdPtr& tid, int priority);

      friend inline auto transact_assembly_set(const TransactIdPtr& tid);

      friend inline auto begin_transact_preemption(const TransactIdPtr& tid);

      friend inline auto end_transact_preemption(const TransactIdPtr& tid);

      friend class internal::transact::Take;

      friend class internal::transact::Release;

      friend class internal::transact::Assemble;

      friend class internal::transact::Gather;

      template<typename Impl>
      friend auto transfer_transact(const TransactIdPtr& tid, Process<Unit, Impl>&& comp);

      template<typename Impl>
      friend auto transfer_transact_within_event(const TransactIdPtr& tid, Process<Unit, Impl>&& comp);

      template<typename Impl>
      friend auto reactivate_transact(std::tuple<TransactIdPtr, std::optional<Process<Unit, Impl>>>&& xy);

      friend inline auto enqueue_transact(const QueuePtr& queue, const TransactIdPtr& tid, int increment);

      friend inline auto dequeue_transact(const QueuePtr& queue, const TransactIdPtr& tid, int decrement);

      template<typename Item2>
      friend class Facility;

      template<typename Item2>
      friend class Storage;

      template<typename Item2, typename Output2, typename Fn2>
      friend auto block_by(Fn2&& fn);
    };
  }
}

#endif /* dvcompute_block_transact_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_generator_block_h
#define dvcompute_generator_block_h

#include <functional>

#include "../../../dvcompute_ns.h"
#include "transact.h"
#include "transact_ops.h"
#include "../observable.h"
#include "../stream.h"
#include "../macros.h"

namespace DVCOMPUTE_NS {

  namespace block {

    namespace internal {

      namespace generator {

        /** @private */
        template<typename Item, typename Impl>
        class ObservableGenerator {

          Observable<Arrival<Item>, Impl> obs;

        public:

          explicit ObservableGenerator(Observable<Arrival<Item>, Impl>&& obs_arg)
            noexcept(noexcept(Observable<Arrival<Item>, Impl>(std::move(obs_arg)))) :
            obs(std::move(obs_arg))
          {}

          ObservableGenerator(ObservableGenerator<Item, Impl>&& other) = default;
          ObservableGenerator<Item, Impl>& operator=(ObservableGenerator<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

          ObservableGenerator(const ObservableGenerator<Item, Impl>& other) = default;
          ObservableGenerator<Item, Impl>& operator=(const ObservableGenerator<Item, Impl>& other) = default;

#endif

          template<typename ContFn>
          DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(std::function<Block<Transact<Item>, Unit>()>&& input,
            ContFn&& cont_fn,
            const ProcessIdPtr& pid,
            const Point* p)
          {
            if (pid->is_cancelled(p)) [[unlikely]] {
              return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);

            } else {
              auto res { 
                std::move(obs).subscribe(cons_observer([input{std::move(input)}](const Arrival<Item>* arrival, const Point* p) {
                  return into_event(new_transact(Arrival<Item> { *arrival }, p->priority))
                    .and_then([&input](Transact<Item>&& transact) mutable {
                      return run_process(take_transact(transact.transact_id)
                        .and_then([block{std::move(input())}, transact{std::move(transact)}](Unit&& unit) mutable {
                          return std::move(block).run(std::move(transact));
                        }));
                    })
                    .operator()(p);
                }))
                .operator()(p)
              };

              if (auto* h = get_result_if(&res)) {
                return finally_process(never_process<Unit>(), into_process(into_event(std::move(*h))))
                  .operator()(std::move(cont_fn), pid, p);

              } else {
                return error_result<Unit>(std::move(res));
              }
            }
          }
        };

        /** Handle the specified stream. */
        template<typename Item, typename BlockFn>
        inline Process<Unit> generator_stream_loop(Stream<Arrival<Item>>&& stream, BlockFn&& block_fn) {
          return std::move(stream)
            .run()
            .and_then([block_fn{std::move(block_fn)}](std::pair<Arrival<Item>, Stream<Arrival<Item>>>&& pair) mutable {
              return into_process(cons_event([arrival{std::move(pair.first)}](const Point *p) mutable {
                    return new_transact(std::move(arrival), p->priority)(p->run);
                  })
                  .and_then([block_fn](Transact<Item>&& transact) mutable {
                    return run_process(take_transact(transact.transact_id)
                      .and_then([block_fn{std::move(block_fn)}, transact{std::move(transact)}](Unit&& unit) mutable {
                        return block_fn().run(std::move(transact));
                      }));
                  }))
                .and_then([xs{std::move(pair.second)}, block_fn{std::move(block_fn)}](Unit&& unit) mutable {
                  return generator_stream_loop<Item, BlockFn>(std::move(xs), std::move(block_fn));
                });
            });
        }

        /** @private */
        template<typename Item>
        class StreamGenerator {

          Stream<Arrival<Item>> stream;

        public:

          explicit StreamGenerator(Stream<Arrival<Item>>&& stream_arg)
            noexcept(noexcept(Stream<Arrival<Item>>(std::move(stream_arg)))) :
            stream(std::move(stream_arg))
          {}

          StreamGenerator(StreamGenerator<Item>&& other) = default;
          StreamGenerator<Item>& operator=(StreamGenerator<Item>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

          StreamGenerator(const StreamGenerator<Item>& other) = default;
          StreamGenerator<Item>& operator=(const StreamGenerator<Item>& other) = default;

#endif

          template<typename ContFn>
          DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(std::function<Block<Transact<Item>, Unit>()>&& input,
            ContFn&& cont_fn,
            const ProcessIdPtr& pid,
            const Point* p)
          {
            if (pid->is_cancelled(p)) [[unlikely]] {
              return DVCOMPUTE_NS::internal::process::revoke_process(std::move(cont_fn), pid, p);

            } else {
              return generator_stream_loop(std::move(stream), std::move(input))
                .operator()(std::move(cont_fn), pid, p);
            }
          }
        };
      }
    }

    /** Represents a generator block computation. */
    template<typename Item, typename Impl = 
        DVCOMPUTE_NS::internal::block::BoxedImpl<std::function<Block<Item, Unit>()>, Unit>>
      using GeneratorBlock = Block<std::function<Block<Item, Unit>()>, Unit, Impl>;

    /** Return a `GeneratorBlock<Transact<Item>>` by the specified `Observable<Arrival<Item>>`. */
    template<typename Item, typename Impl>
    inline auto observable_generator_block(Observable<Arrival<Item>, Impl>&& obs) {
      using ResultImpl = DVCOMPUTE_NS::block::internal::generator::ObservableGenerator<Item, Impl>;
      return GeneratorBlock<Transact<Item>, ResultImpl>(ResultImpl(std::move(obs)));
    }

    /** Return a `GeneratorBlock<Transact<Item>>` by the specified `Stream<Arrival<Item>>`. */
    template<typename Item>
    inline auto stream_generator_block(Stream<Arrival<Item>>&& stream) {
      using ResultImpl = DVCOMPUTE_NS::block::internal::generator::StreamGenerator<Item>;
      return GeneratorBlock<Transact<Item>, ResultImpl>(ResultImpl(std::move(stream)));
    }
  }
}

#endif /* dvcompute_generator_block_h */

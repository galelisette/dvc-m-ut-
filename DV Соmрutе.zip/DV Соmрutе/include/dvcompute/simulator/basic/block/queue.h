/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_queue_h
#define dvcompute_block_queue_h

#include <cstdint>

#include "../../../dvcompute_ns.h"
#include "../types.h"
#include "../ref.h"
#include "../stats/sampling_stats.h"
#include "../stats/timing_stats.h"
#include "../observable.h"
#include "../observable_source.h"
#include "../event.h"

namespace DVCOMPUTE_NS {

  namespace block {

    /** The transact identifier. */
    class TransactId;

    /** The shared pointer for the transact identifier. */
    using TransactIdPtr = SharedPtr<TransactId>;

    /** Defines a queue entity. */
    class Queue;

    /** The shared reference for the queue entity. */
    using QueuePtr = SharedPtr<Queue>;

    /** The queue entry. */
    struct QueueEntry {

      /** The entry queue. */
      QueuePtr queue;

      /** The time of registering the queue entry. */
      double enqueue_time;
    };

    /** Defines a queue entity. */
    class Queue {

      /** The sequence number. */
      uint64_t sequence_no;

      /** The content. */
      Ref<int> content;

      /** The content statistics. */
      Ref<TimingStats<int>> content_stats;

      /** The enqueue count. */
      Ref<int> enqueue_count;

      /** The enqueue zero entry count. */
      Ref<int> enqueue_zero_entry_count;

      /** The wait time. */
      Ref<SamplingStats<double>> wait_time;

      /** The non-zero entry wait time. */
      Ref<SamplingStats<double>> non_zero_entry_wait_time;

      /** Triggered when enqueued. */
      ObservableSource<Unit> enqueued;

      /** Triggered when dequeued. */
      ObservableSource<Unit> dequeued;

      explicit Queue(double time_arg, uint64_t sequence_no_arg) :
        sequence_no(sequence_no_arg),
        content(0),
        content_stats(TimingStats<int>::from_sample(time_arg, 0)),
        enqueue_count(0),
        enqueue_zero_entry_count(0),
        wait_time(SamplingStats<double>()),
        non_zero_entry_wait_time(SamplingStats<double>()),
        enqueued(),
        dequeued()
      {}

    public:

      Queue(Queue&&) = delete;
      Queue(const Queue&) = delete;

      Queue& operator=(Queue&&) = delete;
      Queue& operator=(const Queue&) = delete;

      /** Get the sequence number. */
      uint64_t get_sequence_no() const noexcept {
        return sequence_no;
      }

    private:

      friend inline auto new_queue();
      friend inline auto late_init_queue(QueuePtr& dest);
      friend inline auto queue_empty(const QueuePtr& queue);
      friend inline auto queue_enqueued(const QueuePtr& queue);
      friend inline auto queue_dequeued(const QueuePtr& queue);
      friend inline auto queue_content(const QueuePtr& queue);
      friend inline auto queue_content_stats(const QueuePtr& queue);
      friend inline auto queue_content_changed_(const QueuePtr& queue);
      friend inline auto queue_content_changed(const QueuePtr& queue);
      friend inline auto enqueue_count(const QueuePtr& queue);
      friend inline auto enqueue_count_changed_(const QueuePtr& queue);
      friend inline auto enqueue_count_changed(const QueuePtr& queue);
      friend inline auto enqueue_zero_entry_count(const QueuePtr& queue);
      friend inline auto enqueue_zero_entry_count_changed_(const QueuePtr& queue);
      friend inline auto enqueue_zero_entry_count_changed(const QueuePtr& queue);
      friend inline auto queue_wait_time(const QueuePtr& queue);
      friend inline auto queue_wait_time_changed_(const QueuePtr& queue);
      friend inline auto queue_wait_time_changed(const QueuePtr& queue);
      friend inline auto queue_non_zero_entry_wait_time(const QueuePtr& queue);
      friend inline auto queue_non_zero_entry_wait_time_changed_(const QueuePtr& queue);
      friend inline auto queue_non_zero_entry_wait_time_changed(const QueuePtr& queue);
      friend inline auto queue_rate(const QueuePtr& queue);
      friend inline auto queue_rate_changed_(const QueuePtr& queue);
      friend inline auto queue_rate_changed(const QueuePtr& queue);
      friend inline auto queue_changed_(const QueuePtr& queue);
      friend inline auto reset_queue(const QueuePtr& queue);
      
      friend inline auto enqueue_transact(const QueuePtr& queue, const TransactIdPtr& tid, int increment);
      friend inline auto dequeue_transact(const QueuePtr& queue, const TransactIdPtr& tid, int decrement);
    };

    /** Create a new queue within `Event<QueuePtr>`. */
    inline auto new_queue() {
      auto fn = [](const Point* p) {
        auto t = p->time;
        auto sequence_no = p->run->gen.random_sequence_no();
        
        return Result<QueuePtr>(QueuePtr(SharedPtrFn {}, [t, sequence_no](Queue *address) {
          new(address) Queue(t, sequence_no);
        }));
      };
      return Event<QueuePtr, decltype(fn)>(std::move(fn));
    }

    /** Create a new queue within `Event<Unit>` by the specified destination. */
    inline auto late_init_queue(QueuePtr& dest) {
      auto fn = [=](const Point* p) mutable {
        auto t = p->time;
        auto sequence_no = p->run->gen.random_sequence_no();

        dest.late_init(SharedPtrFn {}, [t, sequence_no](Queue *address) {
          new(address) Queue(t, sequence_no);
        });

        return Result<Unit>(Unit());
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Test whether the queue is empty within `Event<bool>`. */
    inline auto queue_empty(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<bool>(queue->content.read_at(p) == 0);
      };
      return Event<bool, decltype(fn)>(std::move(fn));
    }

    /** Notifies when enqueueing an item. */
    inline auto queue_enqueued(const QueuePtr& queue) {
      return queue->enqueued.publish();
    }

    /** Notifies when dequeueing the item. */
    inline auto queue_dequeued(const QueuePtr& queue) {
      return queue->dequeued.publish();
    }

    /** Return the current queue content within `Event<int>`. */
    inline auto queue_content(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<int>(queue->content.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Return the queue content statistics within `Event<TimingStats<int>>`. */
    inline auto queue_content_stats(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<TimingStats<int>>(queue->content_stats.read_at(p));
      };
      return Event<TimingStats<int>, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when the `queue_content` propery changes. */
    inline auto queue_content_changed_(const QueuePtr& queue) {
      return queue_enqueued(queue).merge(queue_dequeued(queue));
    }

    /** Triggered within `Observable<int>` when the `queue_content` propery changes. */
    inline auto queue_content_changed(const QueuePtr& queue) {
      return queue_content_changed_(queue)
        .mapc([=](const Unit* unit) {
          return queue_content(queue);
        });
    }

    /** Return within `Event<int>` the total number of input items that were enqueued. */
    inline auto enqueue_count(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<int>(queue->enqueue_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when the `enqueue_count` propery changes. */
    inline auto enqueue_count_changed_(const QueuePtr& queue) {
      return queue_enqueued(queue);
    }

    /** Triggered within `Observable<int>` when the `queue_content` propery changes. */
    inline auto enqueue_count_changed(const QueuePtr& queue) {
      return enqueue_count_changed_(queue)
        .mapc([=](const Unit* unit) {
          return enqueue_count(queue);
        });
    }

    /** Return within `Event<int>` the total number of zero entry items that were enqueued. */
    inline auto enqueue_zero_entry_count(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<int>(queue->enqueue_zero_entry_count.read_at(p));
      };
      return Event<int, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when the `enqueue_zero_entry_count` propery changes. */
    inline auto enqueue_zero_entry_count_changed_(const QueuePtr& queue) {
      return queue_dequeued(queue);
    }

    /** Triggered within `Observable<int>` when the `queue_zero_entry_content` propery changes. */
    inline auto enqueue_zero_entry_count_changed(const QueuePtr& queue) {
      return enqueue_zero_entry_count_changed_(queue)
        .mapc([=](const Unit* unit) {
          return enqueue_zero_entry_count(queue);
        });
    }

    /** Return within `Event<SamplingStats<double>>` the wait (or residence) time. */
    inline auto queue_wait_time(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<SamplingStats<double>>(queue->wait_time.read_at(p));
      };
      return Event<SamplingStats<double>, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when the `queue_wait_time` propery changes. */
    inline auto queue_wait_time_changed_(const QueuePtr& queue) {
      return queue_dequeued(queue);
    }

    /** Triggered within `Observable<SamplingStats<double>>` when the `queue_wait_time` propery changes. */
    inline auto queue_wait_time_changed(const QueuePtr& queue) {
      return queue_wait_time_changed_(queue)
        .mapc([=](const Unit* unit) {
          return queue_wait_time(queue);
        });
    }

    /** Return within `Event<SamplingStats<double>>` the wait (or residence) time by excluding zero entries. */
    inline auto queue_non_zero_entry_wait_time(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        return Result<SamplingStats<double>>(queue->non_zero_entry_wait_time.read_at(p));
      };
      return Event<SamplingStats<double>, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when the `queue_non_zero_entry_wait_time` propery changes. */
    inline auto queue_non_zero_entry_wait_time_changed_(const QueuePtr& queue) {
      return queue_dequeued(queue);
    }

    /** Triggered within `Observable<SamplingStats<double>>` when the `queue_non_zero_entry_wait_time` propery changes. */
    inline auto queue_non_zero_entry_wait_time_changed(const QueuePtr& queue) {
      return queue_non_zero_entry_wait_time_changed_(queue)
        .mapc([=](const Unit* unit) {
          return queue_non_zero_entry_wait_time(queue);
        });
    }

    /** 
      * Return within `Event<double>` a long-term average queue rate calculated 
      * as the average queue content divided by the average wait time.
      */
    inline auto queue_rate(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        auto &x = queue->content_stats.read_at(p);
        auto &y = queue->wait_time.read_at(p);
        return Result<double>(x.mean() / y.mean);
      };
      return Event<double, decltype(fn)>(std::move(fn));
    }

    /** Triggered within `Observable<Unit>` when the `queue_rate` propery changes. */
    inline auto queue_rate_changed_(const QueuePtr& queue) {
      return queue_enqueued(queue).merge(queue_dequeued(queue));
    }

    /** Triggered within `Observable<double>` when the `queue_rate` propery changes. */
    inline auto queue_rate_changed(const QueuePtr& queue) {
      return queue_rate_changed_(queue)
        .mapc([=](const Unit* unit) {
          return queue_rate(queue);
        });
    }

    /** Triggered within `Observable<Unit>` when the queue propery changes. */
    inline auto queue_changed_(const QueuePtr& queue) {
      return queue_enqueued(queue).merge(queue_dequeued(queue));
    }

    /** Reset the statistics within `Event<Unit>`. */
    inline auto reset_queue(const QueuePtr& queue) {
      auto fn = [=](const Point* p) {
        int content = queue->content.read_at(p);
        queue->content_stats.write_at(TimingStats<int>::from_sample(p->time, content), p);
        queue->enqueue_count.write_at(0, p);
        queue->enqueue_zero_entry_count.write_at(0, p);
        queue->wait_time.write_at(SamplingStats<double>(), p);
        queue->non_zero_entry_wait_time.write_at(SamplingStats<double>(), p);
        return Result<Unit>(Unit());
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }
  }
}

#endif /* dvcompute_block_queue_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_ref_h
#define dvcompute_ref_h

#if defined(DVCOMPUTE_SEQUENTIAL)
#include "../seq/ref.h"
#elif defined(DVCOMPUTE_DISTRIBUTED)
#include "../dist/ref.h"
#elif defined(DVCOMPUTE_CONSERVATIVE)
#include "../cons/ref.h"
#elif defined(DVCOMPUTE_BRANCHED)
#include "../branch/ref.h"
#else
#error "Unknown simulation mode"
#endif

#endif /* dvcompute_ref_h */

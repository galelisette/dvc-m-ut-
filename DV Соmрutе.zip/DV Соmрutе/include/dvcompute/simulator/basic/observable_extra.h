/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_extra_h
#define dvcompute_observable_extra_h

#include <optional>
#include <memory>
#include <vector>
#include <utility>
#include <algorithm>

#include "../../dvcompute_ns.h"
#include "../utils/list.h"
#include "macros.h"
#include "arrival.h"
#include "observable.h"
#include "observer.h"
#include "types.h"
#include "ref.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace observable {

      template<typename Message, typename Self>
      class ArrivalObservable {

        Self comp;

      public:

        explicit ArrivalObservable(Self &&comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg)))) :
          comp(std::move(comp_arg))
        {}

        ArrivalObservable(ArrivalObservable<Message, Self> &&other) = default;
        ArrivalObservable<Message, Self>& operator=(ArrivalObservable<Message, Self> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        ArrivalObservable(const ArrivalObservable<Message, Self> &other) = default;
        ArrivalObservable<Message, Self>& operator=(const ArrivalObservable<Message, Self> &other) = default;

#endif

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          RefPtr<std::optional<double>> r { mk_shared(Ref<std::optional<double>>(std::nullopt)) };
          return std::move(comp)
            .subscribe(cons_observer([obs{std::move(obs)}, r](const Message* msg, const Point* p) {
              std::optional<double> t0 = r->read_at(p);
              double t = p->time;
              r->write_at(double { t }, p);
              Arrival<Message> arrival {
                *msg, t, t0.has_value() ? std::make_optional(t - t0.value()) : std::nullopt
              };
              return obs(&arrival, p);
            }));
        }
      };
    }
  }

  /** 
   * Transform a signal so that the resulting signal returns a sequence of arrivals
   * saving the information about the time points at which the original signal was 
   * received.
   */
  template<typename Message, typename Signal>
#ifdef DVCOMPUTE_CONCEPTS
  ObservableLike<Arrival<Message>> auto arrival_observable(Signal&& signal) requires ObservableLike<Signal, Message> {
#else
  auto arrival_observable(Signal&& signal) {
#endif
    using ResultImpl = internal::observable::ArrivalObservable<Message, Signal>;
    return Observable<Arrival<Message>, ResultImpl>(ResultImpl(std::move(signal)));
  }

  /**
   * Return an `Event<SharedPtr<ObservableSource<double>>>` source of signal that is triggered 
   * in the integration time points.
   */
  inline Event<SharedPtr<ObservableSource<double>>> new_observable_source_in_integ_times() {
    auto fn = [](const Point* p) {
      SharedPtr<ObservableSource<double>> source { mk_shared(ObservableSource<double>()) };
      Result<Unit> res {
        enqueue_events_with_integ_times([source]() {
          return cons_event([source](const Point* p) {
            double t = p->time;
            return source->trigger_at(&t, p);
          });
        })
        .operator()(p)
      };
      if (get_result_if(&res)) {
        return Result<SharedPtr<ObservableSource<double>>>(std::move(source));
      } else {
        return error_result<SharedPtr<ObservableSource<double>>>(std::move(res));
      }
    };
    return Event<SharedPtr<ObservableSource<double>>, decltype(fn)>(std::move(fn));
  }

  /**
   * Return an `Event<SharedPtr<ObservableSource<double>>>` source of signal that is triggered 
   * in the start time point. It should be called in the start time only.
   */
  inline Event<SharedPtr<ObservableSource<double>>> new_observable_source_in_start_time() {
    auto fn = [](const Point* p) {
      SharedPtr<ObservableSource<double>> source { mk_shared(ObservableSource<double>()) };
      Result<Unit> res {
        enqueue_event(p->run->specs->start_time, 
          cons_event([source](const Point* p) {
            double t = p->time;
            return source->trigger_at(&t, p);
          }))
        .operator()(p)
      };
      if (get_result_if(&res)) {
        return Result<SharedPtr<ObservableSource<double>>>(std::move(source));
      } else {
        return error_result<SharedPtr<ObservableSource<double>>>(std::move(res));
      }
    };
    return Event<SharedPtr<ObservableSource<double>>, decltype(fn)>(std::move(fn));
  }

  /**
   * Return an `Event<SharedPtr<ObservableSource<double>>>` source of signal that is triggered 
   * in the stop time point.
   */
  inline Event<SharedPtr<ObservableSource<double>>> new_observable_source_in_stop_time() {
    auto fn = [](const Point* p) {
      SharedPtr<ObservableSource<double>> source { mk_shared(ObservableSource<double>()) };
      Result<Unit> res {
        enqueue_event(p->run->specs->stop_time, 
          cons_event([source](const Point* p) {
            double t = p->time;
            return source->trigger_at(&t, p);
          }))
        .operator()(p)
      };
      if (get_result_if(&res)) {
        return Result<SharedPtr<ObservableSource<double>>>(std::move(source));
      } else {
        return error_result<SharedPtr<ObservableSource<double>>>(std::move(res));
      }
    };
    return Event<SharedPtr<ObservableSource<double>>, decltype(fn)>(std::move(fn));
  }

  /**
   * Return an `Event<Observable<double>>` signal that is triggered 
   * in the integration time points.
   */
  inline Event<Observable<double>> new_observable_in_integ_times() {
    return new_observable_source_in_integ_times()
      .map([](SharedPtr<ObservableSource<double>>&& obs) {
        return obs->publish().operator Observable<double>();
      });
  }

  /**
   * Return an `Event<Observable<double>>` signal that is triggered 
   * in the start time point. It should be called in the start time only.
   */
  inline Event<Observable<double>> new_observable_in_start_time() {
    return new_observable_source_in_start_time()
      .map([](SharedPtr<ObservableSource<double>>&& obs) {
        return obs->publish().operator Observable<double>();
      });
  }

  /**
   * Return an `Event<Observable<double>>` signal that is triggered 
   * in the stop time point.
   */
  inline Event<Observable<double>> new_observable_in_stop_time() {
    return new_observable_source_in_stop_time()
      .map([](SharedPtr<ObservableSource<double>>&& obs) {
        return obs->publish().operator Observable<double>();
      });
  }

  namespace {

    Event<Unit> observable_in_time_grid_loop(const SharedPtr<ObservableSource<double>>& source, unsigned int index, unsigned int size) {
      auto fn = [source, index, size](const Point *p) {
        const Specs* specs = p->run->specs;
        if (index >= size) {
          return Result<Unit>(Unit());

        } else {
          double t = specs->grid_time(index, size);
          return enqueue_event(t, 
            cons_event([source, index, size, t](const Point* p) {
              return source->trigger(double { t })
                .and_then([source, index, size](Unit&& unit) {
                  return observable_in_time_grid_loop(source, 1 + index, size);
                })
                .operator()(p);
            }))
          .operator()(p);
        }
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }
  }

  /**
   * Return the `Event<SharedPtr<ObservableSource<double>>>` source of the signal 
   * that is triggered in the grid by the specified size.
   */
  inline Event<SharedPtr<ObservableSource<double>>> new_observable_source_in_time_grid(unsigned int size) {
    auto fn = [size](const Point* p) {
      SharedPtr<ObservableSource<double>> source { mk_shared(ObservableSource<double>()) };
      return observable_in_time_grid_loop(source, 0, size)
        .map([source](Unit&& unit) {
          return source;
        })
        .operator()(p);
    };
    return Event<SharedPtr<ObservableSource<double>>, decltype(fn)>(std::move(fn));
  }

  /**
   * Return the `Event<Observable<double>>` signal that is triggered 
   * in the grid by the specified size.
   */
  inline Event<Observable<double>> new_observable_in_time_grid(unsigned int size) {
    return new_observable_source_in_time_grid(size)
      .map([](SharedPtr<ObservableSource<double>>&& obs) {
        return obs->publish().operator Observable<double>();
      });
  }

  /** It represents the predefined signals provided by every simulation model. */
  class PredefinedObservableSet {

    /** The source of signal triggered in the integration time points. */
    SharedPtr<ObservableSource<double>> source_in_integ_times;

    /** The source of signal triggered in the start time point. */
    SharedPtr<ObservableSource<double>> source_in_start_time;

    /** The source of signal triggered in the stop time point. */
    SharedPtr<ObservableSource<double>> source_in_stop_time;

    explicit PredefinedObservableSet(const SharedPtr<ObservableSource<double>>& source_in_integ_times_arg,
      const SharedPtr<ObservableSource<double>>& source_in_start_time_arg,
      const SharedPtr<ObservableSource<double>>& source_in_stop_time_arg) noexcept :
        source_in_integ_times(source_in_integ_times_arg),
        source_in_start_time(source_in_start_time_arg),
        source_in_stop_time(source_in_stop_time_arg)
    {}

    friend inline Event<PredefinedObservableSet> new_predefined_observable_set();

  public:

    PredefinedObservableSet(PredefinedObservableSet&&) = default;
    PredefinedObservableSet& operator=(PredefinedObservableSet&&) = default;

    PredefinedObservableSet(const PredefinedObservableSet&) = default;
    PredefinedObservableSet& operator=(const PredefinedObservableSet&) = default;

    /** The signal triggered in the integration time points. */
    Observable<double> in_integ_times() const {
      return source_in_integ_times->publish();
    }

    /** The signal triggered in the start time point. */
    Observable<double> in_start_time() const {
      return source_in_start_time->publish();
    }

    /** The signal triggered in the stop time point. */
    Observable<double> in_stop_time() const {
      return source_in_stop_time->publish();
    }
  };

  /** Create a `PredefinedObservableSet` instance within the `Event` computation. */
  inline Event<PredefinedObservableSet> new_predefined_observable_set() {
    return new_observable_source_in_integ_times()
      .and_then([](SharedPtr<ObservableSource<double>>&& source_in_integ_times) {
        return new_observable_source_in_start_time()
          .and_then([=](SharedPtr<ObservableSource<double>>&& source_in_start_time) {
            return new_observable_source_in_stop_time()
              .map([=](SharedPtr<ObservableSource<double>>&& source_in_stop_time) {
                return PredefinedObservableSet(source_in_integ_times, source_in_start_time, source_in_stop_time);
              });
          });
      });
  }

  /** The signal history data. */
  template<typename Item>
  struct ObservableHistoryData {

    /** The time points at which data values are collected. */
    std::vector<double> times;

    /** Data values associated with their time points. */
    std::vector<Item> values;
  };

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

  /** Represents the history of the signal values. */
  template<typename Item>
  class ObservableHistory {

    template<typename Item2>
      using List = DVCOMPUTE_NS::utils::im::List<Item2>;

    /** The time values. */
    std::vector<double> times;

    /** The values themselves. */
    std::vector<Item> values;

    explicit ObservableHistory() :
      times(),
      values()
    {}

  public:

    /** Read the history size at the specified modeling time. */
    std::size_t size_at(const Point* p) {
      return values.size();
    }

  private:

    template<typename Item2, typename Impl2>
    friend Composite<SharedPtr<ObservableHistory<Item2>>> new_observable_history(Observable<Item2, Impl2>&& obs, 
      std::optional<Item2>&& init,
      std::optional<SharedPtr<ObservableSource<Item2>>>&& source);

    template<typename Item2, typename Impl2>
    friend Composite<SharedPtr<ObservableHistory<Item2>>> new_observable_history_grid(Observable<Item2, Impl2>&& obs, 
      unsigned int size,
      std::function<Item2(const Item2&, const Item2&)>&& accum_fn,
      std::optional<Item2>&& init);

    template<typename Item2>
    friend Event<Unit> push_to_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist, Item2&& item);

    template<typename Item2>
    friend Event<ObservableHistoryData<Item2>> read_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist);

    template<typename Item2>
    friend Event<ObservableHistoryData<Item2>> take_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist);

    template<typename Item2>
    friend Event<Unit> reset_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist);
  };

  /** Create a new signal history within `Composite<SharedPtr<ObservableHistory<Item>>>`. */
  template<typename Item, typename Impl>
  Composite<SharedPtr<ObservableHistory<Item>>> new_observable_history(Observable<Item, Impl>&& obs, 
    std::optional<Item>&& init = std::nullopt,
    std::optional<SharedPtr<ObservableSource<Item>>>&& source = std::nullopt)
  {
    using namespace DVCOMPUTE_NS::utils::im;
    SharedPtr<ObservableHistory<Item>> hist { mk_shared(ObservableHistory<Item>()) };

    return pure_composite(std::move(hist))
      .and_then([init{std::move(init)}, source](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        if (init.has_value()) {
          return into_composite(cons_event([hist{std::move(hist)}, init{std::move(init)}, source{std::move(source)}](const Point* p) mutable {
              hist->times.push_back(p->time);
              hist->values.push_back(init.value());

              if (source.has_value()) {
                auto res { source.value()->trigger_at(&(init.value()), p) };

                if (!get_result_if(&res)) {
                  return error_result<SharedPtr<ObservableHistory<Item>>>(std::move(res));
                }
              }

              return Result<SharedPtr<ObservableHistory<Item>>>(std::move(hist));
            }))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();

        } else {
          return pure_composite(std::move(hist))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();
        }
      })
      .and_then([obs{std::move(obs)}, source{std::move(source)}](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        return into_composite(std::move(obs).subscribe(cons_observer([hist, source{std::move(source)}](const Item* item, const Point* p) {
            hist->times.push_back(p->time);
            hist->values.push_back(*item);

            if (source.has_value()) {
              auto res { source.value()->trigger_at(item, p) };

              if (!get_result_if(&res)) {
                return error_result<Unit>(std::move(res));
              }
            }

            return Result<Unit>(Unit());
          })))
          .and_then([](Disposable<>&& h) {
            return disposable_composite(std::move(h));
          })
          .and_then([hist{std::move(hist)}](Unit&& unit) mutable {
            return pure_composite(std::move(hist));
          });
      });
  }

  /** 
   * Create a new signal history within `Composite<SharedPtr<ObservableHistory<Item>>>`
   * by the specified grid size and accumulator function. 
   */
  template<typename Item, typename Impl>
  Composite<SharedPtr<ObservableHistory<Item>>> new_observable_history_grid(Observable<Item, Impl>&& obs, 
    unsigned int size,
    std::function<Item(const Item&, const Item&)>&& accum_fn,
    std::optional<Item>&& init = std::nullopt)
  {
    using namespace DVCOMPUTE_NS::utils::im;
    SharedPtr<ObservableHistory<Item>> hist { mk_shared(ObservableHistory<Item>()) };

    return pure_composite(std::move(hist))
      .and_then([init{std::move(init)}](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        if (init.has_value()) {
          return into_composite(cons_event([hist{std::move(hist)}, init{std::move(init)}](const Point* p) mutable {
              hist->times.push_back(p->time);
              hist->values.emplace_back(std::move(init.value()));
              
              return Result<SharedPtr<ObservableHistory<Item>>>(std::move(hist));
            }))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();

        } else {
          return pure_composite(std::move(hist))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();
        }
      })
      .and_then([obs{std::move(obs)}, size, accum_fn{std::move(accum_fn)}](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        return into_composite(std::move(obs).subscribe(cons_observer([hist, size, accum_fn{std::move(accum_fn)}](const Item* item, const Point* p) {
            if (hist->times.empty()) {
              hist->times.push_back(p->time);
              hist->values.push_back(*item);

            } else {
              unsigned int index0 = p->run->specs->grid_index(hist->times.back(), size);
              unsigned int index2 = p->run->specs->grid_index(p->time, size);

              if (index0 != index2 || hist->times.back() <= p->run->specs->grid_time(index0 - 1, size)) {
                hist->times.push_back(p->time);
                hist->values.push_back(*item);

              } else {
                hist->times.back() = p->time;
                hist->values.back() = accum_fn(hist->values.back(), *item);
              }
            }
                
            return Result<Unit>(Unit());
          })))
          .and_then([](Disposable<>&& h) {
            return disposable_composite(std::move(h));
          })
          .and_then([hist{std::move(hist)}](Unit&& unit) mutable {
            return pure_composite(std::move(hist));
          });
      });
  }

  /** Add the item to the history of signal values. */
  template<typename Item>
  Event<Unit> push_to_observable_history(const SharedPtr<ObservableHistory<Item>>& hist, Item&& item) {
    return cons_event([hist, item{std::move(item)}](const Point* p) mutable {
      hist->times.push_back(p->time);
      hist->values.emplace_back(item);

      return Result<Unit>(Unit());
    });
  }

  /** Read the history of signal values. */
  template<typename Item>
  Event<ObservableHistoryData<Item>> read_observable_history(const SharedPtr<ObservableHistory<Item>>& hist) {
    return cons_event([hist](const Point* p) {
      static_cast<void>(p);

      std::vector<double> ts { hist->times };
      std::vector<Item> xs { hist->values };

      ObservableHistoryData<Item> txs { std::move(ts), std::move(xs) };

      return Result<ObservableHistoryData<Item>>(std::move(txs));
    });
  }

  /** Reset the history of the signal values. */
  template<typename Item>
  Event<Unit> reset_observable_history(const SharedPtr<ObservableHistory<Item>>& hist) {
    return cons_event([hist](const Point* p) mutable {
      static_cast<void>(p);

      hist->times.clear();
      hist->values.clear();

      return Result<Unit>(Unit());
    });
  }

  /** Take the history of signal values, after which the history becomes empty. */
  template<typename Item>
  Event<ObservableHistoryData<Item>> take_observable_history(const SharedPtr<ObservableHistory<Item>>& hist) {
    return cons_event([hist](const Point* p) {
      static_cast<void>(p);

      std::vector<double> ts;
      std::vector<Item> xs;

      hist->times.swap(ts);
      hist->values.swap(xs);

      ObservableHistoryData<Item> txs { std::move(ts), std::move(xs) };

      return Result<ObservableHistoryData<Item>>(std::move(txs));
    });
  }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

  /** Represents the history of the signal values. */
  template<typename Item>
  class ObservableHistory {

    template<typename Item2>
      using List = DVCOMPUTE_NS::utils::im::List<Item2>;

    /** The time values. */
    Ref<List<double>> times;

    /** The values themselves. */
    Ref<List<Item>> values;

    /** The history size. */
    Ref<std::size_t> len;

    explicit ObservableHistory() :
      times(List<double>()),
      values(List<Item>()),
      len(0)
    {}

  public:

    /** Read the history size at the specified modeling time. */
    std::size_t size_at(const Point* p) {
      return len.read_at(p);
    }

  private:

    template<typename Item2, typename Impl2>
    friend Composite<SharedPtr<ObservableHistory<Item2>>> new_observable_history(Observable<Item2, Impl2>&& obs, 
      std::optional<Item2>&& init,
      std::optional<SharedPtr<ObservableSource<Item2>>>&& source);

    template<typename Item2, typename Impl2>
    friend Composite<SharedPtr<ObservableHistory<Item2>>> new_observable_history_grid(Observable<Item2, Impl2>&& obs, 
      unsigned int size,
      std::function<Item2(const Item2&, const Item2&)>&& accum_fn,
      std::optional<Item2>&& init); 

    template<typename Item2>
    friend Event<Unit> push_to_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist, Item2&& item);

    template<typename Item2>
    friend Event<ObservableHistoryData<Item2>> read_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist);

    template<typename Item2>
    friend Event<ObservableHistoryData<Item2>> take_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist);

    template<typename Item2>
    friend Event<Unit> reset_observable_history(const SharedPtr<ObservableHistory<Item2>>& hist);
  };

  /** Create a new signal history within `Composite<SharedPtr<ObservableHistory<Item>>>`. */
  template<typename Item, typename Impl>
  Composite<SharedPtr<ObservableHistory<Item>>> new_observable_history(Observable<Item, Impl>&& obs,
    std::optional<Item>&& init = std::nullopt,
    std::optional<SharedPtr<ObservableSource<Item>>>&& source = std::nullopt)
  {
    using namespace DVCOMPUTE_NS::utils::im;
    SharedPtr<ObservableHistory<Item>> hist { mk_shared(ObservableHistory<Item>()) };

    return pure_composite(std::move(hist))
      .and_then([init{std::move(init)}, source](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        if (init.has_value()) {
          return into_composite(cons_event([hist{std::move(hist)}, init{std::move(init)}, source{std::move(source)}](const Point* p) mutable {
              const List<double> times { hist->times.read_at(p) };
              const List<Item> values { hist->values.read_at(p) };
              std::size_t len { hist->len.read_at(p) };

              hist->times.write_at(List<double>(p->time, times), p);
              hist->values.write_at(List<Item>(init.value(), values), p);
              hist->len.write_at(1 + len, p);
              
              if (source.has_value()) {
                auto res { source.value()->trigger_at(&(init.value()), p) };

                if (!get_result_if(&res)) {
                  return error_result<SharedPtr<ObservableHistory<Item>>>(std::move(res));
                }
              }
              
              return Result<SharedPtr<ObservableHistory<Item>>>(std::move(hist));
            }))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();

        } else {
          return pure_composite(std::move(hist))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();
        }
      })
      .and_then([obs{std::move(obs)}, source{std::move(source)}](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        return into_composite(std::move(obs).subscribe(cons_observer([hist, source{std::move(source)}](const Item* item, const Point* p) {
            const List<double> times { hist->times.read_at(p) };
            const List<Item> values { hist->values.read_at(p) };
            std::size_t len { hist->len.read_at(p) };

            hist->times.write_at(List<double>(p->time, times), p);
            hist->values.write_at(List<Item>(*item, values), p);
            hist->len.write_at(1 + len, p);
                
            if (source.has_value()) {
              auto res { source.value()->trigger_at(item, p) };

              if (!get_result_if(&res)) {
                return error_result<Unit>(std::move(res));
              }
            }
              
            return Result<Unit>(Unit());
          })))
          .and_then([](Disposable<>&& h) {
            return disposable_composite(std::move(h));
          })
          .and_then([hist{std::move(hist)}](Unit&& unit) mutable {
            return pure_composite(std::move(hist));
          });
      });
  }

  /** 
   * Create a new signal history within `Composite<SharedPtr<ObservableHistory<Item>>>`
   * by the specified grid size and accumulator function. 
   */
  template<typename Item, typename Impl>
  Composite<SharedPtr<ObservableHistory<Item>>> new_observable_history_grid(Observable<Item, Impl>&& obs, 
    unsigned int size,
    std::function<Item(const Item&, const Item&)>&& accum_fn,
    std::optional<Item>&& init = std::nullopt) 
  {
    using namespace DVCOMPUTE_NS::utils::im;
    SharedPtr<ObservableHistory<Item>> hist { mk_shared(ObservableHistory<Item>()) };

    return pure_composite(std::move(hist))
      .and_then([init{std::move(init)}](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        if (init.has_value()) {
          return into_composite(cons_event([hist{std::move(hist)}, init{std::move(init)}](const Point* p) mutable {
              const List<double> times { hist->times.read_at(p) };
              const List<Item> values { hist->values.read_at(p) };
              std::size_t len { hist->len.read_at(p) };

              hist->times.write_at(List<double>(p->time, times), p);
              hist->values.write_at(List<Item>(init.value(), values), p);
              hist->len.write_at(1 + len, p);
              
              return Result<SharedPtr<ObservableHistory<Item>>>(std::move(hist));
            }))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();

        } else {
          return pure_composite(std::move(hist))
            .operator Composite<SharedPtr<ObservableHistory<Item>>>();
        }
      })
      .and_then([obs{std::move(obs)}, size, accum_fn{std::move(accum_fn)}](SharedPtr<ObservableHistory<Item>>&& hist) mutable {
        return into_composite(std::move(obs).subscribe(cons_observer([hist, size, accum_fn{std::move(accum_fn)}](const Item* item, const Point* p) {
            const List<double> times { hist->times.read_at(p) };
            const List<Item> values { hist->values.read_at(p) };
            std::size_t len { hist->len.read_at(p) };

            if (times.empty()) {
              hist->times.write_at(List<double>(p->time, times), p);
              hist->values.write_at(List<Item>(*item, values), p);
              hist->len.write_at(1 + len, p);

            } else {
              unsigned int index0 = p->run->specs->grid_index(times.head(), size);
              unsigned int index2 = p->run->specs->grid_index(p->time, size);

              if (index0 != index2 || times.head() <= p->run->specs->grid_time(index0 - 1, size)) {
                hist->times.write_at(List<double>(p->time, times), p);
                hist->values.write_at(List<Item>(*item, values), p);
                hist->len.write_at(1 + len, p);

              } else {
                List<double> times2 { List<double>(p->time, times.tail()) };
                List<Item> values2 { List<Item>(accum_fn(values.head(), *item), values.tail()) };

                hist->times.write_at(std::move(times2), p);
                hist->values.write_at(std::move(values2), p);
                hist->len.write_at(1 + len, p);
              }
            }
                
            return Result<Unit>(Unit());
          })))
          .and_then([](Disposable<>&& h) {
            return disposable_composite(std::move(h));
          })
          .and_then([hist{std::move(hist)}](Unit&& unit) mutable {
            return pure_composite(std::move(hist));
          });
      });
  }

  /** Add the item to the history of signal values. */
  template<typename Item>
  Event<Unit> push_to_observable_history(const SharedPtr<ObservableHistory<Item>>& hist, Item&& item) {
    using namespace DVCOMPUTE_NS::utils::im;

    return cons_event([hist, item{std::move(item)}](const Point* p) {
      const List<double> times { hist->times.read_at(p) };
      const List<Item> values { hist->values.read_at(p) };
      std::size_t len = hist->len.read_at(p);

      hist->times.write_at(List<double>(p->time, times), p);
      hist->values.write_at(List<Item>(item, values), p);
      hist->len.write_at(1 + len, p);

      return Result<Unit>(Unit());
    });
  }

  /** Read the history of the signal values. */
  template<typename Item>
  Event<ObservableHistoryData<Item>> read_observable_history(const SharedPtr<ObservableHistory<Item>>& hist) {
    using namespace DVCOMPUTE_NS::utils::im;

    return cons_event([hist](const Point* p) {
      const List<double> ts0 { hist->times.read_at(p) };
      const List<Item> xs0 { hist->values.read_at(p) };

      std::vector<double> ts;
      std::vector<Item> xs;

      for (auto t : ts0) {
        ts.push_back(t);
      }

      for (const auto &x : xs0) {
        xs.push_back(x);
      }

      std::reverse(ts.begin(), ts.end());
      std::reverse(xs.begin(), xs.end());

      ObservableHistoryData<Item> txs { std::move(ts), std::move(xs) };

      return Result<ObservableHistoryData<Item>>(std::move(txs));
    });
  }

  /** Reset the history of the signal values. */
  template<typename Item>
  Event<Unit> reset_observable_history(const SharedPtr<ObservableHistory<Item>>& hist) {
    using namespace DVCOMPUTE_NS::utils::im;

    return cons_event([hist](const Point* p) {
      List<double> ts;
      List<Item> xs;
      std::size_t len = 0;

      hist->times.write_at(std::move(ts), p);
      hist->values.write_at(std::move(xs), p);
      hist->len.write_at(std::size_t { len }, p);

      return Result<Unit>(Unit());
    });
  }

  /** Take the history of the signal values, after which the history becomes empty. */
  template<typename Item>
  Event<ObservableHistoryData<Item>> take_observable_history(const SharedPtr<ObservableHistory<Item>>& hist) {
    return read_observable_history(hist)
      .and_then([=](ObservableHistoryData<Item> &&txs) {
        return reset_observable_history(hist)
          .and_then([txs{std::move(txs)}](Unit) mutable {
            return pure_event(std::move(txs));
          });
      });
  }

#else
#error "Unknown simulation mode"
#endif  

  /** Create a new signal history of the limit size, which is synchronized with IO. */
  template<typename Item, typename Impl>
  Composite<Observable<ObservableHistoryData<Item>>> new_io_observable_history_with_limit_size(Observable<Item, Impl>&& obs,
    std::size_t limit_size,
    std::optional<Item>&& init = std::nullopt)
  {
    SharedPtr<ObservableSource<Item>> signal_src { mk_shared(ObservableSource<Item>()) };
    SharedPtr<ObservableSource<ObservableHistoryData<Item>>> txs_src { mk_shared(ObservableSource<ObservableHistoryData<Item>>()) };

    return new_observable_history(std::move(obs), std::move(init), std::make_optional(signal_src))
      .and_then([=](SharedPtr<ObservableHistory<Item>>&& hist) {
        return into_composite(signal_src->publish().subscribe(cons_observer([=](const Item*, const Point* p) {
          std::size_t size = hist->size_at(p);
          if (size > limit_size) {
            return enqueue_io_event(p->time, cons_event([=](const Point* p) {
              std::size_t size = hist->size_at(p);
              if (size > limit_size) {
                return take_observable_history(hist)
                  .and_then([=](ObservableHistoryData<Item>&& txs) {
                    return txs_src->trigger(std::move(txs));
                  })
                  .operator()(p);

              } else {
                return Result<Unit>(Unit());
              }

            }))
            .operator()(p);

          } else {
            return Result<Unit>(Unit());
          }
        })))
        .and_then([](Disposable<>&& h) {
          return disposable_composite(std::move(h));
        })
        .and_then([=](Unit) {
          SharedPtr<Ref<bool>> flag { mk_shared(Ref<bool>(true)) };

          return into_composite(cons_event([=](const Point* p) {
            return enqueue_io_event(p->run->specs->stop_time, cons_event([=](const Point* p) {
              if (flag->read_at(p) && (hist->size_at(p) > 0)) {
                return take_observable_history(hist)
                  .and_then([=](ObservableHistoryData<Item>&& txs) {
                    return txs_src->trigger(std::move(txs));
                  })
                  .operator()(p);

              } else {
                return Result<Unit>(Unit());
              }
            }))
            .operator()(p);
          }))
          .and_then([=](Unit) {
            return disposable_composite(cons_disposable([=](const Point* p) {
              flag->write_at(bool { false }, p);
              return Result<Unit>(Unit());
            }));
          });
        });
      })
      .map([=](Unit) {
        return txs_src->publish().into_boxed();
      });
  }
}

#endif /* dvcompute_observable_extra_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_slot_extra_h
#define dvcompute_block_slot_extra_h

#include "block_extra.h"
#include "block_slot.h"

namespace DVCOMPUTE_NS {

  namespace slot {

    namespace internal {

      /** To concatenate block slots within `Block<InOutput, InOutput>`. */
      template<typename InOutput, typename Impl>
      Process<InOutput> concat_block_slots(const SharedPtr<std::vector<BlockSlot<InOutput, InOutput, Impl>>>& slots, std::size_t index, InOutput&& item) {
        if (index >= slots->size()) {
          return pure_process(std::move(item));

        } else {
          return (*slots)[index]()
            .run(std::move(item))
            .and_then([slots, index](InOutput&& next_item) {
              return concat_block_slots(slots, 1 + index, std::move(next_item));
            });
        }
      }
    }

    /** The `BlockSlot<Input, Unit>` to terminate the computations. */
    template<typename Input>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<Input, Unit> auto terminate_block_slot() {
#else
    inline auto terminate_block_slot() {
#endif      
      auto fn = []() {
        return terminate_block<Input>();
      };
      return BlockSlot<Input, Unit, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Input, Output>` to transfer the computations to the specified slot. */
    template<typename Input, typename Output, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<Input, Output> auto transfer_block_slot(const BlockSlot<Input, Unit, Impl>& block_slot) {
#else
    inline auto transfer_block_slot(const BlockSlot<Input, Unit, Impl>& block_slot) {
#endif
      auto fn = [=]() {
        return transfer_block<Input, Output>(block_slot());
      };
      return BlockSlot<Input, Output, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Input, Output>` by the specified function that takes `Input&&` and returns `Output`. */
    template<typename ArrFn, typename StdFn = decltype(std::function(std::forward<ArrFn>(std::declval<ArrFn>())))>
#ifdef DVCOMPUTE_CONCEPTS
    inline auto arr_block_slot(ArrFn &&arr_fn) requires BlockArrFn<StdFn> {
#else
    inline auto arr_block_slot(ArrFn &&arr_fn) {
#endif
      auto fn = [arr_fn{std::move(arr_fn)}]() {
        return arr_block(ArrFn { arr_fn });
      };

      using Traits = function_traits<StdFn>;
      using FirstArg = typename Traits::template arg<0>::type;
      using Input = typename std::remove_reference_t<FirstArg>;
      using Output = std::invoke_result_t<ArrFn, Input&&>;

      return BlockSlot<Input, Output, decltype(fn)>(std::move(fn));
    }

    /** The identity `BlockSlot<InOutput, InOutput>` that does not change the input. */
    template<typename InOutput>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<InOutput, InOutput> auto identity_block_slot() {
#else
    inline auto identity_block_slot() {
#endif
      auto fn = []() {
        return DVCOMPUTE_NS::block::identity_block<InOutput>();
      };
      return BlockSlot<InOutput, InOutput, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<InOutput, InOutput>` to simulate some activity by the specified time interval. */
    template<typename InOutput>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<InOutput, InOutput> auto advance_block_slot(double dt) {
#else
    inline auto advance_block_slot(double dt) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::advance_block<InOutput>(hold_process(dt));
      };
      return BlockSlot<InOutput, InOutput, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to enqueue. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto queue_block_slot(const DVCOMPUTE_NS::block::QueuePtr& queue, int increment = 1) {
#else
    inline auto queue_block_slot(const DVCOMPUTE_NS::block::QueuePtr& queue, int increment = 1) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::queue_block<Item>(queue, increment);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to depart from the queue. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto depart_block_slot(const DVCOMPUTE_NS::block::QueuePtr& queue, int decrement = 1) {
#else
    inline auto depart_block_slot(const DVCOMPUTE_NS::block::QueuePtr& queue, int decrement = 1) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::depart_block<Item>(queue, decrement);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to seize the facility. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto seize_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility) {
#else
    inline auto seize_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::seize_block<Item>(facility);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to preempt the facility. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto preempt_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility, const DVCOMPUTE_NS::block::PreemptBlockMode<Item>& mode) {
#else
    inline auto preempt_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility, const DVCOMPUTE_NS::block::PreemptBlockMode<Item>& mode) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::preempt_block<Item>(facility, DVCOMPUTE_NS::block::PreemptBlockMode<Item> { mode });
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to return the facility. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto return_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility) {
#else
    inline auto return_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::return_block<Item>(facility);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to release the facility within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto release_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility) {
#else
    inline auto release_block_slot(const DVCOMPUTE_NS::block::FacilityPtr<Item>& facility) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::release_block<Item>(facility);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to enter the storage. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto enter_block_slot(const DVCOMPUTE_NS::block::StoragePtr<Item>& storage, int decrement = 1) {
#else
    inline auto enter_block_slot(const DVCOMPUTE_NS::block::StoragePtr<Item>& storage, int decrement = 1) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::enter_block<Item>(storage, decrement);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to leave the storage. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto leave_block_slot(const DVCOMPUTE_NS::block::StoragePtr<Item>& storage, int increment = 1) {
#else
    inline auto leave_block_slot(const DVCOMPUTE_NS::block::StoragePtr<Item>& storage, int increment = 1) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::leave_block<Item>(storage, increment);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to assign a new value to the transact. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto assign_block_slot(const Item& item) {
#else
    inline auto assign_block_slot(const Item& item) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::assign_block<Item>(Item { item });
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** 
     * The `BlockSlot<Transact<Item>, Transact<Item>>` to apply some action for the transact value,
     * where `Fn` is a function that takes a `const Item&` and then returns `void`. 
     */
    template<typename Item, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto foreach_block_slot(const Fn& fn) {
#else
    inline auto foreach_block_slot(const Fn& fn) {
#endif
      auto slot_fn = [=]() {
        return DVCOMPUTE_NS::block::foreach_block<Item, Fn>(Fn { fn });
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(slot_fn)>(std::move(slot_fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to assign a new priority to the transacts. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto priority_block_slot(int priority) {
#else
    inline auto priority_block_slot(int priority) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::priority_block<Item>(priority);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** 
     * The `BlockSlot<Transact<Item>, Transact<Item>>` to split the transacts
     * by redirecting a new transact to the specified block slot after split.
     */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto split_block_slot(const BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, Impl>& block_slot) {
#else
    inline auto split_block_slot(const BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, Impl>& block_slot) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::split_block<Item>(block_slot());
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** 
     * The `BlockSlot<Transact<Item>, Transact<Item>>` to spawn the transacts
     * by redirecting a new transact to the specified block slot after spawning with the specified cancellation mode.
     */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto spawn_block_slot_with(ProcessCancellation cancellation, const BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, Impl>& block_slot) {
#else
    inline auto spawn_block_slot_with(ProcessCancellation cancellation, const BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, Impl>& block_slot) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::spawn_block_with<Item>(cancellation, block_slot());
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** 
     * The `BlockSlot<Transact<Item>, Transact<Item>>` to spawn the transacts
     * by redirecting a new transact to the specified block slot after spawning with the mode when 
     * the related transacts are cancelled together in case of cancelling any of them.
     */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto spawn_block_slot(const BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, Impl>& block_slot) {
#else
    inline auto spawn_block_slot(const BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, Impl>& block_slot) {
#endif
      return spawn_block_slot_with(ProcessCancellation::CancelTogether, block_slot);
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to assemble the transacts. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto assemble_block_slot(int count) {
#else
    inline auto assemble_block_slot(int count) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::assemble_block<Item>(count);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** The `BlockSlot<Transact<Item>, Transact<Item>>` to gather the transacts. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>> auto gather_block_slot(int count) {
#else
    inline auto gather_block_slot(int count) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::gather_block<Item>(count);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, DVCOMPUTE_NS::block::Transact<Item>, decltype(fn)>(std::move(fn));
    }

    /** To concatenate block slots as `BlockSlot<InOutput, InOutput>`. */
    template<typename InOutput, typename Impl>
    inline BlockSlot<InOutput, InOutput> concat_block_slots(const SharedPtr<std::vector<BlockSlot<InOutput, InOutput, Impl>>>& slots) {
      return BlockSlot<InOutput, InOutput>([slots]() {
        return cons_block([slots](InOutput &&input) {
          return DVCOMPUTE_NS::slot::internal::concat_block_slots(slots, 0, std::move(input));
        });
      });
    }

    /** To concatenate block slots as `BlockSlot<InOutput, InOutput>`. */
    template<typename InOutput, typename Impl>
    inline BlockSlot<InOutput, InOutput> concat_block_slots(std::vector<BlockSlot<InOutput, InOutput, Impl>>&& slots) {
      return concat_block_slots<InOutput>(mk_shared<std::vector<BlockSlot<InOutput, InOutput, Impl>>>(std::vector<BlockSlot<InOutput, InOutput, Impl>>(std::move(slots))));
    }

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** A `BlockSlot<Transact<Item>, Unit>` to send input items as messages to the specified logical process with the given time delay. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    BlockSlotLike<DVCOMPUTE_NS::block::Transact<Item>, Unit> auto send_message_block_slot(LogicalProcessId pid, double dt) {
#else
    auto send_message_block_slot(LogicalProcessId pid, double dt) {
#endif
      auto fn = [=]() {
        return DVCOMPUTE_NS::block::send_message_block<Item>(pid, dt);
      };
      return BlockSlot<DVCOMPUTE_NS::block::Transact<Item>, Unit, decltype(fn)>(std::move(fn));
    }

#endif /* DVCOMPUTE_DISTRIBUTED || DVCOMPUTE_CONSERVATIVE */

  }
}

#endif /* dvcompute_block_slot_extra_h */

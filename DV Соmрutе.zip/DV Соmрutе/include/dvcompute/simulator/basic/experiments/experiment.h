/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_experiment_h
#define dvcompute_experiments_experiment_h

#include <vector>
#include <functional>
#include <memory>
#include <string>
#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"
#include "dvcompute/simulator/basic/result.h"
#include "dvcompute/simulator/basic/observable_extra.h"
#include "dvcompute/simulator/basic/specs.h"
#include "dvcompute/simulator/basic/simulation.h"
#include "dvcompute/simulator/basic/event.h"
#include "dvcompute/simulator/basic/composite.h"
#include "dvcompute/simulator/basic/disposable.h"
#include "dvcompute/simulator/basic/results/result_set.h"
#include "dvcompute/simulator/basic/results/result_source.h"
#include "dvcompute/simulator/basic/results/result_locale.h"

#if defined(DVCOMPUTE_DISTRIBUTED)
#include "dvcompute/simulator/dist/lp_context.h"
#include "dvcompute/simulator/dist/time_server.h"
#include "dvcompute/simulator/net/network_support.h"
#elif defined(DVCOMPUTE_CONSERVATIVE)
#include "dvcompute/simulator/cons/lp_context.h"
#endif

namespace DVCOMPUTE_NS {

  namespace experiments {

    /** It defines the simulation experiment. */
    struct Experiment;

    /** It describes the source simulation data used in the experiment. */
    struct ExperimentData {

      /** The simulation results used in the experiment. */
      DVCOMPUTE_NS::results::ResultSet results;

      /** The predefined signals provided by every model. */
      PredefinedObservableSet predefined_observables;
    };

    /** It executes the simulation experiment. */
    class ExperimentExecutor {
    public:

      virtual ~ExperimentExecutor() {}

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)
      
      /** Execute the simulation models. */
      virtual Result<Unit> execute(std::vector<std::function<Result<Unit>()>>&& models) = 0;

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

      /** Execute the simulation models. */
      virtual Result<Unit> execute(std::vector<std::function<Result<Unit>(LogicalProcessContext* ctx)>>&& models) = 0;

#else
#error "Unknown simulation mode"
#endif  
    };

    /** Defines what creates the simulation reports by the specified renderer. */
    template<typename Context>
    class ExperimentReporter {
    public:

      virtual ~ExperimentReporter() {}

      /** Initialise the reporting before the simulation runs are started. */
      virtual Result<Unit> initialise() = 0;

      /** Finalise the reporting after all simulation runs are finished. */
      virtual Result<Unit> finalise() = 0;

      /** Launch the simulation run in the start time. */
      virtual Composite<Unit> simulate(const ExperimentData& xs) = 0;

      /** The context used by the renderer. */
      virtual Context context() = 0;
    };

    /** This is a generator of the reporter with the specified rendering backend. */
    template<typename Rendering>
    class ExperimentGenerator {
    public:

      virtual ~ExperimentGenerator() {}

      /** Create the result reporter. */
      virtual std::shared_ptr<ExperimentReporter<typename Rendering::context_type>> report(Rendering& rendering,
        const Experiment& experiment, 
        const typename Rendering::environment_type& env) && = 0;
    };

    /** 
     * Defines a view in which the simulation results should be saved.
     * You should extend this class to define your own views such as
     * the PDF document, for example.
     */
    template<typename Rendering>
    class ExperimentView {
    public:

      virtual ~ExperimentView() {}

      /** Get the view of the corresponding results. */
      virtual std::shared_ptr<ExperimentGenerator<Rendering>> view() && = 0;
    };

    /** It allows rendering the simulation results in an arbitrary way. */
    template<typename Context, typename Environment>
    class ExperimentRendering {
    public:
    
      /** Defines a context used when rendering the experiment. */
      using context_type = Context;

      /** Defines the experiment environment. */
      using environment_type = Environment;

      virtual ~ExperimentRendering() {}

      /** Prepare before rendering the experiment. */
      virtual Result<environment_type> prepare(const Experiment& experiment) = 0;

      /** 
       * Render the experiment after the simulation is finished, for example,
       * create the `index.html` file in the specified directory.
       */
      virtual Result<Unit> render(const Experiment& experiment,
        const std::vector<std::shared_ptr<ExperimentReporter<context_type>>>& reporters,
        const environment_type& env) = 0;

      /** It is called when the experiment has been completed. */
      virtual Result<Unit> on_completed(const Experiment& experiment,
        const environment_type& env) = 0;

      /** It is called when the experiment has been failed. */
      virtual Result<Unit> on_failed(const Experiment& experiment,
        const environment_type& env,
        const Result<Unit>& error) = 0;
    };

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** The continuation of simulation experiment. */
    using ExperimentCont = std::function<Result<Unit>(LogicalProcessContext*, Simulation<results::ResultSet>&&)>;

#endif

    /** It defines the simulation experiment. */
    struct Experiment {

      /** The simulation specs for the experiment. */
      Specs specs { 0.0, 1.0, 0.1, GeneratorSpec() };

      /** How the results must be transformed before rendering. */
      std::shared_ptr<std::function<results::ResultTransform()>> transform;

      /** Specifies a locale. */
      results::ResultLocale locale { results::ResultLocale::en };

      /** How many simulation runs should be launched. */
      int run_count { 1 };

      /** The experiment title. */
      std::string title { "Simulation Experiment" };

      /** The experiment description. */
      std::optional<std::string> description;

      /** Whether the process of generating the results is verbose. */
      bool verbose { true };

      /** The number of threads used when running the simulation experiment (can be ignored). */
      std::optional<unsigned int> num_threads;

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)

      /** Run the simulation experiment. */
      template<typename Rendering, typename Executor>
      Result<Unit> run(std::vector<std::shared_ptr<ExperimentGenerator<Rendering>>>&& generators,
        Rendering&& rendering,
        std::function<Simulation<results::ResultSet>()>&& simulation,
        Executor&& executor) const
      {
        auto launcher = [specs{this->specs}](Simulation<Unit>&& comp, int run_index, int run_count) {
          return std::move(comp).run_by_index(&specs, run_index, run_count);
        };

        return run_with_executor_and_launcher(std::move(generators),
          std::move(rendering), std::move(simulation), std::move(executor), std::move(launcher), false);
      }

      /** Run the simulation experiment with the specified executor and launcher. */
      template<typename Rendering, typename Executor>
      Result<Unit> run_with_executor_and_launcher(std::vector<std::shared_ptr<ExperimentGenerator<Rendering>>>&& generators,
        Rendering&& rendering,
        std::function<Simulation<results::ResultSet>()>&& simulation,
        Executor&& executor,
        std::function<Result<Unit>(Simulation<Unit>&&, int, int)>&& launcher,
        bool start_only) const
      {
        Result<typename Rendering::environment_type> res { rendering.prepare(*this) };
        if (typename Rendering::environment_type* env = get_result_if(&res)) {
          std::shared_ptr<std::vector<std::shared_ptr<ExperimentReporter<typename Rendering::context_type>>>> reporters {
            new std::vector<std::shared_ptr<ExperimentReporter<typename Rendering::context_type>>>()
          };
          for (auto& generator : generators) {
            reporters->emplace_back(std::move(*generator).report(rendering, *this, *env));
          }
          for (auto& reporter : *reporters) {
            TRY_RESULT(reporter->initialise());
          }

          std::vector<std::function<Result<Unit>()>> simulate;

          for (int run_index = 0; run_index < run_count; ++run_index) {
            auto f = [simulation, launcher, reporters, run_index, run_count{this->run_count}, stop_time{this->specs.stop_time}, start_only]() mutable {
              auto comp {
                new_predefined_observable_set()
                  .run_in_start_time()
                  .and_then([simulation{std::move(simulation)}, reporters{std::move(reporters)}, stop_time, start_only](PredefinedObservableSet&& predefined_observables) mutable {
                    return simulation()
                      .and_then([reporters{std::move(reporters)}, predefined_observables{std::move(predefined_observables)}, stop_time, start_only](results::ResultSet&& results) mutable {
                        ExperimentData d {
                          std::move(results), std::move(predefined_observables)
                        };

                        std::vector<Composite<Unit>> comps;
                        for (auto& reporter : *reporters) {
                          comps.emplace_back(reporter->simulate(d));
                        }

                        return composite_sequence_(std::move(comps))
                          .run(empty_disposable())
                          .run_in_start_time(false)
                          .and_then([stop_time, start_only](std::tuple<Unit, Disposable<>>&& pair) {
                            auto fs { std::move(std::get<1>(pair)) };
                            if (start_only) {
                              return enqueue_event(stop_time, into_event(std::move(fs)))
                                .run_in_start_time()
                                .into_boxed();

                            } else {
                              return finally_simulation(pure_event(Unit()).run_in_stop_time(),
                                  into_event(std::move(fs)).run_in_stop_time())
                                .into_boxed();
                            }
                          });
                      });
                  })
              };

              return launcher(std::move(comp), run_index, run_count);
            };

            simulate.emplace_back(std::move(f));
          }

          Result<Unit> res { executor.execute(std::move(simulate)) };

          for (auto& reporter : *reporters) {
            TRY_RESULT(reporter->finalise());
          }

          if (get_result_if(&res)) {
            TRY_RESULT(rendering.render(*this, *reporters, *env));
            TRY_RESULT(rendering.on_completed(*this, *env));

          } else {
            TRY_RESULT(rendering.on_failed(*this, *env, res));
          }

          return res;

        } else {
          return error_result<Unit>(std::move(res));
        }
      }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

      /** Run the simulation experiment. */
      template<typename Rendering, typename Executor>
      Result<Unit> run(std::vector<std::shared_ptr<ExperimentGenerator<Rendering>>>&& generators,
        Rendering&& rendering,
        std::function<Result<Unit>(LogicalProcessContext*, ExperimentCont&&)>&& simulation,
        Executor&& executor) const
      {
        auto launcher = [specs{this->specs}](LogicalProcessContext* ctx, Simulation<Unit>&& comp, int run_index, int run_count) {
          return std::move(comp).run_by_index(&specs, ctx, run_index, run_count);
        };

        return run_with_executor_and_launcher(std::move(generators),
          std::move(rendering), std::move(simulation), std::move(executor), std::move(launcher), false);
      }

      /** Run the simulation experiment with the specified executor and launcher. */
      template<typename Rendering, typename Executor>
      Result<Unit> run_with_executor_and_launcher(std::vector<std::shared_ptr<ExperimentGenerator<Rendering>>>&& generators,
        Rendering&& rendering,
        std::function<Result<Unit>(LogicalProcessContext*, ExperimentCont&&)>&& simulation,
        Executor&& executor,
        std::function<Result<Unit>(LogicalProcessContext*, Simulation<Unit>&&, int, int)>&& launcher,
        bool start_only) const
      {
        Result<typename Rendering::environment_type> res { rendering.prepare(*this) };
        if (typename Rendering::environment_type* env = get_result_if(&res)) {
          std::shared_ptr<std::vector<std::shared_ptr<ExperimentReporter<typename Rendering::context_type>>>> reporters {
            new std::vector<std::shared_ptr<ExperimentReporter<typename Rendering::context_type>>>()
          };
          for (auto& generator : generators) {
            reporters->emplace_back(std::move(*generator).report(rendering, *this, *env));
          }
          for (auto& reporter : *reporters) {
            TRY_RESULT(reporter->initialise());
          }

          std::vector<std::function<Result<Unit>(LogicalProcessContext*)>> simulate;

          for (int run_index = 0; run_index < run_count; ++run_index) {
            auto f = [simulation, launcher, reporters, run_index, run_count{this->run_count}, stop_time{this->specs.stop_time}, start_only](LogicalProcessContext* ctx) mutable {
              return simulation(ctx, [launcher{std::move(launcher)}, reporters{std::move(reporters)}, run_index, run_count, stop_time, start_only](LogicalProcessContext* ctx, Simulation<results::ResultSet>&& results) mutable {
                auto comp {
                  std::move(results)
                    .and_then([reporters{std::move(reporters)}, stop_time, start_only](results::ResultSet&& results) mutable {
                      return new_predefined_observable_set()
                        .run_in_start_time()
                        .and_then([reporters{std::move(reporters)}, results{std::move(results)}, stop_time, start_only](PredefinedObservableSet&& predefined_observables) mutable {
                          ExperimentData d {
                            std::move(results), std::move(predefined_observables)
                          };

                          std::vector<Composite<Unit>> comps;
                          for (auto& reporter : *reporters) {
                            comps.emplace_back(reporter->simulate(d));
                          }

                          return composite_sequence_(std::move(comps))
                            .run(empty_disposable())
                            .run_in_start_time(false)
                            .and_then([stop_time, start_only](std::tuple<Unit, Disposable<>>&& pair) {
                              auto fs { std::move(std::get<1>(pair)) };
                              if (start_only) {
                                return enqueue_event(stop_time, into_event(std::move(fs)))
                                  .run_in_start_time()
                                  .into_boxed();

                              } else {
                                return finally_simulation(pure_event(Unit()).run_in_stop_time(),
                                    into_event(std::move(fs)).run_in_stop_time())
                                  .into_boxed();
                              }
                            });
                        });
                    })

                };

                return launcher(ctx, std::move(comp), run_index, run_count);
              });
            };

            simulate.emplace_back(std::move(f));
          }

          Result<Unit> res { executor.execute(std::move(simulate)) };

          for (auto& reporter : *reporters) {
            TRY_RESULT(reporter->finalise());
          }

          if (get_result_if(&res)) {
            TRY_RESULT(rendering.render(*this, *reporters, *env));
            TRY_RESULT(rendering.on_completed(*this, *env));

          } else {
            TRY_RESULT(rendering.on_failed(*this, *env, res));
          }

          return res;

        } else {
          return error_result<Unit>(std::move(res));
        }
      }

#if defined(DVCOMPUTE_DISTRIBUTED)

    /** Run the time server. */
    static void run_time_server(const std::function<std::unique_ptr<NetworkSupport>(int)>& network_fn, 
      int run_count, 
      const TimeServerParameters& ps) 
    {
      for (int run_index = 0; run_index < run_count; ++run_index) {
        std::unique_ptr<NetworkSupport> network { network_fn(run_index) };
        std::size_t init_quorum = static_cast<std::size_t>(network->size() - 1);

        LogicalProcessCommunicator comm(std::move(network));
        DVCOMPUTE_NS::run_time_server(comm, init_quorum, ps);

        comm.network_support->barrier();
      }
    }

#endif /* DVCOMPUTE_DISTRIBUTED */

#else
#error "Unknown simulation mode"
#endif  
    };
  }
}

#endif /* dvcompute_experiments_experiment_h */

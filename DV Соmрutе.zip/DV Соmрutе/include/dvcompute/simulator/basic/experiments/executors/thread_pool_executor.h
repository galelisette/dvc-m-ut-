/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_executors_thread_pool_h
#define dvcompute_experiments_executors_thread_pool_h

#include <vector>
#include <functional>
#include <thread>
#include <mutex>
#include <memory>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/log_support.h"
#include "dvcompute/simulator/basic/result.h"
#include "dvcompute/simulator/basic/experiments/experiment.h"

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)
      
namespace DVCOMPUTE_NS {

  namespace experiments {

    /** It executes the simulation experiment by using a thread pool. */
    class ThreadPoolExecutor : public ExperimentExecutor {
      
      /** The thread pool size. */
      std::size_t len;

    public:

      explicit ThreadPoolExecutor(const std::size_t size_arg = 0) {
        if (size_arg <= 0) {
          int x = std::thread::hardware_concurrency();
          if (x <= 0) {
            len = 1;

          } else {
            len = x;
          }

        } else {
          len = size_arg;
        }
      }

      virtual ~ThreadPoolExecutor() {}

      /** Return the thread pool size. */
      std::size_t size() const noexcept {
        return len;
      }

      Result<Unit> execute(std::vector<std::function<Result<Unit>()>>&& models) override {
        std::shared_ptr<ThreadPool> pool(new ThreadPool);

        for (auto& model : models) {
          pool->add_task(std::move(model));
        }

        std::vector<std::thread> threads;

        for (std::size_t i = 0; i < len; ++i) {
          threads.emplace_back(std::thread([pool]() { pool->run_thread(); }));
        }

        for (auto& thread : threads) {
          thread.join();
        }

        return Result<Unit>(Unit());
      }

    private:

      class ThreadPool {

        std::deque<std::function<Result<Unit>()>> deque;
        std::mutex deque_mutex;

      public:

        ThreadPool() {}

        /** Add the task. */
        void add_task(std::function<Result<Unit>()>&& task) {
          const std::lock_guard<std::mutex> lock(deque_mutex);
          deque.emplace_back(std::move(task));
        }

        /** Run the thread. */
        void run_thread() {
          while (true) {
            {
              auto task { next_task() };
              if (task.has_value()) {
                auto res { task.value()() };
                if (!get_result_if(&res)) {
                  DVCOMPUTELOG_NS::error("The task was terminated with error.");
                }

              } else {
                break;
              }
            }
            free_thread_local_objects();
          }
        }

      private:

        /** Get the next task. */
        std::optional<std::function<Result<Unit>()>> next_task() {
          const std::lock_guard<std::mutex> lock(deque_mutex);
          if (deque.empty()) {
            return std::nullopt;

          } else {
            auto task { std::move(deque.front()) };
            deque.pop_front();
            return task;
          }
        }
      };
    };
  }
}

#endif
#endif /* dvcompute_experiments_executors_thread_pool_h */

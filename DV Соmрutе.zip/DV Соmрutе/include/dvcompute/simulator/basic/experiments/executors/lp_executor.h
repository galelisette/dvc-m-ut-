/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_executors_lp_h
#define dvcompute_experiments_executors_lp_h

#include <vector>
#include <functional>
#include <memory>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/log_support.h"
#include "dvcompute/simulator/basic/experiments/experiment.h"
#include "dvcompute/simulator/net/network_support.h"

namespace DVCOMPUTE_NS {

  namespace experiments {

#if defined(DVCOMPUTE_DISTRIBUTED)
      
    /** It executes the simulation experiment by the logical process. */
    class LogicalProcessExecutor : public ExperimentExecutor {

      std::function<std::unique_ptr<NetworkSupport>(int)> network_fn;
      LogicalProcessId time_server_id;
      LogicalProcessParameters ps;

    public:

      LogicalProcessExecutor(const std::function<std::unique_ptr<NetworkSupport>(int)>& network_fn_arg,
        LogicalProcessId time_server_id_arg,
        const LogicalProcessParameters& ps_arg) :
          network_fn(network_fn_arg),
          time_server_id(time_server_id_arg),
          ps(ps_arg)
        {}

      virtual ~LogicalProcessExecutor() {}

      Result<Unit> execute(std::vector<std::function<Result<Unit>(LogicalProcessContext* ctx)>>&& models) override {
        for (std::size_t i = 0; i < models.size(); ++i) {
          auto network = network_fn(static_cast<int>(i));
          auto fn = [model{std::move(models[i])}](LogicalProcessContext* ctx) {
            {
              Result<Unit> res { model(ctx) };
              if (!get_result_if(&res)) {
                DVCOMPUTELOG_NS::error("The simulation was not terminated successfully.");
              }
            }
            free_thread_local_objects();
          };

          LogicalProcessCommunicator comm(std::move(network));
          run_logical_process(comm, time_server_id, ps, std::move(fn));

          comm.network_support->barrier();
        }

        return Result<Unit>(Unit());
      }
    };

#elif defined(DVCOMPUTE_CONSERVATIVE)

    /** It executes the simulation experiment by the logical process. */
    class LogicalProcessExecutor : public ExperimentExecutor {

      std::function<std::unique_ptr<NetworkSupport>(int)> network_fn;
      std::vector<LogicalProcessId> pids;
      LogicalProcessParameters ps;

    public:

      LogicalProcessExecutor(const std::function<std::unique_ptr<NetworkSupport>(int)>& network_fn_arg,
        const std::vector<LogicalProcessId> pid_args,
        const LogicalProcessParameters& ps_arg) :
          network_fn(network_fn_arg),
          pids(pid_args),
          ps(ps_arg)
        {}

      virtual ~LogicalProcessExecutor() {}

      Result<Unit> execute(std::vector<std::function<Result<Unit>(LogicalProcessContext* ctx)>>&& models) override {
        for (std::size_t i = 0; i < models.size(); ++i) {
          auto network = network_fn(static_cast<int>(i));
          auto fn = [model{std::move(models[i])}](LogicalProcessContext* ctx) {
            {
              Result<Unit> res { model(ctx) };
              if (!get_result_if(&res)) {
                DVCOMPUTELOG_NS::error("The simulation was not terminated successfully.");
              }
            }
            free_thread_local_objects();
          };

          LogicalProcessCommunicator comm(std::move(network));
          run_logical_process(comm, pids, ps, std::move(fn));

          comm.network_support->barrier();
        }

        return Result<Unit>(Unit());
      }
    };

#endif
  }
}

#endif /* dvcompute_experiments_executors_lp_h */

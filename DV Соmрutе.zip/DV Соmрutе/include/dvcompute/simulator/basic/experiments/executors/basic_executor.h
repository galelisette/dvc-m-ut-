/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_executors_basic_h
#define dvcompute_experiments_executors_basic_h

#include <vector>
#include <functional>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/experiments/experiment.h"

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)
      
namespace DVCOMPUTE_NS {

  namespace experiments {

    /** It executes the simulation experiment in non-distributed cases. */
    class BasicExecutor : public ExperimentExecutor {
    public:

      virtual ~BasicExecutor() {}

      Result<Unit> execute(std::vector<std::function<Result<Unit>()>>&& models) override {
        for (auto& model : models) {
          {
            TRY_RESULT(std::move(model)());
          }
          free_thread_local_objects();
        }

        return Result<Unit>(Unit());
      }
    };
  }
}

#endif
#endif /* dvcompute_experiments_executors_basic_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_rendering_deviation_chart_h
#define dvcompute_experiments_rendering_deviation_chart_h

#include <cstdlib>
#include <memory>
#include <mutex>
#include <map>
#include <vector>
#include <utility>
#include <string>
#include <cstring>
#include <fstream>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/observable_extra.h"
#include "dvcompute/simulator/basic/composite.h"
#include "dvcompute/simulator/basic/stats/sampling_stats.h"
#include "dvcompute/simulator/basic/results/result_set.h"
#include "dvcompute/simulator/basic/experiments/experiment.h"
#include "dvcompute/simulator/basic/experiments/rendering/web_page.h"
#include "dvcompute/simulator/basic/experiments/rendering/default_colors.h"
#include "dvcompute/simulator/utils/html.h"

namespace DVCOMPUTE_NS {

  namespace experiments {

    namespace rendering {

      /** Defines the experiment view that plots the Deviation Chart for simulation variables. */
      class DeviationChart : 
        public ExperimentView<WebPageRendering>,
        public ExperimentGenerator<WebPageRendering>
      {
      public:

        /** The title. */
        std::string title { "Deviation Chart" };

        /** The description. */
        std::optional<std::string> description { 
          "It shows the Deviation Chart." 
        };

        /** The size of the grid, where the series data are collected. */
        unsigned int grid_size { 2 * 640 + 1};

        /** The transform applied to the results before receiving the series. */
        std::function<results::ResultTransform()> transform {
          []() { return results::ResultTransform(); }
        };

        /** It defines the series for which the last values are to be displayed. */
        std::function<results::ResultTransform()> series {
          []() { return results::ResultTransform(); }
        };

        /**
         * The plot title that may include special variable `$TITLE`.
         *
         * An example is `$TITLE`.
         */
        std::optional<std::string> plot_title { "$TITLE" };

        /** The optional label for axis X. */
        std::optional<std::string> xlabel { "t" };

        /** The optional label for axis Y. */
        std::optional<std::string> ylabel { std::nullopt };

        /** When we know exactly that y values are non-negative. */
        bool y_non_negative { false };

        /** The gnuplot command to execute. */
        std::string gnuplot { "gnuplot" };

        std::shared_ptr<ExperimentReporter<WebPageRendering::context_type>> report(WebPageRendering& rendering,
          const Experiment& experiment, 
          const WebPageRendering::environment_type& env) && override;

        std::shared_ptr<ExperimentGenerator<WebPageRendering>> view() && override;
      };

      namespace {

        /** The chart results. */
        struct DeviationChartResults {

          /** The chart names. */
          std::vector<std::string> names;

          /** The time values. */
          std::vector<double> times;

          /** The chart statistics. */
          std::vector<std::vector<SamplingStats<double>>> stats;
        };

        /** The state of the view. */
        class DeviationChartState : 
          public ExperimentReporter<WebPageRendering::context_type>,
          public WebPageWriter
        {
          /** The mutex. */
          std::shared_ptr<std::mutex> mutex;

          /** The view. */
          std::shared_ptr<DeviationChart> view;

          /** The experiment. */
          std::shared_ptr<Experiment> experiment;

          /** The file directory. */
          std::shared_ptr<FilePath> dir;

          /** The file name. */
          std::shared_ptr<std::optional<FilePath>> file_name;

          /** The chart results. */
          std::shared_ptr<DeviationChartResults> results;

        public:

          DeviationChartState(const DeviationChart& view_arg, const Experiment& experiment_arg, const FilePath& dir_arg) :
            mutex(new std::mutex()),
            view(new DeviationChart(view_arg)),
            experiment(new Experiment(experiment_arg)),
            dir(new FilePath(dir_arg)),
            file_name(new std::optional<FilePath>(std::nullopt)),
            results(new DeviationChartResults())
          {}

          DeviationChartState(const DeviationChartState&) = default;
          DeviationChartState& operator=(const DeviationChartState&) = default;

          void write_toc_html(std::ostream& out, std::size_t index) override {
            using namespace DVCOMPUTE_NS::utils::html;

            std::lock_guard<std::mutex> lock(*mutex);
            std::string id = "#id" + std::to_string(index);
            begin_html_list_item(out);
            write_html_link(out, id.c_str(), view->title.c_str());
            end_html_list_item(out);
          }

          void write_html(std::ostream& out, std::size_t index) override {
            using namespace DVCOMPUTE_NS::utils::html;
            using namespace DVCOMPUTE_NS::utils::path;

            write_html_header(out, index);

            std::lock_guard<std::mutex> lock(*mutex);
            if (file_name->has_value()) {
              begin_html_paragraph(out);
              write_html_image(out, path_to_string(append_path(path_file_name(file_name->value()), "figure.svg")).c_str());
              end_html_paragraph(out);
            }
          }

          /** Write the HTML header. */
          void write_html_header(std::ostream& out, std::size_t index) {
            using namespace DVCOMPUTE_NS::utils::html;

            std::lock_guard<std::mutex> lock(*mutex);
            std::string id = "id" + std::to_string(index);
            write_html_header3_by_id(out, id.c_str(), view->title.c_str());
            if (view->description.has_value()) {
              begin_html_paragraph(out);
              write_html_text(out, view->description.value().c_str());
              end_html_paragraph(out);
            }
          }

          Result<Unit> initialise() override {
            return Result<Unit>(Unit());
          }

          Result<Unit> finalise() override {
            using namespace DVCOMPUTE_NS::utils::path;

            setup_file_name();
            save_data();
            save_command_file();
            exec_command_file();

            return Result<Unit>(Unit());
          }

          Composite<Unit> simulate(const ExperimentData& xs) override {
            using namespace DVCOMPUTE_NS::results;

            results::ResultLocale loc;
            std::vector<results::ResultValue<SamplingStats<double>>> exts;
            unsigned int grid_size;
            {
              std::lock_guard<std::mutex> lock(*mutex);
              loc = experiment->locale;
              grid_size = view->grid_size;

              Result<results::ResultSet> res {
                (view->transform)()
                  .and_then((view->series)())
                  .operator()(xs.results)
              };

              if (results::ResultSet *rs = get_result_if(&res)) {
                exts = rs->double_stats_values();
                std::vector<std::string> names;
  
                for (const auto& ext: exts) {
                  names.emplace_back(result_qualified_name(ext.id_path, loc));
                }
  
                if (!(results->names.empty())) {
                  if (results->names != names) {
                    throw PanicResult("DeviationChart: series with different names are returned for different runs.");
                  }

                } else {
                  results->names = std::move(names);

                  for (unsigned int index = 0; index < grid_size; ++ index) {
                    results->times.push_back(experiment->specs.grid_time(index, grid_size));
                  }

                  for (std::size_t i = 0; i < results->names.size(); ++i) {
                    std::vector<SamplingStats<double>> stats;
                    for (unsigned int index = 0; index < grid_size; ++ index) {
                      stats.emplace_back(SamplingStats<double>());
                    }
                    results->stats.emplace_back(std::move(stats));
                  }
                }
  
              } else {
                return into_composite(cons_event([res{std::move(res)}](const Point* p) mutable {
                  return error_result<Unit>(std::move(res));
                }));
              }
            }

            std::vector<Composite<SharedPtr<ObservableHistory<SamplingStats<double>>>>> hist_comps;
            for (const auto& ext : exts) {
              Composite<Observable<SamplingStats<double>>> obs_comp {
                into_composite(new_observable_in_time_grid(grid_size))
                  .map([](Observable<double>&& obs) {
                    return std::move(obs)
                      .map([](const double* x) { return Unit(); })
                      .operator Observable<Unit>();
                  })
                  .map([predefined_observables{xs.predefined_observables}, obs_fn{ext.observable}](Observable<Unit>&& obs) mutable {
                    return ((*obs_fn)()).purify(predefined_observables, std::move(obs));
                  })
                  .map([data_fn{ext.data}](Observable<Unit>&& obs) {
                    return std::move(obs)
                      .mapc([data_fn](const Unit* unit) {
                        return (*data_fn)();
                      })
                      .operator Observable<SamplingStats<double>>();
                  })
                  .operator Composite<Observable<SamplingStats<double>>>()
              };

              Composite<SharedPtr<ObservableHistory<SamplingStats<double>>>> hist_comp {
                std::move(obs_comp)
                  .and_then([grid_size](Observable<SamplingStats<double>>&& obs) {
                    return new_observable_history_grid<SamplingStats<double>>(std::move(obs),
                      grid_size, 
                      [](const SamplingStats<double>& x, const SamplingStats<double>& y) {
                        return x.combine(y);
                      });
                  })
                  .operator Composite<SharedPtr<ObservableHistory<SamplingStats<double>>>>()
              };

              hist_comps.emplace_back(std::move(hist_comp));
            }

            double stop_time = experiment->specs.stop_time;

            return composite_sequence(std::move(hist_comps))
              .and_then([mutex{mutex}, results{results}, grid_size, stop_time](std::vector<SharedPtr<ObservableHistory<SamplingStats<double>>>>&& hists) {
                return into_composite(enqueue_uncancellable_io_event(stop_time,
                  cons_event([mutex, results, grid_size, hists{std::move(hists)}](const Point* p) mutable {
                    for (std::size_t i = 0; i < hists.size(); ++i) {
                      auto res { read_observable_history(hists[i])(p) };
                      if (ObservableHistoryData<SamplingStats<double>> *txs = get_result_if(&res)) {
                        std::lock_guard<std::mutex> lock(*mutex);
                        if (txs->times.size() > results->times.size() || results->times.size() != grid_size) {
                          throw PanicResult("DeviationChart: the resulting series size mismatch.");
                        }

                        for (unsigned int index = 0; index < txs->times.size(); ++index) {
                          if (txs->times[index] != results->times[index]) {
                            throw PanicResult("DeviationChart: the resulting series time mismatch.");
                          }

                          results->stats[i][index] = results->stats[i][index]
                            .combine(txs->values[index].norm(1));
                        }

                      } else {
                        return error_result<Unit>(std::move(res));
                      }
                    }

                    return Result<Unit>(Unit());
                  })));
              });
          }

          WebPageRendering::context_type context() override {
            return std::shared_ptr<WebPageWriter> {
              new DeviationChartState(*this)
            };
          }

          /** Replace all substrings. */
          void replace_string(std::string& s, const char* from, const char* to, std::string::size_type pos = 0) {
            while (pos != std::string::npos) {
              pos = s.find(from, pos);
              if (pos == std::string::npos) {
                break;

              } else {
                s.replace(pos, std::strlen(from), to);
                pos += std::strlen(to);
              }
            }
          }

          /** Set up the file name. */
          void setup_file_name() {
            using namespace DVCOMPUTE_NS::utils::path;

            std::lock_guard<std::mutex> lock(*mutex);
            std::string file_name0 = "deviation-chart";
            FilePath file_path = resolve_file_path(append_path(*dir, file_name0));

            if (!make_directory(file_path)) {
              std::string msg = "Could not create directory: " + path_to_string(file_path);
              throw PanicResult(msg);
            }

            *file_name = std::make_optional(file_path);
          }

          /** Save data in the file. */
          void save_data() {
            using namespace DVCOMPUTE_NS::utils::path;

            std::lock_guard<std::mutex> lock(*mutex);
            FilePath file_path = append_path(file_name->value(), "data.csv");
            std::ofstream out(file_path);
            
            if (!out.good()) {
              std::string msg = "Could not create file: " + path_to_string(file_path);
              throw PanicResult(msg);
            }

            for (std::size_t index = 0; index < view->grid_size; ++index) {
              out << results->times[index];
              for (std::size_t i = 0; i < results->names.size(); ++i) {
                SamplingStats<double> st { results->stats[i][index] };
                double lo = st.mean - 3.0 * st.deviation();
                double hi = st.mean + 3.0 * st.deviation();
                
                if (view->y_non_negative) {
                  lo = std::max(0.0, lo);
                  hi = std::max(0.0, hi);
                }

                out << "\t" << lo
                    << "\t" << st.mean
                    << "\t" << hi;
              }
              out << std::endl;
            }

            if (experiment->verbose) {
              std::cout << "Generated file: " << path_to_string(file_path) << std::endl;
            }
          }

          /** Save the command file. */
          void save_command_file() {
            using namespace DVCOMPUTE_NS::utils::path;

            std::lock_guard<std::mutex> lock(*mutex);
            FilePath file_path = append_path(file_name->value(), "plot.gp");
            std::ofstream out(file_path);
            
            if (!out.good()) {
              std::string msg = "Could not create file: " + path_to_string(file_path);
              throw PanicResult(msg);
            }

            std::string figure_file = std::string("\"") +
              path_to_string(append_path(file_name->value(), "figure.svg")) +
              "\"";

            std::string data_file = std::string("\"") +
              path_to_string(append_path(file_name->value(), "data.csv")) +
              "\"";

            replace_string(figure_file, "\\", "\\\\");
            replace_string(data_file, "\\", "\\\\");

            out << "set term svg" << std::endl;
            out << "set output " << figure_file << std::endl;
            out << "set style fill transparent solid 0.15 border" << std::endl;

            if (!results->names.empty()) {

              if (view->plot_title.has_value()) {
                std::string plot_title { view->plot_title.value() };
                replace_string(plot_title, "$TITLE", view->title.c_str());
                replace_string(plot_title, "_", "\\\\_");
                replace_string(plot_title, "\"", "\\\"");
                
                out << "set title \"" << plot_title << "\"" << std::endl;
              }

              if (view->xlabel.has_value()) {
                std::string xlabel { view->xlabel.value() };
                replace_string(xlabel, "_", "\\\\_");
                replace_string(xlabel, "\"", "\\\"");
                
                out << "set xlabel \"" << xlabel << "\"" << std::endl;
              }

              if (view->ylabel.has_value()) {
                std::string ylabel { view->ylabel.value() };
                replace_string(ylabel, "_", "\\\\_");
                replace_string(ylabel, "\"", "\\\"");
                
                out << "set ylabel \"" << ylabel << "\"" << std::endl;
              }

              out << std::endl;
              out << "plot ";
              for (std::size_t i = 0; i < results->names.size(); ++i) {
                std::string title = results->names[i];
                replace_string(title, "_", "\\\\_");
                replace_string(title, "\"", "\\\"");

                if (i > 0) {
                  out << "     ";
                }

                out << data_file << " using 1:" << 2+3*i << ":" << 4+3*i << " with filledcurves fc "
                    << get_default_color_name(i) << " notitle, \\"
                    << std::endl << "     "
                    << data_file << " using 1:" << 3+3*i << " smooth mcs with lines lc "
                    << get_default_color_name(i) << " title \"" << title << "\"";

                if (i < results->names.size() - 1) {
                  out << ", \\";
                }

                out << std::endl;
              }

            } else {
              out << "set title \"No series are found\"" << std::endl;
              out << "set ylabel \"t\"" << std::endl;
              out << "set ylabel \"t\"" << std::endl;
              out << std::endl;
              out << "plot " << data_file << " using 1:1 smooth mcs with lines lc "
                  << get_default_color_name(0) << " title \"t\"";
            }

            if (experiment->verbose) {
              std::cout << "Generated file: " << path_to_string(file_path) << std::endl;
            }
          }

          /** Execute the command file. */
          void exec_command_file() {
            using namespace DVCOMPUTE_NS::utils::path;

            std::string cmd;
            {
              std::lock_guard<std::mutex> lock(*mutex);
              FilePath file_path = append_path(file_name->value(), "plot.gp");
              cmd = path_to_string(file_path);

#ifdef _WIN32
              replace_string(cmd, "\"", "\\\"");
              cmd = std::string("\"") + cmd + "\"";
#else
              replace_string(cmd, "\"", "\\\"");
              replace_string(cmd, " ", "\\ ");
              replace_string(cmd, "(", "\\(");
              replace_string(cmd, ")", "\\)");
#endif
              cmd = view->gnuplot + " " + cmd;

              if (experiment->verbose) {
                std::cout << "Launching " << view->gnuplot << "..." << std::endl;
              }
            }

            int res = std::system(cmd.c_str());
 
            if (res != 0) {
              std::lock_guard<std::mutex> lock(*mutex);
              if (experiment->verbose) {
                std::cout << "Launching " << view->gnuplot << " returned a non zero result!" << std::endl;
              }
            }
          }
        };
      }

      inline std::shared_ptr<ExperimentReporter<WebPageRendering::context_type>> DeviationChart::report(WebPageRendering& rendering,
          const Experiment& experiment, 
          const WebPageRendering::environment_type& env) &&
      {
        return std::shared_ptr<ExperimentReporter<WebPageRendering::context_type>> {
          new DeviationChartState(*this, experiment, env)
        };
      }
      
      inline std::shared_ptr<ExperimentGenerator<WebPageRendering>> DeviationChart::view() && {
        return std::shared_ptr<ExperimentGenerator<WebPageRendering>> {
          new DeviationChart(*this)
        };
      }
    }
  }
}

#endif /* dvcompute_experiments_rendering_deviation_chart_h */

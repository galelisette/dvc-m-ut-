/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_rendering_last_values_h
#define dvcompute_experiments_rendering_last_values_h

#include <memory>
#include <mutex>
#include <map>
#include <vector>
#include <utility>
#include <string>
#include <cstring>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/results/result_set.h"
#include "dvcompute/simulator/basic/experiments/experiment.h"
#include "dvcompute/simulator/basic/experiments/rendering/web_page.h"
#include "dvcompute/simulator/utils/html.h"

namespace DVCOMPUTE_NS {

  namespace experiments {

    namespace rendering {

      /** Defines the experiment view that shows the last values of simulation variables. */
      class LastValues : 
        public ExperimentView<WebPageRendering>,
        public ExperimentGenerator<WebPageRendering>
      {
      public:

        /** The title. */
        std::string title { "Last Values" };

        /**
         * The run title that may include special variables
         * `$RUN_INDEX`, `$RUN_COUNT` and `$TITLE`.
         *
         * An example is `$TITLE / Run $RUN_INDEX of $RUN_COUNT`.
         */
        std::string run_title { "$TITLE / Run $RUN_INDEX of $RUN_COUNT" };

        /** The description. */
        std::optional<std::string> description { 
          "It shows the values in the final time point(s)." 
        };

        /** It transforms data before they will be shown. */
        std::function<std::string(const char*)> format {
          [](const char* x) { return std::string(x); }
        };

        /** The transform applied to the results before receiving the series. */
        std::function<results::ResultTransform()> transform {
          []() { return results::ResultTransform(); }
        };

        /** It defines the series for which the last values are to be displayed. */
        std::function<results::ResultTransform()> series {
          []() { return results::ResultTransform(); }
        };

        std::shared_ptr<ExperimentReporter<WebPageRendering::context_type>> report(WebPageRendering& rendering,
          const Experiment& experiment, 
          const WebPageRendering::environment_type& env) && override;

        std::shared_ptr<ExperimentGenerator<WebPageRendering>> view() && override;
      };

      namespace {

        /** The state of the view. */
        class LastValueState : 
          public ExperimentReporter<WebPageRendering::context_type>,
          public WebPageWriter
        {
          /** The mutex. */
          std::shared_ptr<std::mutex> mutex;

          /** The view. */
          std::shared_ptr<LastValues> view;

          /** The experiment. */
          std::shared_ptr<Experiment> experiment;

          /** The last values. */
          std::shared_ptr<std::map<int, std::vector<std::pair<std::string, std::string>>>> values;

        public:

          LastValueState(const LastValues& view_arg, const Experiment& experiment_arg) :
            mutex(new std::mutex()),
            view(new LastValues(view_arg)),
            experiment(new Experiment(experiment_arg)),
            values(new std::map<int, std::vector<std::pair<std::string, std::string>>>())
          {
            int n = experiment->run_count;
            for (int i = 0; i < n; ++i) {
              values->emplace(i, std::vector<std::pair<std::string, std::string>>());
            }
          }

          LastValueState(const LastValueState&) = default;
          LastValueState& operator=(const LastValueState&) = default;

          void write_toc_html(std::ostream& out, std::size_t index) override {
            using namespace DVCOMPUTE_NS::utils::html;

            std::lock_guard<std::mutex> lock(*mutex);
            std::string id = "#id" + std::to_string(index);
            begin_html_list_item(out);
            write_html_link(out, id.c_str(), view->title.c_str());
            end_html_list_item(out);
          }

          void write_html(std::ostream& out, std::size_t index) override {
            int run_count;
            {
              std::lock_guard<std::mutex> lock(*mutex);
              run_count = experiment->run_count;
            }

            if (run_count == 1) {
              write_html_single(out, index);

            } else {
              write_html_multiple(out, index);
            }
          }

          /** Get the HTML code for a single run. */
          void write_html_single(std::ostream& out, std::size_t index) {
            write_html_header(out, index);
            std::lock_guard<std::mutex> lock(*mutex);
            for (auto& p : (*values)[0]) {
              write_html_pair(out, p.first.c_str(), view->format(p.second.c_str()).c_str());
            }
          }

          /** Get the HTML code for multiple runs. */
          void write_html_multiple(std::ostream& out, std::size_t index) {
            write_html_header(out, index);
            std::lock_guard<std::mutex> lock(*mutex);
            int n = experiment->run_count;
            for (int run_index = 0; run_index < n; ++run_index) {
              std::string s = view->run_title;
              replace_string(s, "$TITLE", view->title.c_str());
              replace_string(s, "$RUN_COUNT", std::to_string(n).c_str());
              replace_string(s, "$RUN_INDEX", std::to_string(1 + run_index).c_str());

              {     
                using namespace DVCOMPUTE_NS::utils::html;
                write_html_header4(out, s.c_str());
              }

              for (auto& p : (*values)[run_index]) {
                write_html_pair(out, p.first.c_str(), view->format(p.second.c_str()).c_str());
              }
            }
          }

          /** Write the pair in HTML. */
          void write_html_pair(std::ostream& out, const char* k, const char* v) {
            using namespace DVCOMPUTE_NS::utils::html;

            begin_html_paragraph(out);
            write_html_text(out, k);
            write_html_text(out, " = ");
            write_html_text(out, v);
            end_html_paragraph(out);
          }

          /** Write the HTML header. */
          void write_html_header(std::ostream& out, std::size_t index) {
            using namespace DVCOMPUTE_NS::utils::html;

            std::lock_guard<std::mutex> lock(*mutex);
            std::string id = "id" + std::to_string(index);
            write_html_header3_by_id(out, id.c_str(), view->title.c_str());
            if (view->description.has_value()) {
              begin_html_paragraph(out);
              write_html_text(out, view->description.value().c_str());
              end_html_paragraph(out);
            }
          }

          Result<Unit> initialise() override {
            return Result<Unit>(Unit());
          }

          Result<Unit> finalise() override {
            return Result<Unit>(Unit());
          }

          Composite<Unit> simulate(const ExperimentData& xs) override {
            results::ResultLocale loc;
            std::vector<results::ResultValue<std::string>> exts;
            {
              std::lock_guard<std::mutex> lock(*mutex);
              loc = experiment->locale;
              Result<results::ResultSet> res {
                (view->transform)()
                  .and_then((view->series)())
                  .operator()(xs.results)
              };

              if (results::ResultSet *rs = get_result_if(&res)) {
                exts = rs->string_values(loc);
              } else {
                return into_composite(cons_event([res{std::move(res)}](const Point* p) mutable {
                  return error_result<Unit>(std::move(res));
                }));
              }
            }

            return into_composite(xs.predefined_observables
              .in_stop_time()
              .subscribe(cons_observer([loc, exts{std::move(exts)}, mutex{mutex}, values{values}](const double* t, const Point* p) {
                return enqueue_uncancellable_io_event(p->time,
                  cons_event([loc, exts, mutex{mutex}, values{values}](const Point* p) {
                    std::vector<Event<std::pair<std::string, std::string>>> comps;
                    for (auto& ext : exts) {
                      auto x { result_qualified_name(ext.id_path, loc) };
                      comps.emplace_back((*ext.data)()
                        .map([x](std::string&& y) {
                          return std::pair<std::string, std::string>(x, y);
                        })
                        .operator Event<std::pair<std::string, std::string>>());
                    }

                    auto res { 
                      event_sequence(std::move(comps)) 
                        .operator()(p)
                    };

                    if (auto *xys = get_result_if(&res)) {
                      std::lock_guard<std::mutex> lock(*mutex);
                      (*values)[p->run->run_index] = std::move(*xys);

                    } else {
                      return error_result<Unit>(std::move(res));
                    }

                    return Result<Unit>(Unit());
                  }))
                  .operator()(p);
              })))
            .and_then([](Disposable<>&& h) {
              return disposable_composite(std::move(h));
            });
          }

          WebPageRendering::context_type context() override {
            return std::shared_ptr<WebPageWriter> {
              new LastValueState(*this)
            };
          }

          /** Replace all substrings. */
          void replace_string(std::string& s, const char* from, const char* to, std::string::size_type pos = 0) {
            while (pos != std::string::npos) {
              pos = s.find(from, pos);
              if (pos == std::string::npos) {
                break;

              } else {
                s.replace(pos, std::strlen(from), to);
                pos += std::strlen(to);
              }
            }
          }
        };
      }

      inline std::shared_ptr<ExperimentReporter<WebPageRendering::context_type>> LastValues::report(WebPageRendering& rendering,
          const Experiment& experiment, 
          const WebPageRendering::environment_type& env) &&
      {
        return std::shared_ptr<ExperimentReporter<WebPageRendering::context_type>> {
          new LastValueState(*this, experiment)
        };
      }
      
      inline std::shared_ptr<ExperimentGenerator<WebPageRendering>> LastValues::view() && {
        return std::shared_ptr<ExperimentGenerator<WebPageRendering>> {
          new LastValues(*this)
        };
      }
    }
  }
}

#endif /* dvcompute_experiments_rendering_last_values_h */

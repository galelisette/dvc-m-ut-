/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_rendering_web_page_h
#define dvcompute_experiments_rendering_web_page_h

#include <fstream>
#include <memory>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/experiments/experiment.h"
#include "dvcompute/simulator/utils/path.h"
#include "dvcompute/simulator/utils/html.h"

namespace DVCOMPUTE_NS {

  namespace experiments {

    namespace rendering {

      /** It replies to the requests made by the web page renderer. */
      class WebPageWriter {
      public:

        virtual ~WebPageWriter() {}

        /**
         * Write the TOC (Table of Contents) item in the HTML index file
         * after the finalisation function is called, i.e. in the very end.
         * The index parameter specifies the ordered number of the item.
         */
        virtual void write_toc_html(std::ostream& out, std::size_t index) = 0;

        /** 
         * Write the HTML code in the index file after the finalisation
         * function is called. The index parameter specifies the ordered
         * number of the item. You should start the HTML code with call
         * of the `begin_html_list_item` function.
         */
        virtual void write_html(std::ostream& out, std::size_t index) = 0;
      };

      /** The file path. */
      using FilePath = DVCOMPUTE_NS::utils::path::FilePath;

      /** It defines the web page rendering. */
      class WebPageRendering : public ExperimentRendering<std::shared_ptr<WebPageWriter>, FilePath> {

        /** The experiment file path. */
        FilePath path;

      public:

        explicit WebPageRendering(const FilePath& path_arg) :
          path(path_arg)
        {}

        /** Return the file path. */
        FilePath filepath() const {
          return path;
        }

        Result<environment_type> prepare(const Experiment& experiment) override {
          using namespace DVCOMPUTE_NS::utils::path;

          FilePath dir = resolve_file_path(path);
          if (!make_directory(dir)) {
            std::string msg = "Could not create directory: " + path_to_string(dir);
            throw PanicResult(msg);
          }

          return Result<environment_type>(std::move(dir));
        }

        Result<Unit> render(const Experiment& experiment,
          const std::vector<std::shared_ptr<ExperimentReporter<context_type>>>& reporters,
          const environment_type& env) override
        {
          FilePath path = DVCOMPUTE_NS::utils::path::append_path(env, "index.html");
          std::ofstream file(path);

          if (!file.good()) {
            std::string msg = "Could not create file: " + DVCOMPUTE_NS::utils::path::path_to_string(path);
            throw PanicResult(msg);
          }

          using namespace DVCOMPUTE_NS::utils::html;

          begin_html_document(file, experiment.title.c_str());
          for (std::size_t i = 0; i < reporters.size(); ++i) {
            reporters[i]->context()->write_toc_html(file, 1 + i);
          }
          write_html_break(file);
          if (experiment.description.has_value()) {
            begin_html_paragraph(file);
            write_html_text(file, experiment.description.value().c_str());
            end_html_paragraph(file);
          }
          for (std::size_t i = 0; i < reporters.size(); ++i) {
            reporters[i]->context()->write_html(file, 1 + i);
          }
          end_html_document(file);

          if (experiment.verbose) {
            std::cout << "Generated file: " << DVCOMPUTE_NS::utils::path::path_to_string(path) << std::endl;
          }

          return Result<Unit>(Unit());
        }

        Result<Unit> on_completed(const Experiment& experiment,
          const environment_type& env) override
        {
          return Result<Unit>(Unit());
        }

        Result<Unit> on_failed(const Experiment& experiment,
          const environment_type& env,
          const Result<Unit>& error) override
        {
          return Result<Unit>(Unit());
        }
      };
    }
  }
}

#endif /* dvcompute_experiments_rendering_web_page_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_experiments_rendering_default_colors_h
#define dvcompute_experiments_rendering_default_colors_h

#include <cstddef>

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  namespace experiments {

    namespace rendering {

      namespace {

        /** The default colors based on https://stackoverflow.com/questions/17120363/default-colour-set-on-gnuplot-website. */
        static const char default_color_names[][15] {
          "\"dark-violet\"", "\"#009e73\"", "\"#56b4e9\"", "\"#e69f00\"", 
          "\"#f0e442\"", "\"#0072b2\"", "\"#e51e10\"", "\"gray50\""
        };
      }

      /** Get the default color name by the specified index. */
      inline const char* get_default_color_name(std::size_t index) {
        return default_color_names[index % 8];
      }
    }
  }
}

#endif /* dvcompute_experiments_rendering_default_colors_h */

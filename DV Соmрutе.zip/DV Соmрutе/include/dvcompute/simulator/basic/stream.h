/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_stream_h
#define dvcompute_stream_h

#include <utility>

#include "../../dvcompute_ns.h"
#include "event.h"
#include "process.h"
#include "macros.h"

namespace DVCOMPUTE_NS {

  template<typename Item>
  struct Stream;

  template<typename Item>
  Stream<Item> empty_stream();

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace stream {

      /** Whether `F` is a function that takes `Arg&&` and returns an `Event` computation. */
      template<typename F, typename Arg, typename Item>
      concept StreamMapCFn3 = std::is_invocable_r_v<Event<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg&&` and returns an `Event` computation. */
      template<typename F, typename Arg>
      concept StreamMapCFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires StreamMapCFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns a `Stream` computation. */
      template<typename F, typename Item>
      concept StreamDelayFn2 = std::is_invocable_r_v<Stream<Item>, F>;

      /** Whether `F` is a function that returns a `Stream` computation. */
      template<typename F>
      concept StreamDelayFn1 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires StreamDelayFn2<F, typename std::invoke_result_t<F>::item_type>;
      };
    }
  }

  /** Whether `F` is a function that takes `Arg&&` and returns an `Event` computation. */
  template<typename F, typename Arg>
  concept StreamMapCFn = internal::stream::StreamMapCFn2<F, Arg>;

  /** Whether `F` is a function that takes `const Arg&` and returns a boolean flag. */
  template<typename F, typename Arg>
  concept StreamPredFn = std::is_invocable_r_v<bool, F, const Arg&>;

  /** Whether `F` is a function that takes `const Arg&` and returns an `Event<bool>` computation. */
  template<typename F, typename Arg>
  concept StreamPredCFn = std::is_invocable_r_v<Event<bool>, F, const Arg&>;

  /** Whether `F` is a function that returns a `Stream` computation. */
  template<typename F>
  concept StreamDelayFn = internal::stream::StreamDelayFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  /** An infinite stream of data. */
  template<typename Item>
  struct Stream {

    using item_type = Item;

    /** The cons-cell. */
    Process<std::pair<Item, Stream<Item>>> cons;

    /** Run the stream computation. */
    Process<std::pair<Item, Stream<Item>>> run() && {
      return std::move(cons);
    }

    /** Map the stream according the specified function. */
    template<typename MapFn>
    Stream<std::invoke_result_t<MapFn, Item&&>> map(MapFn&& fn) && {
      using MapItem = std::invoke_result_t<MapFn, Item&&>;
      return Stream<MapItem> {
        std::move(cons).and_then([fn{std::move(fn)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          MapItem head { fn(std::move(pair.first)) };
          return pure_process(std::pair<MapItem, Stream<MapItem>>(std::move(head), 
            std::move(pair.second).map(std::move(fn))));
        })
      };
    }

    /** 
     * Composite the stream according the specified function that 
     * returns a `Process` computation by the provided input value. 
     */
    template<typename MapCFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<typename std::invoke_result_t<MapCFn, Item&&>::item_type> mapc(MapCFn&& fn) && requires StreamMapCFn<MapCFn, Item> {
#else
    Stream<typename std::invoke_result_t<MapCFn, Item&&>::item_type> mapc(MapCFn&& fn) && {
#endif
      using MapCItem = typename std::invoke_result_t<MapCFn, Item&&>::item_type;
      return Stream<MapCItem> {
        std::move(cons).and_then([fn{std::move(fn)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          return into_process(fn(std::move(pair.first)))
            .and_then([fn{std::move(fn)}, second{std::move(pair.second)}](MapCItem&& head) mutable {
              return pure_process(std::pair<MapCItem, Stream<MapCItem>>(std::move(head), 
                std::move(second).mapc(std::move(fn))));
            });
        })
      };
    }

    /** 
     * Filter only those data values that satisfy the specified predicate
     * which must be a function that returns a boolean value by the provided
     * input value.
     */
    template<typename PredFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<Item> filter(PredFn&& pred) && requires StreamPredFn<PredFn, Item> {
#else
    Stream<Item> filter(PredFn&& pred) && {
#endif
      return Stream<Item> {
        std::move(cons).and_then([pred{std::move(pred)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          if (pred(pair.first)) {
            return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first), 
                std::move(pair.second).filter(std::move(pred))))
              .operator Process<std::pair<Item, Stream<Item>>>();

          } else {
            return std::move(pair.second).filter(std::move(pred)).run();
          }
        })
      };
    }

    /** 
     * Filter only those data values that satisfy the specified predicate
     * which must be a function that returns an `Event<bool>` computation
     * by the provided input value.
     */
    template<typename PredCFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<Item> filterc(PredCFn&& pred) && requires StreamPredCFn<PredCFn, Item> {
#else
    Stream<Item> filterc(PredCFn&& pred) && {
#endif
      return Stream<Item> {
        std::move(cons).and_then([pred{std::move(pred)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          return into_process(pred(pair.first))
            .and_then([pred{std::move(pred)}, pair{std::move(pair)}](bool f) mutable {
              if (f) {
                return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first), 
                    std::move(pair.second).filterc(std::move(pred))))
                  .operator Process<std::pair<Item, Stream<Item>>>();

              } else {
                return std::move(pair.second).filterc(std::move(pred)).run();
              }
            });
        })
      };
    }

    /** Return the prefix of the stream of the specified length. */
    Stream<Item> take(int n) && {
      if (n <= 0) {
        return empty_stream<Item>();

      } else {
        return Stream<Item> {
          std::move(cons).and_then([n](std::pair<Item, Stream<Item>>&& pair) {
            return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first),
              std::move(pair.second).take(n - 1)));
          })
        };
      }
    }

    /** Return the longest prefix of the stream of elements that satisfy the predicate. */
    template<typename PredFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<Item> take_while(PredFn&& pred) && requires StreamPredFn<PredFn, Item> {
#else
    Stream<Item> take_while(PredFn&& pred) && {
#endif
      return Stream<Item> {
        std::move(cons).and_then([pred{std::move(pred)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          if (pred(pair.first)) {
            return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first), 
                std::move(pair.second).take_while(std::move(pred))))
              .operator Process<std::pair<Item, Stream<Item>>>();

          } else {
            return never_process<std::pair<Item, Stream<Item>>>()
              .operator Process<std::pair<Item, Stream<Item>>>();
          }
        })
      };
    }

    /** 
     * Return the longest prefix of the stream of elements that satisfy the computations,
     * which are defined by the function of the stream item that returns `Event<bool>`.
     */
    template<typename PredCFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<Item> take_while_c(PredCFn&& pred) && requires StreamPredCFn<PredCFn, Item> {
#else
    Stream<Item> take_while_c(PredCFn&& pred) && {
#endif
      return Stream<Item> {
        std::move(cons).and_then([pred{std::move(pred)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          return into_process(pred(pair.first))
            .and_then([pred{std::move(pred)}, pair{std::move(pair)}](bool f) mutable {
              if (f) {
                return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first), 
                    std::move(pair.second).take_while_c(std::move(pred))))
                  .operator Process<std::pair<Item, Stream<Item>>>();

              } else {
                return never_process<std::pair<Item, Stream<Item>>>()
                  .operator Process<std::pair<Item, Stream<Item>>>();
              }
            });
        })
      };
    }

    /** Return the suffix of the stream after the specified first elements. */
    Stream<Item> drop(int n) && {
      if (n <= 0) {
        return std::move(*this);

      } else {
        return Stream<Item> {
          std::move(cons).and_then([n](std::pair<Item, Stream<Item>>&& pair) {
            return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first),
              std::move(pair.second).drop(n - 1)));
          })
        };
      }
    }

    /** Return the suffix of the stream of elements remaining after `take_while`. */
    template<typename PredFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<Item> drop_while(PredFn&& pred) && requires StreamPredFn<PredFn, Item> {
#else
    Stream<Item> drop_while(PredFn&& pred) && {
#endif
      return Stream<Item> {
        std::move(cons).and_then([pred{std::move(pred)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          if (pred(pair.first)) {
            return std::move(pair.second).drop_while(std::move(pred)).run();

          } else {
            return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first), 
                std::move(pair.second)))
              .operator Process<std::pair<Item, Stream<Item>>>();
          }
        })
      };
    }

    /** Return the suffix of the stream of elements remaining after `take_while_c`. */
    template<typename PredCFn>
#ifdef DVCOMPUTE_CONCEPTS
    Stream<Item> drop_while_c(PredCFn&& pred) && requires StreamPredCFn<PredCFn, Item> {
#else
    Stream<Item> drop_while_c(PredCFn&& pred) && {
#endif
      return Stream<Item> {
        std::move(cons).and_then([pred{std::move(pred)}](std::pair<Item, Stream<Item>>&& pair) mutable {
          return into_process(pred(pair.first))
            .and_then([pred{std::move(pred)}, pair{std::move(pair)}](bool f) mutable {
              if (f) {
                return std::move(pair.second).drop_while_c(std::move(pred)).run();

              } else {
                return pure_process(std::pair<Item, Stream<Item>>(std::move(pair.first), 
                    std::move(pair.second)))
                  .operator Process<std::pair<Item, Stream<Item>>>();
              }
            });
        })
      };
    }
  };

  /** An empty stream that never returns data. */
  template<typename Item>
  Stream<Item> empty_stream() {
    return Stream<Item> {
      never_process<std::pair<Item, Stream<Item>>>()
    };
  }

  /**
   * Delay the `Stream` computation and return the resulting compound `Stream<Item>`
   * computation, where `DelayFn` is a function that returns an intermediate `Stream`
   * computation, but `Item == std::invoke_result_t<DelayFn>::item_type`.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  auto delay_stream(DelayFn&& f) requires StreamDelayFn<DelayFn> {
#else
  auto delay_stream(DelayFn&& f) {
#endif
    using Item = typename std::invoke_result_t<DelayFn>::item_type;
    return Stream<Item> {
      delay_process([f{std::move(f)}]() mutable {
        return f().run();
      }).into_boxed()
    };
  }

  /** Iterate stream: value, fn(value), fn(fn(value)), ... . */
  template<typename Item, typename Fn>
  Stream<Item> iterate_stream(Fn&& fn, Item&& value) {
    return delay_stream([fn{std::move(fn)}, value{std::move(value)}]() mutable {
      Item next_value { fn(value) };
      return Stream<Item> {
        pure_process(std::pair<Item, Stream<Item>>(std::move(value), iterate_stream(std::move(fn), std::move(next_value))))
          .into_boxed()
      };
    });
  }
}

#endif /* dvcompute_stream_h */

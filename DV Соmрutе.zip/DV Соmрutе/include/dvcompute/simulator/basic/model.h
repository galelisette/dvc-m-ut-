/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_model_h
#define dvcompute_model_h

#include <vector>
#include <string>
#include <functional>

#include "../../dvcompute_ns.h"

#include "types.h"
#include "result.h"
#include "simulation.h"
#include "event.h"
#include "block/queue.h"
#include "results/result_source.h"
#include "results/result_set.h"

namespace DVCOMPUTE_NS {

  /** Encapsulates the simulation model. */
  class Model {

    std::vector<DVCOMPUTE_NS::results::ResultSource> sources;
    std::vector<Simulation<Unit>> actions;

    template<typename Item>
    void emplace_result_source(const SharedPtr<Item>& item, std::string&& name) {
      sources.emplace_back(DVCOMPUTE_NS::results::result_source(item, name));
    }

    template<typename Item>
    void emplace_result_source(const SharedPtr<Item>& item, std::string&& name, std::string&& descr) {
      sources.emplace_back(DVCOMPUTE_NS::results::result_source(item, name, descr));
    }

    template<typename Item>
    void emplace_result_source(const std::function<Event<Item>()>& comp_fn, std::string&& name) {
      sources.emplace_back(DVCOMPUTE_NS::results::result_source(comp_fn, name));
    }

    template<typename Item>
    void emplace_result_source(const std::function<Event<Item>()>& comp_fn, std::string&& name, std::string&& descr) {
      sources.emplace_back(DVCOMPUTE_NS::results::result_source(comp_fn, name, descr));
    }

  public:

    explicit Model() : actions() {}

    /** Initialize the model in the start time and return the result set within `Simulation<DVCOMPUTE_NS::results::ResultSet>`. */
    auto init_in_start_time() && {
      return simulation_sequence_(std::move(actions))
        .map([sources{std::move(sources)}](Unit&& unit) mutable {
          return DVCOMPUTE_NS::results::ResultSet(std::move(sources));
        });
    }

    /** Initialize the model in the start time within `Simulation<Unit>` by ignoring the output result set. */
    auto init_in_start_time_() && {
      sources.clear();  // N.B. here could be a memory leak!
      return simulation_sequence_(std::move(actions));
    }

    /** Add a new action that will be performed at start time of simulation. */
    void emplace_action(Simulation<Unit>&& action) {
      actions.emplace_back(std::move(action));
    }

    /** Create a new mutable reference cell by the specified initial value. */
    template<typename Item>
    RefPtr<Item> new_ref(Item&& item) {
      return mk_shared(Ref(std::move(item)));
    }

    /** Create a new mutable reference cell by the specified initial value and name. */
    template<typename Item>
    RefPtr<Item> new_ref(Item&& item, std::string&& name) {
      auto x { new_ref(std::move(item)) };
      emplace_result_source(x, std::move(name));
      return x;
    }

    /** Create a new mutable reference cell by the specified initial value, name and description. */
    template<typename Item>
    RefPtr<Item> new_ref(Item&& item, std::string&& name, std::string&& descr) {
      auto x { new_ref(std::move(item)) };
      emplace_result_source(x, std::move(name), std::move(descr));
      return x;
    }

    /** Create a new queue in the start time. */
    block::QueuePtr new_queue() {
      block::QueuePtr x { SharedPtrLateInit() };
      emplace_action(block::late_init_queue(x).run_in_start_time());
      return x;
    }

    /** Create a new queue in the start time by the specified name. */
    block::QueuePtr new_queue(std::string&& name) {
      auto x { new_queue() };
      emplace_result_source(x, std::move(name));
      return x;
    }

    /** Create a new queue in the start time by the specified name and description. */
    block::QueuePtr new_queue(std::string&& name, std::string&& descr) {
      auto x { new_queue() };
      emplace_result_source(x, std::move(name), std::move(descr));
      return x;
    }

    /** Create a new facility in the start time. */
    template<typename Item>
    block::FacilityPtr<Item> new_facility() {
      block::FacilityPtr<Item> x { SharedPtrLateInit() };
      emplace_action(block::late_init_facility(x).run_in_start_time());
      return x;
    }

    /** Create a new facility in the start time by the specified name. */
    template<typename Item>
    block::FacilityPtr<Item> new_facility(std::string&& name) {
      auto x { new_facility<Item>() };
      emplace_result_source(x, std::move(name));
      return x;
    }

    /** Create a new facility in the start time by the specified name and description. */
    template<typename Item>
    block::FacilityPtr<Item> new_facility(std::string&& name, std::string&& descr) {
      auto x { new_facility<Item>() };
      emplace_result_source(x, std::move(name), std::move(descr));
      return x;
    }

    /** Create a new storage in the start time by the specified capacity. */
    template<typename Item>
    block::StoragePtr<Item> new_storage(int capacity) {
      block::StoragePtr<Item> x { SharedPtrLateInit() };
      emplace_action(block::late_init_storage(capacity, x).run_in_start_time());
      return x;
    }

    /** Create a new storage in the start time by the specified capacity and name. */
    template<typename Item>
    block::StoragePtr<Item> new_storage(int capacity, std::string&& name) {
      auto x { new_storage<Item>(capacity) };
      emplace_result_source(x, std::move(name));
      return x;
    }

    /** Create a new storage in the start time by the specified capacity, name and description. */
    template<typename Item>
    block::StoragePtr<Item> new_storage(int capacity, std::string&& name, std::string&& descr) {
      auto x { new_storage<Item>(capacity) };
      emplace_result_source(x, std::move(name), std::move(descr));
      return x;
    }

    /** The `Observable<Arrival<double>>` computation with random time delays distributed uniformly. */
    inline auto new_random_uniform_observable(double min, double max) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_uniform_observable(min, max, source).run_().run_in_start_time());
      return source->publish();
    }

    /** The `Observable<Arrival<int>>` computation with integer random time delays distributed uniformly. */
    inline auto new_random_int_uniform_observable(int min, int max) {
      SharedPtr<ObservableSource<Arrival<int>>> source {
        mk_shared(ObservableSource<Arrival<int>>())
      };
      emplace_action(init_random_int_uniform_observable(min, max, source).run_().run_in_start_time());
      return source->publish();
    }

    /** The `Observable<Arrival<double>>` computation with random time delays from the triangular distribution. */
    inline auto new_random_triangular_observable(double min, double median, double max) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_triangular_observable(min, median, max, source).run_().run_in_start_time());
      return source->publish();
    }

    /** The `Observable<Arrival<double>>` computation with random time delays from the normal distribution. */
    inline auto new_random_normal_observable(double mu, double nu) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_normal_observable(mu, nu, source).run_().run_in_start_time());
      return source->publish();
    }

    /** The `Observable<Arrival<double>>` computation with random time delays from the lognormal distribution. */
    inline auto new_random_log_normal_observable(double mu, double nu) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_log_normal_observable(mu, nu, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<double>>` computation with exponential 
     * random time delays that have the specified average (the reciprocal of the rate). 
     */
    inline auto new_random_exponential_observable(double mu) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_exponential_observable(mu, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<double>>` computation with the Erlang 
     * random time delays that have the specified scale (the reciprocal of the rate) and integer shape. 
     */
    inline auto new_random_erlang_observable(double scale, int shape) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_erlang_observable(scale, shape, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<int>>` computation with the Poisson 
     * random time delays that have the specified average. 
     */
    inline auto new_random_poisson_observable(double mu) {
      SharedPtr<ObservableSource<Arrival<int>>> source {
        mk_shared(ObservableSource<Arrival<int>>())
      };
      emplace_action(init_random_poisson_observable(mu, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<int>>` computation with binomial 
     * random time delays by the specified probability and trials. 
     */
    inline auto new_random_binomial_observable(double prob, int trials) {
      SharedPtr<ObservableSource<Arrival<int>>> source {
        mk_shared(ObservableSource<Arrival<int>>())
      };
      emplace_action(init_random_binomial_observable(prob, trials, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<double>>` computation with random 
     * time delays from the Gamma distribution. 
     */
    inline auto new_random_gamma_observable(double kappa, double theta) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_gamma_observable(kappa, theta, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<double>>` computation with random 
     * time delays from the Beta distribution. 
     */
    inline auto new_random_beta_observable(double alpha, double beta) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_beta_observable(alpha, beta, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<double>>` computation with random 
     * time delays from the Weibull distribution. 
     */
    inline auto new_random_weibull_observable(double alpha, double beta) {
      SharedPtr<ObservableSource<Arrival<double>>> source {
        mk_shared(ObservableSource<Arrival<double>>())
      };
      emplace_action(init_random_weibull_observable(alpha, beta, source).run_().run_in_start_time());
      return source->publish();
    }

    /** 
     * The `Observable<Arrival<T>>` computation with random 
     * time delays that have the specified discrete distribution, where `T` must be
     * converted to `double` through `static_cast`.
     */
    template<typename T>
    inline auto new_random_discrete_observable(const SharedPtr<std::vector<std::pair<T, double>>>& dpdf) {
      SharedPtr<ObservableSource<Arrival<T>>> source {
        mk_shared(ObservableSource<Arrival<T>>())
      };
      emplace_action(init_random_discrete_observable(dpdf, source).run_().run_in_start_time());
      return source->publish();
    }

    /** Register the computation by the specified name. */
    template<typename Item>
    void register_event(const std::function<Event<Item>()>& comp_fn, std::string&& name) {
      emplace_result_source(comp_fn, std::move(name));
    }

    /** Register the computation by the specified name and description. */
    template<typename Item>
    void register_event(const std::function<Event<Item>()>& comp_fn, std::string&& name, std::string&& descr) {
      emplace_result_source(comp_fn, std::move(name), std::move(descr));
    }
  };
}

#endif /* dvcompute_model_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_specs_h
#define dvcompute_specs_h

#if defined(DVCOMPUTE_SEQUENTIAL)
#include "../seq/specs.h"
#elif defined(DVCOMPUTE_DISTRIBUTED)
#include "../dist/specs.h"
#elif defined(DVCOMPUTE_CONSERVATIVE)
#include "../cons/specs.h"
#elif defined(DVCOMPUTE_BRANCHED)
#include "../branch/specs.h"
#else
#error "Unknown simulation mode"
#endif

#endif /* dvcompute_specs_h */

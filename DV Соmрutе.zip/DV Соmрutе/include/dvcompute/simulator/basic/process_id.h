/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_process_id_h
#define dvcompute_process_id_h

#include <limits>
#include <optional>

#include "macros.h"
#include "types.h"
#include "specs.h"
#include "result.h"
#include "event.h"
#include "observable.h"
#include "observable_source.h"
#include "ref.h"
#include "process_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace process {

      /** The Process operations. */
      class ProcessOps;
    }
  }

  /** It defines how the parent and child computations should be cancelled. */
  enum class ProcessCancellation {

    /** Cancel the both computations together. */
    CancelTogether,

    /** Cancel the child if its parent is cancelled. */
    CancelChildAfterParent,

    /** Cancel the parent if its child is cancelled. */
    CancelParentAfterChild,

    /** Cancel the computations in isolation. */
    CancelInIsolation
  };

  /** The event that occurs within the `Process` computation. */
  enum class ProcessEvent {

    /** Cancel the computation. */
    CancelInitiating,

    /** Preempt the computation. */
    PreemptionInitiating,

    /** Proceed with the computation after it was preempted. */
    PreemptionEnding
  };

  /** The discontinuous process identifier. */
  class ProcessId {

    /** Whether the process is cancelled. */
    Ref<bool> cancel_activated;

     /** Whether the cancellation has been initiated. */
    Ref<bool> cancel_initiated;

    /** The count of preemption requests. */
    Ref<int> preemption_count;

    /** The source of events. */
    ObservableSource<ProcessEvent> source;

    /** Whether the process is already started. */
    Ref<bool> started;

    /** Whether the process was passivated. */
    Ref<std::optional<bool>> react_flag;

    /** The reactivation continuation. */
    Ref<internal::process::BoxedContFn<Unit>> react_cont_fn;

    /** The reactivation time priority. */
    Ref<int> react_priority;

    /** Whether the process was interrupted prematurely. */
    Ref<std::optional<bool>> interrupt_flag;

    /** The interruption continuation. */
    Ref<internal::process::BoxedContFn<Unit>> interrupt_cont_fn;

    /** The time of interruption. */
    Ref<double> interrupt_time;

    /** The version of interruption. */
    Ref<int> interrupt_version;

    /** The interruption time priority. */
    Ref<int> interrupt_priority;

    friend class DVCOMPUTE_NS::internal::process::ProcessOps;

  public:

    explicit ProcessId(const Run* r) :
      cancel_activated(false),
      cancel_initiated(false),
      preemption_count(0),
      source(),
      started(false),
      react_flag(std::nullopt),
      react_cont_fn(internal::process::BoxedContFn<Unit>()),
      react_priority(0),
      interrupt_flag(std::nullopt),
      interrupt_cont_fn(internal::process::BoxedContFn<Unit>()),
      interrupt_time(std::numeric_limits<double>::min()),
      interrupt_version(0),
      interrupt_priority(0)
    {}

    /** Test whether the process is cancelled. */
    bool is_cancelled(const Point* p) const {
      return cancel_activated.read_at(p);
    }

    /** Whether the cancellation was initiated. */
    bool is_cancel_initiated_at(const Point* p) const {
      return cancel_initiated.read_at(p);
    }

    /** Returns an `Observable<ProcessEvent>` computation. */
    auto observable() {
      return source.publish();
    }

    /** Signal within `Observable<Unit>` when the cancellation is initiated. */
    auto cancel_initiating() {
      return observable()
        .filter([](const ProcessEvent* msg) {
          return *msg == ProcessEvent::CancelInitiating;
        })
        .map([](const ProcessEvent* msg) {
          return Unit();
        });
    }

    /** Signal within `Observable<Unit>` when the process is preempted. */
    auto preemption_initiating() {
      return observable()
        .filter([](const ProcessEvent* msg) {
          return *msg == ProcessEvent::PreemptionInitiating;
        })
        .map([](const ProcessEvent* msg) {
          return Unit();
        });
    }

    /** Signal within `Observable<Unit>` when the process is proceeded after it was preempted . */
    auto preemption_ending() {
      return observable()
        .filter([](const ProcessEvent* msg) {
          return *msg == ProcessEvent::PreemptionEnding;
        })
        .map([](const ProcessEvent* msg) {
          return Unit();
        });
    }

    /** Initiate the cancellation. */
    Result<Unit> initiate_cancel_at(const Point* p) {
      if (!cancel_initiated.read_at(p)) {
        cancel_initiated.write_at(true, p);
        cancel_activated.write_at(true, p);
        ProcessEvent msg = ProcessEvent::CancelInitiating;
        return source.trigger_at(&msg, p);
      } else {
        return Result<Unit>(Unit());
      }
    }

    /** Preempt the computation. */
    Result<Unit> begin_preemption_at(const Point* p) {
      if (!cancel_initiated.read_at(p)) {
        int n = preemption_count.read_at(p);
        preemption_count.write_at(1 + n, p);
        if (n == 0) {
          ProcessEvent msg = ProcessEvent::PreemptionInitiating;
          return source.trigger_at(&msg, p);
        } else {
          return Result<Unit>(Unit());
        }
      } else {
        return Result<Unit>(Unit());
      }
    }

    /** Proceed with the computation after it was preempted. */
    Result<Unit> end_preemption_at(const Point* p) {
      if (!cancel_initiated.read_at(p)) {
        int n = preemption_count.read_at(p);
        preemption_count.write_at(n - 1, p);
        if (n - 1 == 0) {
          ProcessEvent msg = ProcessEvent::PreemptionEnding;
          return source.trigger_at(&msg, p);
        } else {
          return Result<Unit>(Unit());
        }
      } else {
        return Result<Unit>(Unit());
      }
    }
  };

  /** The shared pointer for the process identifier. */
  using ProcessIdPtr = SharedPtr<ProcessId>;

  namespace internal {

    namespace process {

      /** @private */
      inline ProcessIdPtr new_process_id_by_run(const Run* r);

      /** @private */
      inline void deactivate_process_cancelled(const ProcessIdPtr&, const Point*);

      /** @private */
      inline Result<Unit> prepare_process_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline Result<Unit> cancel_process_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline Result<Unit> begin_process_preemption_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline Result<Unit> end_process_preemption_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline bool is_process_cancel_initiated_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline bool is_process_preempted_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline void hold_process_at(double dt,
        process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr &pid,
        const Point* p);

      /** @private */
      inline void interrupt_process_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline bool is_process_interrupted_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline std::optional<double> process_interruption_time_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline Result<Unit> passivate_process_at(process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p);

      /** @private */
      inline Result<Unit> passivate_process_before_at(event::BoxedImpl<Unit>&& fn,
        process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p);

      /** @private */
      inline bool is_process_passivated_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline void reactivate_process_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline Result<Unit> reactivate_process_immediately_at(const ProcessIdPtr& pid, const Point* p);

      /** @private */
      inline Result<Unit> reactivate_processes_immediately_at(std::vector<ProcessIdPtr>&& pids, const Point* p);

      /** @private */
      inline Result<Unit> process_with_priority(int priority,
        process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr &pid,
        const Point* p);

      /** @private */
      inline Result<Unit> spawn_process(process::BoxedContFn<Unit>&& cont_fn,
        const ProcessIdPtr &pid,
        ProcessCancellation cancellation,
        const ProcessIdPtr &child_pid,
        process::BoxedImpl<Unit>&& child_fn,
        const Point* p);
    }
  }
}

#endif /* dvcompute_process_id_h */

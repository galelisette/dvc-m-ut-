/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_generator_primitives_h
#define dvcompute_generator_primitives_h

#include <functional>
#include <random>
#include <vector>
#include <tuple>
#include <cmath>
#include <cassert>
#include <cstddef>

#include "../../dvcompute_ns.h"

#include "result.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace generator {

      namespace primitives {

        /** The boxed representation of the source generator. */
        using BoxedGenerator = std::function<double()>;

        /** Create an uniform random number generator with minimum value 0 and maximum 1. */
        inline BoxedGenerator uniform_generator() {
          std::random_device r;
          std::default_random_engine g(r());
          std::uniform_real_distribution dist(0.0, 1.0);
          return [g{std::move(g)}, dist{std::move(dist)}]() mutable {
            return dist(g);
          };
        }

        /** Create an uniform random number generator by the specified seed. */
        inline BoxedGenerator uniform_generator_by_seed(const std::vector<int>& seed) {
          std::mt19937 g;
          std::seed_seq seq(seed.begin(), seed.end());
          g.seed(seq);
          std::uniform_real_distribution dist(0.0, 1.0);
          return [g{std::move(g)}, dist{std::move(dist)}]() mutable {
            return dist(g);
          };
        }

        /** Create an uniform random number generator by the specified seed. */
        inline BoxedGenerator uniform_generator_by_seed(std::seed_seq& seq) {
          std::mt19937 g;
          g.seed(seq);
          std::uniform_real_distribution dist(0.0, 1.0);
          return [g{std::move(g)}, dist{std::move(dist)}]() mutable {
            return dist(g);
          };
        }

        /** Return the normal number generator with mean 0 and deviation 1. */
        inline BoxedGenerator normal_generator(BoxedGenerator&& g) {
          double next = 0.0;
          bool flag = false;
          return [g{std::move(g)}, next, flag]() mutable {
            if (flag) {
              flag = false;
              return next;
            } else {
              double xi1 = 0.0;
              double xi2 = 0.0;
              double psi = 0.0;
              while (psi >= 1.0 || psi == 0.0) {
                double g1 = g();
                double g2 = g();
                xi1 = 2.0 * g1 - 1.0;
                xi2 = 2.0 * g2 - 1.0;
                psi = xi1 * xi1 + xi2 * xi2;
              }
              psi = std::sqrt(- 2.0 * std::log(psi) / psi);
              flag = true;
              next = xi2 * psi;
              return xi1 * psi;
            }
          };
        }

        /** Generate an uniform random number with the specified minimum and maximum. */
        inline double generate_uniform(const BoxedGenerator& g, double min, double max) {
          return min + g() * (max - min);
        }

        /** Generate an integer uniform random number with the specified minimum and maximum. */
        inline int generate_int_uniform(const BoxedGenerator& g, int min, int max) {
          double x = g();
          double min2 = min - 0.5;
          double max2 = max + 0.5;
          int z = static_cast<int>(std::round(min2 + x * (max2 - min2)));
          if (z < min) {
            return min;
          } else if (z > max) {
            return max;
          } else {
            return z;
          }
        }

        /** Generate the triangular random number by the specified minimum, median and maximum. */
        inline double generate_triangular(const BoxedGenerator& g, double min, double median, double max) {
          double x = g();
          if (x <= (median - min) / (max - min)) {
            return min + std::sqrt((median - min) * (max - min) * x);
          } else {
            return max - std::sqrt((max - median) * (max - min) * (1.0 - x));
          }
        }

        /** Generate a normal random number by the specified generator, mean and deviation. */
        inline double generate_normal(const BoxedGenerator& g, double mu, double nu) {
          return mu + nu * g();
        }

        /** 
         * Generate the lognormal random number derived from a normal distribution with
         * the specified generator, mean and deviation. 
         */
        inline double generate_log_normal(const BoxedGenerator& g, double mu, double nu) {
          return std::exp(mu + nu * g());
        }

        /** Generate the exponential random number by the specified mean. */
        inline double generate_exponential(const BoxedGenerator& g, double mu) {
          return - std::log(g()) * mu;
        }

        /** Return the Erlang random number */
        inline double generate_erlang(const BoxedGenerator& g, double scale, int shape) {
          assert(shape >= 0 && "Negative shape");
          double y = 1.0;
          for (int i = 0; i < shape; ++i) {
            y *= g();
          }
          return - std::log(y) * scale;
        }

        /** Generate the Poisson random number by the specified mean. */
        inline int generate_poisson(const BoxedGenerator& g, double mu) {
          double prob = g();
          double prod = std::exp(- mu);
          int acc = 0;
          while (prob > prod) {
            double prob2 = prob - prod;
            double prod2 = prod * mu / (1.0 + acc);
            int acc2 = 1 + acc;
            prob = prob2;
            prod = prod2;
            acc = acc2;
          }
          return acc;
        }

        /** Generate a binomial random number with the specified probability and number of trials. */
        inline int generate_binomial(const BoxedGenerator& g, double prob, int trials) {
          assert(trials >= 0 && "Negative number of trials");
          int acc = 0;
          for (int i = 0; i < trials; ++i) {
            if (g() <= prob) {
              ++acc;
            }
          }
          return acc;
        }

        /** Generate a random number from the Gamma distribution using Marsaglia and Tsang method. */
        inline double generate_gamma(const BoxedGenerator& gn, const BoxedGenerator& gu, double kappa, double theta) {
          if (kappa <= 0.0) {
            throw PanicResult("The shape parameter (kappa) must be positive!");
          } else if (kappa > 1.0) {
            double d = kappa - 1.0 / 3.0;
            double c = 1.0 / std::sqrt(9.0 * d);
            while (true) {
              double z = gn();
              if (z > - (1.0 / c)) {
                double x = 1.0 + c * z;
                double v = x * x * x;
                double u = gu();
                if (std::log(u) <= 0.5 * z * z + d - d * v + d * std::log(v)) {
                  return d * v * theta;
                }
              }
            }
         } else {
            double x = generate_gamma(gn, gu, 1.0 + kappa, theta);
            double u = gu();
            return x * std::pow(u, 1.0 / kappa);
          }
        }

        /** Generate a random number from the Beta distribution. */
        inline double generate_beta(const BoxedGenerator& gn, const BoxedGenerator& gu, double alpha, double beta) {
          double g1 = generate_gamma(gn, gu, alpha, 1.0);
          double g2 = generate_gamma(gn, gu, beta, 1.0);
          return g1 / (g1 + g2);
        }

        /** Generate a random number from the Weibull distribution. */
        inline double generate_weibull(const BoxedGenerator& g, double alpha, double beta) {
          return beta * std::pow(- std::log(g()), 1.0 / alpha);
        }

        /** Generate a random value from the specified discrete distribution. */
        template<typename T>
        T generate_discrete(const BoxedGenerator& g, const std::vector<std::pair<T, double>>& dpdf) {
          if (dpdf.size() > 0) {
            double x = g();
            double acc = 0.0;
            for (size_t i = 0; i < dpdf.size() - 1; ++i) {
              double p = dpdf[i].second;
              if (x <= acc + p) {
                return dpdf[i].first;
              } else {
                acc += p;
              }
            }
            return dpdf[dpdf.size() - 1].first;
          } else {
            throw new PanicResult("Empty discrete probability density");
          }
        }
      }
    }
  }
}

#endif /* dvcompute_generator_primitives_h */

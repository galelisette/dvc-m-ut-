/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observer_h
#define dvcompute_observer_h

#include <functional>
#include <vector>
#include <type_traits>
#include <utility>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "function_traits.h"
#include "specs.h"
#include "result.h"
#include "types.h"
#include "observer_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace observer {

      // /** @private */
      // template<typename Message, typename Item>
      // using BoxedImpl = std::function<Result<Item>(const Message*, const Point*)>;

      /** @private */
      template<typename Message, typename Item, typename ThenItem, typename Self, typename BindFn>
      class Then {

        Self comp;
        BindFn k;

      public:

        explicit Then(Self &&comp_arg, BindFn &&k_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(BindFn(std::move(k_arg)))) :
          comp(std::move(comp_arg)), k(std::move(k_arg))
        {}

        Then(Then<Message, Item, ThenItem, Self, BindFn> &&other) = default;
        Then<Message, Item, ThenItem, Self, BindFn>& operator=(Then<Message, Item, ThenItem, Self, BindFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Message, Item, ThenItem, Self, BindFn> &other) = default;
        Then<Message, Item, ThenItem, Self, BindFn>& operator=(const Then<Message, Item, ThenItem, Self, BindFn> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<ThenItem> operator()(const Message *msg, const Point *p) const {
          Result<Item> res { comp(msg, p) };
          if (auto *item = get_result_if<Item>(&res)) [[likely]] {
            return k(std::move(*item))(msg, p);
          } else {
            return error_result<ThenItem>(std::move(res));
          }
        }
      };

      /** @private */
      template<typename Message, typename Item>
      class Return {

        Item item;

      public:

        explicit Return(const Item &item_arg) : item(item_arg) {}
        explicit Return(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : item(std::move(item_arg)) {}

        Return(Return<Message, Item> &&other) = default;
        Return<Message, Item>& operator=(Return<Message, Item> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Return(const Return<Message, Item> &other) = default;
        Return<Message, Item>& operator=(const Return<Message, Item> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Message *msg, const Point *p) const {
          return Result<Item>(std::move(item));
        }
      };
    }
  }

  /**
   * Represents an observer that handles the `Message` message but returns
   * a value of the `Item` type.
   */
  template<typename Message, typename Item, typename Impl = internal::observer::BoxedImpl<Message, Item>>
  class Observer;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace observer {

      /** Whether `F` is a function that takes `Arg` and returns an `Observer<Message>` computation. */
      template<typename F, typename Arg, typename Message, typename Item>
      concept ObserverBindFn4 = std::is_invocable_r_v<Observer<Message, Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns an `Observer<Message>` computation. */
      template<typename F, typename Arg, typename Message>
      concept ObserverBindFn3 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires ObserverBindFn4<F, Arg, Message, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns an `Observer<Message>` computation. */
      template<typename F, typename Message, typename Item>
      concept ObserverDelayFn3 = std::is_invocable_r_v<Observer<Message, Item>, F>;

      /** Whether `F` is a function that returns an `Observer<Message>` computation. */
      template<typename F, typename Message>
      concept ObserverDelayFn2 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires ObserverDelayFn3<F, Message, typename std::invoke_result_t<F>::item_type>;
      };

      /** Whether `F` is a function that returns an `Observer<Message>` computation. */
      template<typename F>
      concept ObserverDelayFn1 = requires {
        typename std::invoke_result_t<F>::message_type;
        requires ObserverDelayFn2<F, typename std::invoke_result_t<F>::message_type>;
      };

      /** Whether `F` is a function that takes the `Message` and `Point` pointers but then returns a `Result` value. */
      template<typename F, typename Traits, typename FirstArg, typename Message, typename Item>
      concept ObserverConsFn5 = std::is_invocable_r_v<Result<Item>, F, const Message*, const Point*>;

      /** Whether `F` is a function that takes the `Message` and `Point` pointers but then returns a `Result` value. */
      template<typename F, typename Traits, typename FirstArg, typename Message>
      concept ObserverConsFn4 = requires {
        typename std::invoke_result_t<F, const Message*, const Point*>::item_type;
        requires ObserverConsFn5<F, Traits, FirstArg, Message, typename std::invoke_result_t<F, const Message*, const Point*>::item_type>;
      };

      /** Whether `F` is a function that takes the `Message` and `Point` pointers but then returns a `Result` value. */
      template<typename F, typename Traits, typename FirstArg>
      concept ObserverConsFn3 = requires {
        requires ObserverConsFn4<F, Traits, FirstArg, typename std::remove_const_t<std::remove_pointer_t<FirstArg>>>;
      };

      /** Whether `F` is a function that takes the `Message` and `Point` pointers but then returns a `Result` value. */
      template<typename F, typename Traits>
      concept ObserverConsFn2 = requires {
        typename Traits::template arg<0>::type;
        requires ObserverConsFn3<F, Traits, typename Traits::template arg<0>::type>;
      };

      /** Whether `F` is a function that takes the `Message` and `Point` pointers but then returns a `Result` value. */
      template<typename F>
      concept ObserverConsFn1 = requires {
        typename function_traits<F>;
        requires ObserverConsFn2<F, function_traits<F>>;
      };
    }
  }

  /** Whether `Self` is actually an `Observer<Message, Item>` computation. */
  template<typename Self, typename Message, typename Item>
  concept ObserverLike = std::is_convertible_v<Self, Observer<Message, Item>>;

  /** Whether `F` is a function that takes `Arg` and returns an `Observer<Message>` computation. */
  template<typename F, typename Arg, typename Message>
  concept ObserverBindFn = internal::observer::ObserverBindFn3<F, Arg, Message>;

  /** Whether `F` is a function that returns an `Observer<Message>` computation. */
  template<typename F>
  concept ObserverDelayFn = internal::observer::ObserverDelayFn1<F>;

  /** Whether `F` is a function that takes the `Message` and `Point` pointers but then returns a `Result` value. */
  template<typename F>
  concept ObserverConsFn = internal::observer::ObserverConsFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  /**
   * Represents an observer that handles the `Message` message but returns
   * a value of the `Item` type.
   */
  template<typename Message, typename Item, typename Impl>
  class Observer {

    Impl impl;

  public:

    using message_type = Message;
    using item_type = Item;

    explicit Observer(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) : impl(std::move(impl_arg)) {}

    Observer(Observer<Message, Item, Impl>&& other) = default;
    Observer<Message, Item, Impl>& operator=(Observer<Message, Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Observer(const Observer<Message, Item, Impl>& other) = default;
    Observer<Message, Item, Impl>& operator=(const Observer<Message, Item, Impl>& other) = default;

    /** Copy the computation. */
    Observer<Message, Item, Impl> copy() const {
      return Observer<Message, Item, Impl>(*this);
    }

#endif

    /** Call the computation. */
    DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Message *msg, const Point *p) const {
      return impl(msg, p);
    }

    /**
     * Bind this with a continuation and return the resulting compound `Observer<Message, ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Observer<Message, ThenItem>` computation.
     */
    template<typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && requires ObserverBindFn<BindFn, Item, Message> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::observer::Then<Message, Item, ThenItem, Impl, BindFn>;
      return Observer<Message, ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Bind this with a continuation and return the resulting compound `Observer<Message, ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Observer<Message, ThenItem>` computation.
     */
    template<typename BindFn>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && requires ObserverBindFn<BindFn, Item, Message> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::observer::Then<Message, Item, ThenItem, Impl, BindFn>;
      return Observer<Message, ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Map the computed value and return the resulting compound `Observer<Message, MapItem>`
     * computation, where `MapFn` is a function that takes an `Item` and then transforms it
     * to `MapItem`.
     */
    template<typename MapFn>
    DVCOMPUTE_ALWAYS_INLINE auto map(MapFn&& f) && {
      return std::move(*this).and_then([f{std::move(f)}](Item&& item) mutable {
        using MapItem = std::invoke_result_t<MapFn, Item&&>;
        using MapImpl = internal::observer::Return<Message, MapItem>;
        return Observer<Message, MapItem, MapImpl>(MapImpl(f(std::move(item))));
      });
    }

    /** Convert this to a boxed representation. */
    Observer<Message, Item> into_boxed() && {
      using ResultImpl = internal::observer::BoxedImpl<Message, Item>;
      return Observer<Message, Item>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Observer<Message, Item>() && {
      using ResultImpl = internal::observer::BoxedImpl<Message, Item>;
      return Observer<Message, Item>(ResultImpl(std::move(impl)));
    }
  };

  /** Create an `Observer` computation by the specified pure value. */
  template<typename Message, typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline ObserverLike<Message, Item> auto pure_observer(const Item& item) {
#else
  inline auto pure_observer(const Item& item) {
#endif
    using ResultImpl = internal::observer::Return<Message, Item>;
    return Observer<Message, Item, ResultImpl>(ResultImpl(item));
  }

  /** Create an `Observer` computation by the specified pure value. */
  template<typename Message, typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline ObserverLike<Message, Item> auto pure_observer(Item&& item) {
#else
  inline auto pure_observer(Item&& item) {
#endif
    using ResultImpl = internal::observer::Return<Message, Item>;
    return Observer<Message, Item, ResultImpl>(ResultImpl(std::move(item)));
  }

  /**
   * Delay the `Observer` computation and return the resulting compound `Observer`
   * computation, where `DelayFn` is a function that returns an intermediate `Observer`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_observer(DelayFn&& f) requires ObserverDelayFn<DelayFn> {
#else
  inline auto delay_observer(DelayFn&& f) {
#endif
    using Message = typename std::invoke_result_t<DelayFn>::message_type;
    return pure_observer<Message>(Unit()).and_then([f{std::move(f)}](Unit&& unit) {
      return f();
    });
  }

  /**
   * Construct a new `Observer<Message, Item>` computation by the specified closure `ConsFn`,
   * which must be a function of the `Message` and `Point` pointers, respectively, that
   * returns an `Item`.
   */
  template<typename ConsFn, typename StdFn = decltype(std::function(std::forward<ConsFn>(std::declval<ConsFn>())))>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_observer(ConsFn&& f) requires ObserverConsFn<StdFn> {
#else
  inline auto cons_observer(ConsFn&& f) {
#endif
    using Traits = function_traits<StdFn>;
    using FirstArg = typename Traits::template arg<0>::type;
    using Message = typename std::remove_const_t<std::remove_pointer_t<FirstArg>>;
    using Item = typename std::invoke_result_t<ConsFn, const Message*, const Point*>::item_type;
    auto fn = [f{std::move(f)}](const Message *msg, const Point *p) { return f(msg, p); };
    return Observer<Message, Item, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations, where the final computation has
   * type `Observer<Message, std::vector<Item>>`.
   */
  template<typename Message, typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ObserverLike<Message, std::vector<Item>> auto observer_sequence(std::vector<Observer<Message, Item, Impl>>&& comps) {
#else
  auto observer_sequence(std::vector<Observer<Message, Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Message *msg, const Point *p) {
      std::vector<Item> result;
      for (auto& comp : comps) {
        Result<Item> res { comp(msg, p) };
        if (auto item = get_result_if<Item>(&res)) [[likely]] {
          result.emplace_back(std::move(*item));
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<std::vector<Item>>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<std::vector<Item>>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<std::vector<Item>>(result);
    };
    return Observer<Message, std::vector<Item>, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations for performing side effects,
   * when the intermediate results are discarded, but the final computation
   * has type `Observer<Message, Unit>`.
   */
  template<typename Message, typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ObserverLike<Message, Unit> auto observer_sequence_(std::vector<Observer<Message, Item, Impl>>&& comps) {
#else
  auto observer_sequence_(std::vector<Observer<Message, Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Message *msg, const Point *p) {
      for (auto& comp : comps) {
        Result<Item> res { comp(msg, p) };
        if (get_result_if<Item>(&res)) [[likely]] {
          continue;
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<Unit>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<Unit>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<Unit>(Unit());
    };
    return Observer<Message, Unit, decltype(fn)>(std::move(fn));
  }
}

#endif /* dvcompute_observer_h */

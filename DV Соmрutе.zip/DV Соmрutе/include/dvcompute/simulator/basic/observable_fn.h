/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_fn_h
#define dvcompute_observable_fn_h

#include <functional>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "types.h"
#include "specs.h"
#include "result.h"
#include "event.h"
#include "disposable.h"
#include "observer.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace observable {

#ifndef DVCOMPUTE_COPY_CTOR

      // /** @private */
      // template<typename Message>
      //   using BoxedImpl = std::function<Event<Disposable<>>(Observer<Message, Unit>&&)>;

      /** This is a vtable. */
      template<typename Message>
      struct BoxedImplVTable {

        typedef void (*DestructFn)(char*);
        typedef Event<Disposable<>> (*CallFn)(char*, Observer<Message, Unit>&&);

        DestructFn destruct_fn;
        CallFn call_fn;
      };

      template<typename Fn>
      static void boxed_impl_destruct(char* data) noexcept {
        delete reinterpret_cast<Fn*>(data);
      }

      template<typename Fn, typename Message>
      static Event<Disposable<>> boxed_impl_call(char* data, Observer<Message, Unit>&& obs) {
        return std::move(*reinterpret_cast<Fn*>(data)).operator()(std::move(obs));
      }

      /** This is a vtable definition for closures. */
      template<typename Fn, typename Message>
      struct BoxedImplVTableDef {

        static constexpr BoxedImplVTable<Message> instance {
          &boxed_impl_destruct<Fn>,
          &boxed_impl_call<Fn, Message>
        };
      };

      /** @private */
      template<typename Message>
      class BoxedImpl {

        const BoxedImplVTable<Message>* vtable;
        char* data;

      public:

        ~BoxedImpl() {
          if (data != nullptr) {
            vtable->destruct_fn(data);
          }
        }

        explicit BoxedImpl() noexcept :
          vtable(nullptr),
          data(nullptr)
        {}

        template<typename Fn>
        BoxedImpl(Fn&& fn) :
          vtable(&BoxedImplVTableDef<Fn, Message>::instance),
          data(reinterpret_cast<char*>(new Fn(std::move(fn))))
        {}

        BoxedImpl(BoxedImpl&& other) noexcept :
          vtable(other.vtable),
          data(other.data)
        {
          other.data = nullptr;
        }

        BoxedImpl& operator=(BoxedImpl&& other) noexcept {
          BoxedImpl tmp { std::move(other) };
          swap(tmp);
          return *this;
        }

        operator bool() const noexcept {
          return data != nullptr;
        }

        Event<Disposable<>> operator()(Observer<Message, Unit>&& obs) && {
          return vtable->call_fn(data, std::move(obs));
        }

        void swap(BoxedImpl& other) noexcept {
          std::swap(vtable, other.vtable);
          std::swap(data, other.data);
        }
      };

#else

      // /** @private */
      // template<typename Message>
      //   using BoxedImpl = std::function<Event<Disposable<>>(Observer<Message, Unit>&&)>;

      /** This is a vtable. */
      template<typename Message>
      struct BoxedImplVTable {

        typedef void (*DestructFn)(char*);
        typedef char* (*CloneFn)(const char*);
        typedef Event<Disposable<>> (*CallFn)(char*, Observer<Message, Unit>&&);

        DestructFn destruct_fn;
        CloneFn clone_fn;
        CallFn call_fn;
      };

      template<typename Fn>
      static void boxed_impl_destruct(char* data) noexcept {
        delete reinterpret_cast<Fn*>(data);
      }

      template<typename Fn>
      static char* boxed_impl_clone(const char* data) {
        return reinterpret_cast<char*>(new Fn(*reinterpret_cast<const Fn*>(data)));
      }

      template<typename Fn, typename Message>
      static Event<Disposable<>> boxed_impl_call(char* data, Observer<Message, Unit>&& obs) {
        return std::move(*reinterpret_cast<Fn*>(data)).operator()(std::move(obs));
      }

      /** This is a vtable definition for closures. */
      template<typename Fn, typename Message>
      struct BoxedImplVTableDef {

        static constexpr BoxedImplVTable<Message> instance {
          &boxed_impl_destruct<Fn>,
          &boxed_impl_clone<Fn>,
          &boxed_impl_call<Fn, Message>
        };
      };

      /** @private */
      template<typename Message>
      class BoxedImpl {

        const BoxedImplVTable<Message>* vtable;
        char* data;

      public:

        ~BoxedImpl() {
          if (data != nullptr) {
            vtable->destruct_fn(data);
          }
        }

        explicit BoxedImpl() noexcept :
          vtable(nullptr),
          data(nullptr)
        {}

        template<typename Fn>
        BoxedImpl(Fn fn) :
          vtable(&BoxedImplVTableDef<Fn, Message>::instance),
          data(reinterpret_cast<char*>(new Fn(std::move(fn))))
        {}

        BoxedImpl(const BoxedImpl& other) :
          vtable(other.vtable),
          data(nullptr)
        {
          if (other.data != nullptr) {
            data = vtable->clone_fn(other.data);
          }
        }

        BoxedImpl(BoxedImpl&& other) noexcept :
          vtable(other.vtable),
          data(other.data)
        {
          other.data = nullptr;
        }

        BoxedImpl& operator=(const BoxedImpl& other) {
          BoxedImpl tmp(other);
          swap(tmp);
          return *this;
        }

        BoxedImpl& operator=(BoxedImpl&& other) noexcept {
          BoxedImpl tmp { std::move(other) };
          swap(tmp);
          return *this;
        }

        operator bool() const noexcept {
          return data != nullptr;
        }

        Event<Disposable<>> operator()(Observer<Message, Unit>&& obs) && {
          return vtable->call_fn(data, std::move(obs));
        }

        void swap(BoxedImpl& other) noexcept {
          std::swap(vtable, other.vtable);
          std::swap(data, other.data);
        }
      };

#endif /* DVCOMPUTE_COPY_CTOR */

    }
  }
}

#endif /* dvcompute_observable_fn_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_strategy_h
#define dvcompute_strategy_h

#include <deque>
#include <functional>
#include <optional>
#include <map>
#include <tuple>

#include "../../dvcompute_ns.h"
#include "../utils/ordered_int_map.h"
#include "../utils/list.h"
#include "../utils/queue.h"

#include "specs.h"
#include "ref.h"

namespace DVCOMPUTE_NS {

  /** A marker denoting that the priorities are not supported. */
  class UndefinedPriority {};

  /** A small designator that the operation is not permitted. */
  class UnsupportedQueueStorage {};

  /**
   * The queue storage either supports `push`, or `push_with_priority`, but
   * it cannot support the both methods simulateneously.
   */
  template<typename Item, typename Priority = UndefinedPriority>
  class QueueStorage {
  public:

    virtual ~QueueStorage() {}

    /** Test whether the storage is empty. */
    virtual bool empty(const Point* p) const = 0;

    /** Pop the front item. */
    virtual std::optional<Item> pop(const Point* p) = 0;

    /** Push an item, or throw `UnsupportedQueueStorage` error if only `push_with_priority` is supported. */
    virtual void push(Item&& item, const Point* p) = 0;
    
    /** Push an item with the specified priority, or throw `UnsupportedQueueStorage` error if only `push` is supported. */
    virtual void push_with_priority(const Priority& priority, Item&& item, const Point* p) = 0;

    /** Try to remove an item satisfying the specified predicate and return the item removed. */
    virtual std::optional<Item> remove_by(std::function<bool (const Item&)>&& pred, const Point* p) = 0; 

    /** Detect whether there is an element satisfying the specified predicate in the queue. */
    virtual bool exists(std::function<bool (const Item&)>&& pred, const Point* p) const = 0;
    
    /** Find an element satisfying the specified predicate or return `nullptr`. */
    virtual const Item* find(std::function<bool (const Item&)>&& pred, const Point* p) const = 0;
  };

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

  /** A basic queue storage. */
  template<typename Item>
  class PriorityStorage : public QueueStorage<Item, int> {

    /** The underlying queue. */
    std::map<int, std::deque<Item>> queue;

    /** Whether the FCFS queue. */
    bool fcfs;

  public:

    PriorityStorage(bool fcfs_arg) : fcfs(fcfs_arg) {}

    PriorityStorage(const PriorityStorage&) = delete;
    PriorityStorage& operator=(const PriorityStorage&) = delete;

    PriorityStorage(PriorityStorage&&) = delete;
    PriorityStorage& operator=(PriorityStorage&&) = delete;

    bool empty(const Point* p) const override {
      return queue.empty();
    }

    std::optional<Item> pop(const Point* p) override {
      auto it = queue.begin();
      if (it != queue.end()) {
        std::deque<Item> &deque = it->second;
        
        if (fcfs) {
          std::optional<Item> item { std::move(deque.front()) };
          deque.pop_front();
          if (deque.empty()) {
            queue.erase(it);
          }
          return item;

        } else {
          std::optional<Item> item { std::move(deque.back()) };
          deque.pop_back();
          if (deque.empty()) {
            queue.erase(it);
          }
          return item;
        }

      } else {
        return std::nullopt;
      }
    }

    void push(Item&& item, const Point* p) override {
      throw UnsupportedQueueStorage();
    }
    
    void push_with_priority(const int& priority, Item&& item, const Point* p) override {
      int key = - priority;
      auto it = queue.find(key);
      if (it != queue.end()) {
        std::deque<Item> &deque = it->second;
        deque.emplace_back(std::move(item));

      } else {
        std::deque<Item> deque;
        deque.emplace_back(std::move(item));
        queue.emplace(std::move(key), std::move(deque));
      }
    }

    std::optional<Item> remove_by(std::function<bool (const Item&)>&& pred, const Point* p) override {
      if (!fcfs) {
        throw UnsupportedQueueStorage();
      } else {
        for (auto it = queue.begin(); it != queue.end(); ++it) {
          std::deque<Item> &deque = it->second;
          auto x { remove_from_deque(deque, pred, p) };
          if (x.has_value()) {
            if (deque.empty()) {
              queue.erase(it);
            }
            return x;
          }
        }
        return std::nullopt;
      }
    }

    bool exists(std::function<bool (const Item&)>&& pred, const Point* p) const override {
      if (!fcfs) {
        throw UnsupportedQueueStorage();
      } else {
        for (auto it = queue.begin(); it != queue.end(); ++it) {
          const std::deque<Item> &deque = it->second;
          if (exists_in_deque(deque, pred, p)) {
            return true;
          }
        }
        return false;
      }
    }
    
    const Item* find(std::function<bool (const Item&)>&& pred, const Point* p) const override {
      if (!fcfs) {
        throw UnsupportedQueueStorage();
      } else {
        for (auto it = queue.begin(); it != queue.end(); ++it) {
          const std::deque<Item> &deque = it->second;
          auto *x = find_in_deque(deque, pred, p);
          if (x != nullptr) {
            return x;
          }
        }
        return nullptr;
      }
    }

  private:

    /// Remove from the deque an item satisfying the predicate.
    std::optional<Item> remove_from_deque(std::deque<Item>& deque, const std::function<bool (const Item&)>& pred, const Point* p) {
      if (!fcfs) {
        throw UnsupportedQueueStorage();
      } else {
        for (auto it = deque.begin(); it != deque.end(); ++it) {
          if (pred(*it)) {
            std::optional<Item> item { std::move(*it) };
            deque.erase(it);
            return item;
          }
        }
        return std::nullopt;
      }
    }

    /// Test whether in the deque there is an item satisfying the predicate.
    bool exists_in_deque(const std::deque<Item>& deque, const std::function<bool (const Item&)>& pred, const Point* p) const {
      if (!fcfs) {
        throw UnsupportedQueueStorage();
      } else {
        for (auto it = deque.begin(); it != deque.end(); ++it) {
          if (pred(*it)) {
            return true;
          }
        }
        return false;
      }
    }

    /// Find an item satisfying the predicate in the deque.
    const Item* find_in_deque(const std::deque<Item>& deque, const std::function<bool (const Item&)>& pred, const Point* p) const {
      if (!fcfs) {
        throw UnsupportedQueueStorage();
      } else {
        for (auto it = deque.begin(); it != deque.end(); ++it) {
          if (pred(*it)) {
            return it.operator->();
          }
        }
        return nullptr;
      }
    }
  };

  /** The priority FCFS queue storage. */
  template<typename Item>
  class PriorityFCFSStorage : public PriorityStorage<Item> {
  public:
    PriorityFCFSStorage() : PriorityStorage<Item>(true) {}
  };

  /** The priority LCFS queue storage. */
  template<typename Item>
  class PriorityLCFSStorage : public PriorityStorage<Item> {
  public:
    PriorityLCFSStorage() : PriorityStorage<Item>(false) {}
  };

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

  /** The priority FCFS queue storage. */
  template<typename Item>
  class PriorityFCFSStorage : public QueueStorage<Item, int> {

    template<typename V>
      using OrderedIntMap = DVCOMPUTE_NS::utils::im::OrderedIntMap<int, V>;

    template<typename T>
      using Queue = DVCOMPUTE_NS::utils::im::Queue<T>;

    /** The underlying queue. */
    Ref<OrderedIntMap<Queue<Item>>> queue;

  public:

    PriorityFCFSStorage() : queue(OrderedIntMap<Queue<Item>>()) {}

    PriorityFCFSStorage(const PriorityFCFSStorage&) = delete;
    PriorityFCFSStorage& operator=(const PriorityFCFSStorage&) = delete;

    PriorityFCFSStorage(PriorityFCFSStorage&&) = delete;
    PriorityFCFSStorage& operator=(PriorityFCFSStorage&&) = delete;

    bool empty(const Point* p) const override {
      return queue.read_at(p).empty();
    }

    std::optional<Item> pop(const Point* p) override {
      const auto &q = queue.read_at(p);
      auto it = q.find_min();

      if (it != q.end()) {
        int key = it.key();
        const Queue<Item> &deque = it.value();
        std::optional<Item> item { deque.front() };
        Queue<Item> next_deque { deque.pop_front() };

        if (next_deque.empty()) {
          queue.write_at(q.erase(key), p);
        } else {
          queue.write_at(q.emplace(key, std::move(next_deque)), p);
        }

        return item;

      } else {
        return std::nullopt;
      }
    }

    void push(Item&& item, const Point* p) override {
      throw UnsupportedQueueStorage();
    }
    
    void push_with_priority(const int& priority, Item&& item, const Point* p) override {
      int key = - priority;
      const auto &q = queue.read_at(p);
      auto it = q.find(key);

      if (it != q.end()) {
        const Queue<Item> &deque = it.value();
        queue.write_at(q.emplace(key, deque.push_back(item)), p);

      } else {
        Queue<Item> deque;
        queue.write_at(q.emplace(key, deque.push_back(item)), p);
      }
    }

    std::optional<Item> remove_by(std::function<bool (const Item&)>&& pred, const Point* p) override {
      auto x { remove_and_find_key(std::move(pred), p) };
      if (x.has_value()) {
        int key = std::get<0>(x.value());
        std::optional<Item> item { std::move(std::get<1>(x.value())) };
        auto &deque = std::get<2>(x.value());
        const auto &q = queue.read_at(p);

        if (deque.empty()) {
          queue.write_at(q.erase(key), p);
        } else {
          queue.write_at(q.emplace(key, std::move(deque)), p);
        }

        return item;

      } else {
        return std::nullopt;
      }
    }

    bool exists(std::function<bool (const Item&)>&& pred, const Point* p) const override {
      auto const &q = queue.read_at(p);
      auto fn = [pred{std::move(pred)}](int k, const Queue<Item>& deque) {
        if (deque.exists(pred)) {
          return true;
        } else {
          return false;
        }
      };

      return q.traverse(fn, false);
    }
    
    const Item* find(std::function<bool (const Item&)>&& pred, const Point* p) const override {
      auto const &q = queue.read_at(p);
      auto fn = [pred{std::move(pred)}](int k, const Queue<Item>& deque) -> const Item* {
        auto it = deque.find(pred);
        if (it != deque.end()) {
          return it.get();
        } else {
          return nullptr;
        }
      };
      const Item* default_result = nullptr;

      return q.traverse_ptr(fn, default_result);
    }

  private:

    /// Remove an item satisfying the predicate and return the corresponding key and new deque.
    std::optional<std::tuple<int, Item, Queue<Item>>> remove_and_find_key(std::function<bool (const Item&)>&& pred, const Point* p) {
      const auto &q = queue.read_at(p);
      auto fn = [pred{std::move(pred)}](int k, const Queue<Item>& deque) -> std::optional<std::tuple<int, Item, Queue<Item>>> {
        auto x { deque.erase_by(pred) };
        if (x.has_value()) {
          return std::make_tuple(k, std::get<0>(x.value()), std::get<1>(x.value()));
        } else {
          return std::nullopt;
        }
      };
      std::optional<std::tuple<int, Item, Queue<Item>>> default_result = std::nullopt;

      return q.traverse_opt(fn, default_result);
    }
  };

  /** The priority LCFS queue storage. */
  template<typename Item>
  class PriorityLCFSStorage : public QueueStorage<Item, int> {

    template<typename V>
      using OrderedIntMap = DVCOMPUTE_NS::utils::im::OrderedIntMap<int, V>;

    template<typename T>
      using List = DVCOMPUTE_NS::utils::im::List<T>;

    /** The underlying queue. */
    Ref<OrderedIntMap<List<Item>>> queue;

  public:

    PriorityLCFSStorage() : queue(OrderedIntMap<List<Item>>()) {}

    PriorityLCFSStorage(const PriorityLCFSStorage&) = delete;
    PriorityLCFSStorage& operator=(const PriorityLCFSStorage&) = delete;

    PriorityLCFSStorage(PriorityLCFSStorage&&) = delete;
    PriorityLCFSStorage& operator=(PriorityLCFSStorage&&) = delete;

    bool empty(const Point* p) const override {
      return queue.read_at(p).empty();
    }

    std::optional<Item> pop(const Point* p) override {
      const auto &q = queue.read_at(p);
      auto it = q.find_min();

      if (it != q.end()) {
        int key = it.key();
        const List<Item> &deque = it.value();
        std::optional<Item> item { deque.head() };
        List<Item> next_deque { deque.tail() };

        if (next_deque.empty()) {
          queue.write_at(q.erase(key), p);
        } else {
          queue.write_at(q.emplace(key, std::move(next_deque)), p);
        }

        return item;

      } else {
        return std::nullopt;
      }
    }

    void push(Item&& item, const Point* p) override {
      throw UnsupportedQueueStorage();
    }
    
    void push_with_priority(const int& priority, Item&& item, const Point* p) override {
      int key = - priority;
      const auto &q = queue.read_at(p);
      auto it = q.find(key);

      if (it != q.end()) {
        const List<Item> &deque = it.value();
        queue.write_at(q.emplace(key, List<Item>(item, deque)), p);

      } else {
        List<Item> deque;
        queue.write_at(q.emplace(key, List<Item>(item, deque)), p);
      }
    }

    std::optional<Item> remove_by(std::function<bool (const Item&)>&& pred, const Point* p) override {
      throw UnsupportedQueueStorage();
    }

    bool exists(std::function<bool (const Item&)>&& pred, const Point* p) const override {
      throw UnsupportedQueueStorage();
    }
    
    const Item* find(std::function<bool (const Item&)>&& pred, const Point* p) const override {
      throw UnsupportedQueueStorage();
    }
  };

#else
#error "Unknown simulation mode"
#endif /* DVCOMPUTE_SEQUENTIAL || DVCOMPUTE_DISTRIBUTED || DVCOMPUTE_CONSERVATIVE || DVCOMPUTE_BRANCHED */

  /** 
   * Defines a priority queue strategy based on the FCFS (a.k.a. FIFO) strategy.
   * It means "First Came - First Served" for items that have the same priority.
   */
  class PriorityFCFSStrategy {
  public:

    /** Create a new storage. */
    template<typename Item>
    QueueStorage<Item, int>* create_storage() const {
      return new PriorityFCFSStorage<Item>();
    }
  };

  /** 
   * Defines a priority queue strategy based on the LCFS (a.k.a. LIFO) strategy.
   * It means "Last Came - First Served" for items that have the same priority.
   */
  class PriorityLCFSStrategy {
  public:

    /** Create a new storage. */
    template<typename Item>
    QueueStorage<Item, int>* create_storage() const {
      return new PriorityLCFSStorage<Item>();
    }
  };
}

#endif /* dvcompute_strategy_h */

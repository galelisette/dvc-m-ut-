/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_source_h
#define dvcompute_observable_source_h

#include <functional>
#include <tuple>
#include <memory>
#include <optional>

#include "../../dvcompute_ns.h"

#include "types.h"
#include "disposable.h"
#include "observer.h"
#include "observable.h"
#include "ref.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace observable_source {

      /** @private */
      template<typename Message>
      class ObserverList {
      public:

        typedef SharedPtr<Observer<Message, Unit>> car_type;
        typedef SharedPtr<ObserverList<Message>> cdr_type;
        typedef std::pair<car_type, cdr_type> cell_type;

      private:

        std::optional<cell_type> cell;

      public:

        bool empty() const noexcept {
          return !cell.has_value();
        }

        explicit ObserverList() noexcept : cell(std::nullopt) {}

        explicit ObserverList(const cell_type& cell_arg) : cell(cell_arg) {}

        ObserverList(const ObserverList<Message>&) = default;
        ObserverList(ObserverList<Message>&&) = default;

        ObserverList& operator=(const ObserverList<Message>&) = default;
        ObserverList& operator=(ObserverList<Message>&&) = default;

        /** Trigger the specified message at the current modeling time point. */
        Result<Unit> trigger_at(const Message *msg, const Point *p) const {
          const ObserverList *curr = this;
          while (curr->cell.has_value()) {
            const cell_type &x = curr->cell.value();
            const car_type &car = x.first;
            const cdr_type &cdr = x.second;
            Result<Unit> res { car->operator()(msg, p) };
            if (get_result_if<Unit>(&res)) {
              curr = cdr.get();
            } else {
              return error_result<Unit>(std::move(res));
            }
          }
          return Result<Unit>(Unit());
        }

        /** Add a new observer to the list and return the resulting list. */
        static ObserverList<Message> cons(const car_type &car, const cdr_type &cdr) {
          return ObserverList(cell_type(car, cdr));
        }

        /** Remove the specified observer from the list and return a new list. */
        ObserverList<Message> remove(const car_type &observer) const {
          ObserverList<Message> first;
          const ObserverList *curr = this;

          while (true) {
            if (curr->empty()) {
              return *this;
            } else {
              const cell_type &x = curr->cell.value();
              const car_type &car = x.first;
              const cdr_type &cdr = x.second;
              if (car.get() == observer.get()) {
                return first.append_rev(cdr);
              } else {
                first = ObserverList(cell_type(car, mk_shared(ObserverList(first))));
                curr = cdr.get();
              }
            }
          }
        }

      private:

        /** Append the reserved observers to the list tail. */
        ObserverList<Message> append_rev(const cdr_type &tail) const {
          cdr_type acc = tail;
          const ObserverList *curr = this;

          while (true) {
            if (curr->empty()) { // it is almost impossible
              return *acc;
            } else {
              const cell_type &x = curr->cell.value();
              const car_type &car = x.first;
              const cdr_type &cdr = x.second;
              if (cdr->empty()) {
                return ObserverList(cell_type(car, acc));
              } else {
                curr = cdr.get();
                acc = mk_shared(ObserverList(cell_type(car, acc)));
              }
            }
          }
        }
      };

      /** @private */
      template<typename Message>
      class Publish {

        typedef Observer<Message, Unit> observer_type;
        typedef ObserverList<Message> list_type;

        /** The list of observers. */
        WeakPtr<Ref<list_type>> weak_observers;

      public:

        explicit Publish(const WeakPtr<Ref<list_type>>& weak_observers_arg) noexcept : weak_observers(weak_observers_arg) {}
        explicit Publish(WeakPtr<Ref<list_type>>&& weak_observers_arg) noexcept : weak_observers(std::move(weak_observers_arg)) {}

        Publish(const Publish<Message> &other) = default;
        Publish(Publish<Message> &&other) = default;

        Publish<Message>& operator=(const Publish<Message> &other) = default;
        Publish<Message>& operator=(Publish<Message> &&other) = default;

        template<typename Obs>
        auto operator()(Obs &&obs) && {
          SharedPtr<observer_type> observer { mk_shared(observer_type(std::move(obs).operator Observer<Message, Unit>())) };
          return cons_event([weak_observers{weak_observers}, observer{std::move(observer)}](const Point *p) {
            RefPtr<list_type> observers(weak_observers.lock());
            if (observers) {
              WeakPtr<observer_type> weak_observer(observer);

              auto dispose = [weak_observers, weak_observer](const Point *p) {
                RefPtr<list_type> observers(weak_observers.lock());
                if (observers) {
                  SharedPtr<observer_type> observer(weak_observer.lock());
                  if (observer.get() != nullptr) {
                    const list_type &observers0 = observers->read_at(p);
                    observers->write_at(observers0.remove(observer), p);
                  }
                  return Result<Unit>(Unit());
                } else {
                  return Result<Unit>(Unit());
                }
              };

              const auto& xs = observers->read_at(p);
              SharedPtr<list_type> observers0 { mk_shared(list_type(xs)) };
              observers->write_at(ObserverList<Message>::cons(observer, observers0), p);

              return Result<Disposable<>>(Disposable<>(std::move(dispose)));

            } else {
              return Result<Disposable<>>(empty_disposable().operator Disposable<>());
            }
          });
        }
      };
    }
  }

  /** The source of `Observable` computations. */
  template<typename Message>
  class ObservableSource {

    typedef internal::observable_source::ObserverList<Message> list_type;

    /** The list of observers. */
    RefPtr<list_type> observers;

  public:

    explicit ObservableSource(): observers(mk_shared(Ref<list_type>(list_type()))) {}

    ObservableSource(const ObservableSource<Message> &) = delete;
    ObservableSource& operator=(const ObservableSource<Message> &) = delete;

    ObservableSource(ObservableSource<Message> &&) = default;
    ObservableSource& operator=(ObservableSource<Message> &&) = default;

    /** Trigger the message at the specified modeling time point. */
    Result<Unit> trigger_at(const Message *msg, const Point *p) const {
      list_type xs(observers->read_at(p));
      return xs.trigger_at(msg, p);
    }

    /** Triger the message within the `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    EventLike<Unit> auto trigger(Message&& msg) const {
#else
    auto trigger(Message&& msg) const {
#endif
      auto fn = [observers{observers}, msg{std::move(msg)}](const Point *p) {
        list_type xs(observers->read_at(p));
        return xs.trigger_at(&msg, p);
      };
      return Event<Unit, decltype(fn)>(std::move(fn));
    }

    /** Publish the source as an `Observable<Message>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    ObservableLike<Message> auto publish() const noexcept {
#else
    auto publish() const noexcept {
#endif
      using ResultImpl = internal::observable_source::Publish<Message>;
      return Observable<Message, ResultImpl>(ResultImpl(WeakPtr<Ref<list_type>>(observers)));
    }
  };
}

#endif /* dvcompute_observable_source_sh */

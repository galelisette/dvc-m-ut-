/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_event_h
#define dvcompute_event_h

#include <functional>
#include <vector>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "specs.h"
#include "result.h"
#include "parameter.h"
#include "simulation.h"
#include "event_queue.h"
#include "event_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace event {

      // /** @private */
      // template<typename Item>
      //   using BoxedImpl = std::function<Result<Item>(const Point*)>;

      /** @private */
      template<typename Item, typename ThenItem, typename Self, typename BindFn>
      class Then {

        Self comp;
        BindFn k;

      public:

        explicit Then(Self &&comp_arg, BindFn &&k_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(BindFn(std::move(k_arg)))) :
          comp(std::move(comp_arg)), k(std::move(k_arg))
        {}

        Then(Then<Item, ThenItem, Self, BindFn> &&other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(Then<Item, ThenItem, Self, BindFn> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Item, ThenItem, Self, BindFn> &other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(const Then<Item, ThenItem, Self, BindFn> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<ThenItem> operator()(const Point *p) && {
          Result<Item> res { std::move(comp)(p) };
          if (auto *item = get_result_if<Item>(&res)) [[likely]] {
            return k(std::move(*item))(p);
          } else {
            return error_result<ThenItem>(std::move(res));
          }
        }
      };

      /** @private */
      template<typename Item>
      class Return {

        Item item;

      public:

        explicit Return(const Item &item_arg) : item(item_arg) {}
        explicit Return(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) :
          item(std::move(item_arg))
        {}

        Return(Return<Item> &&other) = default;
        Return<Item>& operator=(Return<Item> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Return(const Return<Item> &other) = default;
        Return<Item>& operator=(const Return<Item> &other) = default;

#endif

        DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Point *p) && {
          return Result<Item>(std::move(item));
        }
      };
    }
  }

  /** Represents an event handler. */
  template<typename Item, typename Impl = internal::event::BoxedImpl<Item>>
  class Event;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace event {

      /** Whether `F` is a function that takes `Arg` and returns an `Event` computation. */
      template<typename F, typename Arg, typename Item>
      concept EventBindFn3 = std::is_invocable_r_v<Event<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns an `Event` computation. */
      template<typename F, typename Arg>
      concept EventBindFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires EventBindFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns an `Event` computation. */
      template<typename F, typename Item>
      concept EventDelayFn2 = std::is_invocable_r_v<Event<Item>, F>;

      /** Whether `F` is a function that returns an `Event` computation. */
      template<typename F>
      concept EventDelayFn1 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires EventDelayFn2<F, typename std::invoke_result_t<F>::item_type>;
      };

      /** Whether `F` is a function that takes the `Point` pointer and returns a `Result` value. */
      template<typename F, typename Item>
      concept EventConsFn2 = std::is_invocable_r_v<Result<Item>, F, const Point*>;

      /** Whether `F` is a function that takes the `Point` pointer and returns a `Result` value. */
      template<typename F>
      concept EventConsFn1 = requires {
        typename std::invoke_result_t<F, const Point*>::item_type;
        requires EventConsFn2<F, typename std::invoke_result_t<F, const Point*>::item_type>;
      };
    }
  }

  /** Whether `Self` is actually an `Event<Item>` computation. */
  template<typename Self, typename Item>
  concept EventLike = std::is_convertible_v<Self, Event<Item>>;

  /** Whether `F` is a function that takes `Arg` and returns an `Event` computation. */
  template<typename F, typename Arg>
  concept EventBindFn = internal::event::EventBindFn2<F, Arg>;

  /** Whether `F` is a function that returns an `Event` computation. */
  template<typename F>
  concept EventDelayFn = internal::event::EventDelayFn1<F>;

  /** Whether `F` is a function that takes the `Point` pointer and returns a `Result` value. */
  template<typename F>
  concept EventConsFn = internal::event::EventConsFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace event {

      template<typename Item, typename Impl>
      inline Impl&& move_impl(Event<Item, Impl>&& comp);
    }
  }

  /** Represents an event handler. */
  template<typename Item, typename Impl>
  class Event {

    Impl impl;

    template<typename Item2, typename Impl2>
    friend inline Impl2&& internal::event::move_impl(Event<Item2, Impl2>&& comp);

  public:

    using item_type = Item;

    explicit Event(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) :
      impl(std::move(impl_arg))
    {}

    Event(Event<Item, Impl>&& other) = default;
    Event<Item, Impl>& operator=(Event<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Event(const Event<Item, Impl>& other) = default;
    Event<Item, Impl>& operator=(const Event<Item, Impl>& other) = default;

    /** Copy the computation. */
    Event<Item, Impl> copy() const {
      return Event<Item, Impl>(*this);
    }

#endif

    /** Call the computation. */
    DVCOMPUTE_ALWAYS_INLINE Result<Item> operator()(const Point *p) && {
      return std::move(impl)(p);
    }

    /**
     * Bind this with a continuation and return the resulting compound `Event<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Event<ThenItem>` computation.
     */
    template<typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && requires EventBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::event::Then<Item, ThenItem, Impl, BindFn>;
      return Event<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Bind this with a continuation and return the resulting compound `Event<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Event<ThenItem>` computation.
     */
    template<typename BindFn>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && requires EventBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::event::Then<Item, ThenItem, Impl, BindFn>;
      return Event<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Map the computed value and return the resulting compound `Event<MapItem>`
     * computation, where `MapFn` is a function that takes an `Item` and then transforms it
     * to `MapItem`.
     */
    template<typename MapFn>
    DVCOMPUTE_ALWAYS_INLINE auto map(MapFn&& f) && {
      return std::move(*this).and_then([f{std::move(f)}](Item&& item) mutable {
        using MapItem = std::invoke_result_t<MapFn, Item&&>;
        using MapImpl = internal::event::Return<MapItem>;
        return Event<MapItem, MapImpl>(MapImpl(f(std::move(item))));
      });
    }

    /** Convert this to a boxed representation. */
    Event<Item> into_boxed() && {
      using ResultImpl = internal::event::BoxedImpl<Item>;
      return Event<Item>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Event<Item>() && {
      using ResultImpl = internal::event::BoxedImpl<Item>;
      return Event<Item>(ResultImpl(std::move(impl)));
    }

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** Run the computation at the start modeling time within `Simulation<Item>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    SimulationLike<Item> auto run_in_start_time(bool including_current = true) && {
#else
    auto run_in_start_time(bool including_current = true) && {
#endif
      auto fn = [impl{std::move(impl)}, including_current](const Run* r) mutable {
        Point p(r->point_in_start_time());
        internal::event::run_events(including_current, &p);
        return std::move(impl)(&p);
      };
      return Simulation<Item, decltype(fn)>(std::move(fn));
    }

    /** Run the computation at the stop modeling time within `Simulation<Item>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    SimulationLike<Item> auto run_in_stop_time(bool including_current = true) && {
#else
    auto run_in_stop_time(bool including_current = true) && {
#endif
      auto fn = [impl{std::move(impl)}, including_current](const Run* r) mutable {
        Point p(r->point_in_stop_time());
        internal::event::run_events(including_current, &p);
        return std::move(impl)(&p);
      };
      return Simulation<Item, decltype(fn)>(std::move(fn));
    }

#elif defined(DVCOMPUTE_DISTRIBUTED)

    /** Run the computation at the start modeling time within `Simulation<Item>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    SimulationLike<Item> auto run_in_start_time(bool including_current = true) && {
#else
    auto run_in_start_time(bool including_current = true) && {
#endif
      auto fn = [impl{std::move(impl)}, including_current](const Run* r) mutable {
        Point p(r->point_in_start_time());
        Point p0(internal::event::current_event_point(r, p.priority));

        std::function<Result<Unit>(const Point* p)> unit_fn = [](const Point* p) {
          return Result<Unit>(Unit());
        };

        internal::event::enqueue_event(p.time, p.priority, std::move(unit_fn), &p0);
        internal::event::sync_events(including_current, &p);

        return std::move(impl)(&p);
      };
      return Simulation<Item, decltype(fn)>(std::move(fn));
    }

    /** Run the computation at the stop modeling time within `Simulation<Item>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
    SimulationLike<Item> auto run_in_stop_time(bool including_current = true) && {
#else
    auto run_in_stop_time(bool including_current = true) && {
#endif
      auto fn = [impl{std::move(impl)}, including_current](const Run* r) mutable {
        Point p(r->point_in_stop_time());
        Point p0(internal::event::current_event_point(r, p.priority));

        std::function<Result<Unit>(const Point* p)> unit_fn = [](const Point* p) {
          return Result<Unit>(Unit());
        };

        internal::event::enqueue_event(p.time, p.priority, std::move(unit_fn), &p0);
        internal::event::sync_events(including_current, &p);

        return std::move(impl)(&p);
      };
      return Simulation<Item, decltype(fn)>(std::move(fn));
    }

#endif /* DVCOMPUTE_SEQUENTIAL || DVCOMPUTE_DISTRIBUTED || DVCOMPUTE_BRANCHED */
  };

  namespace internal {

    namespace event {

      /** @private */
      template<typename Item, typename Impl>
      inline Impl&& move_impl(Event<Item, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

#if defined(DVCOMPUTE_DISTRIBUTED)
  /** Try to leave the simulation within `Event<Unit>`. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto leave_simulation() {
#else
  inline auto leave_simulation() {
#endif
    auto fn = [](const Point* p) {
      internal::event::leave_simulation(p);
      return Result<Unit>();
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }
#endif /* DVCOMPUTE_DISTRIBUTED */

  /** Create an `Event` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Item> auto pure_event(const Item& item) {
#else
  inline auto pure_event(const Item& item) {
#endif
    using ResultImpl = internal::event::Return<Item>;
    return Event<Item, ResultImpl>(ResultImpl(item));
  }

  /** Create an `Event` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Item> auto pure_event(Item&& item) {
#else
  inline auto pure_event(Item&& item) {
#endif
    using ResultImpl = internal::event::Return<Item>;
    return Event<Item, ResultImpl>(ResultImpl(std::move(item)));
  }

  /**
   * Delay the `Event` computation and return the resulting compound `Event`
   * computation, where `DelayFn` is a function that returns an intermediate `Event`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_event(DelayFn&& f) requires EventDelayFn<DelayFn> {
#else
  inline auto delay_event(DelayFn&& f) {
#endif
    return pure_event(Unit()).and_then([f{std::move(f)}](Unit&& unit) mutable {
      return f();
    });
  }

  /**
   * Construct a new `Event<Item>` computation by the specified closure `ConsFn`,
   * which must be a function of the `Point` pointer that returns an `Item`.
   */
  template<typename ConsFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_event(ConsFn&& f) requires EventConsFn<ConsFn> {
#else
  inline auto cons_event(ConsFn&& f) {
#endif
    using Item = typename std::invoke_result_t<ConsFn, const Point*>::item_type;
    auto fn = [f{std::move(f)}](const Point *p) mutable { return f(p); };
    return Event<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Event<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Item> auto into_event(Event<Item, Impl>&& from) {
#else
  inline auto into_event(Event<Item, Impl>&& from) {
#endif
    return std::move(from);
  }

  /** Convert the specified computation to `Event<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Item> auto into_event(Simulation<Item, Impl>&& from) {
#else
  inline auto into_event(Simulation<Item, Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](const Point *p) mutable { return std::move(from)(p->run); };
    return Event<Item, decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Event<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Item> auto into_event(Parameter<Item, Impl>&& from) {
#else
  inline auto into_event(Parameter<Item, Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](const Point *p) mutable { return std::move(from)(p->run); };
    return Event<Item, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations, where the final computation has
   * type `Event<std::vector<Item>>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<std::vector<Item>> auto event_sequence(std::vector<Event<Item, Impl>>&& comps) {
#else
  auto event_sequence(std::vector<Event<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Point *p) mutable {
      std::vector<Item> result;
      for (auto& comp : comps) {
        Result<Item> res { std::move(comp)(p) };
        if (auto item = get_result_if<Item>(&res)) [[likely]] {
          result.emplace_back(std::move(*item));
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<std::vector<Item>>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<std::vector<Item>>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<std::vector<Item>>(std::move(result));
    };
    return Event<std::vector<Item>, decltype(fn)>(std::move(fn));
  }

  /**
   * The sequence of computations for performing side effects,
   * when the intermediate results are discarded, but the final computation
   * has type `Event<Unit>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto event_sequence_(std::vector<Event<Item, Impl>>&& comps) {
#else
  auto event_sequence_(std::vector<Event<Item, Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Point *p) mutable {
      for (auto& comp : comps) {
        Result<Item> res { std::move(comp)(p) };
        if (get_result_if<Item>(&res)) [[likely]] {
          continue;
        } else if (auto c = get_cancel_result_if(&res)) {
          return Result<Unit>(*c);
        } else if (auto e = get_retry_result_if(&res)) {
          return Result<Unit>(*e);
        } else {
          throw UnknownResult();
        }
      }
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time. The last parameter specifies
   * the computation that will be called in case of hard cancelling the event handler
   * (by real-time requirements, for example).
   */
  template<typename Impl, typename CancelImpl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_event_with_cancel(double event_time, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#else
  auto enqueue_event_with_cancel(double event_time, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#endif
    auto fn = [event_time, event{std::move(event)}, cancel_event{std::move(cancel_event)}](const Point *p) mutable {
      internal::event::enqueue_event_with_cancel(event_time, p->priority, internal::event::move_impl(std::move(event)), internal::event::move_impl(std::move(cancel_event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_event(double event_time, Event<Unit, Impl>&& event) {
#else
  auto enqueue_event(double event_time, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_event(event_time, p->priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time with the given priority.
   * The last parameter specifies the computation that will be called in case of
   * hard cancelling the event handler (by real-time requirements, for example).
   */
  template<typename Impl, typename CancelImpl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_event_with_priority_and_cancel(double event_time, int priority, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#else
  auto enqueue_event_with_priority_and_cancel(double event_time, int priority, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#endif
    auto fn = [event_time, priority, event{std::move(event)}, cancel_event{std::move(cancel_event)}](const Point *p) mutable {
      internal::event::enqueue_event_with_cancel(event_time, priority, internal::event::move_impl(std::move(event)), internal::event::move_impl(std::move(cancel_event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time with the given priority.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#else
  auto enqueue_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, priority, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_event(event_time, priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handler that
   * should be actuated at the specified modeling time. The last parameter specifies 
   * the computation that will be called in case of hard cancelling the event handler
   * (by real-time requirements, for example).
   */
  template<typename Impl, typename CancelImpl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_io_event_with_cancel(double event_time, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#else
  auto enqueue_io_event_with_cancel(double event_time, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#endif
    auto fn = [event_time, event{std::move(event)}, cancel_event{std::move(cancel_event)}](const Point *p) mutable {
      internal::event::enqueue_io_event_with_cancel(event_time, p->priority, internal::event::move_impl(std::move(event)), internal::event::move_impl(std::move(cancel_event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  /**
   * Enqueue within `Event<Unit>` computaton  the specified IO event handler that
   * should be actuated at the specified modeling time.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_io_event(double event_time, Event<Unit, Impl>&& event) {
#else
  auto enqueue_io_event(double event_time, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_io_event(event_time, p->priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handler that
   * should be actuated at the specified modeling time with the given priority.
   * The last parameter specifies the computation that will be called in case of 
   * hard cancelling the event handler (by real-time requirements, for example).
   */
  template<typename Impl, typename CancelImpl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_io_event_with_priority_and_cancel(double event_time, int priority, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#else
  auto enqueue_io_event_with_priority_and_cancel(double event_time, int priority, Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#endif
    auto fn = [event_time, priority, event{std::move(event)}, cancel_event{std::move(cancel_event)}](const Point *p) mutable {
      internal::event::enqueue_io_event_with_cancel(event_time, priority, internal::event::move_impl(std::move(event)), internal::event::move_impl(std::move(cancel_event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handler that
   * should be actuated at the specified modeling time with the given priority.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_io_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#else
  auto enqueue_io_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, priority, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_io_event(event_time, priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time. This computation cannot 
   * be cancelled in case of hard cancelling (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_event(double event_time, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_event(double event_time, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_uncancellable_event(event_time, p->priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time with the given priority. 
   * This computation cannot be cancelled in case of hard cancelling 
   * (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, priority, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_uncancellable_event(event_time, priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handler that
   * should be actuated at the specified modeling time. This computation cannot 
   * be cancelled in case of hard cancelling (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_io_event(double event_time, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_io_event(double event_time, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_uncancellable_io_event(event_time, p->priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handler that
   * should be actuated at the specified modeling time with the given priority. 
   * This computation cannot be cancelled in case of hard cancelling 
   * (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_io_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_io_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#endif
    auto fn = [event_time, priority, event{std::move(event)}](const Point *p) mutable {
      internal::event::enqueue_uncancellable_io_event(event_time, priority, internal::event::move_impl(std::move(event)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#else

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time. This computation cannot 
   * be cancelled in case of hard cancelling (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_event(double event_time, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_event(double event_time, Event<Unit, Impl>&& event) {
#endif
    return enqueue_event(event_time, std::move(event));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time with the given priority. 
   * This computation cannot be cancelled in case of hard cancelling 
   * (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#endif
    return enqueue_event_with_priority(event_time, priority, std::move(event));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handler that
   * should be actuated at the specified modeling time. This computation cannot 
   * be cancelled in case of hard cancelling (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_io_event(double event_time, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_io_event(double event_time, Event<Unit, Impl>&& event) {
#endif
    return enqueue_io_event(event_time, std::move(event));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the specified modeling time with the given priority. 
   * This computation cannot be cancelled in case of hard cancelling 
   * (by real-time requirements, for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_uncancellable_io_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#else
  auto enqueue_uncancellable_io_event_with_priority(double event_time, int priority, Event<Unit, Impl>&& event) {
#endif
    return enqueue_io_event_with_priority(event_time, priority, std::move(event));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  /** Return the current modeling time within `Event<double>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<double> auto event_time() {
#else
  inline auto event_time() {
#endif
    auto fn = [](const Point* p) {
      return Result<double>(p->time);
    };
    return Event<double, decltype(fn)>(std::move(fn));
  }

  /** Return the current modeling time priority within `Event<int>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<int> auto event_priority() {
#else
  inline auto event_priority() {
#endif
    auto fn = [](const Point* p) {
      return p->priority;
    };
    return Event<int, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the current modeling time but later. The last parameter 
   * specifies the computation that will be called in case of hard cancelling 
   * the event handler (by real-time requirements, for example).
   */
  template<typename Impl, typename CancelImpl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto yield_event_with_cancel(Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#else
  auto yield_event_with_cancel(Event<Unit, Impl>&& event, Event<Unit, CancelImpl>&& cancel_event) {
#endif
    auto fn = [event{std::move(event)}, cancel_event{std::move(cancel_event)}](const Point* p) mutable {
      return enqueue_event_with_cancel(p->time, std::move(event), std::move(cancel_event)).operator()(p);
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the current modeling time but later.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto yield_event(Event<Unit, Impl>&& event) {
#else
  auto yield_event(Event<Unit, Impl>&& event) {
#endif
    auto fn = [event{std::move(event)}](const Point* p) mutable {
      return enqueue_event(p->time, std::move(event)).operator()(p);
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handler that
   * should be actuated at the current modeling time but later. This computation 
   * cannot be cancelled in case of hard cancelling (by real-time requirements, 
   * for example).
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto yield_uncancellable_event(Event<Unit, Impl>&& event) {
#else
  auto yield_uncancellable_event(Event<Unit, Impl>&& event) {
#endif
    auto fn = [event{std::move(event)}](const Point* p) mutable {
      return enqueue_uncancellable_event(p->time, std::move(event)).operator()(p);
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }
}

#endif /* dvcompute_event_h */

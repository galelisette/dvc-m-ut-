/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_generator_h
#define dvcompute_generator_h

#include <cstdint>
#include <vector>
#include <exception>
#include <limits>
#include <memory>

#include "../../dvcompute_ns.h"

#include "generator_primitives.h"

namespace DVCOMPUTE_NS {

  /** The generator specification. */
  class GeneratorSpec {
    std::vector<int> seed;

  public:
    explicit GeneratorSpec() {}
    explicit GeneratorSpec(const std::vector<int>& seed_arg): seed(seed_arg) {}

    GeneratorSpec(const GeneratorSpec&) = default;
    GeneratorSpec(GeneratorSpec&&) = default;

    GeneratorSpec& operator=(const GeneratorSpec&) = default;
    GeneratorSpec& operator=(GeneratorSpec&&) = default;

    const std::vector<int>& get_seed() const {
      return seed;
    }
  };

  /** The unsupported generator spec. */
  class UnsupportedGeneratorSpec : public std::exception {
  public:
    explicit UnsupportedGeneratorSpec() {}
  };

  namespace internal {

    namespace generator {

      /** The random number generator. */
      class Generator {

        /** The uniform random number generator. */
        primitives::BoxedGenerator gu;

        /** The normal random number generator. */
        primitives::BoxedGenerator gn;

        /** The unique sequence number. */
        mutable uint64_t sequence_no;

        /** Whether the spec is random. */
        bool random_spec;

      public:

        explicit Generator(const GeneratorSpec& spec) {
          auto seed = spec.get_seed();
          if (seed.empty()) {
            gu = primitives::uniform_generator();
            gn = primitives::normal_generator(primitives::uniform_generator());
            sequence_no = 0;
            random_spec = true;
          } else {
#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED) || defined(DVCOMPUTE_CONSERVATIVE)
            std::shared_ptr<primitives::BoxedGenerator> g0(new primitives::BoxedGenerator(primitives::uniform_generator_by_seed(seed)));
            gu = [g0]() mutable {
              return g0->operator()();
            };
            gn = primitives::normal_generator([g0]() mutable {
              return g0->operator()();
            });
            sequence_no = 0;
            random_spec = false;
#elif defined(DVCOMPUTE_DISTRIBUTED)
            throw UnsupportedGeneratorSpec();
#else
#error "Unknown simulation mode"
#endif
          }
        }

        explicit Generator(const Generator& parent) {
          if (parent.random_spec) {
            gu = primitives::uniform_generator();
            gn = primitives::normal_generator(primitives::uniform_generator());
            sequence_no = 0;
            random_spec = true;
          } else {
            constexpr int min_x = std::numeric_limits<int>::min() / 8;
            constexpr int max_x = std::numeric_limits<int>::max() / 8;
            std::seed_seq seq {
              primitives::generate_int_uniform(parent.gu, min_x, max_x),
              primitives::generate_int_uniform(parent.gu, min_x, max_x),
              primitives::generate_int_uniform(parent.gu, min_x, max_x),
              primitives::generate_int_uniform(parent.gu, min_x, max_x),
              primitives::generate_int_uniform(parent.gu, min_x, max_x),
              primitives::generate_int_uniform(parent.gu, min_x, max_x),
              primitives::generate_int_uniform(parent.gu, min_x, max_x)
            };
            std::shared_ptr<primitives::BoxedGenerator> g0(new primitives::BoxedGenerator(primitives::uniform_generator_by_seed(seq)));
            gu = [g0]() mutable {
              return g0->operator()();
            };
            gn = primitives::normal_generator([g0]() mutable {
              return g0->operator()();
            });
            sequence_no = parent.sequence_no;
            random_spec = false;
          }
        }

        /** Generate an uniform random number with the specified minimum and maximum. */
        double random_uniform(double min, double max) const {
          return primitives::generate_uniform(gu, min, max);
        }

        /** Generate an integer uniform random number with the specified minimum and maximum. */
        int random_int_uniform(int min, int max) const {
          return primitives::generate_int_uniform(gu, min, max);
        }

        /** Generate the triangular random number by the specified minimum, median and maximum. */
        double random_triangular(double min, double median, double max) const {
          return primitives::generate_triangular(gu, min, median, max);
        }

        /** Generate a normal random number by the specified generator, mean and deviation. */
        double random_normal(double mu, double nu) const {
          return primitives::generate_normal(gn, mu, nu);
        }

        /** 
          * Generate the lognormal random number derived from a normal distribution with
          * the specified generator, mean and deviation.
          */
        double random_log_normal(double mu, double nu) const {
          return primitives::generate_log_normal(gn, mu, nu);
        }

        /** Return the exponential random number with the specified mean. */
        double random_exponential(double mu) const {
          return primitives::generate_exponential(gu, mu);
        }

        /** Return the Erlang random number */
        double random_erlang(double scale, int shape) const {
          return primitives::generate_erlang(gu, scale, shape);
        }

        /** Generate the Poisson random number by the specified mean. */
        int random_poisson(double mu) const {
          return primitives::generate_poisson(gu, mu);
        }

        /** Generate a binomial random number with the specified probability and number of trials. */
        int random_binomial(double prob, int trials) const {
          return primitives::generate_binomial(gu, prob, trials);
        }

        /** Generate a random number from the Gamma distribution. */
        double random_gamma(double kappa, double theta) const {
          return primitives::generate_gamma(gn, gu, kappa, theta);
        }

        /** Generate a random number from the Beta distribution. */
        double random_beta(double alpha, double beta) const {
          return primitives::generate_beta(gn, gu, alpha, beta);
        }

        /** Generate a random number from the Weibull distribution. */
        double random_weibull(double alpha, double beta) const {
          return primitives::generate_weibull(gu, alpha, beta);
        }

        /** Generate a random value from the specified discrete distribution. */
        template<typename T>
        T random_discrete(const std::vector<std::pair<T, double>>& dpdf) const {
          return primitives::generate_discrete(gu, dpdf);
        }

        /** Generate a sequence number which can be considered quite unique. */
        uint64_t random_sequence_no() const {
          return ++sequence_no;
        }
      };
    }
  }
}

#endif /* dvcompute_generator_h */

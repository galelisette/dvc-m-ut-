/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_disposable_h
#define dvcompute_disposable_h

#include <functional>
#include <vector>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "specs.h"
#include "result.h"
#include "event.h"
#include "disposable_fn.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace disposable {

      // /** @private */
      // using BoxedImpl = std::function<Result<Unit>(const Point*)>;

      /** @private */
      template<typename Left, typename Right>
      class Merge {

        Left left;
        Right right;

      public:

        explicit Merge(Left &&left_arg, Right &&right_arg)
          noexcept(noexcept(Left(std::move(left_arg))) && noexcept(Right(std::move(right_arg)))) :
          left(std::move(left_arg)), right(std::move(right_arg))
        {}

        Merge(Merge<Left, Right> &&other) = default;
        Merge<Left, Right>& operator=(Merge<Left, Right> &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Merge(const Merge<Left, Right> &other) = default;
        Merge<Left, Right>& operator=(const Merge<Left, Right> &other) = default;

#endif

        Result<Unit> operator()(const Point *p) && {
          auto res { std::move(left)(p) };
          if (get_result_if<Unit>(&res)) [[likely]] {
            return std::move(right)(p);
          } else {
            return res;
          }
        }
      };

      /** @private */
      class Empty {
      public:

        explicit Empty() noexcept {}

        Empty(Empty &&other) = default;
        Empty& operator=(Empty &&other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Empty(const Empty &other) = default;
        Empty& operator=(const Empty &other) = default;

#endif

        Result<Unit> operator()(const Point *p) && {
          return Result<Unit>(Unit());
        }
      };
    }
  }

  /** Represents a computation that disposes some resources. */
  template<typename Impl = internal::disposable::BoxedImpl>
  class Disposable;

#ifdef DVCOMPUTE_CONCEPTS

  /** Whether `Self` is actually a `Disposable<>` computation. */
  template<typename Self>
  concept DisposableLike = std::is_convertible_v<Self, Disposable<>>;

  /** Whether `F` is a function that returns a `Disposable<>` computation. */
  template<typename F>
  concept DisposableDelayFn = std::is_invocable_r_v<Disposable<>, F>;

  /** Whether `F` is a function that takes the `Point` pointer and returns a `Result<Unit>` value. */
  template<typename F>
  concept DisposableConsFn = std::is_invocable_r_v<Result<Unit>, F, const Point*>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace disposable {

      template<typename Impl>
      inline Impl&& move_impl(Disposable<Impl>&& comp);
    }
  }

  /** Represents a computation that disposes some resources. */
  template<typename Impl>
  class Disposable {

    Impl impl;

    template<typename Impl2>
    friend inline Impl2&& internal::disposable::move_impl(Disposable<Impl2>&& comp);

  public:

    explicit Disposable(Impl &&impl_arg)
    noexcept(noexcept(Impl(std::move(impl_arg)))) :
      impl(std::move(impl_arg))
    {}

    Disposable(Disposable<Impl>&& other) = default;
    Disposable<Impl>& operator=(Disposable<Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Disposable(const Disposable<Impl>& other) = default;
    Disposable<Impl>& operator=(const Disposable<Impl>& other) = default;

    /** Copy the computation. */
    Disposable<Impl> copy() const {
      return Disposable<Impl>(*this);
    }

#endif

    /** Call the computation. */
    DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(const Point *p) && {
      return std::move(impl)(p);
    }

    /**
     * Merge this computation with another `Disposable` one and then return
     * the resulting compound `Disposable` computation.
     */
    template<typename Other>
#ifdef DVCOMPUTE_CONCEPTS
    DisposableLike auto merge(Other&& other) && requires DisposableLike<Other> {
#else
    auto merge(Other&& other) && {
#endif
      using RightRValue = decltype(internal::disposable::move_impl(std::move(other)));
      using Right = std::remove_reference_t<RightRValue>;
      using ResultImpl = internal::disposable::Merge<decltype(impl), Right>;
      return Disposable<ResultImpl>(ResultImpl(std::move(impl), internal::disposable::move_impl(std::move(other))));
    }

    /** Convert this to a boxed representation. */
    Disposable<> into_boxed() && {
      using ResultImpl = internal::disposable::BoxedImpl;
      return Disposable<>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Disposable<>() && {
      using ResultImpl = internal::disposable::BoxedImpl;
      return Disposable<>(ResultImpl(std::move(impl)));
    }
  };

  namespace internal {

    namespace disposable {

      /** @private */
      template<typename Impl>
      inline Impl&& move_impl(Disposable<Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /** Create a `Disposable` computation that disposes nothing. */
#ifdef DVCOMPUTE_CONCEPTS
  inline DisposableLike auto empty_disposable() {
#else
  inline auto empty_disposable() {
#endif
    using ResultImpl = internal::disposable::Empty;
    return Disposable<ResultImpl>(ResultImpl());
  }

  /**
   * Delay the `Disposable` computation and return the resulting compound `Disposable`
   * computation, where `DelayFn` is a function that returns an intermediate `Disposable`
   * computation.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto delay_disposable(DelayFn&& f) requires DisposableDelayFn<DelayFn> {
#else
  inline auto delay_disposable(DelayFn&& f) {
#endif
    auto fn = [f{std::move(f)}](const Point *p) mutable { return f()(p); };
    return Disposable<decltype(fn)>(std::move(fn));
  }

  /**
   * Construct a new `Disposable` computation by the specified closure `ConsFn`,
   * which must be a function of the `Point` pointer.
   */
  template<typename ConsFn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto cons_disposable(ConsFn&& f) requires DisposableConsFn<ConsFn> {
#else
  inline auto cons_disposable(ConsFn&& f) {
#endif
    auto fn = [f{std::move(f)}](const Point *p) mutable { return f(p); };
    return Disposable<decltype(fn)>(std::move(fn));
  }

  /** Convert the specified computation to `Event<Unit>`. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto into_event(Disposable<Impl>&& from) {
#else
  inline auto into_event(Disposable<Impl>&& from) {
#endif
    auto fn = [from{std::move(from)}](const Point *p) mutable { return std::move(from)(p); };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Concatenate the specified `Disposable` computations and return
   * the resulting compound `Disposable` computation.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  DisposableLike auto concat_disposables(std::vector<Disposable<Impl>>&& comps) {
#else
  auto concat_disposables(std::vector<Disposable<Impl>>&& comps) {
#endif
    auto fn = [comps{std::move(comps)}](const Point *p) mutable {
      for (auto& comp : comps) {
        auto res { std::move(comp)(p) };
        if (get_result_if<Unit>(&res)) [[likely]] {
          continue;
        } else {
          return res;
        }
      }
      return Result<Unit>(Unit());
    };
    return Disposable<decltype(fn)>(std::move(fn));
  }
}

#endif /* dvcompute_disposable_h */

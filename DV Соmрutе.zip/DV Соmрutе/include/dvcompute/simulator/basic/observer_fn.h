/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observer_fn_h
#define dvcompute_observer_fn_h

#include <functional>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "types.h"
#include "specs.h"
#include "result.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace observer {

#ifndef DVCOMPUTE_COPY_CTOR

      // /** @private */
      // template<typename Message, typename Item>
      // using BoxedImpl = std::function<Result<Item>(const Message*, const Point*)>;

      /** This is a vtable. */
      template<typename Message, typename Item>
      struct BoxedImplVTable {

        typedef void (*DestructFn)(char*);
        typedef Result<Item> (*CallFn)(const char*, const Message* msg, const Point*);

        DestructFn destruct_fn;
        CallFn call_fn;
      };

      template<typename Fn>
      static void boxed_impl_destruct(char* data) noexcept {
        delete reinterpret_cast<Fn*>(data);
      }

      template<typename Fn, typename Message, typename Item>
      static Result<Item> boxed_impl_call(const char* data, const Message* msg, const Point* p) {
        return reinterpret_cast<Fn*>(const_cast<char*>(data))->operator()(msg, p);
      }

      /** This is a vtable definition for closures. */
      template<typename Fn, typename Message, typename Item>
      struct BoxedImplVTableDef {

        static constexpr BoxedImplVTable<Message, Item> instance {
          &boxed_impl_destruct<Fn>,
          &boxed_impl_call<Fn, Message, Item>
        };
      };

      /** @private */
      template<typename Message, typename Item>
      class BoxedImpl {

        const BoxedImplVTable<Message, Item>* vtable;
        char* data;

      public:

        ~BoxedImpl() {
          if (data != nullptr) {
            vtable->destruct_fn(data);
          }
        }

        explicit BoxedImpl() noexcept :
          vtable(nullptr),
          data(nullptr)
        {}

        template<typename Fn>
        BoxedImpl(Fn&& fn) :
          vtable(&BoxedImplVTableDef<Fn, Message, Item>::instance),
          data(reinterpret_cast<char*>(new Fn(std::move(fn))))
        {}

        BoxedImpl(BoxedImpl&& other) noexcept :
          vtable(other.vtable),
          data(other.data)
        {
          other.data = nullptr;
        }

        BoxedImpl& operator=(BoxedImpl&& other) noexcept {
          BoxedImpl tmp { std::move(other) };
          swap(tmp);
          return *this;
        }

        operator bool() const noexcept {
          return data != nullptr;
        }

        Result<Item> operator()(const Message* msg, const Point* p) const {
          return vtable->call_fn(data, msg, p);
        }

        void swap(BoxedImpl& other) noexcept {
          std::swap(vtable, other.vtable);
          std::swap(data, other.data);
        }
      };

#else

      // /** @private */
      // template<typename Message, typename Item>
      // using BoxedImpl = std::function<Result<Item>(const Message*, const Point*)>;

      /** This is a vtable. */
      template<typename Message, typename Item>
      struct BoxedImplVTable {

        typedef void (*DestructFn)(char*);
        typedef char* (*CloneFn)(const char*);
        typedef Result<Item> (*CallFn)(const char*, const Message* msg, const Point*);

        DestructFn destruct_fn;
        CloneFn clone_fn;
        CallFn call_fn;
      };

      template<typename Fn>
      static void boxed_impl_destruct(char* data) noexcept {
        delete reinterpret_cast<Fn*>(data);
      }

      template<typename Fn>
      static char* boxed_impl_clone(const char* data) {
        return reinterpret_cast<char*>(new Fn(*reinterpret_cast<const Fn*>(data)));
      }

      template<typename Fn, typename Message, typename Item>
      static Result<Item> boxed_impl_call(const char* data, const Message* msg, const Point* p) {
        return reinterpret_cast<Fn*>(const_cast<char*>(data))->operator()(msg, p);
      }

      /** This is a vtable definition for closures. */
      template<typename Fn, typename Message, typename Item>
      struct BoxedImplVTableDef {

        static constexpr BoxedImplVTable<Message, Item> instance {
          &boxed_impl_destruct<Fn>,
          &boxed_impl_clone<Fn>,
          &boxed_impl_call<Fn, Message, Item>
        };
      };

      /** @private */
      template<typename Message, typename Item>
      class BoxedImpl {

        const BoxedImplVTable<Message, Item>* vtable;
        char* data;

      public:

        ~BoxedImpl() {
          if (data != nullptr) {
            vtable->destruct_fn(data);
          }
        }

        explicit BoxedImpl() noexcept :
          vtable(nullptr),
          data(nullptr)
        {}

        template<typename Fn>
        BoxedImpl(Fn fn) :
          vtable(&BoxedImplVTableDef<Fn, Message, Item>::instance),
          data(reinterpret_cast<char*>(new Fn(std::move(fn))))
        {}

        BoxedImpl(const BoxedImpl& other) :
          vtable(other.vtable),
          data(nullptr)
        {
          if (other.data != nullptr) {
            data = vtable->clone_fn(other.data);
          }
        }

        BoxedImpl(BoxedImpl&& other) noexcept :
          vtable(other.vtable),
          data(other.data)
        {
          other.data = nullptr;
        }

        BoxedImpl& operator=(const BoxedImpl& other) {
          BoxedImpl tmp(other);
          swap(tmp);
          return *this;
        }

        BoxedImpl& operator=(BoxedImpl&& other) noexcept {
          BoxedImpl tmp { std::move(other) };
          swap(tmp);
          return *this;
        }

        operator bool() const noexcept {
          return data != nullptr;
        }

        Result<Item> operator()(const Message* msg, const Point* p) const {
          return vtable->call_fn(data, msg, p);
        }

        void swap(BoxedImpl& other) noexcept {
          std::swap(vtable, other.vtable);
          std::swap(data, other.data);
        }
      };

#endif /* DVCOMPUTE_COPY_CTOR */

    }
  }
}

#endif /* dvcompute_observer_fn_h */

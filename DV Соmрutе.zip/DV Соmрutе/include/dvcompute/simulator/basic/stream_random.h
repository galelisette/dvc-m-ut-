/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_stream_random_h
#define dvcompute_stream_random_h

#include <optional>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "disposable.h"
#include "stream.h"
#include "parameter.h"
#include "event.h"
#include "process.h"
#include "arrival.h"

namespace DVCOMPUTE_NS {

#ifdef DVCOMPUTE_CONCEPTS

  /** Whether `F` is a function that returns a `Parameter<td::pair<double, Item>>` computation. */
  template<typename F, typename Item>
  concept StreamRandomFn = std::is_invocable_r_v<Parameter<std::pair<double, Item>>, F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace stream {

      namespace random {

        /** Return a stream of random events that arrive with the specified delay and start time. */
        template<typename Item, typename Fn>
        inline Stream<Arrival<Item>> random_stream_loop(Fn&& fn, const std::optional<double>& t0) 
#ifdef DVCOMPUTE_CONCEPTS
          requires StreamRandomFn<Fn, Item>
#endif
        {
          return Stream<Arrival<Item>> {
            into_process(event_time()
              .and_then([t0](double t1) mutable {
                return cons_event([t0, t1](const Point *p) {
                  if (!t0.has_value()) {
                    return Result<Unit>(Unit());

                  } else if (t0.value() == t1) {
                    return Result<Unit>(Unit());

                  } else {
                    throw PanicResult("The time of requesting for a new random event is different from "
                      "the time when the previous event has arrived. Probably, your model "
                      "contains a logical error. The random events should be requested permanently.");
                  }
                });
              }))
              .and_then([fn{std::move(fn)}, t0](Unit&& unit) mutable {
                return into_process(fn())
                  .and_then([fn{std::move(fn)}, t0](std::pair<double, Item>&& p) mutable {
                    double delay = std::max(0.0, p.first);
                    Item a { std::move(p.second) };
                    return hold_process(delay)
                      .and_then([a{std::move(a)}, fn{std::move(fn)}, t0, delay](Unit&& unit) mutable {
                        return into_process(event_time())
                          .and_then([a{std::move(a)}, fn{std::move(fn)}, t0, delay](double t2) mutable {

                            Arrival<Item> arrival {
                              std::move(a), t2, t0.has_value() ? std::make_optional(delay) : std::nullopt
                            };

                            return pure_process(std::pair<Arrival<Item>, Stream<Arrival<Item>>>(std::move(arrival),
                              random_stream_loop<Item>(std::move(fn), std::make_optional(t2))));
                          });
                      });
                  });
              })
          };
        }
      }
    }
  }

  /** Return a stream of random events that arrive with the specified delay. */
  template<typename Item, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
  inline Stream<Arrival<Item>> random_stream(Fn&& fn) requires StreamRandomFn<Fn, Item> {
#else
  inline Stream<Arrival<Item>> random_stream(Fn&& fn) {
#endif
    return DVCOMPUTE_NS::internal::stream::random::random_stream_loop<Item>(std::move(fn), std::nullopt);
  }

  /** A stream computation with random time delays distributed uniformly. */
  inline Stream<Arrival<double>> random_uniform_stream(double min, double max) {
    return random_stream<double>([=]() {
      return random_uniform_parameter(min, max)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** A stream computation with integer random time delays distributed uniformly. */
  inline Stream<Arrival<int>> random_int_uniform_stream(int min, int max) {
    return random_stream<int>([=]() {
      return random_int_uniform_parameter(min, max)
        .map([](int x) { return std::pair(static_cast<double>(x), x); });
    });
  }

  /** A stream computation with random time delays from the triangular distribution. */
  inline Stream<Arrival<double>> random_triangular_stream(double min, double median, double max) {
    return random_stream<double>([=]() {
      return random_triangular_parameter(min, median, max)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** A stream computation with random time delays from the normal distribution. */
  inline Stream<Arrival<double>> random_normal_stream(double mu, double nu) {
    return random_stream<double>([=]() {
      return random_normal_parameter(mu, nu)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** A stream computation with random time delays from the lognormal distribution. */
  inline Stream<Arrival<double>> random_log_normal_stream(double mu, double nu) {
    return random_stream<double>([=]() {
      return random_log_normal_parameter(mu, nu)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** 
   * A stream computation with exponential random time delays that 
   * have the specified average (the reciprocal of the rate). 
   */
  inline Stream<Arrival<double>> random_exponential_stream(double mu) {
    return random_stream<double>([=]() {
      return random_exponential_parameter(mu)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** 
   * A stream computation with the Erlang random time delays that 
   * have the specified scale (the reciprocal of the rate) and integer shape. 
   */
  inline Stream<Arrival<double>> random_erlang_stream(double scale, int shape) {
    return random_stream<double>([=]() {
      return random_erlang_parameter(scale, shape)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** 
   * A stream computation with the Poisson random time delays that 
   * have the specified average. 
   */
  inline Stream<Arrival<int>> random_poisson_stream(double mu) {
    return random_stream<int>([=]() {
      return random_poisson_parameter(mu)
        .map([](int x) { return std::pair(static_cast<double>(x), x); });
    });
  }

  /** 
   * A stream computation with binomial random time delays by 
   * the specified probability and trials. 
   */
  inline Stream<Arrival<int>> random_binomial_stream(double prob, int trials) {
    return random_stream<int>([=]() {
      return random_binomial_parameter(prob, trials)
        .map([](int x) { return std::pair(static_cast<double>(x), x); });
    });
  }

  /** A stream computation with random time delays from the Gamma distribution. */
  inline Stream<Arrival<double>> random_gamma_stream(double kappa, double theta) {
    return random_stream<double>([=]() {
      return random_gamma_parameter(kappa, theta)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** A stream computation with random time delays from the Beta distribution. */
  inline Stream<Arrival<double>> random_beta_stream(double alpha, double beta) {
    return random_stream<double>([=]() {
      return random_beta_parameter(alpha, beta)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** A stream computation with random time delays from the Weibull distribution. */
  inline Stream<Arrival<double>> random_weibull_stream(double alpha, double beta) {
    return random_stream<double>([=]() {
      return random_weibull_parameter(alpha, beta)
        .map([](double x) { return std::pair(x, x); });
    });
  }

  /** 
   * A stream computation with random time delays that have the specified discrete 
   * distribution, where `T` must be converted to `double` through `static_cast`.
   */
  template<typename T>
  inline Stream<Arrival<T>> random_discrete_stream(const SharedPtr<std::vector<std::pair<T, double>>>& dpdf) {
    return random_stream<T>([=]() {
      return random_discrete_parameter(dpdf)
        .map([](T&& x) { return std::pair(static_cast<double>(x), std::move(x)); });
    });
  }
}

#endif /* dvcompute_stream_random_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_block_extra_h
#define dvcompute_block_extra_h

#include "macros.h"
#include "block.h"
#include "block/transact.h"
#include "block/transact_ops.h"
#include "block/queue.h"
#include "block/queue_ops.h"
#include "block/assembly_set.h"
#include "block/assembly_set_ops.h"
#include "block/facility.h"
#include "process.h"

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)
#include "../net/lp_id.h"
#include "../net/messaging.h"
#endif

namespace DVCOMPUTE_NS {

  namespace block {

    namespace internal {

      namespace transact {

        /** @private */
        template<typename Item, typename Impl>
        class Split {

          Block<Transact<Item>, Unit, Impl> block_chain;

        public:

          explicit Split(Block<Transact<Item>, Unit, Impl>&& block_chain_arg) 
            noexcept(noexcept(Block<Transact<Item>, Unit, Impl>(std::move(block_chain_arg)))) : 
              block_chain(std::move(block_chain_arg)) 
          {}

          Split(Split<Item, Impl>&& other) = default;
          Split<Item, Impl>& operator=(Split<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

          Split(const Split<Item, Impl>& other) = default;
          Split<Item, Impl>& operator=(const Split<Item, Impl>& other) = default;

#endif

          template<typename ContFn>
          Result<Unit> operator()(Transact<Item>&& input,
            ContFn&& cont_fn,
            const ProcessIdPtr& pid,
            const Point* p) &&
          {
            auto res { split_transact(input)(p) };
            if (Transact<Item> *other = get_result_if(&res)) {
              TransactIdPtr tid = other->transact_id;
              
              auto res { 
                enqueue_event(p->time, transfer_transact_within_event(tid, 
                  std::move(block_chain).run(std::move(*other))))(p) 
              };

              if (get_result_if<Unit>(&res)) {
                return std::move(cont_fn)(std::move(input), pid, p);
              
              } else {
                return error_result<Unit>(std::move(res));
              }

            } else {
              return error_result<Unit>(std::move(res));
            }
          }
        };

        /** @private */
        template<typename Item, typename Impl>
        class Spawn {

          ProcessCancellation cancellation;
          Block<Transact<Item>, Unit, Impl> block_chain;

        public:

          explicit Spawn(ProcessCancellation cancellation_arg, Block<Transact<Item>, Unit, Impl>&& block_chain_arg) 
            noexcept(noexcept(Block<Transact<Item>, Unit, Impl>(std::move(block_chain_arg)))) : 
              cancellation(cancellation_arg), block_chain(std::move(block_chain_arg)) 
          {}

          Spawn(Spawn<Item, Impl>&& other) = default;
          Spawn<Item, Impl>& operator=(Spawn<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

          Spawn(const Spawn<Item, Impl>& other) = default;
          Spawn<Item, Impl>& operator=(const Spawn<Item, Impl>& other) = default;

#endif

          template<typename ContFn>
          Result<Unit> operator()(Transact<Item>&& input,
            ContFn&& cont_fn,
            const ProcessIdPtr& pid,
            const Point* p) &&
          {
            auto res { split_transact(input)(p) };
            if (Transact<Item> *other = get_result_if(&res)) {
              TransactIdPtr tid = other->transact_id;

              auto inner_cont_fn = [input{std::move(input)}, cont_fn{std::move(cont_fn)}](Result<Unit>&& res, const ProcessIdPtr& pid, const Point* p) mutable {
                if (get_result_if<Unit>(&res)) {
                  return std::move(cont_fn)(std::move(input), pid, p);
                
                } else {
                  return error_result<Unit>(std::move(res));
                }
              };

              return spawn_process_with(cancellation, transfer_transact(tid, 
                  std::move(block_chain).run(std::move(*other))))
                .operator()(std::move(inner_cont_fn), pid, p);

            } else {
              return error_result<Unit>(std::move(res));
            }
          }
        };
      }

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

      /** To concatenate blocks within `Block<InOutput, InOutput>`. */
      template<typename InOutput, typename Impl>
      Process<InOutput> concat_blocks(std::vector<Block<InOutput, InOutput, Impl>>&& comps, std::size_t index, InOutput&& item) {
        if (index >= comps.size()) {
          return pure_process(std::move(item));

        } else {
          return std::move(comps[index])
            .run(std::move(item))
            .and_then([comps{std::move(comps)}, index](InOutput&& next_item) mutable {
              return concat_blocks(std::move(comps), 1 + index, std::move(next_item));
            });
        }
      }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

      /** To concatenate blocks within `Block<InOutput, InOutput>`. */
      template<typename InOutput, typename Impl>
      Process<InOutput> concat_blocks(SharedPtr<std::vector<Block<InOutput, InOutput, Impl>>>&& comps, std::size_t index, InOutput&& item) {
        if (index >= comps->size()) {
          return pure_process(std::move(item));

        } else {
          return comps->operator[](index).copy()
            .run(std::move(item))
            .and_then([comps{std::move(comps)}, index](InOutput&& next_item) mutable {
              return concat_blocks(std::move(comps), 1 + index, std::move(next_item));
            });
        }
      }

#else
#error "Unknown simulation mode"
#endif

    }

    /** 
     * Proceed with the computation by the specified preempted transact
     * and remaining time from the process holding computation such as
     * the Advance block.
     */
    template<typename Item>
      using PreemptBlockTransfer = std::function<Block<Transact<Item>, Unit>(const std::optional<double>&)>;

    /** The preempt block mode. */
    template<typename Item>
    struct PreemptBlockMode {

      /** The Priority mode; otherwise, the Interrupt mode. */
      bool priority_mode;

      /** 
       * Where to transfer the preempted transact, passing the remaing time
       * from the process holding computation such as the Advance block.
       */
      std::optional<PreemptBlockTransfer<Item>> transfer;

      /** The Remove mode. */
      bool remove_mode;

      operator FacilityPreemptMode<Item>() && {
        if (transfer.has_value()) {
          return FacilityPreemptMode<Item> {
            priority_mode,
            [transfer{std::move(transfer.value())}](const Transact<Item>& transact, const std::optional<double>& dt) mutable {
              return transfer(dt).run(Transact<Item> { transact });
            },
            remove_mode
          };

        } else {
          return FacilityPreemptMode<Item> {
            priority_mode,
            std::nullopt,
            remove_mode
          };
        }
      }
    };

    /** The identity block that does not change the input within `Block<InOutput, InOutput>`. */
    template<typename InOutput>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<InOutput, InOutput> auto identity_block() {
#else
    inline auto identity_block() {
#endif
      return cons_block([](InOutput&& input) mutable {
        return pure_process(std::move(input));
      });
    }

    /** The block to simulate some activity within `Block<InOutput, InOutput>`. */
    template<typename InOutput, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<InOutput, InOutput> auto advance_block(Process<Unit, Impl>&& comp) {
#else
    inline auto advance_block(Process<Unit, Impl>&& comp) {
#endif
      return cons_block([comp{std::move(comp)}](InOutput&& input) mutable {
        return std::move(comp).map([input{std::move(input)}](Unit&& unit) mutable {
          return std::move(input);
        });
      });
    }

    /** The block to enqueue within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto queue_block(const QueuePtr& queue, int increment = 1) {
#else
    inline auto queue_block(const QueuePtr& queue, int increment = 1) {
#endif
      return cons_block([=](Transact<Item>&& transact) {
        return into_process(enqueue_transact(queue, transact.transact_id, increment)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          }));
      });
    }

    /** The block to depart from the queue within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto depart_block(const QueuePtr& queue, int decrement = 1) {
#else
    inline auto depart_block(const QueuePtr& queue, int decrement = 1) {
#endif
      return cons_block([=](Transact<Item>&& transact) {
        return into_process(dequeue_transact(queue, transact.transact_id, decrement)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          }));
      });
    }

    /** The block to seize the facility within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto seize_block(const FacilityPtr<Item>& facility) {
#else
    inline auto seize_block(const FacilityPtr<Item>& facility) {
#endif
      return cons_block([=](Transact<Item>&& transact) {
        return seize_facility(facility, transact)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to preempt the facility within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto preempt_block(const FacilityPtr<Item>& facility, PreemptBlockMode<Item>&& mode) {
#else
    inline auto preempt_block(const FacilityPtr<Item>& facility, PreemptBlockMode<Item>&& mode) {
#endif
      return cons_block([facility, mode{std::move(mode)}](Transact<Item>&& transact) mutable {
        return preempt_facility(facility, transact, std::move(mode).operator FacilityPreemptMode<Item>())
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to return the facility within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto return_block(const FacilityPtr<Item>& facility) {
#else
    inline auto return_block(const FacilityPtr<Item>& facility) {
#endif
      return cons_block([facility](Transact<Item>&& transact) {
        return return_facility(facility, transact.transact_id)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to release the facility within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto release_block(const FacilityPtr<Item>& facility) {
#else
    inline auto release_block(const FacilityPtr<Item>& facility) {
#endif
      return cons_block([facility](Transact<Item>&& transact) {
        return release_facility(facility, transact.transact_id)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to enter the storage within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto enter_block(const StoragePtr<Item>& storage, int decrement = 1) {
#else
    inline auto enter_block(const StoragePtr<Item>& storage, int decrement = 1) {
#endif
      return cons_block([=](Transact<Item>&& transact) {
        return enter_storage(storage, transact.transact_id, decrement)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to leave the storage within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto leave_block(const StoragePtr<Item>& storage, int increment = 1) {
#else
    inline auto leave_block(const StoragePtr<Item>& storage, int increment = 1) {
#endif
      return cons_block([=](Transact<Item>&& transact) {
        return leave_storage(storage, increment)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to assign a new value to the transact within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto assign_block(Item&& item) {
#else
    inline auto assign_block(Item&& item) {
#endif
      return cons_block([item{std::move(item)}](Transact<Item>&& transact) mutable {
        return pure_process(Transact<Item> {
          transact.transact_id, std::move(item)
        });
      });
    }

    /** The block to assign a new value to the transact within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto assign_block_c(Event<Item, Impl>&& comp) {
#else
    inline auto assign_block_c(Event<Item, Impl>&& comp) {
#endif
      return cons_block([comp{std::move(comp)}](Transact<Item>&& transact) mutable {
        return into_process(std::move(comp)
          .and_then([tid{transact.transact_id}](Item&& item) mutable {
            return pure_event(Transact<Item> {
              tid, std::move(item)
            });
          }));
      });
    }

    /** 
     * The block to apply some action for the transact value within `Block<Transact<Item>, Transact<Item>>`,
     * where `Fn` is a function that takes a `const Item&` and then returns `void`. 
     */
    template<typename Item, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto foreach_block(Fn&& fn) {
#else
    inline auto foreach_block(Fn&& fn) {
#endif
      return cons_block([fn{std::move(fn)}](Transact<Item>&& transact) mutable {
        fn(const_cast<const Item&>(transact.value));
        return pure_process(std::move(transact));
      });
    }

    /** 
     * The block to apply some action for the transact value within `Block<Transact<Item>, Transact<Item>>`,
     * where `Fn` is a function that takes a `const Item&` and then returns `Event<Unit>`. 
     */
    template<typename Item, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto foreach_block_c(Fn&& fn) {
#else
    inline auto foreach_block_c(Fn&& fn) {
#endif
      return cons_block([fn{std::move(fn)}](Transact<Item>&& transact) mutable {
        return into_process(fn(const_cast<const Item&>(transact.value)))
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to assign a new priority to the transact within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto priority_block(int priority) {
#else
    inline auto priority_block(int priority) {
#endif
      return cons_block([priority](Transact<Item>&& transact) {
        return assign_transact_priority(transact.transact_id, priority)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to assign a new priority to the transact within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto priority_block_c(Event<int, Impl>&& comp) {
#else
    inline auto priority_block_c(Event<int, Impl>&& comp) {
#endif
      return cons_block([comp{std::move(comp)}](Transact<Item>&& transact) mutable {
        return into_process(std::move(comp))
          .and_then([transact{std::move(transact)}](int priority) mutable {
            return assign_transact_priority(transact.transact_id, priority)
              .map([transact{std::move(transact)}](Unit&& unit) mutable {
                return std::move(transact);
              });
          });
      });
    }

    /** 
     * The block to split the transact within `Block<Transact<Item>, Transact<Item>>`
     * by redirecting a new transact to the specified block chain after split.
     */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto split_block(Block<Transact<Item>, Unit, Impl>&& block_chain) {
#else
    inline auto split_block(Block<Transact<Item>, Unit, Impl>&& block_chain) {
#endif
      using ResultImpl = DVCOMPUTE_NS::block::internal::transact::Split<Item, Impl>;
      return Block<Transact<Item>, Transact<Item>, ResultImpl>(ResultImpl(std::move(block_chain)));
    }

    /** 
     * The block to spawn the transact within `Block<Transact<Item>, Transact<Item>>`
     * by redirecting a new transact to the specified block chain after spawning with the specified cancellation mode.
     */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto spawn_block_with(ProcessCancellation cancellation, Block<Transact<Item>, Unit, Impl>&& block_chain) {
#else
    inline auto spawn_block_with(ProcessCancellation cancellation, Block<Transact<Item>, Unit, Impl>&& block_chain) {
#endif
      using ResultImpl = DVCOMPUTE_NS::block::internal::transact::Spawn<Item, Impl>;
      return Block<Transact<Item>, Transact<Item>, ResultImpl>(ResultImpl(cancellation, std::move(block_chain)));
    }

    /** 
     * The block to spawn the transact within `Block<Transact<Item>, Transact<Item>>`
     * by redirecting a new transact to the specified block chain after spawning with the mode when 
     * the related transacts are cancelled together in case of cancelling any of them.
     */
    template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto spawn_block(Block<Transact<Item>, Unit, Impl>&& block_chain) {
#else
    inline auto spawn_block(Block<Transact<Item>, Unit, Impl>&& block_chain) {
#endif
      return spawn_block_with(ProcessCancellation::CancelTogether, std::move(block_chain));
    }

    /** The block to assemble the transact within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto assemble_block(int count) {
#else
    inline auto assemble_block(int count) {
#endif
      return cons_block([count](Transact<Item>&& transact) {
        return assemble_transact(transact.transact_id, count)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** The block to gather the transacts within `Block<Transact<Item>, Transact<Item>>`. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    inline BlockLike<Transact<Item>, Transact<Item>> auto gather_block(int count) {
#else
    inline auto gather_block(int count) {
#endif
      return cons_block([count](Transact<Item>&& transact) {
        return gather_transacts(transact.transact_id, count)
          .map([transact{std::move(transact)}](Unit&& unit) mutable {
            return std::move(transact);
          });
      });
    }

    /** Create a new block computation `Block<Transact<Item>, Output>` by the specified function of `const Item&` and current modeling time point `const Point*`. */
    template<typename Item, typename Output, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
    BlockLike<Transact<Item>, Output> auto block_by(Fn&& fn) {
#else
    auto block_by(Fn&& fn) {
#endif
      auto impl = [fn{std::move(fn)}](Transact<Item>&& transact,
        DVCOMPUTE_NS::internal::process::BoxedContFn<Output>&& cont_fn,
        const ProcessIdPtr &pid,
        const Point *p) mutable
      {
        if (pid->is_cancelled(p)) [[unlikely]] {
          return revoke_process(std::move(cont_fn), pid, p);
        } else {
          return fn(static_cast<const Item&>(transact.value), p)(std::move(transact), std::move(cont_fn), pid, p);
        }
      };
      return Block<Transact<Item>, Output, decltype(impl)>(std::move(impl));
    }

    /** To concatenate blocks within `Block<InOutput, InOutput>`. */
    template<typename InOutput, typename Impl>
    inline Block<InOutput, InOutput> concat_blocks(std::vector<Block<InOutput, InOutput, Impl>>&& comps) {
      return cons_block([comps{std::move(comps)}](InOutput&& item) mutable {
#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)       
        return DVCOMPUTE_NS::block::internal::concat_blocks(std::move(comps), 0, std::move(item));
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
        return DVCOMPUTE_NS::block::internal::concat_blocks(mk_shared<std::vector<Block<InOutput, InOutput, Impl>>>(std::vector<Block<InOutput, InOutput, Impl>>(std::move(comps))), 0, std::move(item));
#else
#error "Unknown simulation mode"
#endif
      });
    }

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** Create a new block computation `Block<Transact<Item>, Unit>` that sends input items as messages to the specified logical process with the given time delay. */
    template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
    BlockLike<Transact<Item>, Unit> auto send_message_block(LogicalProcessId pid, double dt) {
#else
    auto send_message_block(LogicalProcessId pid, double dt) {
#endif
      return cons_block([pid, dt](Transact<Item>&& transact) {
        return into_process(send_message(pid, dt, std::move(transact.value)));
      });
    }

#endif /* DVCOMPUTE_DISTRIBUTED || DVCOMPUTE_CONSERVATIVE */

  }
}

#endif /* dvcompute_block_extra_h */

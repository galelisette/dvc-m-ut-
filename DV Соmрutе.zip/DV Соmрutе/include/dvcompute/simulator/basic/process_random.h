/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_process_random_h
#define dvcompute_process_random_h

#include <algorithm>

#include "../../dvcompute_ns.h"

#include "parameter_random.h"
#include "process.h"
#include "types.h"

namespace DVCOMPUTE_NS {

  /** 
   * The `Process<double>` computation that holds the process for a random time interval 
   * disributed uniformly as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_uniform_process(double min, double max) {
#else
  inline auto random_uniform_process(double min, double max) {
#endif
    return into_process(random_uniform_parameter(min, max))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval 
   * disributed uniformly as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_uniform_process_(double min, double max) {
#else
  inline auto random_uniform_process_(double min, double max) {
#endif
    return into_process(random_uniform_parameter(min, max))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<int>` computation that holds the process for an integer random time interval 
   * disributed uniformly as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<int> auto random_int_uniform_process(int min, int max) {
#else
  inline auto random_int_uniform_process(int min, int max) {
#endif
    return into_process(random_int_uniform_parameter(min, max))
      .and_then([](int dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for an integer random time interval 
   * disributed uniformly as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_int_uniform_process_(int min, int max) {
#else
  inline auto random_int_uniform_process_(int min, int max) {
#endif
    return into_process(random_int_uniform_parameter(min, max))
      .and_then([](int dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval 
   * from the triangular distribution as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_triangular_process(double min, double median, double max) {
#else
  inline auto random_triangular_process(double min, double median, double max) {
#endif
    return into_process(random_triangular_parameter(min, median, max))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval 
   * the triangular distribution as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_triangular_process_(double min, double median, double max) {
#else
  inline auto random_triangular_process_(double min, double median, double max) {
#endif
    return into_process(random_triangular_parameter(min, median, max))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval 
   * disributed normally as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_normal_process(double mu, double nu) {
#else
  inline auto random_normal_process(double mu, double nu) {
#endif
    return into_process(random_normal_parameter(mu, nu))
      .and_then([](double dt0) {
        double dt = std::max(dt0, 0.0);
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval 
   * disributed normally as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_normal_process_(double mu, double nu) {
#else
  inline auto random_normal_process_(double mu, double nu) {
#endif
    return into_process(random_normal_parameter(mu, nu))
      .and_then([](double dt0) {
        double dt = std::max(dt0, 0.0);
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval 
   * disributed lognormally as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_log_normal_process(double mu, double nu) {
#else
  inline auto random_log_normal_process(double mu, double nu) {
#endif
    return into_process(random_log_normal_parameter(mu, nu))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval 
   * disributed lognormally as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_log_normal_process_(double mu, double nu) {
#else
  inline auto random_log_normal_process_(double mu, double nu) {
#endif
    return into_process(random_log_normal_parameter(mu, nu))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for an exponential random 
   * time interval with the specified average as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_exponential_process(double mu) {
#else
  inline auto random_exponential_process(double mu) {
#endif
    return into_process(random_exponential_parameter(mu))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for an exponential random 
   * time interval with the specified average as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_exponential_process_(double mu) {
#else
  inline auto random_exponential_process_(double mu) {
#endif
    return into_process(random_exponential_parameter(mu))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for an Erlang random 
   * time interval with the specified scale (the reciprocal of the rate) and integer shape 
   * as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_erlang_process(double scale, int shape) {
#else
  inline auto random_erlang_process(double scale, int shape) {
#endif
    return into_process(random_erlang_parameter(scale, shape))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for an Erlang random 
   * time interval with the specified scale (the reciprocal of the rate) and integer shape 
   * as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_erlang_process_(double scale, int shape) {
#else
  inline auto random_erlang_process_(double scale, int shape) {
#endif
    return into_process(random_erlang_parameter(scale, shape))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<int>` computation that holds the process for a Poisson random 
   * time interval with the specified average as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<int> auto random_poisson_process(double mu) {
#else
  inline auto random_poisson_process(double mu) {
#endif
    return into_process(random_poisson_parameter(mu))
      .and_then([](int dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a Poisson random 
   * time interval with the specified average as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_poisson_process_(double mu) {
#else
  inline auto random_poisson_process_(double mu) {
#endif
    return into_process(random_poisson_parameter(mu))
      .and_then([](int dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<int>` computation that holds the process for a binomial random 
   * time interval with the specified probability and trials as side effect and 
   * then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<int> auto random_binomial_process(double prob, int trials) {
#else
  inline auto random_binomial_process(double prob, int trials) {
#endif
    return into_process(random_binomial_parameter(prob, trials))
      .and_then([](int dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a binomial random 
   * time interval with the specified probability and trials as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_binomial_process_(double prob, int trials) {
#else
  inline auto random_binomial_process_(double prob, int trials) {
#endif
    return into_process(random_binomial_parameter(prob, trials))
      .and_then([](int dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval from
   * the Gamma distribution as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_gamma_process(double kappa, double theta) {
#else
  inline auto random_gamma_process(double kappa, double theta) {
#endif
    return into_process(random_gamma_parameter(kappa, theta))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval from
   * the Gamma distribution as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_gamma_process_(double kappa, double theta) {
#else
  inline auto random_gamma_process_(double kappa, double theta) {
#endif
    return into_process(random_gamma_parameter(kappa, theta))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval from
   * the Beta distribution as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_beta_process(double alpha, double beta) {
#else
  inline auto random_beta_process(double alpha, double beta) {
#endif
    return into_process(random_beta_parameter(alpha, beta))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval from
   * the Beta distribution as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_beta_process_(double alpha, double beta) {
#else
  inline auto random_beta_process_(double alpha, double beta) {
#endif
    return into_process(random_beta_parameter(alpha, beta))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval from
   * the Weibull distribution as side effect and then returns the interval as result.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_weibull_process(double alpha, double beta) {
#else
  inline auto random_weibull_process(double alpha, double beta) {
#endif
    return into_process(random_weibull_parameter(alpha, beta))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval from
   * the Weibull distribution as side effect.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_weibull_process_(double alpha, double beta) {
#else
  inline auto random_weibull_process_(double alpha, double beta) {
#endif
    return into_process(random_weibull_parameter(alpha, beta))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }

  /** 
   * The `Process<double>` computation that holds the process for a random time interval from
   * the specified discrete distribution as side effect and then returns the interval as result.
   *
   * The first value of the tuple defines the time interval, while the second one defines the probability.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<double> auto random_discrete_process(const SharedPtr<std::vector<std::pair<double, double>>>& dpdf) {
#else
  inline auto random_discrete_process(const SharedPtr<std::vector<std::pair<double, double>>>& dpdf) {
#endif
    return into_process(random_discrete_parameter(dpdf))
      .and_then([](double dt) {
        return hold_process(dt)
          .map([dt](Unit unit) {
            return dt;
          });
      });
  }

  /** 
   * The `Process<Unit>` computation that holds the process for a random time interval from
   * the specified discrete distribution as side effect.
   *
   * The first value of the tuple defines the time interval, while the second one defines the probability.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto random_discrete_process_(const SharedPtr<std::vector<std::pair<double, double>>>& dpdf) {
#else
  inline auto random_discrete_process_(const SharedPtr<std::vector<std::pair<double, double>>>& dpdf) {
#endif
    return into_process(random_discrete_parameter(dpdf))
      .and_then([](double dt) {
        return hold_process(dt);
      });
  }
}

#endif /* dvcompute_process_random_h */

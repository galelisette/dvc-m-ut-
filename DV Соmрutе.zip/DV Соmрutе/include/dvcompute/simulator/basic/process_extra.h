/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_process_extra_h
#define dvcompute_process_extra_h

#include <optional>
#include <algorithm>
#include <vector>

#include "../../dvcompute_ns.h"

#include "process.h"
#include "observable_source.h"
#include "../utils/list.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace process {

      /** Substitute the process computation. */
      template<typename Item, typename Fn>
      inline BoxedContFn<Item> substitute_process(BoxedContFn<Item>&& cont_fn, Fn&& fn) {
        return BoxedContFn<Item>([cont_fn{std::move(cont_fn)}, fn{std::move(fn)}](Result<Item>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
          if (auto* i = get_result_if<Item>(&item)) {
            return fn(std::move(cont_fn), pid, std::move(*i), p);
          } else {
            return std::move(cont_fn)(std::move(item), pid, p);
          }
        });
      }

      /** Substitute the process priority. */
      template<typename Item>
      inline BoxedContFn<Item> substitute_process_priority(int priority, BoxedContFn<Item>&& cont_fn) {
        return BoxedContFn<Item>([priority, cont_fn{std::move(cont_fn)}](Result<Item>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
          if (auto* i = get_result_if<Item>(&item)) {
            if (p->priority == priority) {
              return std::move(cont_fn)(std::move(item), pid, p);
            } else {
              return enqueue_uncancellable_event_with_priority(p->time, priority, 
                cons_event([cont_fn{std::move(cont_fn)}, item{std::move(*i)}, pid](const Point* p) mutable {
                  return resume_process(std::move(cont_fn), pid, std::move(item), p);
                }))
                .operator()(p);
            }
          } else {
            return std::move(cont_fn)(std::move(item), pid, p);
          }
        });
      }

      template<typename Item>
      Result<Unit> reenter_process_at(process::BoxedContFn<Item>&& cont_fn,
        const ProcessIdPtr& pid,
        Item&& val,
        const Point* p);

      /** Sleep until the preempted computation will be reentered. */
      template<typename Item>
      Result<Unit> sleep_process_at(process::BoxedContFn<Item>&& cont_fn,
          const ProcessIdPtr& pid,
          Item&& val,
          const Point* p)
      {
        RefPtr<std::optional<Disposable<>>> rh { mk_shared(Ref<std::optional<Disposable<>>> { std::nullopt }) };
        RefPtr<process::BoxedContFn<Item>> rc { mk_shared(Ref<process::BoxedContFn<Item>> { std::move(cont_fn) }) };
        RefPtr<std::optional<Item>> rv { mk_shared(Ref<std::optional<Item>> { std::move(val) }) };

        auto h {
          process_observable(pid)
            .subscribe(cons_observer([rh, rc, rv, pid](const ProcessEvent* msg, const Point* p) {
              auto h { rh->swap_at(std::nullopt, p) };
              if (h.has_value()) {
                auto r { std::move(h.value())(p) };
                if (get_result_if<Unit>(&r)) {
                  switch (*msg) {
                    case ProcessEvent::CancelInitiating:
                      return enqueue_uncancellable_event(p->time, 
                        cons_event([rc, pid](const Point* p) mutable {
                          if (pid->is_cancelled(p)) {
                            auto c { rc->swap_at(process::BoxedContFn<Item>(), p) };
                            if (c) {
                              return process::revoke_process(std::move(c), pid, p);
                            } else {
                              throw PanicResult("Expected non-empty value");
                            }
                          } else {
                            return Result<Unit>(Unit());
                          }
                        }))
                        .operator()(p);

                    case ProcessEvent::PreemptionEnding:
                      return enqueue_uncancellable_event(p->time, 
                        cons_event([rc, rv, pid](const Point* p) mutable {
                          auto c { rc->swap_at(process::BoxedContFn<Item>(), p) };
                          if (c) {
                            auto v = rv->swap_at(std::nullopt, p);
                            if (v.has_value()) {
                              return reenter_process_at(std::move(c), pid, std::move(v.value()), p);
                            } else {
                              throw PanicResult("Expected non-empty value");
                            }
                          } else {
                            throw PanicResult("Expected non-empty value");
                          }
                        }))
                        .operator()(p);

                    case ProcessEvent::PreemptionInitiating:
                      throw PanicResult("The computation was already preempted");

                    default:
                      throw PanicResult("Unexhausted match");
                  }

                } else {
                  return r;
                }

              } else {
                throw PanicResult("Expected non-empty value");
              }
            }))
            .operator()(p)
        };

        if (Disposable<>* disposable = get_result_if<Disposable<>>(&h)) {
          rh->write_at(std::move(*disposable), p);
          return Result<Unit>(Unit());

        } else {
          return error_result<Unit>(std::move(h));
        }
      }

      /** Reenter the process computation. */
      template<typename Item>
      Result<Unit> reenter_process_at(process::BoxedContFn<Item>&& cont_fn,
        const ProcessIdPtr& pid,
        Item&& val,
        const Point* p)
      {
        if (!is_process_preempted_at(pid, p)) {
          return enqueue_uncancellable_event(p->time, 
            cons_event([cont_fn{std::move(cont_fn)}, val{std::move(val)}, pid](const Point* p) mutable {
              if (!is_process_preempted_at(pid, p)) {
                return process::resume_process(std::move(cont_fn), pid, std::move(val), p);
              } else {
                return sleep_process_at(std::move(cont_fn), pid, std::move(val), p);
              }
            }))
          .operator()(p);

        } else {
          return sleep_process_at(std::move(cont_fn), pid, std::move(val), p);
        }
      }

      /** Represents a temporarily frozen `Process`computation. */
      template<typename Item>
      struct FrozenProcess {
        Event<process::BoxedContFn<Item>> comp;
      };

      /** Unfreeze the process computation. */
      template<typename Item>
      Result<process::BoxedContFn<Item>> unfreeze_process_at(process::FrozenProcess<Item>&& frozen_comp, const Point* p) {
        return std::move(frozen_comp.comp)(p);
      }

      /** Freeze the process computation. */
      template<typename Item>
      Result<process::FrozenProcess<Item>> freeze_process_at(process::BoxedContFn<Item>&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p) 
      {
        process::BoxedContFn<Item> c { process::substitute_process_priority(p->priority, std::move(cont_fn)) };
        RefPtr<std::optional<Disposable<>>> rh { mk_shared(Ref<std::optional<Disposable<>>> { std::nullopt }) };
        RefPtr<process::BoxedContFn<Item>> rc { mk_shared(Ref<process::BoxedContFn<Item>> { std::move(c) }) };
        WeakPtr<ProcessId> weak_pid(pid);

        auto h {
          process_cancel_initiating(pid)
            .subscribe(cons_observer([rh, rc, weak_pid](const Unit* msg, const Point* p) {
              ProcessIdPtr pid(weak_pid.lock());
              if (pid) {
                auto h { rh->swap_at(std::nullopt, p) };
                if (h.has_value()) {
                  auto r { std::move(h.value())(p) };
                  if (get_result_if<Unit>(&r)) {
                    auto c { rc->swap_at(process::BoxedContFn<Item>(), p) };
                    if (c) {
                      return enqueue_uncancellable_event(p->time, 
                        cons_event([c{std::move(c)}, pid](const Point* p) mutable {
                          if (pid->is_cancelled(p)) {
                            return process::revoke_process(std::move(c), pid, p);
                          } else {
                            return Result<Unit>(Unit());
                          }
                        }))
                        .operator()(p);

                    } else {
                      return Result<Unit>(Unit());
                    }

                  } else {
                    return r;
                  }

                } else {
                  throw PanicResult("Expected non-empty value");
                }

              } else {
                throw PanicResult("The process identifier cannot be removed");
              }
            }))
            .operator()(p)
        };

        if (Disposable<>* disposable = get_result_if<Disposable<>>(&h)) {
          rh->write_at(std::move(*disposable), p);
          return process::FrozenProcess<Item> {
            cons_event([rh, rc](const Point* p) mutable {
              auto h { rh->swap_at(std::nullopt, p) };
              if (h.has_value()) {
                auto r { std::move(h.value())(p) };
                if (get_result_if<Unit>(&r)) {
                  return Result<process::BoxedContFn<Item>>(rc->swap_at(process::BoxedContFn<Item>(), p));
                } else {
                  return error_result<process::BoxedContFn<Item>>(std::move(r));
                }

              } else {
                throw PanicResult("Expected non-empty value");
              }
            })
          };

        } else {
          return error_result<process::FrozenProcess<Item>>(std::move(h));
        }
      }

      /** Freeze the process computation by reentering the specified computation. */
      template<typename Item>
      Result<process::FrozenProcess<Item>> freeze_process_with_reentering_at(process::BoxedContFn<Item>&& cont_fn,
        const ProcessIdPtr& pid,
        Item&& val,
        process::BoxedImpl<Item>&& comp,
        const Point* p)
      {
        process::BoxedContFn<Item> c { process::substitute_process_priority(p->priority, std::move(cont_fn)) };
        RefPtr<std::optional<Disposable<>>> rh { mk_shared(Ref<std::optional<Disposable<>>> { std::nullopt }) };
        RefPtr<process::BoxedContFn<Item>> rc { mk_shared(Ref<process::BoxedContFn<Item>> { std::move(c) }) };
        WeakPtr<ProcessId> weak_pid(pid);

        auto h {
          process_cancel_initiating(pid)
            .subscribe(cons_observer([rh, rc, weak_pid](const Unit* msg, const Point* p) {
              ProcessIdPtr pid(weak_pid.lock());
              if (pid) {
                auto h { rh->swap_at(std::nullopt, p) };
                if (h.has_value()) {
                  auto r { std::move(h.value())(p) };
                  if (get_result_if<Unit>(&r)) {
                    auto c { rc->swap_at(process::BoxedContFn<Item>(), p) };
                    if (c) {
                      return enqueue_uncancellable_event(p->time, 
                        cons_event([c{std::move(c)}, pid](const Point* p) mutable {
                          if (pid->is_cancelled(p)) {
                            return process::revoke_process(std::move(c), pid, p);
                          } else {
                            return Result<Unit>(Unit());
                          }
                        }))
                        .operator()(p);

                    } else {
                      return Result<Unit>(Unit());
                    }

                  } else {
                    return r;
                  }

                } else {
                  throw PanicResult("Expected non-empty value");
                }

              } else {
                throw PanicResult("The process identifier cannot be removed");
              }
            }))
            .operator()(p)
        };

        if (Disposable<>* disposable = get_result_if<Disposable<>>(&h)) {
          rh->write_at(std::move(*disposable), p);
          return process::FrozenProcess<Item> {
            cons_event([rh, rc, pid, val{std::move(val)}, comp{std::move(comp)}](const Point* p) mutable {
              auto h { rh->swap_at(std::nullopt, p) };
              if (h.has_value()) {
                auto r { std::move(h.value())(p) };
                if (get_result_if<Unit>(&r)) {
                  auto c { rc->swap_at(process::BoxedContFn<Item>(), p) };
                  if (c) {
                    if (!is_process_preempted_at(pid, p)) {
                      return Result<process::BoxedContFn<Item>>(std::move(c));

                    } else {
                      process::BoxedContFn<Item> inner_cont_fn([comp{std::move(comp)}, c{std::move(c)}](Result<Item>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
                        if (get_result_if<Item>(&item)) {
                          return std::move(comp)(std::move(c), pid, p);
                        } else {
                          return std::move(c)(std::move(item), pid, p);
                        }
                      });

                      auto r { sleep_process_at(std::move(inner_cont_fn), pid, std::move(val), p) };

                      if (get_result_if<Unit>(&r)) {
                        return Result<process::BoxedContFn<Item>>(process::BoxedContFn<Item>());
                      } else {
                        return error_result<process::BoxedContFn<Item>>(std::move(r));
                      }
                    }

                  } else {
                    return Result<process::BoxedContFn<Item>>(process::BoxedContFn<Item>());  
                  }

                } else {
                  return error_result<process::BoxedContFn<Item>>(std::move(r));
                }

              } else {
                throw PanicResult("Expected non-empty value");
              }
            })
          };

        } else {
          return error_result<process::FrozenProcess<Item>>(std::move(h));
        }
      }

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)

      /**
      * The sequence of computations, where the final computation has
      * type `Process<std::vector<Item>>`.
      */
      template<typename Item, typename Impl>
      Process<std::vector<Item>> process_sequence(std::vector<Process<Item, Impl>>&& comps, std::size_t index, std::vector<Item>&& acc) {
        if (index >= comps.size()) {
          std::reverse(acc.begin(), acc.end());
          return pure_process(std::move(acc));

        } else {
          return std::move(comps[index])
            .and_then([comps{std::move(comps)}, index, acc{std::move(acc)}](Item&& item) mutable {
              acc.emplace_back(std::move(item));
              return process_sequence(std::move(comps), 1 + index, std::move(acc));
            });
        }
      }

      /**
      * The sequence of computations for performing side effect, where the final 
      * computation has type `Process<Unit>`.
      */
      template<typename Item, typename Impl>
      Process<Unit> process_sequence_(std::vector<Process<Item, Impl>>&& comps, std::size_t index) {
        if (index >= comps.size()) {
          return pure_process(Unit());

        } else {
          return std::move(comps[index])
            .and_then([comps{std::move(comps)}, index](Item&& item) mutable {
              return process_sequence_(std::move(comps), 1 + index);
            });
        }
      }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)

      /**
      * The sequence of computations, where the final computation has
      * type `Process<std::vector<Item>>`.
      */
      template<typename Item, typename Impl>
      Process<std::vector<Item>> process_sequence(SharedPtr<std::vector<Process<Item, Impl>>>&& comps, std::size_t index, DVCOMPUTE_NS::utils::im::List<Item>&& acc) {
        if (index >= comps->size()) {
          auto res0 { acc.reversed() };
          std::vector<Item> res;

          for (auto &item : res0) {
            res.push_back(item);
          }

          return pure_process(std::move(res));

        } else {
          return comps->operator[](index).copy()
            .and_then([comps{std::move(comps)}, index, acc{std::move(acc)}](Item&& item) mutable {
              return process_sequence(std::move(comps), 1 + index, DVCOMPUTE_NS::utils::im::List(item, acc));
            });
        }
      }

      /**
      * The sequence of computations for performing side effect, where the final 
      * computation has type `Process<Unit>`.
      */
      template<typename Item, typename Impl>
      Process<Unit> process_sequence_(SharedPtr<std::vector<Process<Item, Impl>>>&& comps, std::size_t index) {
        if (index >= comps->size()) {
          return pure_process(Unit());

        } else {
          return comps->operator[](index).copy()
            .and_then([comps{std::move(comps)}, index](Item&& item) mutable {
              return process_sequence_(std::move(comps), 1 + index);
            });
        }
      }

#else
#error "Unknown simulation mode"
#endif

    }
  }

  /** 
   * Await a signal that should be emitted by the specified observable. 
   * Return the `Process<Message>` computation. 
   */
  template<typename Message, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Message> auto process_await(Observable<Message, Impl>&& obs) {
#else
  auto process_await(Observable<Message, Impl>&& obs) {
#endif
    auto impl = [obs{std::move(obs)}](internal::process::BoxedContFn<Message>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      auto frozen_cont { internal::process::freeze_process_at(std::move(cont_fn), pid, p) };
      if (auto *cont = get_result_if<internal::process::FrozenProcess<Message>>(&frozen_cont)) {

        RefPtr<std::optional<Disposable<>>> rh { mk_shared(Ref<std::optional<Disposable<>>> { std::nullopt }) };
        RefPtr<std::optional<Disposable<>>> rh2 { mk_shared(Ref<std::optional<Disposable<>>> { std::nullopt }) };
        RefPtr<std::optional<internal::process::FrozenProcess<Message>>> rc { mk_shared(Ref<std::optional<internal::process::FrozenProcess<Message>>> { std::move(*cont) }) };

        auto h {
          std::move(obs).subscribe(cons_observer([rh, rh2, rc, pid](const Message* msg, const Point* p) {
            auto h { rh->swap_at(std::nullopt, p) };
            if (h.has_value()) {
              TRY_RESULT(std::move(h.value())(p));
            }

            auto h2 { rh2->swap_at(std::nullopt, p) };
            if (h2.has_value()) {
              TRY_RESULT(std::move(h2.value())(p));
            }

            auto c { rc->swap_at(std::nullopt, p) };
            if (c.has_value()) {
              auto unfrozen_cont { unfreeze_process_at(std::move(c.value()), p) };
              if (auto *cont = get_result_if<internal::process::BoxedContFn<Message>>(&unfrozen_cont)) {
                if (*cont) {
                  Message msg2 { *msg };
                  return internal::process::reenter_process_at(std::move(*cont), pid, std::move(msg2), p);
                } else {
                  return Result<Unit>(Unit());
                }

              } else {
                return error_result<Unit>(std::move(unfrozen_cont));
              }

            } else {
              return Result<Unit>(Unit());
            }
          }))
          .operator()(p)
        };

        if (Disposable<>* disposable = get_result_if<Disposable<>>(&h)) {
          auto h2 {
            process_cancel_initiating(pid)
              .subscribe(cons_observer([rh, rh2](const Unit* msg, const Point* p) {
                auto h { rh->swap_at(std::nullopt, p) };
                if (h.has_value()) {
                  TRY_RESULT(std::move(h.value())(p));
                }

                auto h2 { rh2->swap_at(std::nullopt, p) };
                if (h2.has_value()) {
                  TRY_RESULT(std::move(h2.value())(p));
                }

                return Result<Unit>(Unit());
              }))
              .operator()(p)
          };

          if (Disposable<>* disposable2 = get_result_if<Disposable<>>(&h2)) {
            rh->write_at(std::move(*disposable), p);
            rh2->write_at(std::move(*disposable2), p);

            return Result<Unit>(Unit());
          
          } else {
            TRY_RESULT(std::move(*disposable)(p));

            return error_result<Unit>(std::move(h2));
          }

        } else {
          return error_result<Unit>(std::move(h));
        }

      } else {
        return error_result<Unit>(std::move(frozen_cont));
      }
    };
    return Process<Message, decltype(impl)>(std::move(impl));
  }

  /** 
   * Try to run the child process with the given identifier within the specified timeout.
   * If the process will finish successfully within this time interval then
   * the result wrapped in `Process<std::optional<Item>>` will be returned; otherwise, 
   * the child process will be cancelled and `std::nullopt` will be returned within
   * the resulting computation.
   *
   * A cancellation of the child process does not lead to cancelling the parent process.
   * Then `std::nullopt` is returned within the computation.
   *
   * This is a heavy-weight operation destined for working with arbitrary discontinuous
   * processes. Please consider using a more light-weight function `interrupt_process` or 
   * `cancel_process_by_id` whenever possible.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<std::optional<Item>> auto timeout_process_using_id(double timeout, 
    const ProcessIdPtr& pid, 
    Process<Item, Impl>&& comp)
#else
  auto timeout_process_using_id(double timeout, 
    const ProcessIdPtr& pid, 
    Process<Item, Impl>&& comp)
#endif
  {
    SharedPtr<ObservableSource<std::optional<Item>>> s { mk_shared(ObservableSource<std::optional<Item>>()) };
    return into_process(new_process_id())
      .and_then([timeout, pid, comp{std::move(comp)}, s](ProcessIdPtr&& timeout_id) mutable {
        return spawn_process_using_id_with(ProcessCancellation::CancelChildAfterParent, timeout_id, 
          hold_process(timeout)
            .and_then([pid](Unit&& unit) {
              return into_process(cancel_process_by_id(pid));
            }))
        .and_then([pid, timeout_id, comp{std::move(comp)}, s](Unit&& unit) mutable {
          RefPtr<std::optional<Item>> r { mk_shared(Ref<std::optional<Item>> { std::nullopt }) };
          return spawn_process_using_id_with(ProcessCancellation::CancelChildAfterParent, pid,
            finally_process(std::move(comp).and_then([r, s](Item&& item) {
              std::optional<Item> item2 = item;
              return into_process(write_ref(r, std::move(item2)));
            }), into_process(cancel_process_by_id(timeout_id)
              .and_then([r, s](Unit&& unit) {
                return read_ref(r).and_then([s](std::optional<Item>&& item) {
                  return s->trigger(std::move(item));
                });
              }))));
        })
        .and_then([s](Unit&& unit) {
          return process_await(s->publish());
        });
      });
  }

  /** 
   * Try to run the child process within the specified timeout.
   * If the process will finish successfully within this time interval then
   * the result wrapped in `Process<std::optional<Item>>` will be returned; otherwise, 
   * the child process will be cancelled and `std::nullopt` will be returned within
   * the resulting computation.
   *
   * A cancellation of the child process does not lead to cancelling the parent process.
   * Then `std::nullopt` is returned within the computation.
   *
   * This is a heavy-weight operation destined for working with arbitrary discontinuous
   * processes. Please consider using a more light-weight function `interrupt_process` or 
   * `cancel_process_by_id` whenever possible.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<std::optional<Item>> auto timeout_process(double timeout, Process<Item, Impl>&& comp) {
#else
  auto timeout_process(double timeout, Process<Item, Impl>&& comp) {
#endif
    return into_process(new_process_id())
      .and_then([timeout, comp{std::move(comp)}](ProcessIdPtr&& pid) mutable {
        return timeout_process_using_id(timeout, pid, std::move(comp));
      });
  }

  /**
   * The sequence of computations, where the final computation has
   * type `Process<std::vector<Item>>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<std::vector<Item>> auto process_sequence(std::vector<Process<Item, Impl>>&& comps) {
#else
  auto process_sequence(std::vector<Process<Item, Impl>>&& comps) {
#endif
#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
    return internal::process::process_sequence(std::move(comps), 0, std::vector<Item>());
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
    return internal::process::process_sequence(mk_shared<std::vector<Process<Item, Impl>>>(std::vector<Process<Item, Impl>>(std::move(comps))), 0, utils::im::List<Item>());
#else
#error "Unknown simulation mode"
#endif
  }

  /**
   * The sequence of computations for performing side effect, where the final 
   * computation has type `Process<Unit>`.
   */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Unit> auto process_sequence_(std::vector<Process<Item, Impl>>&& comps) {
#else
  auto process_sequence_(std::vector<Process<Item, Impl>>&& comps) {
#endif
#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_CONSERVATIVE)
    return internal::process::process_sequence_(std::move(comps), 0);
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
    return internal::process::process_sequence_(mk_shared<std::vector<Process<Item, Impl>>>(std::vector<Process<Item, Impl>>(std::move(comps))), 0);
#else
#error "Unknown simulation mode"
#endif
  }
}

#endif /* dvcompute_process_extra_h */

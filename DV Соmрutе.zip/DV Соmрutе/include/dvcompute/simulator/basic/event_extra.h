/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_event_extra_h
#define dvcompute_event_extra_h

#include "event.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace event {

      /** @private */
      template<typename Fn>
      Event<Unit> enqueue_events_with_integ_times_loop(Fn&& comp_fn, unsigned int n) {
        auto fn = [comp_fn{std::move(comp_fn)}, n](const Point *p) mutable {
          Result<Unit> res { comp_fn()(p) };
          if (get_result_if(&res)) {
            Point p2 { p->run->point_with_iteration(1 + n, p->priority) };
            return enqueue_event(p2.time, 
                DVCOMPUTE_NS::internal::event::enqueue_events_with_integ_times_loop(std::move(comp_fn), 1 + n))
              .operator()(p);

          } else {
            return error_result<Unit>(std::move(res));
          }
        };
        return Event<Unit, decltype(fn)>(std::move(fn));
      }

      /** @private */
      template<typename Fn>
      Event<Unit> enqueue_io_events_with_integ_times_loop(Fn&& comp_fn, unsigned int n) {
        auto fn = [comp_fn{std::move(comp_fn)}, n](const Point *p) mutable {
          Result<Unit> res { comp_fn()(p) };
          if (get_result_if(&res)) {
            Point p2 { p->run->point_with_iteration(1 + n, p->priority) };
            return enqueue_io_event(p2.time, 
                DVCOMPUTE_NS::internal::event::enqueue_io_events_with_integ_times_loop(std::move(comp_fn), 1 + n))
              .operator()(p);

          } else {
            return error_result<Unit>(std::move(res));
          }
        };
        return Event<Unit, decltype(fn)>(std::move(fn));
      }
    }
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified event handlers that
   * should be actuated in the integration time points. The handlers are created by
   * the function provided.
   */
  template<typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_events_with_integ_times(Fn&& comp_fn) {
#else
  auto enqueue_events_with_integ_times(Fn&& comp_fn) {
#endif
    auto fn = [comp_fn{std::move(comp_fn)}](const Point *p) mutable {
      unsigned int n = p->iteration(); 
      Point p2 { p->run->point_with_iteration(n, p->priority) };
      bool f = (p2.time < p->time);
      unsigned int n3 = f ? (1 + n) : n;
      Point p3 = f ? p->run->point_with_iteration(n3, p->priority) : p2;
      return enqueue_event(p3.time, 
          DVCOMPUTE_NS::internal::event::enqueue_events_with_integ_times_loop(std::move(comp_fn), n3))
        .operator()(p);
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified IO event handlers that
   * should be actuated in the integration time points. The handlers are created by
   * the function provided.
   */
  template<typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto enqueue_io_events_with_integ_times(Fn&& comp_fn) {
#else
  auto enqueue_io_events_with_integ_times(Fn&& comp_fn) {
#endif
    auto fn = [comp_fn{std::move(comp_fn)}](const Point *p) mutable {
      unsigned int n = p->iteration(); 
      Point p2 { p->run->point_with_iteration(n, p->priority) };
      bool f = (p2.time < p->time);
      unsigned int n3 = f ? (1 + n) : n;
      Point p3 = f ? p->run->point_with_iteration(n3, p->priority) : p2;
      return enqueue_io_event(p3.time, 
          DVCOMPUTE_NS::internal::event::enqueue_io_events_with_integ_times_loop(std::move(comp_fn), n3))
        .operator()(p);
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }
}

#endif /* dvcompute_event_extra_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_arrival_h
#define dvcompute_arrival_h

#include <optional>

#include "../../dvcompute_ns.h"
#include "types.h"

namespace DVCOMPUTE_NS {

  /** An arrival to denote some external event. */
  template<typename Item>
  struct Arrival {

    /** The data received with the event. */
    Item value;

    /** The simulation time at which the event has arrived. */
    double time;

    /** The delay time which has passed from the time of arriving the previous event. */
    std::optional<double> delay;
  };
}

#endif /* dvcompute_arrival_h */

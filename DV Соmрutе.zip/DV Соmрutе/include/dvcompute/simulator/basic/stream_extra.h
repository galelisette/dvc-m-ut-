/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_stream_extra_h
#define dvcompute_stream_extra_h

#include <optional>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "stream.h"
#include "process.h"
#include "arrival.h"
#include "stream.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace stream {

      namespace extra {

        /** Transform the stream into a stream of arrivals. */
        template<typename Item>
        inline Stream<Arrival<Item>> arrival_stream_loop(Stream<Item>&& stream, const std::optional<double>& t0) {
          return Stream<Arrival<Item>> {
            std::move(stream)
              .run()
              .and_then([t0](std::pair<Item, Stream<Item>>&& pair) {
                return into_process(event_time())
                  .and_then([pair{std::move(pair)}, t0](double t) mutable {
                    Arrival<Item> arrival {
                      std::move(pair.first), t, t0.has_value() ? std::make_optional(t - t0.value()) : std::nullopt
                    };

                    return pure_process(std::pair<Arrival<Item>, Stream<Arrival<Item>>>(std::move(arrival),
                      arrival_stream_loop<Item>(std::move(pair.second), std::make_optional(t))));
                  });
              })
          };
        }
      }
    }
  }

  /** Transform a stream into a stream of arrivals. */
  template<typename Item>
  inline Stream<Arrival<Item>> arrival_stream(Stream<Item>&& stream) {
    return DVCOMPUTE_NS::internal::stream::extra::arrival_stream_loop<Item>(std::move(stream), std::nullopt);
  }
}

#endif /* dvcompute_stream_extra_h */

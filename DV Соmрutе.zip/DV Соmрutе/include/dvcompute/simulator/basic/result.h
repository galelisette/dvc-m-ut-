/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_h
#define dvcompute_result_h

#include <variant>
#include <vector>
#include <stdexcept>
#include <type_traits>

#include "../../dvcompute_ns.h"
#include "../../dvcompute_api.h"
#include "macros.h"
#include "types.h"

/** General-purpose C++ Discrete Event Simulation (DES) library. */
namespace DVCOMPUTE_NS {

  /** Represents an event triggered when there is need to retry the computation. */
  class DVCOMPUTE_API RetryResult {

    const char* msg;

  public:

    explicit RetryResult(const char* msg_arg) noexcept : msg(msg_arg) {}

    RetryResult(const RetryResult& other) = default;
    RetryResult& operator=(const RetryResult& other) = default;

    /** Return the description of the error. */
    const char* what() const {
      return msg;
    }
  };

  /** The cancellation event. */
  class DVCOMPUTE_API CancelResult {};

  /** The result of computation. */
  template<typename Item>
  struct Result {
    
    const int tag;

    union {
      Item item;                    // tag = 0
      CancelResult cancel_result;   // tag = 1
      RetryResult retry_result;     // tag = 2
    };

  public:

    using item_type = Item;

    explicit Result() :
      tag(0)
    {
      new (&item) Item();
    }

    Result(const Item& item_arg) :
      tag(0)
    {
      new (&item) Item(item_arg);
    }

    Result(Item&& item_arg) noexcept(noexcept(Item(std::move(item_arg)))) :
      tag(0)
    {
      new (&item) Item(std::move(item_arg));
    }

    Result(const CancelResult& e_arg) :
      tag(1)
    {
      new (&cancel_result) CancelResult(e_arg);
    }

    Result(CancelResult&& e_arg) noexcept(noexcept(CancelResult(std::move(e_arg)))) :
      tag(1)
    {
      new (&cancel_result) CancelResult(std::move(e_arg));
    }

    Result(const RetryResult& e_arg) :
      tag(2)
    {
      new (&retry_result) RetryResult(e_arg);
    }

    Result(RetryResult&& e_arg) noexcept(noexcept(RetryResult(std::move(e_arg)))) :
      tag(2)
    {
      new (&retry_result) RetryResult(std::move(e_arg));
    }

    Result(Result<Item>&& other) noexcept(noexcept(Item(std::move(other.item)))) :
      tag(other.tag)
    {
      switch(tag) {
        case 0:
          new(&item) Item(std::move(other.item));
          break;

        case 1:
          new(&cancel_result) CancelResult(std::move(other.cancel_result));
          break;

        case 2:
          new(&retry_result) RetryResult(std::move(other.retry_result));
          break;
      }
    }

    Result(const Result<Item>& other) :
      tag(other.tag)
    {
      switch(tag) {
        case 0:
          new(&item) Item(other.item);
          break;

        case 1:
          new(&cancel_result) CancelResult(other.cancel_result);
          break;

        case 2:
          new(&retry_result) RetryResult(other.retry_result);
          break;
      }
    }

    Result<Item>& operator=(Result<Item>&&) = delete;
    Result<Item>& operator=(const Result<Item>&) = delete;

    ~Result() {
      switch(tag) {
        case 0:
          item.~Item();
          break;

        case 1:
          cancel_result.~CancelResult();
          break;

        case 2:
          retry_result.~RetryResult();
          break;
      }
    }

  private:

    template<typename Item2>
    friend Item2* get_result_if(Result<Item2>* result) noexcept;

    template<typename Item2>
    friend const Item2* get_result_if(const Result<Item2>* result) noexcept;

    template<typename Item2>
    friend CancelResult* get_cancel_result_if(Result<Item2>* result) noexcept;

    template<typename Item2>
    friend const CancelResult* get_cancel_result_if(const Result<Item2>* result) noexcept;

    template<typename Item2>
    friend RetryResult* get_retry_result_if(Result<Item2>* result) noexcept;

    template<typename Item2>
    friend const RetryResult* get_retry_result_if(const Result<Item2>* result) noexcept;
  };

  /** The result of computation. */
  template<>
  struct Result<Unit> {

    inline static Unit unit {};     // tag = 0
    
    const int tag;

    union {
      CancelResult cancel_result;   // tag = 1
      RetryResult retry_result;     // tag = 2
    };

  public:

    using item_type = Unit;

    explicit Result() noexcept :
      tag(0)
    {}

    Result(const Unit& item_arg) noexcept :
      tag(0)
    {}

    Result(Unit&& item_arg) noexcept :
      tag(0)
    {}

    Result(const CancelResult& e_arg) :
      tag(1)
    {
      new (&cancel_result) CancelResult(e_arg);
    }

    Result(CancelResult&& e_arg) noexcept(noexcept(CancelResult(std::move(e_arg)))) :
      tag(1)
    {
      new (&cancel_result) CancelResult(std::move(e_arg));
    }

    Result(const RetryResult& e_arg) :
      tag(2)
    {
      new (&retry_result) RetryResult(e_arg);
    }

    Result(RetryResult&& e_arg) noexcept(noexcept(RetryResult(std::move(e_arg)))) :
      tag(2)
    {
      new (&retry_result) RetryResult(std::move(e_arg));
    }

    Result(Result<Unit>&& other) noexcept :
      tag(other.tag)
    {
      switch(tag) {
        case 0:
          break;

        case 1:
          new(&cancel_result) CancelResult(std::move(other.cancel_result));
          break;

        case 2:
          new(&retry_result) RetryResult(std::move(other.retry_result));
          break;
      }
    }

    Result(const Result<Unit>& other) :
      tag(other.tag)
    {
      switch(tag) {
        case 0:
          break;

        case 1:
          new(&cancel_result) CancelResult(other.cancel_result);
          break;

        case 2:
          new(&retry_result) RetryResult(other.retry_result);
          break;
      }
    }

    Result<Unit>& operator=(Result<Unit>&&) = delete;
    Result<Unit>& operator=(const Result<Unit>&) = delete;

    ~Result() {
      switch(tag) {
        case 0:
          break;

        case 1:
          cancel_result.~CancelResult();
          break;

        case 2:
          retry_result.~RetryResult();
          break;
      }
    }

  private:

    template<typename Item2>
    friend Item2* get_result_if(Result<Item2>* result) noexcept;

    template<typename Item2>
    friend const Item2* get_result_if(const Result<Item2>* result) noexcept;

    template<typename Item2>
    friend CancelResult* get_cancel_result_if(Result<Item2>* result) noexcept;

    template<typename Item2>
    friend const CancelResult* get_cancel_result_if(const Result<Item2>* result) noexcept;

    template<typename Item2>
    friend RetryResult* get_retry_result_if(Result<Item2>* result) noexcept;

    template<typename Item2>
    friend const RetryResult* get_retry_result_if(const Result<Item2>* result) noexcept;
  };

  template<typename Item>
  inline Item* get_result_if(Result<Item>* result) noexcept {
    if (result->tag == 0) {
      return &result->item;
    } else {
      return nullptr;
    }
  }

  template<>
  inline Unit* get_result_if<Unit>(Result<Unit>* result) noexcept {
    if (result->tag == 0) {
      return &Result<Unit>::unit;
    } else {
      return nullptr;
    }
  }

  template<typename Item>
  inline const Item* get_result_if(const Result<Item>* result) noexcept {
    if (result->tag == 0) {
      return &result->item;
    } else {
      return nullptr;
    }
  }

  template<>
  inline const Unit* get_result_if<Unit>(const Result<Unit>* result) noexcept {
    if (result->tag == 0) {
      return &Result<Unit>::unit;
    } else {
      return nullptr;
    }
  }

  template<typename Item>
  inline CancelResult* get_cancel_result_if(Result<Item>* result) noexcept {
    if (result->tag == 1) {
      return &result->cancel_result;
    } else {
      return nullptr;
    }
  }

  template<>
  inline CancelResult* get_cancel_result_if<Unit>(Result<Unit>* result) noexcept {
    if (result->tag == 1) {
      return &result->cancel_result;
    } else {
      return nullptr;
    }
  }

  template<typename Item>
  inline const CancelResult* get_cancel_result_if(const Result<Item>* result) noexcept {
    if (result->tag == 1) {
      return &result->cancel_result;
    } else {
      return nullptr;
    }
  }

  template<>
  inline const CancelResult* get_cancel_result_if<Unit>(const Result<Unit>* result) noexcept {
    if (result->tag == 1) {
      return &result->cancel_result;
    } else {
      return nullptr;
    }
  }

  template<typename Item>
  inline RetryResult* get_retry_result_if(Result<Item>* result) noexcept {
    if (result->tag == 2) {
      return &result->retry_result;
    } else {
      return nullptr;
    }
  }

  template<>
  inline RetryResult* get_retry_result_if<Unit>(Result<Unit>* result) noexcept {
    if (result->tag == 2) {
      return &result->retry_result;
    } else {
      return nullptr;
    }
  }

  template<typename Item>
  inline const RetryResult* get_retry_result_if(const Result<Item>* result) noexcept {
    if (result->tag == 2) {
      return &result->retry_result;
    } else {
      return nullptr;
    }
  }

  template<>
  inline const RetryResult* get_retry_result_if<Unit>(const Result<Unit>* result) noexcept {
    if (result->tag == 2) {
      return &result->retry_result;
    } else {
      return nullptr;
    }
  }

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace result {

      /** Whether `F` is a function that takes `Arg` and returns an `Result<Item>` computation. */
      template<typename F, typename Arg, typename Item>
      concept ResultBindFn3 = std::is_invocable_r_v<Result<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns an `Result<Item>` computation. */
      template<typename F, typename Arg>
      concept ResultBindFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires ResultBindFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };
    }
  }

  /** Whether `F` is a function that takes `Arg` and returns an `Result<Item>` computation. */
  template<typename F, typename Arg>
  concept ResultBindFn = internal::result::ResultBindFn2<F, Arg>;

#endif /* DVCOMPUTE_CONCEPTS */

  /** The unknown result. */
  class DVCOMPUTE_API UnknownResult : public std::exception {
  public:
    explicit UnknownResult() {}
  };

  /** The panic result. */
  class DVCOMPUTE_API PanicResult : public std::logic_error {
  public:
    explicit PanicResult(const char* what_arg) : std::logic_error(what_arg) {}
    explicit PanicResult(const std::string& what_arg) : std::logic_error(what_arg) {}
  };

  template<typename ThenItem, typename Item>
  DVCOMPUTE_NOINLINE Result<ThenItem> error_result(Result<Item>&& item) {
    if (auto c = get_cancel_result_if(&item)) {
      return Result<ThenItem>(std::move(*c));
    } else if (auto e = get_retry_result_if(&item)) {
      return Result<ThenItem>(std::move(*e));
    } else {
      throw UnknownResult();
    }
  }

  template<typename Item, typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
  DVCOMPUTE_ALWAYS_INLINE auto then_result(Result<Item>&& item, BindFn&& k) requires ResultBindFn<BindFn, Item> {
#else
  DVCOMPUTE_ALWAYS_INLINE auto then_result(Result<Item>&& item, BindFn&& k) {
#endif
    using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
    if (Item *i = get_result_if<Item>(&item)) [[likely]] {
      return k(std::move(*i));
    } else {
      return error_result<ThenItem>(std::move(item));
    }
  }

  template<typename Item>
  const Item& expect_result(const Result<Item>& result) {
    if (const Item *x = get_result_if<Item>(&result)) {
      return *x;
    } else if (get_cancel_result_if(&result)) {
      throw new PanicResult("Expected a pure result but received a CancelResult");
    } else if (auto e = get_retry_result_if(&result)) {
      throw new PanicResult("Expected a pure result but received a RetryResult");
    } else {
      throw new UnknownResult();      
    }
  }

  template<typename Item>
  Item& expect_result(Result<Item>& result) {
    if (Item *x = get_result_if<Item>(&result)) {
      return *x;
    } else if (get_cancel_result_if(&result)) {
      throw new PanicResult("Expected a pure result but received a CancelResult");
    } else if (auto e = get_retry_result_if(&result)) {
      throw new PanicResult("Expected a pure result but received a RetryResult");
    } else {
      throw new UnknownResult();      
    }
  }

  template<typename Item>
  Item expect_result(Result<Item>&& result) {
    if (Item *x = get_result_if<Item>(&result)) {
      return Item(std::move(*x));
    } else if (get_cancel_result_if(&result)) {
      throw new PanicResult("Expected a pure result but received a CancelResult");
    } else if (auto e = get_retry_result_if(&result)) {
      throw new PanicResult("Expected a pure result but received a RetryResult");
    } else {
      throw new UnknownResult();      
    }
  }

  template<typename Item>
  Result<std::vector<Item>> result_sequence(std::vector<Result<Item>>&& sub_results) {
    std::vector<Item> result;
    for (auto& res : sub_results) {
      if (auto item = get_result_if<Item>(&res)) [[likely]] {
        result.emplace_back(std::move(*item));
      } else if (auto c = get_cancel_result_if(&res)) {
        return Result<std::vector<Item>>(*c);
      } else if (auto e = get_retry_result_if(&res)) {
        return Result<std::vector<Item>>(*e);
      } else {
        throw UnknownResult();
      }
    }
    return Result<std::vector<Item>>(result);
  }

#define TRY_RESULT(result) {                     \
    Result<Unit> res_1234567890 { result };      \
    if (!get_result_if<Unit>(&(res_1234567890))) {          \
      return error_result<Unit>(std::move(res_1234567890)); \
    }                                            \
  }
}

#endif /* dvcompute_result_h */

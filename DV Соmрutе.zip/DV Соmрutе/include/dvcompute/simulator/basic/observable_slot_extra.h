/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_observable_slot_extra_h
#define dvcompute_observable_slot_extra_h

#include "observable_extra.h"
#include "observable_slot.h"

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)
#include "../net/messaging.h"
#endif

namespace DVCOMPUTE_NS {

  namespace slot {

    /** The empty `ObservableSlot<Message>` that does not emit messages at all. */
    template<typename Message>
#ifdef DVCOMPUTE_CONCEPTS
    inline ObservableSlotLike<Message> auto empty_observable_slot() {
#else
    inline auto empty_observable_slot() {
#endif
      auto fn = []() {
        return empty_observable<Message>();
      };
      return ObservableSlot<Message, decltype(fn)>(std::move(fn));
    }

    /** To concatenate observable slots as `ObservableSlot<Message>`. */
    template<typename Message, typename Impl>
    inline ObservableSlot<Message> concat_observable_slots(const std::vector<ObservableSlot<Message, Impl>>& slots) {
      ObservableSlot<Message> result = empty_observable_slot<Message>();
      for (const auto& slot : slots) {
        result = result.merge(slot);
      }
      return result;
    }

#if defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** Return an `ObservableSlot<Message>` for incoming messages that come from other logical processes. */
    template<typename Message>
#ifdef DVCOMPUTE_CONCEPTS
    ObservableSlotLike<Message> auto input_message_slot() {
#else
    auto input_message_slot() {
#endif
      auto fn = []() {
        return input_messages<Message>();
      };
      return ObservableSlot<Message, decltype(fn)>(std::move(fn));
    }

#endif /* DVCOMPUTE_DISTRIBUTED || DVCOMPUTE_CONSERVATIVE */

  }
}

#endif /* dvcompute_observable_slot_extra_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_macros_h
#define dvcompute_macros_h

#ifndef NDEBUG
#define DVCOMPUTE_TIME_CHECK
#endif /* NDEBUG */

#if defined(__GNUC__)
#define DVCOMPUTE_ALWAYS_INLINE __attribute__((always_inline))
#define DVCOMPUTE_NOINLINE __attribute__((noinline))
#elif defined(__clang__)
#define DVCOMPUTE_ALWAYS_INLINE __attribute__((always_inline))
#define DVCOMPUTE_NOINLINE __attribute__((noinline))
#elif defined(_MSC_VER)
#define DVCOMPUTE_ALWAYS_INLINE __forceinline
#define DVCOMPUTE_NOINLINE __declspec(noinline)
#else
#define DVCOMPUTE_ALWAYS_INLINE
#define DVCOMPUTE_NOINLINE
#endif

#if defined(__LCC__)
#define DVCOMPUTE_E2K_INTRINSICS
#undef DVCOMPUTE_BIT_EMULATION
#elif defined(__cpp_lib_bitops)
#undef DVCOMPUTE_E2K_INTRINSICS
#undef DVCOMPUTE_BIT_EMULATION
#else
#undef DVCOMPUTE_E2K_INTRINSICS
#undef DVCOMPUTE_BIT_EMULATION
#endif /* bit ops */

#if defined(__LCC__)
#define DVCOMPUTE_COPY_CTOR
#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_BRANCHED)
#define DVCOMPUTE_COPY_CTOR
#endif /* copy constructors */

#if defined(__cpp_concepts)
#if defined(__clang__)
#define DVCOMPUTE_CONCEPTS
#elif defined(__GNUC__)
#if __GNUC__ > 10
#define DVCOMPUTE_CONCEPTS
#else
#undef DVCOMPUTE_CONCEPTS
#endif /* __GNUC__ > 10 */
#else
#define DVCOMPUTE_CONCEPTS
#endif /* __GNUC__ */
#else
#undef DVCOMPUTE_CONCEPTS
#endif /* concepts */

#if defined(__LCC__)
#undef DVCOMPUTE_CXX_FILESYSTEM
#else
#define DVCOMPUTE_CXX_FILESYSTEM
#endif /* c++17 file system module */

#endif /* dvcompute_macros_h */

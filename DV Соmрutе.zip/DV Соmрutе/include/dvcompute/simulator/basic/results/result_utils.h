/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_utils_h
#define dvcompute_result_utils_h

#include <string>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/results/result_source.h"
#include "dvcompute/simulator/basic/results/result_locale.h"

namespace DVCOMPUTE_NS {

  namespace results {

    /** Get the qualified name. */
    inline std::string result_qualified_name(const std::vector<std::shared_ptr<ResultId>>& id_path, ResultLocale loc) {
      std::string s;
      for (auto& id : id_path) {
        if (!s.empty()) {
          s += '.';
        }
        auto title { id->title(loc) };
        if (title.has_value()) {
          s += title.value();
        } else {
          s += "{name}";
        }
      }

      return s;
    }
  }
}

#endif /* dvcompute_result_utils_h */

﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_sampling_stats_h
#define dvcompute_result_sampling_stats_h

#include <string>
#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "../result_source.h"
#include "../result_items.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** Observation-based statistics. */
      class SamplingStatsId : public ResultTypeId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("сводная статистика");
          } else {
            return std::string("statistics summary");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика");
          } else {
            return std::string("stats");
          }
        }
      };

      /** The count of samples in the statistics summary. */
      class SamplingStatsCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество");
          } else {
            return std::string("count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("кол-во");
          } else {
            return std::string("count");
          }
        }
      };
    
      /** The average value in the statistics summary. */
      class SamplingStatsMeanId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее значение");
          } else {
            return std::string("mean");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее значение");
          } else {
            return std::string("mean");
          }
        }
      };
      
      /** The average square value in the statistics summary. */
      class SamplingStatsMean2Id : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее квадратов");
          } else {
            return std::string("mean square");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее квадратов");
          } else {
            return std::string("mean square");
          }
        }
      };
      
      /** The deviation in the statistics summary. */
      class SamplingStatsDeviationId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднеквадратическое отклонение");
          } else {
            return std::string("deviation");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("СКО");
          } else {
            return std::string("deviation");
          }
        }
      };
      
      /** The variance in the statistics summary. */
      class SamplingStatsVarianceId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("дисперсия");
          } else {
            return std::string("variance");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("дисперсия");
          } else {
            return std::string("variance");
          }
        }
      };
      
      /** The minimum value in the statistics summary. */
      class SamplingStatsMinId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("минимальное значение");
          } else {
            return std::string("minimum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("минимум");
          } else {
            return std::string("minimum");
          }
        }
      };
      
      /** The maximum value in the statistics summary. */
      class SamplingStatsMaxId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("максимальное значение");
          } else {
            return std::string("maximum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("максимум");
          } else {
            return std::string("maximum");
          }
        }
      };

      template<typename Item>
      inline ResultSource make_stats_result_source(const ResultValue<SamplingStats<Item>>& arg) {
        std::vector<ResultProperty> props;

        props.emplace_back(arg.map_prop("count", 
          std::shared_ptr<ResultId>(new SamplingStatsCountId), 
          [](SamplingStats<Item>&& x) { return static_cast<int>(x.count); }));

        props.emplace_back(arg.map_prop("mean", 
          std::shared_ptr<ResultId>(new SamplingStatsMeanId), 
          [](SamplingStats<Item>&& x) { return x.mean; }));

        props.emplace_back(arg.map_prop("mean2", 
          std::shared_ptr<ResultId>(new SamplingStatsMean2Id), 
          [](SamplingStats<Item>&& x) { return x.mean2; }));

        props.emplace_back(arg.map_prop("std", 
          std::shared_ptr<ResultId>(new SamplingStatsDeviationId), 
          [](SamplingStats<Item>&& x) { return x.deviation(); }));

        props.emplace_back(arg.map_prop("var", 
          std::shared_ptr<ResultId>(new SamplingStatsVarianceId), 
          [](SamplingStats<Item>&& x) { return x.variance(); }));

        props.emplace_back(arg.map_prop("min", 
          std::shared_ptr<ResultId>(new SamplingStatsMinId), 
          [](SamplingStats<Item>&& x) { return x.min; }));

        props.emplace_back(arg.map_prop("max", 
          std::shared_ptr<ResultId>(new SamplingStatsMaxId), 
          [](SamplingStats<Item>&& x) { return x.max; }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new SamplingStatsId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }
    }

    template<>
    inline ResultSource make_result_source(const ResultValue<SamplingStats<int>>& arg) {
      return make_stats_result_source(arg);
    }

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<SamplingStats<int>>& arg) {
      return ResultSource {
        make_result_item(ResultValue<SamplingStats<int>> { arg })
      };
    }

    template<>
    inline ResultSource make_result_source(const ResultValue<SamplingStats<double>>& arg) {
      return make_stats_result_source(arg);
    }

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<SamplingStats<double>>& arg) {
      return ResultSource {
        make_result_item(ResultValue<SamplingStats<double>> { arg })
      };
    }
  }
}

#endif /* dvcompute_result_sampling_stats_h */

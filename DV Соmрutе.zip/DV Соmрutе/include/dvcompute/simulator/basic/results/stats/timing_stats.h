﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_timing_stats_h
#define dvcompute_result_timing_stats_h

#include <string>
#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "../result_source.h"
#include "../result_items.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** Time persistent variable statistics. */
      class TimingStatsId : public ResultTypeId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("временная статистика");
          } else {
            return std::string("timing statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("временная статистика");
          } else {
            return std::string("timing stats");
          }
        }
      };

      /** The count of samples in the statistics summary. */
      class TimingStatsCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество");
          } else {
            return std::string("count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("кол-во");
          } else {
            return std::string("count");
          }
        }
      };
    
      /** The average value in the statistics summary. */
      class TimingStatsMeanId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее значение");
          } else {
            return std::string("mean");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее значение");
          } else {
            return std::string("mean");
          }
        }
      };
      
      /** The average square value in the statistics summary. */
      class TimingStatsMean2Id : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее квадратов");
          } else {
            return std::string("mean square");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее квадратов");
          } else {
            return std::string("mean square");
          }
        }
      };
      
      /** The deviation in the statistics summary. */
      class TimingStatsDeviationId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднеквадратическое отклонение");
          } else {
            return std::string("deviation");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("СКО");
          } else {
            return std::string("deviation");
          }
        }
      };
      
      /** The variance in the statistics summary. */
      class TimingStatsVarianceId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("дисперсия");
          } else {
            return std::string("variance");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("дисперсия");
          } else {
            return std::string("variance");
          }
        }
      };
      
      /** The minimum value in the statistics summary. */
      class TimingStatsMinId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("минимальное значение");
          } else {
            return std::string("minimum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("минимум");
          } else {
            return std::string("minimum");
          }
        }
      };
      
      /** The maximum value in the statistics summary. */
      class TimingStatsMaxId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("максимальное значение");
          } else {
            return std::string("maximum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("максимум");
          } else {
            return std::string("maximum");
          }
        }
      };

      /** The time of attaining the minimum value in the statistics summary. */
      class TimingStatsMinTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время достижения минимума");
          } else {
            return std::string("the time of minimum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время минимума");
          } else {
            return std::string("the time of minimum");
          }
        }
      };
      
      /** The time of attaining the maximum value in the statistics summary. */
      class TimingStatsMaxTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время достижения максимума");
          } else {
            return std::string("the time of maximum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время максимума");
          } else {
            return std::string("the time of maximum");
          }
        }
      };

      /** The start time of gathering the statistics summary. */
      class TimingStatsStartTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("начальное время сбора статистики");
          } else {
            return std::string("the start time of gathering the statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("начальное время");
          } else {
            return std::string("the start time");
          }
        }
      };

      /** The last time of gathering the statistics summary. */
      class TimingStatsLastTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("конечное время сбора статистики");
          } else {
            return std::string("the last time of gathering the statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("конечное время");
          } else {
            return std::string("the last time");
          }
        }
      };

      /** The sum value. */
      class TimingStatsSumId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("сумма");
          } else {
            return std::string("the sum");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("сумма");
          } else {
            return std::string("the sum");
          }
        }
      };

      /** The sum square value. */
      class TimingStatsSum2Id : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("сумма квадратов");
          } else {
            return std::string("the sum square");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("сумма квадратов");
          } else {
            return std::string("the sum square");
          }
        }
      };

      template<typename Item>
      inline ResultSource make_timing_stats_result_source(const ResultValue<TimingStats<Item>>& arg) {
        std::vector<ResultProperty> props;

        props.emplace_back(arg.map_prop("count", 
          std::shared_ptr<ResultId>(new TimingStatsCountId), 
          [](TimingStats<Item>&& x) { return static_cast<int>(x.count); }));

        props.emplace_back(arg.map_prop("mean", 
          std::shared_ptr<ResultId>(new TimingStatsMeanId), 
          [](TimingStats<Item>&& x) { return x.mean(); }));

        props.emplace_back(arg.map_prop("mean2", 
          std::shared_ptr<ResultId>(new TimingStatsMean2Id), 
          [](TimingStats<Item>&& x) { return x.mean2(); }));

        props.emplace_back(arg.map_prop("std", 
          std::shared_ptr<ResultId>(new TimingStatsDeviationId), 
          [](TimingStats<Item>&& x) { return x.deviation(); }));

        props.emplace_back(arg.map_prop("var", 
          std::shared_ptr<ResultId>(new TimingStatsVarianceId), 
          [](TimingStats<Item>&& x) { return x.variance(); }));

        props.emplace_back(arg.map_prop("min", 
          std::shared_ptr<ResultId>(new TimingStatsMinId), 
          [](TimingStats<Item>&& x) { return x.min; }));

        props.emplace_back(arg.map_prop("max", 
          std::shared_ptr<ResultId>(new TimingStatsMaxId), 
          [](TimingStats<Item>&& x) { return x.max; }));

        props.emplace_back(arg.map_prop("min_time", 
          std::shared_ptr<ResultId>(new TimingStatsMinTimeId), 
          [](TimingStats<Item>&& x) { return x.min_time; }));

        props.emplace_back(arg.map_prop("max_time", 
          std::shared_ptr<ResultId>(new TimingStatsMaxTimeId), 
          [](TimingStats<Item>&& x) { return x.max_time; }));

        props.emplace_back(arg.map_prop("start_time", 
          std::shared_ptr<ResultId>(new TimingStatsStartTimeId), 
          [](TimingStats<Item>&& x) { return x.start_time; }));

        props.emplace_back(arg.map_prop("last_time", 
          std::shared_ptr<ResultId>(new TimingStatsLastTimeId), 
          [](TimingStats<Item>&& x) { return x.last_time; }));

        props.emplace_back(arg.map_prop("sum", 
          std::shared_ptr<ResultId>(new TimingStatsSumId), 
          [](TimingStats<Item>&& x) { return x.sum; }));

        props.emplace_back(arg.map_prop("sum2", 
          std::shared_ptr<ResultId>(new TimingStatsSum2Id), 
          [](TimingStats<Item>&& x) { return x.sum2; }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new TimingStatsId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }
    }

    template<>
    inline ResultSource make_result_source(const ResultValue<TimingStats<int>>& arg) {
      return make_timing_stats_result_source(arg);
    }

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<TimingStats<int>>& arg) {
      return ResultSource {
        make_result_item(ResultValue<TimingStats<int>> { arg })
      };
    }

    template<>
    inline ResultSource make_result_source(const ResultValue<TimingStats<double>>& arg) {
      return make_timing_stats_result_source(arg);
    }

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<TimingStats<double>>& arg) {
      return ResultSource {
        make_result_item(ResultValue<TimingStats<double>> { arg })
      };
    }
  }
}

#endif /* dvcompute_result_timing_stats_h */

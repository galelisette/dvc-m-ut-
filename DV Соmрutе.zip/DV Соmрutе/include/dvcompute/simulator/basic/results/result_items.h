/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_items_h
#define dvcompute_result_items_h

#include <string>
#include <sstream>

#include "dvcompute/dvcompute_ns.h"
#include "result_source.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** @private */
      template<typename Item>
      inline ResultData<SamplingStats<Item>> norm_timing_stats_data(ResultData<TimingStats<Item>>&& m) {
        return std::move(m).and_then([](TimingStats<Item>&& stats) {
          return cons_event([stats](const Point* p) {
            return Result<SamplingStats<Item>>(stats.norm(p->iteration()));
          });
        });
      }

      /** This is an actual representation of `ResultValue<int>`. */
      class IntResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<int> value;

      public:

        explicit IntResultItem(ResultValue<int>&& value_arg) : value(std::move(value_arg)) {}

        explicit IntResultItem(const ResultValue<int>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new IntResultItem(value))
          };
        }

        ResultSource summary() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new IntResultItem(value))
          };
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::make_optional(value.map([](int x) {
            std::vector<int> ys;
            ys.push_back(x);
            return ys;
          }));
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::make_optional(value.map([](int x) {
            return SamplingStats<int>::from_sample(x);
          }));
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::make_optional(value.map([](int x) {
            return static_cast<double>(x);
          }));
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::make_optional(value.map([](int x) {
            std::vector<double> ys;
            ys.push_back(x);
            return ys;
          }));
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.map([](int x) {
            return SamplingStats<double>::from_sample(x);
          }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([](int x) {
            return std::to_string(x);
          }));
        }
      };

      /** This is an actual representation of `ResultValue<double>`. */
      class DoubleResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<double> value;

      public:

        explicit DoubleResultItem(ResultValue<double>&& value_arg) : value(std::move(value_arg)) {}

        explicit DoubleResultItem(const ResultValue<double>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new DoubleResultItem(value))
          };
        }

        ResultSource summary() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new DoubleResultItem(value))
          };
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::make_optional(value);
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::make_optional(value.map([](double x) {
            std::vector<double> ys;
            ys.push_back(x);
            return ys;
          }));
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.map([](double x) {
            return SamplingStats<double>::from_sample(x);
          }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([](double x) {
            return std::to_string(x);
          }));
        }
      };

      /** This is an actual representation of `ResultValue<std::vector<int>>`. */
      class IntVectorResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<std::vector<int>> value;

      public:

        explicit IntVectorResultItem(ResultValue<std::vector<int>>&& value_arg) : value(std::move(value_arg)) {}

        explicit IntVectorResultItem(const ResultValue<std::vector<int>>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new IntVectorResultItem(value))
          };
        }

        ResultSource summary() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new IntVectorResultItem(value))
          };
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::make_optional(value.map([](std::vector<int>&& xs) {
            return SamplingStats<int>::from_samples(xs.begin(), xs.end());
          }));
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::make_optional(value.map([](std::vector<int>&& xs) {
            std::vector<double> ys;
            for (int x : xs) {
              ys.push_back(x);
            }
            return ys;
          }));
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.map([](std::vector<int>&& xs) {
            return SamplingStats<int>::from_samples(xs.begin(), xs.end()).operator SamplingStats<double>();
          }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([](std::vector<int>&& xs) {
            std::ostringstream stream;
            
            stream << "[";
            bool started = false;
            for (int x : xs) {
              if (started) {
                stream << "; ";
              } else {
                started = true;
              }
              stream << x;
            }
            stream << "]";
            stream.flush();

            return std::string(stream.str());
          }));
        }
      };

      /** This is an actual representation of `ResultValue<std::vector<double>>`. */
      class DoubleVectorResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<std::vector<double>> value;

      public:

        explicit DoubleVectorResultItem(ResultValue<std::vector<double>>&& value_arg) : value(std::move(value_arg)) {}

        explicit DoubleVectorResultItem(const ResultValue<std::vector<double>>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new DoubleVectorResultItem(value))
          };
        }

        ResultSource summary() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new DoubleVectorResultItem(value))
          };
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.map([](std::vector<double>&& xs) {
            return SamplingStats<double>::from_samples(xs.begin(), xs.end());
          }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([](std::vector<double>&& xs) {
            std::ostringstream stream;
            
            stream << "[";
            bool started = false;
            for (double x : xs) {
              if (started) {
                stream << "; ";
              } else {
                started = true;
              }
              stream << x;
            }
            stream << "]";
            stream.flush();

            return std::string(stream.str());
          }));
        }
      };

      /** This is an actual representation of `ResultValue<SamplingStats<int>>`. */
      class IntStatsResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<SamplingStats<int>> value;

      public:

        explicit IntStatsResultItem(ResultValue<SamplingStats<int>>&& value_arg) : value(std::move(value_arg)) {}

        explicit IntStatsResultItem(const ResultValue<SamplingStats<int>>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return make_result_source(value);
        }

        ResultSource summary() const override {
          return make_result_source_summary(value);
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.map([](SamplingStats<int>&& stats) {
            return stats.operator SamplingStats<double>();
          }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([loc](SamplingStats<int>&& stats) {
            return to_string(stats, loc);
          }));
        }
      };

      /** This is an actual representation of `ResultValue<SamplingStats<double>>`. */
      class DoubleStatsResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<SamplingStats<double>> value;

      public:

        explicit DoubleStatsResultItem(ResultValue<SamplingStats<double>>&& value_arg) : value(std::move(value_arg)) {}

        explicit DoubleStatsResultItem(const ResultValue<SamplingStats<double>>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return make_result_source(value);
        }

        ResultSource summary() const override {
          return make_result_source_summary(value);
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([loc](SamplingStats<double>&& stats) {
            return to_string(stats, loc);
          }));
        }
      };

      /** This is an actual representation of `ResultValue<TimingStats<int>>`. */
      class IntTimingStatsResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<TimingStats<int>> value;

      public:

        explicit IntTimingStatsResultItem(ResultValue<TimingStats<int>>&& value_arg) : value(std::move(value_arg)) {}

        explicit IntTimingStatsResultItem(const ResultValue<TimingStats<int>>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return make_result_source(value);
        }

        ResultSource summary() const override {
          return make_result_source_summary(value);
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::make_optional(value.and_then([](ResultData<TimingStats<int>>&& stats) {
            return norm_timing_stats_data(std::move(stats));
          }));
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.map([](TimingStats<int>&& stats) {
              return stats.operator TimingStats<double>();
            })
            .and_then([](ResultData<TimingStats<double>>&& stats) {
              return norm_timing_stats_data(std::move(stats));
            }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::make_optional(value.map([](TimingStats<int>&& stats) {
              return stats.operator TimingStats<double>();
            }));
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([loc](TimingStats<int>&& stats) {
            return to_string(stats, loc);
          }));
        }
      };

      /** This is an actual representation of `ResultValue<TimingStats<double>>`. */
      class DoubleTimingStatsResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<TimingStats<double>> value;

      public:

        explicit DoubleTimingStatsResultItem(ResultValue<TimingStats<double>>&& value_arg) : value(std::move(value_arg)) {}

        explicit DoubleTimingStatsResultItem(const ResultValue<TimingStats<double>>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return make_result_source(value);
        }

        ResultSource summary() const override {
          return make_result_source_summary(value);
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::make_optional(value.and_then([](ResultData<TimingStats<double>>&& stats) {
            return norm_timing_stats_data(std::move(stats));
          }));
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::make_optional(value);
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([loc](TimingStats<double>&& stats) {
            return to_string(stats, loc);
          }));
        }
      };

      /** This is an actual representation of `ResultValue<bool>`. */
      class BoolResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<bool> value;

      public:

        explicit BoolResultItem(ResultValue<bool>&& value_arg) : value(std::move(value_arg)) {}

        explicit BoolResultItem(const ResultValue<bool>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new BoolResultItem(value))
          };
        }

        ResultSource summary() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new BoolResultItem(value))
          };
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([loc](bool x) {
            if (loc == ResultLocale::ru) {
              return std::string(x ? "истина" : "ложь");
            } else {
              return std::string(x ? "true" : "false");
            }
          }));
        }
      };

      /** This is an actual representation of `ResultValue<std::string>`. */
      class StringResultItem : public ResultItem {

        /** The actual result value. */
        ResultValue<std::string> value;

      public:

        explicit StringResultItem(ResultValue<std::string>&& value_arg) : value(std::move(value_arg)) {}

        explicit StringResultItem(const ResultValue<std::string>& value_arg) : value(value_arg) {}

        ResultName name() const override {
          return value.name;
        }

        std::vector<ResultName> name_path() const override {
          return value.name_path;
        }

        std::shared_ptr<ResultId> id() const override {
          return value.id;
        }

        std::vector<std::shared_ptr<ResultId>> id_path() const override {
          return value.id_path;
        }

        ResultObservable observable() const override {
          return (*value.observable)();
        }

        ResultSource expand() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new StringResultItem(value))
          };
        }

        ResultSource summary() const override {
          return ResultSource {
            std::shared_ptr<ResultItem>(new StringResultItem(value))
          };
        }

        std::optional<ResultValue<int>> as_int_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<double>> as_double_value() const override {
          return std::nullopt;
        };

        std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const override {
          return std::nullopt;
        }

        std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const override {
          return std::make_optional(value.map([](std::string&& x) {
            return std::move(x);
          }));
        }
      };
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<int>&& arg) {
      return std::shared_ptr<ResultItem>(new IntResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<double>&& arg) {
      return std::shared_ptr<ResultItem>(new DoubleResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<std::vector<int>>&& arg) {
      return std::shared_ptr<ResultItem>(new IntVectorResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<std::vector<double>>&& arg) {
      return std::shared_ptr<ResultItem>(new DoubleVectorResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<SamplingStats<int>>&& arg) {
      return std::shared_ptr<ResultItem>(new IntStatsResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<SamplingStats<double>>&& arg) {
      return std::shared_ptr<ResultItem>(new DoubleStatsResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<TimingStats<int>>&& arg) {
      return std::shared_ptr<ResultItem>(new IntTimingStatsResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<TimingStats<double>>&& arg) {
      return std::shared_ptr<ResultItem>(new DoubleTimingStatsResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<bool>&& arg) {
      return std::shared_ptr<ResultItem>(new BoolResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<std::string>&& arg) {
      return std::shared_ptr<ResultItem>(new StringResultItem(std::move(arg)));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<unsigned int>&& arg) {
      return make_result_item(std::move(arg).map([](unsigned int x) {
        return static_cast<int>(x);
      }));
    }

    template<>
    inline std::shared_ptr<ResultItem> make_result_item(ResultValue<std::vector<unsigned int>>&& arg) {
      return make_result_item(std::move(arg).map([](std::vector<unsigned int>&& xs) {
        std::vector<int> ys;
        for (unsigned int x : xs) {
          ys.push_back(static_cast<int>(x));
        }
        return ys;
      }));
    }
  }
}

#endif /* dvcompute_result_items_h */

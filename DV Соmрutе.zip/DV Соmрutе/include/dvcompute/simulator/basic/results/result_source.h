/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_source_h
#define dvcompute_result_source_h

#include <string>
#include <optional>
#include <variant>
#include <vector>
#include <memory>
#include <type_traits>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/event.h"
#include "dvcompute/simulator/basic/stats/sampling_stats.h"
#include "dvcompute/simulator/basic/stats/timing_stats.h"
#include "dvcompute/simulator/basic/results/result_locale.h"
#include "dvcompute/simulator/utils/ordered_map.h"

namespace DVCOMPUTE_NS {

  namespace results {

    /** A name used for indentifying the results when generating output. */
    using ResultName = std::string;

    /** A description of the simulation result. */
    using ResultDescription = std::string;

    /** Represents the very simulation results. */
    template<typename Item>
    using ResultData = Event<Item>;

    /** The result source identifier. */
    class ResultId {
    public:

      virtual ~ResultId() {}

      /** Get a description by the specified locale. */
      virtual std::optional<ResultDescription> description(ResultLocale loc) const = 0;

      /** Get a title by the specified locale. */
      virtual std::optional<ResultDescription> title(ResultLocale loc) const = 0;
    };

    /** The result type identifier. */
    class ResultTypeId {
    public:

      virtual ~ResultTypeId() {}
    
      /** Get a description by the specified locale. */
      virtual std::optional<ResultDescription> description(ResultLocale loc) const = 0;

      /** Get a title by the specified locale. */
      virtual std::optional<ResultDescription> title(ResultLocale loc) const = 0;
    };

    /** It represents the user-defined result identifier. */
    class UserDefinedResultId : public ResultId {

      std::optional<ResultDescription> description_field;
      std::optional<ResultDescription> title_field;

    public:

      UserDefinedResultId(const std::optional<ResultDescription>& description_arg,
        const std::optional<ResultDescription>& title_arg) :
          description_field(description_arg),
          title_field(title_arg)
      {}

      std::optional<ResultDescription> description(ResultLocale loc) const override {
        return description_field;
      }

      std::optional<ResultDescription> title(ResultLocale loc) const override {
        return title_field;
      }
    };

    /** The result exception. */
    class ResultException : public std::logic_error {
    public:
      explicit ResultException(const char* what_arg) : std::logic_error(what_arg) {}
      explicit ResultException(const std::string& what_arg) : std::logic_error(what_arg) {}
    };

    /** There is no signal at all. */
    struct EmptyResultObservable {};

    /** The signal is unknown, but the entity probably changes. */
    struct UnknownResultObservable {};
    
    /** When the signal is precisely specified. */
    struct SpecifiedResultObservable {
      Observable<Unit> obs;
    };

    /** When the specified signal was combined with unknown signal. */
    struct MixedResultObservable {
      Observable<Unit> obs;
    };

    /** Whether an object containing the results emits a signal notifying about change of data. */
    class ResultObservable {

      using Obs = std::variant<EmptyResultObservable, 
        UnknownResultObservable, 
        SpecifiedResultObservable,
        MixedResultObservable>;

      Obs obs;

    public:

      /** Create an empty result observable. */
      ResultObservable(EmptyResultObservable obs_arg) noexcept :
        obs(obs_arg)
      {}

      /** Create the unknown result observable. */
      ResultObservable(UnknownResultObservable obs_arg) noexcept :
        obs(obs_arg)
      {}

      /** Create an intance by the specified result observable. */
      ResultObservable(SpecifiedResultObservable&& obs_arg) noexcept(noexcept(Obs(std::move(obs_arg)))) :
        obs(std::move(obs_arg))
      {}

      /** Create an intance by the mixed result observable. */
      ResultObservable(MixedResultObservable&& obs_arg) noexcept(noexcept(Obs(std::move(obs_arg)))) :
        obs(std::move(obs_arg))
      {}

      ResultObservable(ResultObservable&&) = default;
      ResultObservable& operator=(ResultObservable&&) = default;

      /** Merge two result observables. */
      ResultObservable merge(ResultObservable&& other) && {
        if (std::get_if<EmptyResultObservable>(&obs)) {
          return std::move(other);

        } else if (std::get_if<UnknownResultObservable>(&obs)) {

          if (std::get_if<EmptyResultObservable>(&other.obs)) {
            return ResultObservable(UnknownResultObservable {});

          } else if (std::get_if<UnknownResultObservable>(&other.obs)) {
            return ResultObservable(UnknownResultObservable {});

          } else if (SpecifiedResultObservable* y = std::get_if<SpecifiedResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(y->obs) });

          } else if (std::get_if<MixedResultObservable>(&other.obs)) {
            return std::move(other);

          } else {
            throw "Unexhausted match";
          }

        } else if (SpecifiedResultObservable* x = std::get_if<SpecifiedResultObservable>(&obs)) {

          if (std::get_if<EmptyResultObservable>(&other.obs)) {
            return ResultObservable(SpecifiedResultObservable { std::move(x->obs) });

          } else if (std::get_if<UnknownResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(x->obs) });

          } else if (SpecifiedResultObservable* y = std::get_if<SpecifiedResultObservable>(&other.obs)) {
            return ResultObservable(SpecifiedResultObservable { std::move(x->obs).merge(std::move(y->obs)) });

          } else if (MixedResultObservable* y = std::get_if<MixedResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(x->obs).merge(std::move(y->obs)) });

          } else {
            throw "Unexhausted match";
          }

        } else if (MixedResultObservable* x = std::get_if<MixedResultObservable>(&obs)) {

          if (std::get_if<EmptyResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(x->obs) });

          } else if (std::get_if<UnknownResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(x->obs) });

          } else if (SpecifiedResultObservable* y = std::get_if<SpecifiedResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(x->obs).merge(std::move(y->obs)) });

          } else if (MixedResultObservable* y = std::get_if<MixedResultObservable>(&other.obs)) {
            return ResultObservable(MixedResultObservable { std::move(x->obs).merge(std::move(y->obs)) });

          } else {
            throw "Unexhausted match";
          }

        } else {
          throw "Unexhausted match";
        }
      }

      /** Purifies the result signal based on predefined signals provided by the very model. */
      Observable<Unit> purify(const PredefinedObservableSet& predefined_signals, std::optional<Observable<Unit>>&& in_integ_times = std::nullopt) && {
        if (std::get_if<EmptyResultObservable>(&obs)) {
          return predefined_signals.in_start_time()
            .merge(predefined_signals.in_stop_time())
            .map([](const double *a) { return Unit(); });

        } else if (std::get_if<UnknownResultObservable>(&obs)) {
          if (in_integ_times.has_value()) {
            return std::move(in_integ_times.value());

          } else {
            return predefined_signals.in_integ_times()
              .map([](const double *a) { return Unit(); });
          }

        } else if (SpecifiedResultObservable* x = std::get_if<SpecifiedResultObservable>(&obs)) {
          return predefined_signals.in_start_time()
            .merge(predefined_signals.in_stop_time())
            .map([](const double *a) { return Unit(); })
            .merge(std::move(x->obs));

        } else if (MixedResultObservable* x = std::get_if<MixedResultObservable>(&obs)) {
          if (in_integ_times.has_value()) {
            return std::move(in_integ_times.value())
              .merge(std::move(x->obs));

          } else {
            return predefined_signals.in_integ_times()
              .map([](const double *a) { return Unit(); })
              .merge(std::move(x->obs));
          }

        } else {
          throw "Unexhausted match";
        }
      }
    };

    /** Concatenate the signals. */
    inline ResultObservable concat_result_observables(std::vector<ResultObservable>&& xs) {
      ResultObservable res(EmptyResultObservable {});
      for (ResultObservable& x : xs) {
        res = std::move(res).merge(std::move(x));
      }
      return res;
    }

    struct ResultSource;

    struct ResultProperty;

    /** A container of the simulation results such as queue, or array. */
    template<typename Data>
    struct ResultContainer {

      /** The container name. */
      ResultName name;

      /** The container name path. */
      std::vector<ResultName> name_path;

      /** The container identifier. */
      std::shared_ptr<ResultId> id;

      /** The container identifier path. */
      std::vector<std::shared_ptr<ResultId>> id_path;

      /** The container data. */
      SharedPtr<Data> data;

      /** Whether the container emits a signal when changing simulation data. */
      std::shared_ptr<std::function<ResultObservable()>> observable;

      /** Map the contained data by applying the corresponding function. */
      template<typename Fn>
      inline auto map(Fn&& f) const {
        using MapData = decltype(f(data.get()));
        return ResultContainer<MapData> {
          name, name_path, id, id_path, SharedPtr<MapData>(mk_shared(MapData(f(data.get())))), observable
        };
      }

      /** Create a new raw property source by the specified container. */
      template<typename Fn1, typename Fn2>
      inline ResultSource raw_prop_source(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn1&& prop_data,
        Fn2&& prop_observable) const;

      /** Create a new raw property by the specified container. */
      template<typename Fn1, typename Fn2>
      inline ResultProperty raw_prop(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn1&& prop_data,
        Fn2&& prop_observable) const;

      /** Create a new constant property source by the specified container. */
      template<typename Fn>
      inline ResultProperty const_prop(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn&& prop_data) const;

      /**
       * Create by the specified container a property that changes in 
       * the integration time points, or it is supposed to be such one.
       */
      template<typename Fn>
      inline ResultProperty integ_prop(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn&& prop_data) const;

      /** Create a new property by the specified container. */
      template<typename Fn1, typename Fn2>
      inline ResultProperty prop(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn1&& prop_data,
        Fn2&& prop_observable) const;
     };

    /** A parameterised value that actually represents a generalised result item that has no parametric type. */
    template<typename Item>
    struct ResultValue {

      /** The value name. */
      ResultName name;

      /** The value name path. */
      std::vector<ResultName> name_path;

      /** The value identifier. */
      std::shared_ptr<ResultId> id;

      /** The value identifier path. */
      std::vector<std::shared_ptr<ResultId>> id_path;

      /** Simulation data supplied by the value. */
      std::shared_ptr<std::function<ResultData<Item>()>> data;

      /** Whether the container emits a signal when changing simulation data. */
      std::shared_ptr<std::function<ResultObservable()>> observable;

      /** Map the contained data by applying the corresponding function. */
      template<typename Fn>
      inline auto map(Fn&& f) const {
        using MapItem = std::invoke_result_t<Fn, Item&&>;
        auto g = [f{std::move(f)}, data{data}]() mutable {
          return (*data)().map(std::move(f));
        };
        std::shared_ptr<std::function<ResultData<MapItem>()>> data2(new std::function<ResultData<MapItem>()>(std::move(g)));
        return ResultValue<MapItem> {
          name, name_path, id, id_path, data2, observable
        };
      }

      /** Apply the functional composition. */
      template<typename Fn>
      inline auto and_then(Fn&& f) const {
        using ResultItem = typename std::invoke_result_t<Fn, ResultData<Item>&&>::item_type;
        auto g = [f{std::move(f)}, data{data}]() mutable {
          return f((*data)());
        };
        std::shared_ptr<std::function<ResultData<ResultItem>()>> data2(new std::function<ResultData<ResultItem>()>(std::move(g)));
        return ResultValue<ResultItem> {
          name, name_path, id, id_path, data2, observable
        };
      }

      /** Convert the result value to a container. */
      inline ResultContainer<ResultData<Item>> into_container() && {
        SharedPtr<ResultData<Item>> data2 { mk_shared(ResultData<Item>((*data)())) };
        return ResultContainer<ResultData<Item>> {
          name, name_path, id, id_path, data2, observable
        };
      }

      /** Create a new raw property source by the specified result value. */
      template<typename Fn>
      inline ResultSource raw_prop_source(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn&& prop_data) const;

      /** Create a new raw property by the specified result value. */
      template<typename Fn>
      inline ResultProperty raw_prop(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn&& prop_data) const;

      /** Create by the specified result value a mapped property which is recomputed each time again and again. */
      template<typename Fn>
      inline ResultProperty map_prop(const char* prop_name, 
        const std::shared_ptr<ResultId>& prop_id,
        Fn&& prop_data) const;
    };

    /** This is an actual representation of the item. */
    class ResultItem {
    public:

      virtual ~ResultItem() {}

      /** Return the item name. */
      virtual ResultName name() const = 0;

      /** Return the item name path. */
      virtual std::vector<ResultName> name_path() const = 0;

      /** Return the item identifier. */
      virtual std::shared_ptr<ResultId> id() const = 0;

      /** Returnn the item identifier path. */
      virtual std::vector<std::shared_ptr<ResultId>> id_path() const = 0;

      /** Whether the item emits a signal. */
      virtual ResultObservable observable() const = 0;

      /** 
       * Return an expanded version of the item, for example,
       * when the statistics item is exanded to an object
       * having the corresponded properties for count, average,
       * deviation, minimum, maximum and so on.
       */
      virtual ResultSource expand() const = 0;

      /**
       * Return usually a short version of the item, i.e. its summary,
       * but values of some data types such as statistics can be
       * implicitly expanded to an object with the corresponding
       * properties.
       */
      virtual ResultSource summary() const = 0;

      /** Try to return integer numbers in time points. */
      virtual std::optional<ResultValue<int>> as_int_value() const = 0;

      /** Try to return a vector of integer numbers in time points. */
      virtual std::optional<ResultValue<std::vector<int>>> as_int_vector_value() const = 0;

      /** Try to return statistics based on integer numbers. */
      virtual std::optional<ResultValue<SamplingStats<int>>> as_int_stats_value() const = 0;

      /** Try to return the timing statistics based on integer numbers. */
      virtual std::optional<ResultValue<TimingStats<int>>> as_int_timing_stats_value() const = 0;

      /** Try to return double floating point numbers in time points. */
      virtual std::optional<ResultValue<double>> as_double_value() const = 0;

      /** Try to return a vector of double floating point numbers in time points. */
      virtual std::optional<ResultValue<std::vector<double>>> as_double_vector_value() const = 0;

      /** Try to return statistics based on double floating point numbers. */
      virtual std::optional<ResultValue<SamplingStats<double>>> as_double_stats_value() const = 0;

      /** Try to return the timing statistics based on double floating point numbers. */
      virtual std::optional<ResultValue<TimingStats<double>>> as_double_timing_stats_value() const = 0;

      /** Try to return the `std::string` representation in time points. */
      virtual std::optional<ResultValue<std::string>> as_string_value(ResultLocale loc) const = 0;

      /** Return integer numbers in time points, or raise an exception. */
      ResultValue<int> int_value() const {
        auto opt { as_int_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of integer numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return a vector of integer numbers in time points, or raise an exception. */
      ResultValue<std::vector<int>> int_vector_value() const {
        auto opt { as_int_vector_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of vectors of integer numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return statistics based on integer numbers in time points, or raise an exception. */
      ResultValue<SamplingStats<int>> int_stats_value() const {
        auto opt { as_int_stats_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of statistics based on integer numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return the timing statistics based on integer numbers in time points, or raise an exception. */
      ResultValue<TimingStats<int>> int_timing_stats_value() const {
        auto opt { as_int_timing_stats_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of the timing statistics based on integer numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return double floating point numbers in time points, or raise an exception. */
      ResultValue<double> double_value() const {
        auto opt { as_double_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of double floating point numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return a vector of double floating point numbers in time points, or raise an exception. */
      ResultValue<std::vector<double>> double_vector_value() const {
        auto opt { as_double_vector_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of vectors of double floating point numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return statistics based on double floating point numbers in time points, or raise an exception. */
      ResultValue<SamplingStats<double>> double_stats_value() const {
        auto opt { as_double_stats_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of statistics based on double floating point numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return the timing statistics based on double floating point numbers in time points, or raise an exception. */
      ResultValue<TimingStats<double>> double_timing_stats_value() const {
        auto opt { as_double_timing_stats_value() };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of the timing statistics based on double floating point numbers";
          
          throw ResultException(msg);
        }
      }

      /** Return `std::string` representations in time points, or raise an exception. */
      ResultValue<std::string> string_value(ResultLocale loc) const {
        auto opt { as_string_value(loc) };
        if (opt.has_value()) {
          return std::move(opt.value());

        } else {
          std::string msg;

          msg += "Cannot represent ";
          msg += name();
          msg += " as a source of wide string representations";
          
          throw ResultException(msg);
        }
      }
    };

    /** Create a result item by the specified argument. */
    template<typename Arg>
    inline std::shared_ptr<ResultItem> make_result_item(Arg&&);

    /** The simulation results represented by an object having properties. */
    struct ResultObject {

      /** The object name. */
      ResultName name;

      /** The object identifier. */
      std::shared_ptr<ResultId> id;

      /** The object type identifier. */
      std::shared_ptr<ResultTypeId> type_id;

      /** The object properties. */
      std::vector<ResultProperty> props;

      /** A combined signal if present. */
      std::shared_ptr<std::function<ResultObservable()>> observable;

      /** A short version of the object, i.e. its summary. */
      std::shared_ptr<std::function<ResultSource()>> summary;
    };

    /** The simulation results represented by a vector. */
    struct ResultVector {

      /** The vector name. */
      ResultName name;

      /** The vector identifier. */
      std::shared_ptr<ResultId> id;

      /** The results supplied by the vector items. */
      std::vector<ResultSource> items;

      /** The subscript used as a suffix to create item names. */
      std::vector<ResultName> subscript;

      /** A combined signal if present. */
      std::shared_ptr<std::function<ResultObservable()>> observable;

      /** A short version of the vector, i.e. its summary. */
      std::shared_ptr<std::function<ResultSource()>> summary;
    };

    /** It separates the simulation results when printing. */
    struct ResultSeparator {

      /** The separator text. */
      std::string text;
    };

    /** The result source variant. */
    using ResultSourceVariant = std::variant<std::shared_ptr<ResultItem>,
      std::shared_ptr<ResultObject>,
      std::shared_ptr<ResultVector>,
      std::shared_ptr<ResultSeparator>>;

    struct ResultSource {

      /** The variant. */
      ResultSourceVariant var;

      /**
       * Return a summarised and usually more short version of the result source by expanding
       * the main properties or excluding auxiliary properties if required.
       */
      ResultSource summary() const {
        if (auto *item = std::get_if<std::shared_ptr<ResultItem>>(&var)) {
          return (*item)->summary();
        } else if (auto *obj = std::get_if<std::shared_ptr<ResultObject>>(&var)) {
          return (*(*obj)->summary)();
        } else if (auto *vec = std::get_if<std::shared_ptr<ResultVector>>(&var)) {
          return (*(*vec)->summary)();
        } else if (auto *sep = std::get_if<std::shared_ptr<ResultSeparator>>(&var)) {
          return ResultSource { *sep };
        } else {
          throw "Unexhausted match";
        }
      }

      /** Return a signal emitted by the source. */
      ResultObservable observable() const {
        if (auto *item = std::get_if<std::shared_ptr<ResultItem>>(&var)) {
          return (*item)->observable();
        } else if (auto *obj = std::get_if<std::shared_ptr<ResultObject>>(&var)) {
          return (*(*obj)->observable)();
        } else if (auto *vec = std::get_if<std::shared_ptr<ResultVector>>(&var)) {
          return (*(*vec)->observable)();
        } else if (std::get_if<std::shared_ptr<ResultSeparator>>(&var)) {
          return ResultObservable(EmptyResultObservable {});
        } else {
          throw "Unexhausted match";
        }
      }

      /** Flatten the result source. */
      std::vector<std::shared_ptr<ResultItem>> flatten() const;

      /** Return the result source name. */
      ResultName name() const {
        if (auto *item = std::get_if<std::shared_ptr<ResultItem>>(&var)) {
          return (*item)->name();
        } else if (auto *obj = std::get_if<std::shared_ptr<ResultObject>>(&var)) {
          return (*obj)->name;
        } else if (auto *vec = std::get_if<std::shared_ptr<ResultVector>>(&var)) {
          return (*vec)->name;
        } else if (std::get_if<std::shared_ptr<ResultSeparator>>(&var)) {
          return ResultName();
        } else {
          throw "Unexhausted match";
        }
      }

      /** 
       * Expand the result source by returning a more detailed version 
       * while expanding the properties as possible.
       */
      ResultSource expand() const;

      /** Represent the result source as integer numbers, or raise exception. */
      std::vector<ResultValue<int>> int_values() const {
        std::vector<ResultValue<int>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->int_value());
        }
        return ys;
      }

      /** Represent the result source as vectors of integer numbers, or raise exception. */
      std::vector<ResultValue<std::vector<int>>> int_vector_values() const {
        std::vector<ResultValue<std::vector<int>>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->int_vector_value());
        }
        return ys;
      }

      /** Represent the result source as statistics based on integer numbers, or raise exception. */
      std::vector<ResultValue<SamplingStats<int>>> int_stats_values() const {
        std::vector<ResultValue<SamplingStats<int>>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->int_stats_value());
        }
        return ys;
      }

      /** Represent the result source as the timing statistics based on integer numbers, or raise exception. */
      std::vector<ResultValue<TimingStats<int>>> int_timing_stats_values() const {
        std::vector<ResultValue<TimingStats<int>>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->int_timing_stats_value());
        }
        return ys;
      }

      /** Represent the result source as double floating point numbers, or raise exception. */
      std::vector<ResultValue<double>> double_values() const {
        std::vector<ResultValue<double>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->double_value());
        }
        return ys;
      }

      /** Represent the result source as vectors of double floating point numbers, or raise exception. */
      std::vector<ResultValue<std::vector<double>>> double_vector_values() const {
        std::vector<ResultValue<std::vector<double>>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->double_vector_value());
        }
        return ys;
      }

      /** Represent the result source as statistics based on double floating point numbers, or raise exception. */
      std::vector<ResultValue<SamplingStats<double>>> double_stats_values() const {
        std::vector<ResultValue<SamplingStats<double>>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->double_stats_value());
        }
        return ys;
      }

      /** Represent the result source as the timing statistics based on double floating point numbers, or raise exception. */
      std::vector<ResultValue<TimingStats<double>>> double_timing_stats_values() const {
        std::vector<ResultValue<TimingStats<double>>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->double_timing_stats_value());
        }
        return ys;
      }

      /** Represent the result source as `std::string` representations, or raise exception. */
      std::vector<ResultValue<std::string>> string_values(ResultLocale loc) const {
        std::vector<ResultValue<std::string>> ys;
        auto xs { flatten() };
        for (auto &x : xs) {
          ys.emplace_back(x->string_value(loc));
        }
        return ys;
      }
    };

    /** The object property containing the simulation results. */
    struct ResultProperty {

      /** The property short label. */
      ResultName label;

      /** The property identifier. */
      std::shared_ptr<ResultId> id;

      /** The simulation results supplied by the property. */
      ResultSource source;
    };

    /** It associates the result sources with their names. */
    using ResultSourceMap = DVCOMPUTE_NS::utils::im::OrderedMap<ResultName, ResultSource>;

    /** Create a result source by the specified argument. */
    template<typename Arg>
    inline ResultSource make_result_source(const Arg&);

    /** Create a result source by the specified argument. */
    template<typename Arg>
    inline ResultSource make_result_source_summary(const Arg&);

    template<>
    inline ResultSource make_result_source(const ResultValue<SamplingStats<int>>& arg);

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<SamplingStats<int>>& arg);

    template<>
    inline ResultSource make_result_source(const ResultValue<SamplingStats<double>>& arg);

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<SamplingStats<double>>& arg);

    template<>
    inline ResultSource make_result_source(const ResultValue<TimingStats<int>>& arg);

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<TimingStats<int>>& arg);

    template<>
    inline ResultSource make_result_source(const ResultValue<TimingStats<double>>& arg);

    template<>
    inline ResultSource make_result_source_summary(const ResultValue<TimingStats<double>>& arg);

    template<>
    inline ResultSource make_result_source(const ResultContainer<DVCOMPUTE_NS::block::Queue>& arg);

    template<>
    inline ResultSource make_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Queue>& arg);

    template<typename Data>
    template<typename Fn1, typename Fn2>
    inline ResultSource ResultContainer<Data>::raw_prop_source(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn1&& prop_data,
      Fn2&& prop_observable) const 
    {
      ResultName name2 { name + "." + prop_name };
      std::vector<ResultName> name_path2(name_path);
      name_path2.emplace_back(ResultName(prop_name));
      
      std::shared_ptr<ResultId> id2 { prop_id };
      std::vector<std::shared_ptr<ResultId>> id_path2(id_path);
      id_path2.push_back(prop_id);

      using ResultItem = typename std::invoke_result_t<Fn1, const SharedPtr<Data>&>::item_type;
      auto fn2 = [data{data}, prop_data{std::move(prop_data)}]() mutable {
        return prop_data(data);
      };
      auto gn2 = [data{data}, prop_observable{std::move(prop_observable)}]() mutable {
        return prop_observable(data);
      };
      std::shared_ptr<std::function<ResultData<ResultItem>()>> data2 {
        new std::function<ResultData<ResultItem>()>(std::move(fn2))
      };
      std::shared_ptr<std::function<ResultObservable()>> observable2 {
        new std::function<ResultObservable()>(std::move(gn2))
      };

      return ResultSource {
        make_result_item(ResultValue<ResultItem> {
          name2, name_path2, id2, id_path2, data2, observable2
        })
      };
    }

    template<typename Data>
    template<typename Fn1, typename Fn2>
    inline ResultProperty ResultContainer<Data>::raw_prop(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn1&& prop_data,
      Fn2&& prop_observable) const
    {
      ResultName label2(prop_name);
      std::shared_ptr<ResultId> id2 { prop_id };
      ResultSource src2 { raw_prop_source(prop_name, prop_id, std::move(prop_data), std::move(prop_observable)) };

      return ResultProperty {
        label2, id2, src2
      };
    }

    template<typename Data>
    template<typename Fn>
    inline ResultProperty ResultContainer<Data>::const_prop(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn&& prop_data) const
    {
      return raw_prop(prop_name, prop_id,
        [prop_data{std::move(prop_data)}](const SharedPtr<Data>& e) mutable { return pure_event(prop_data(e)); },
        [](const SharedPtr<Data>& e) { return ResultObservable(EmptyResultObservable {}); });
    }

    template<typename Data>
    template<typename Fn>
    inline ResultProperty ResultContainer<Data>::integ_prop(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn&& prop_data) const
    {
      return raw_prop(prop_name, prop_id,
        [prop_data{std::move(prop_data)}](const SharedPtr<Data>& e) mutable { return prop_data(e); },
        [](const SharedPtr<Data>& e) { return ResultObservable(UnknownResultObservable {}); });
    }

    template<typename Data>
    template<typename Fn1, typename Fn2>
    inline ResultProperty ResultContainer<Data>::prop(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn1&& prop_data,
      Fn2&& prop_observable) const
    {
      return raw_prop(prop_name, prop_id,
        [prop_data{std::move(prop_data)}](const SharedPtr<Data>& e) mutable { return prop_data(e); },
        [prop_observable{std::move(prop_observable)}](const SharedPtr<Data>& e) { return ResultObservable(SpecifiedResultObservable { prop_observable(e) }); });
    }

    template<typename Item>
    template<typename Fn>
    inline ResultSource ResultValue<Item>::raw_prop_source(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn&& prop_data) const
    {
      ResultName name2 { name + "." + prop_name };
      std::vector<ResultName> name_path2(name_path);
      name_path2.emplace_back(ResultName(prop_name));
      
      std::shared_ptr<ResultId> id2 { prop_id };
      std::vector<std::shared_ptr<ResultId>> id_path2(id_path);
      id_path2.push_back(prop_id);

      using ResultItem = typename std::invoke_result_t<Fn, ResultData<Item>&&>::item_type;
      auto fn2 = [data{data}, prop_data{std::move(prop_data)}]() mutable {
        return prop_data((*data)());
      };
      std::shared_ptr<std::function<ResultData<ResultItem>()>> data2 {
        new std::function<ResultData<ResultItem>()>(std::move(fn2))
      };

      return ResultSource {
        make_result_item(ResultValue<ResultItem> {
          name2, name_path2, id2, id_path2, data2, observable
        })
      };
    }

    template<typename Item>
    template<typename Fn>
    inline ResultProperty ResultValue<Item>::raw_prop(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn&& prop_data) const
    {
      ResultName label2(prop_name);
      std::shared_ptr<ResultId> id2 { prop_id };
      ResultSource src2 { raw_prop_source(prop_name, prop_id, std::move(prop_data)) };

      return ResultProperty {
        label2, id2, src2
      };
    }

    template<typename Item>
    template<typename Fn>
    inline ResultProperty ResultValue<Item>::map_prop(const char* prop_name, 
      const std::shared_ptr<ResultId>& prop_id,
      Fn&& prop_data) const
    {
      return raw_prop(prop_name, prop_id,
        [prop_data{std::move(prop_data)}](ResultData<Item>&& comp) mutable { 
          return std::move(comp).map(prop_data);
        });
    }

    /** Calculate the result vector signal by items. */
    inline ResultObservable vector_item_observable(const std::vector<ResultSource>& other_items) {
      ResultObservable res(EmptyResultObservable {});
      for (auto &item : other_items) {
        res = std::move(res).merge(item.observable());
      }
      return res;
    }

    /** Create a new instance with other items. */
    inline ResultSource vector_with_items(const std::shared_ptr<ResultVector>& vec, 
      std::vector<ResultSource>&& other_items)
    {
      auto fn = [other_items]() {
        return vector_item_observable(other_items);
      };
      std::shared_ptr<std::function<ResultObservable()>> observable2 {
        new std::function<ResultObservable()>(std::move(fn))
      };

      auto gn = [vec, other_items]() {
        return vector_with_items(vec, std::vector<ResultSource>(other_items));
      };
      std::shared_ptr<std::function<ResultSource()>> summary2 {
        new std::function<ResultSource()>(std::move(gn))
      };

      return ResultSource {
        std::shared_ptr<ResultVector>(new ResultVector {
          vec->name, vec->id, std::move(other_items), vec->subscript,
          observable2, summary2
        })
      };
    }

    /** Calculate the result vector summary by items. */
    inline ResultSource vector_item_summary(const std::shared_ptr<ResultVector>& vec) {
      std::vector<ResultSource> xs;
      for (auto &item : vec->items) {
        xs.emplace_back(item.summary());
      }
      return vector_with_items(vec, std::move(xs));
    }

    inline std::vector<std::shared_ptr<ResultItem>> ResultSource::flatten() const {
      std::vector<std::shared_ptr<ResultItem>> res;

      if (auto *item = std::get_if<std::shared_ptr<ResultItem>>(&var)) {
        res.push_back(*item);

      } else if (auto *obj = std::get_if<std::shared_ptr<ResultObject>>(&var)) {
        for (auto &p : (*obj)->props) {
          auto zs { p.source.flatten() };
          for (auto &z : zs) {
            res.emplace_back(std::move(z));
          }
        }

      } else if (auto *vec = std::get_if<std::shared_ptr<ResultVector>>(&var)) {
        for (auto &i : (*vec)->items) {
          auto zs { i.flatten() };
          for (auto &z : zs) {
            res.emplace_back(std::move(z));
          }
        }

      } else if (std::get_if<std::shared_ptr<ResultSeparator>>(&var)) {
        // nothing to do

      } else {
        throw "Unexhausted match";
      }

      return res;
    }

    inline ResultSource ResultSource::expand() const {
      if (auto *item = std::get_if<std::shared_ptr<ResultItem>>(&var)) {
        return (*item)->expand();

      } else if (auto *obj = std::get_if<std::shared_ptr<ResultObject>>(&var)) {
        std::vector<ResultProperty> ys;
        for (auto &p : (*obj)->props) {
          ys.emplace_back(ResultProperty {
            p.label, p.id, p.source.expand()
          });
        }
        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            (*obj)->name, (*obj)->id, (*obj)->type_id, 
            std::move(ys), (*obj)->observable, (*obj)->summary
          })
        };

      } else if (auto *vec = std::get_if<std::shared_ptr<ResultVector>>(&var)) {
        std::vector<ResultSource> ys;
        for (auto &i : (*vec)->items) {
          ys.emplace_back(i.expand());
        }
        return ResultSource {
          std::shared_ptr<ResultVector>(new ResultVector {
            (*vec)->name, (*vec)->id, std::move(ys),
            (*vec)->subscript, (*vec)->observable, (*vec)->summary
          })
        };

      } else if (auto *sep = std::get_if<std::shared_ptr<ResultSeparator>>(&var)) {
        return ResultSource { (*sep) };

      } else {
        throw "Unexhausted match";
      }
    }

    /** Get the title by the result name. */
    inline ResultDescription result_name_to_title(const ResultName& name) {
      return name;
    }

    /** 
     * Return the source of simulation results by the specified provider,
     * name, its name path, identifier and the corresponding identifier path.
     */
    template<typename Provider>
    inline ResultSource result_source(const Provider& provider, 
      const ResultName& name,
      const std::vector<ResultName>& name_path,
      const std::shared_ptr<ResultId>& id,
      const std::vector<std::shared_ptr<ResultId>>& id_path);

    /** 
     * Return the source of simulation results by the specified provider,
     * name, description and title.
     */
    template<typename Provider>
    inline ResultSource result_source(const Provider& provider, 
      const ResultName& name,
      const std::optional<ResultDescription>& description,
      const std::optional<ResultDescription>& title)
    {
      std::vector<ResultName> name_path;
      name_path.push_back(name);

      std::shared_ptr<ResultId> id(new UserDefinedResultId(description, title));
      std::vector<std::shared_ptr<ResultId>> id_path;
      id_path.push_back(id);

      return result_source(provider, name, name_path, id, id_path);
    }

    /** 
     * Return the source of simulation results by the specified provider,
     * name and description.
     */
    template<typename Provider>
    inline ResultSource result_source(const Provider& provider, 
      const ResultName& name,
      const ResultDescription& description)
    {
      return result_source(provider, name, description, result_name_to_title(name));
    }

    /** 
     * Return the source of simulation results by the specified provider and its name.
     */
    template<typename Provider>
    inline ResultSource result_source(const Provider& provider, const ResultName& name) {
      return result_source(provider, name, std::nullopt, result_name_to_title(name));
    }
  }
}

#endif /* dvcompute_result_source_h */

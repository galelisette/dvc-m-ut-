/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_extra_h
#define dvcompute_result_extra_h

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/ref.h"
#include "result_source.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** The modeling time. */
      class TimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("модельное время");
          } else {
            return std::string("modeling time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время");
          } else {
            return std::string("time");
          }
        }
      };
    }
      
    template<typename Item>
    ResultSource result_source(const RefPtr<Item>& provider, 
      const ResultName& name,
      const std::vector<ResultName>& name_path,
      const std::shared_ptr<ResultId>& id,
      const std::vector<std::shared_ptr<ResultId>>& id_path)
    {
      ResultValue<Item> x {
        name, name_path, id, id_path,
        std::shared_ptr<std::function<ResultData<Item>()>>(new std::function<ResultData<Item>()> {
          [provider]() { return read_ref(provider); }
        }),
        std::shared_ptr<std::function<ResultObservable()>>(new std::function<ResultObservable()> {
          []() { return ResultObservable(UnknownResultObservable {}); }
        })
      };

      return ResultSource {
        make_result_item(std::move(x))
      };
    }

    template<typename Item>
    ResultSource result_source(const std::function<Event<Item>()>& provider, 
      const ResultName& name,
      const std::vector<ResultName>& name_path,
      const std::shared_ptr<ResultId>& id,
      const std::vector<std::shared_ptr<ResultId>>& id_path)
    {
      ResultValue<Item> x {
        name, name_path, id, id_path,
        std::shared_ptr<std::function<ResultData<Item>()>>(new std::function<ResultData<Item>()> {
          [provider]() { return provider(); }
        }),
        std::shared_ptr<std::function<ResultObservable()>>(new std::function<ResultObservable()> {
          []() { return ResultObservable(UnknownResultObservable {}); }
        })
      };

      return ResultSource {
        make_result_item(std::move(x))
      };
    }

    /** Return the result source for modeling time. */
    inline ResultSource time_result_source() {
      ResultName name = "t";
      std::vector<ResultName> name_path;
      name_path.push_back(name);

      std::shared_ptr<ResultId> id(new TimeId);
      std::vector<std::shared_ptr<ResultId>> id_path;
      id_path.push_back(id);

      ResultValue<double> x {
        name, name_path, id, id_path,
        std::shared_ptr<std::function<ResultData<double>()>>(new std::function<ResultData<double>()> {
          []() { return event_time(); }
        }),
        std::shared_ptr<std::function<ResultObservable()>>(new std::function<ResultObservable()> {
          []() { return ResultObservable(UnknownResultObservable {}); }
        })
      };

      return ResultSource {
        make_result_item(std::move(x))
      };
    }

    /** Return a separator result source. */
    inline ResultSource separator_result_source(const std::string& text) {
      return ResultSource {
        std::shared_ptr<ResultSeparator>(new ResultSeparator {
          text
        })
      };
    }
  }
}

#endif /* dvcompute_result_extra_h */

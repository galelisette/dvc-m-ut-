/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_io_h
#define dvcompute_result_io_h

#include <iostream>
#include <string>
#include <sstream>

#include "dvcompute/dvcompute_ns.h"
#include "result_source.h"
#include "result_set.h"
#include "../event_extra.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** Write an indented and labelled text representation of the results by the specified item. */
      template<typename Stream>
      void write_item(const ResultItem& item,
        const std::string& rep,
        Stream& stream, 
        unsigned int indent, 
        const ResultName& label,
        ResultLocale loc,
        const Point* p)
      {
        auto descr { item.id()->description(loc) };
        if (descr.has_value()) {
          for (unsigned int i = 0; i < indent; ++i) {
            stream << ' ';
          }
          stream << "// " << descr.value() << std::endl;
        }

        for (unsigned int i = 0; i < indent; ++i) {
          stream << ' ';
        }
        stream << label << " = " << rep << std::endl << std::endl;
      }

      /** Write the identifier descriptor as indented and labelled. */
      template<typename Stream>
      void write_descr(const ResultId& id,
        Stream& stream,
        unsigned int indent, 
        const ResultName& label,
        ResultLocale loc,
        const Point* p)
      {
        auto descr { id.description(loc) };
        if (descr.has_value()) {
          for (unsigned int i = 0; i < indent; ++i) {
            stream << ' ';
          }
          stream << "// " << descr.value() << std::endl;
        }

        for (unsigned int i = 0; i < indent; ++i) {
          stream << ' ';
        }
        stream << label << ':' << std::endl << std::endl;
      }

      /** Write the separator as indented and labelled. */
      template<typename Stream>
      void write_separator(Stream& stream, 
        unsigned int indent, 
        const ResultName& label,
        const Point* p)
      {
        for (unsigned int i = 0; i < indent; ++i) {
          stream << ' ';
        }
        stream << label << std::endl << std::endl;
      }

      /** Write an indented and labelled text representation of the results by the specified source. */
      template<typename Stream>
      Result<Unit> write_source_ex(const ResultSource& source,
        Stream& stream,
        unsigned int indent,
        const ResultName& label,
        ResultLocale loc,
        const Point* p)
      {
        if (const auto *x = std::get_if<std::shared_ptr<ResultItem>>(&source.var)) {
          auto a1 { (*x)->string_value(loc) };
          auto a2 { (a1.data)->operator()() };
          auto res { std::move(a2)(p) };
          if (auto *a4 = get_result_if(&res)) {
            write_item(**x, *a4, stream, indent, label, loc, p);
            return Result<Unit>(Unit());

          } else {
            return error_result<Unit>(std::move(res));
          }
        
        } else if (auto *x = std::get_if<std::shared_ptr<ResultObject>>(&source.var)) {
          write_descr(*((*x)->id), stream, indent, label, loc, p);
          for (std::size_t i = 0; i < (*x)->props.size(); ++i) {
            const auto& source2 = (*x)->props[i].source;
            unsigned int indent2 = indent + 2;
            ResultName label2 = (*x)->props[i].label;
            TRY_RESULT(write_source_ex(source2, stream, indent2, label2, loc, p));
          }
          return Result<Unit>(Unit());

        } else if (auto *x = std::get_if<std::shared_ptr<ResultVector>>(&source.var)) {
          write_descr(*((*x)->id), stream, indent, label, loc, p);
          for (std::size_t i = 0; i < (*x)->items.size(); ++i) {
            const auto& source2 = (*x)->items[i];
            unsigned int indent2 = indent + 2;
            ResultName label2 = label + (*x)->subscript[i];
            TRY_RESULT(write_source_ex(source2, stream, indent2, label2, loc, p));
          }
          return Result<Unit>(Unit());
        
        } else if (auto *x = std::get_if<std::shared_ptr<ResultSeparator>>(&source.var)) {
          static_cast<void>(x);
          write_separator(stream, indent, label, p);
          return Result<Unit>(Unit());
        
        } else {
          throw "Unexhausted match";
        }
      }

      /** Write an indented text representation of the results by the specified source. */
      template<typename Stream>
      Result<Unit> write_source(const ResultSource& source,
        Stream& stream,
        unsigned int indent,
        ResultLocale loc,
        const Point* p)
      {
        if (const auto *x = std::get_if<std::shared_ptr<ResultItem>>(&source.var)) {
          return write_source_ex(source, stream, indent, (*x)->name(), loc, p);
        
        } else if (auto *x = std::get_if<std::shared_ptr<ResultObject>>(&source.var)) {
          return write_source_ex(source, stream, indent, (*x)->name, loc, p);

        } else if (auto *x = std::get_if<std::shared_ptr<ResultVector>>(&source.var)) {
          return write_source_ex(source, stream, indent, (*x)->name, loc, p);
        
        } else if (auto *x = std::get_if<std::shared_ptr<ResultSeparator>>(&source.var)) {
          return write_source_ex(source, stream, indent, (*x)->text, loc, p);
        
        } else {
          throw "Unexhausted match";
        }
      }
    }

    /** Allows writing the `std::string` representation of the resulting object. */
    template<typename ResultObject, typename Stream>
    Result<Unit> write_results_at(const ResultObject& obj, Stream& stream, ResultLocale loc, const Point* p);

    template<typename Stream>
    Result<Unit> write_results_at(const ResultSource& obj, Stream& stream, ResultLocale loc, const Point* p) {
      return write_source(obj, stream, 0, loc, p);
    }

    template<typename ResultObject, typename Stream>
    Result<Unit> write_results_at(const std::shared_ptr<ResultObject>& obj, Stream& stream, ResultLocale loc, const Point* p) {
      return write_results_at(*obj, stream, loc, p);
    }

    template<typename Stream>
    Result<Unit> write_results_at(const ResultSet& obj, Stream& stream, ResultLocale loc, const Point* p) {
      auto x1 { separator_result_source("----------") };
      auto x2 { time_result_source() };

      TRY_RESULT(write_results_at(x1, stream, loc, p));
      TRY_RESULT(write_results_at(x2, stream, loc, p));

      for (const auto& source : obj.sources()) {
        TRY_RESULT(write_results_at(source, stream, loc, p));
      }

      return Result<Unit>(Unit());
    }

    /** Write the object representation within `Event<Unit>`. */
    template<typename ResultObject, typename Stream>
    inline auto write_results(ResultObject&& obj,
      const std::shared_ptr<Stream>& stream, 
      ResultLocale loc)
    {
      return cons_event([obj{std::move(obj)}, stream, loc](const Point* p) {
        return write_results_at(obj, *stream, loc, p);
      });
    }

    /** Write the object representation in the integration time points within `Simulation<Unit>`. */
    template<typename ResultObject, typename Stream>
    inline auto write_results_in_integ_times(ResultObject&& obj,
      const std::shared_ptr<Stream>& stream,
      ResultLocale loc)
    {
      std::shared_ptr<ResultObject> p(new ResultObject(std::move(obj)));
      return enqueue_io_events_with_integ_times([p, stream, loc]() {
        return write_results(p, stream, loc);
      })
      .run_in_start_time()
      .and_then([](Unit&& unit) {
        return pure_event(Unit())
          .run_in_stop_time();
      });
    }

    /** Write the object representation in the stop time within `Simulation<Unit>`. */
    template<typename ResultObject, typename Stream>
    inline auto write_results_in_stop_time(ResultObject&& obj,
      const std::shared_ptr<Stream>& stream,
      ResultLocale loc)
    {
      return cons_event([](const Point* p) {
        return Result<double>(p->run->specs->stop_time);
      })
      .and_then([obj{std::move(obj)}, stream, loc](double t2) mutable {
        return enqueue_uncancellable_io_event(t2, write_results(obj, stream, loc));
      })
      .run_in_start_time()
      .and_then([](Unit&& unit) {
        return pure_event(Unit())
          .run_in_stop_time();
      });
    }

#if defined(DVCOMPUTE_SEQUENTIAL) || defined(DVCOMPUTE_BRANCHED)

    /** Write simulation results in the integration time points. */
    template<typename Stream>
    void write_simulation_results_in_integ_times(Simulation<ResultSet>&& sim,
      const Specs* specs,
      Stream& stream,
      ResultLocale loc)
    {
      std::shared_ptr<Stream> p(&stream, [](Stream* x) { return; });
      auto res { 
        std::move(sim)
          .and_then([p, loc](ResultSet&& results) {
            return write_results_in_integ_times(std::move(results), p, loc);
          })
          .run(specs)
      };
      expect_result(std::move(res));
    }

    /** Write simulation results in the stop time point. */
    template<typename Stream>
    void write_simulation_results_in_stop_time(Simulation<ResultSet>&& sim,
      const Specs* specs,
      Stream& stream,
      ResultLocale loc)
    {
      std::shared_ptr<Stream> p(&stream, [](Stream* x) { return; });
      auto res { 
        std::move(sim)
          .and_then([p, loc](ResultSet&& results) {
            return write_results_in_stop_time(std::move(results), p, loc);
          })
          .run(specs)
      };
      expect_result(std::move(res));
    }

    /** Print the simulation results in the integration time points. */
    inline void print_simulation_results_in_integ_times(Simulation<ResultSet>&& sim,
      const Specs* specs,
      ResultLocale loc)
    {
      write_simulation_results_in_integ_times(std::move(sim), specs, std::cout, loc);
    }

    /** Print the simulation results in the stop time point. */
    inline void print_simulation_results_in_stop_time(Simulation<ResultSet>&& sim,
      const Specs* specs,
      ResultLocale loc)
    {
      write_simulation_results_in_stop_time(std::move(sim), specs, std::cout, loc);
    }

#elif defined(DVCOMPUTE_DISTRIBUTED) || defined(DVCOMPUTE_CONSERVATIVE)

    /** Write simulation results in the integration time points. */
    template<typename Stream>
    void write_simulation_results_in_integ_times(Simulation<ResultSet>&& sim,
      const Specs* specs,
      LogicalProcessContext* ctx,
      Stream& stream,
      ResultLocale loc)
    {
      std::shared_ptr<Stream> p(&stream, [](Stream* x) { return; });
      auto res { 
        std::move(sim)
          .and_then([p, loc](ResultSet&& results) {
            return write_results_in_integ_times(std::move(results), p, loc);
          })
          .run(specs, ctx)
      };
      expect_result(std::move(res));
    }

    /** Write simulation results in the stop time point. */
    template<typename Stream>
    void write_simulation_results_in_stop_time(Simulation<ResultSet>&& sim,
      const Specs* specs,
      LogicalProcessContext* ctx,
      Stream& stream,
      ResultLocale loc)
    {
      std::shared_ptr<Stream> p(&stream, [](Stream* x) { return; });
      auto res { 
        std::move(sim)
          .and_then([p, loc](ResultSet&& results) {
            return write_results_in_stop_time(std::move(results), p, loc);
          })
          .run(specs, ctx)
      };
      expect_result(std::move(res));
    }

    /** Print the simulation results in the integration time points. */
    inline void print_simulation_results_in_integ_times(Simulation<ResultSet>&& sim,
      const Specs* specs,
      LogicalProcessContext* ctx,
      ResultLocale loc)
    {
      write_simulation_results_in_integ_times(std::move(sim), specs, ctx, std::cout, loc);
    }

    /** Print the simulation results in the stop time point. */
    inline void print_simulation_results_in_stop_time(Simulation<ResultSet>&& sim,
      const Specs* specs,
      LogicalProcessContext* ctx,
      ResultLocale loc)
    {
      write_simulation_results_in_stop_time(std::move(sim), specs, ctx, std::cout, loc);
    }

#else
#error "Unknown simulation mode"
#endif
  }
}

#endif /* dvcompute_result_io_h */

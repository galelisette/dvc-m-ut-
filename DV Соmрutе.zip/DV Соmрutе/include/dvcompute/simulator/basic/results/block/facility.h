﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_block_facility_h
#define dvcompute_result_block_facility_h

#include <string>
#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "../result_source.h"
#include "../result_items.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** The facility identifier. */
      class FacilityId : public ResultTypeId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("прибор");
          } else {
            return std::string("the facility");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("прибор");
          } else {
            return std::string("facility");
          }
        }
      };

      /** The current queue size. */
      class FacilityQueueCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущая длина очереди");
          } else {
            return std::string("the current queue size");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("длина очереди");
          } else {
            return std::string("queue size");
          }
        }
      };

      /** The queue size statistics. */
      class FacilityQueueCountStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика по длине очереди");
          } else {
            return std::string("the queue size statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика длины очереди");
          } else {
            return std::string("queue size stats");
          }
        }
      };

      /** The total wait time. */
      class FacilityTotalWaitTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее время ожидания прибора");
          } else {
            return std::string("the total wait time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее время ожидания");
          } else {
            return std::string("the total wait time");
          }
        }
      };

      /** The wait time statistics. */
      class FacilityWaitTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания прибора");
          } else {
            return std::string("the wait time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания");
          } else {
            return std::string("the wait time");
          }
        }
      };

      /** The total holding time. */
      class FacilityTotalHoldingTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее время удержания прибора");
          } else {
            return std::string("the total holding time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее время удержания");
          } else {
            return std::string("the total holding time");
          }
        }
      };

      /** The holding time statistics. */
      class FacilityHoldingTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время удержания прибора");
          } else {
            return std::string("the holding time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время удержания");
          } else {
            return std::string("the holding time");
          }
        }
      };

      /** Whether the facility is currently interrupted. */
      class FacilityInterruptedId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("удержание прибора сейчас прервано?");
          } else {
            return std::string("is the facility interrupted now?");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("удержание прервано сейчас?");
          } else {
            return std::string("interrupted now?");
          }
        }
      };

      /** The current available count. */
      class FacilityCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущее доступное количество");
          } else {
            return std::string("the current available count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество");
          } else {
            return std::string("count");
          }
        }
      };

      /** The available count statistics. */
      class FacilityCountStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика доступного количества прибора");
          } else {
            return std::string("the available count statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика доступного количества");
          } else {
            return std::string("the available count statistics");
          }
        }
      };

      /** The total capture count. */
      class FacilityCaptureCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее количество захватов прибора");
          } else {
            return std::string("the total capture count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество захватов прибора");
          } else {
            return std::string("the capture count");
          }
        }
      };

      /** The current utilisation count. */
      class FacilityUtilCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущее используемое количество прибора");
          } else {
            return std::string("the current utilization count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("используемое количество");
          } else {
            return std::string("the utilization count");
          }
        }
      };

      /** The utilisation count statistics. */
      class FacilityUtilCountStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика используемого количества прибора");
          } else {
            return std::string("the utilization count statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика используемого количества");
          } else {
            return std::string("the utilization count stats");
          }
        }
      };

      template<typename Item>
      inline ResultSource make_facility_result_source(const ResultContainer<DVCOMPUTE_NS::block::Facility<Item>>& arg) {
        using namespace DVCOMPUTE_NS::block;

        std::vector<ResultProperty> props;

        props.emplace_back(arg.prop("queue_count", 
          std::shared_ptr<ResultId>(new FacilityQueueCountId), 
          [](const FacilityPtr<Item>& x) { return facility_queue_count(x); },
          [](const FacilityPtr<Item>& x) { return facility_queue_count_changed_(x); }));

        props.emplace_back(arg.prop("queue_count_stats", 
          std::shared_ptr<ResultId>(new FacilityQueueCountStatsId), 
          [](const FacilityPtr<Item>& x) { return facility_queue_count_stats(x); },
          [](const FacilityPtr<Item>& x) { return facility_queue_count_changed_(x); }));

        props.emplace_back(arg.prop("total_wait_time", 
          std::shared_ptr<ResultId>(new FacilityTotalWaitTimeId), 
          [](const FacilityPtr<Item>& x) { return facility_total_wait_time(x); },
          [](const FacilityPtr<Item>& x) { return facility_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("wait_time", 
          std::shared_ptr<ResultId>(new FacilityWaitTimeId), 
          [](const FacilityPtr<Item>& x) { return facility_wait_time(x); },
          [](const FacilityPtr<Item>& x) { return facility_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("total_holding_time", 
          std::shared_ptr<ResultId>(new FacilityTotalHoldingTimeId), 
          [](const FacilityPtr<Item>& x) { return facility_total_holding_time(x); },
          [](const FacilityPtr<Item>& x) { return facility_holding_time_changed_(x); }));

        props.emplace_back(arg.prop("holding_time", 
          std::shared_ptr<ResultId>(new FacilityHoldingTimeId), 
          [](const FacilityPtr<Item>& x) { return facility_holding_time(x); },
          [](const FacilityPtr<Item>& x) { return facility_holding_time_changed_(x); }));

        props.emplace_back(arg.integ_prop("interrupted", 
          std::shared_ptr<ResultId>(new FacilityInterruptedId), 
          [](const FacilityPtr<Item>& x) { return is_facility_interrupted(x); }));

        props.emplace_back(arg.prop("count", 
          std::shared_ptr<ResultId>(new FacilityCountId), 
          [](const FacilityPtr<Item>& x) { return facility_count(x); },
          [](const FacilityPtr<Item>& x) { return facility_count_changed_(x); }));

        props.emplace_back(arg.prop("count_stats", 
          std::shared_ptr<ResultId>(new FacilityCountStatsId), 
          [](const FacilityPtr<Item>& x) { return facility_count_stats(x); },
          [](const FacilityPtr<Item>& x) { return facility_count_changed_(x); }));

        props.emplace_back(arg.prop("capture_count", 
          std::shared_ptr<ResultId>(new FacilityCaptureCountId), 
          [](const FacilityPtr<Item>& x) { return facility_capture_count(x); },
          [](const FacilityPtr<Item>& x) { return facility_capture_count_changed_(x); }));

        props.emplace_back(arg.prop("util_count", 
          std::shared_ptr<ResultId>(new FacilityUtilCountId), 
          [](const FacilityPtr<Item>& x) { return facility_util_count(x); },
          [](const FacilityPtr<Item>& x) { return facility_util_count_changed_(x); }));

        props.emplace_back(arg.prop("util_count_stats", 
          std::shared_ptr<ResultId>(new FacilityUtilCountStatsId), 
          [](const FacilityPtr<Item>& x) { return facility_util_count_stats(x); },
          [](const FacilityPtr<Item>& x) { return facility_util_count_changed_(x); }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new FacilityId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }

      template<typename Item>
      inline ResultSource make_facility_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Facility<Item>>& arg) {
        using namespace DVCOMPUTE_NS::block;

        std::vector<ResultProperty> props;

        props.emplace_back(arg.prop("queue_count_stats", 
          std::shared_ptr<ResultId>(new FacilityQueueCountStatsId), 
          [](const FacilityPtr<Item>& x) { return facility_queue_count_stats(x); },
          [](const FacilityPtr<Item>& x) { return facility_queue_count_changed_(x); }));

        props.emplace_back(arg.prop("wait_time", 
          std::shared_ptr<ResultId>(new FacilityWaitTimeId), 
          [](const FacilityPtr<Item>& x) { return facility_wait_time(x); },
          [](const FacilityPtr<Item>& x) { return facility_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("holding_time", 
          std::shared_ptr<ResultId>(new FacilityHoldingTimeId), 
          [](const FacilityPtr<Item>& x) { return facility_holding_time(x); },
          [](const FacilityPtr<Item>& x) { return facility_holding_time_changed_(x); }));

        props.emplace_back(arg.prop("count_stats", 
          std::shared_ptr<ResultId>(new FacilityCountStatsId), 
          [](const FacilityPtr<Item>& x) { return facility_count_stats(x); },
          [](const FacilityPtr<Item>& x) { return facility_count_changed_(x); }));

        props.emplace_back(arg.prop("capture_count", 
          std::shared_ptr<ResultId>(new FacilityCaptureCountId), 
          [](const FacilityPtr<Item>& x) { return facility_capture_count(x); },
          [](const FacilityPtr<Item>& x) { return facility_capture_count_changed_(x); }));

        props.emplace_back(arg.prop("util_count_stats", 
          std::shared_ptr<ResultId>(new FacilityUtilCountStatsId), 
          [](const FacilityPtr<Item>& x) { return facility_util_count_stats(x); },
          [](const FacilityPtr<Item>& x) { return facility_util_count_changed_(x); }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new FacilityId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }
    }

    template<typename Item>
    inline ResultSource make_result_source(const ResultContainer<DVCOMPUTE_NS::block::Facility<Item>>& arg) {
      return make_facility_result_source(arg);
    }

    template<typename Item>
    inline ResultSource make_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Facility<Item>>& arg) {
      return make_facility_result_source_summary(arg);
    }

    template<typename Item>
    inline ResultSource result_source(const DVCOMPUTE_NS::block::FacilityPtr<Item>& provider, 
      const ResultName& name,
      const std::vector<ResultName>& name_path,
      const std::shared_ptr<ResultId>& id,
      const std::vector<std::shared_ptr<ResultId>>& id_path)
    {
      using namespace DVCOMPUTE_NS::block;

      ResultContainer<DVCOMPUTE_NS::block::Facility<Item>> cont {
        name, name_path, id, id_path, provider,
        std::shared_ptr<std::function<ResultObservable()>>(new std::function<ResultObservable()> {
          [provider]() { return ResultObservable(SpecifiedResultObservable { facility_changed_(provider) }); }
        })
      };

      return make_result_source(cont);
    }
  }
}

#endif /* dvcompute_result_block_facility_h */

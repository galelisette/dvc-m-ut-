﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_block_storage_h
#define dvcompute_result_block_storage_h

#include <string>
#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "../result_source.h"
#include "../result_items.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** The storage identifier. */
      class StorageId : public ResultTypeId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("многоканальное устройство");
          } else {
            return std::string("the storage");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("многоканальное устройство");
          } else {
            return std::string("storage");
          }
        }
      };

      /** The storage capacity. */
      class StorageCapacityId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("ёмкость устройства");
          } else {
            return std::string("the storage capacity");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("ёмкость");
          } else {
            return std::string("capacity");
          }
        }
      };

      /** Whether the storage is empty. */
      class StorageEmptyId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("устройство пустое?");
          } else {
            return std::string("is the storage empty?");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("пустое?");
          } else {
            return std::string("empty?");
          }
        }
      };

      /** Whether the storage is full. */
      class StorageFullId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("устройство заполнено?");
          } else {
            return std::string("is the storage full?");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("заполнено?");
          } else {
            return std::string("full?");
          }
        }
      };

      /** The current queue size. */
      class StorageQueueCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущая длина очереди");
          } else {
            return std::string("the current queue size");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("длина очереди");
          } else {
            return std::string("queue size");
          }
        }
      };

      /** The queue size statistics. */
      class StorageQueueCountStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика по длине очереди");
          } else {
            return std::string("the queue size statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика длины очереди");
          } else {
            return std::string("queue size stats");
          }
        }
      };

      /** The total wait time. */
      class StorageTotalWaitTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее время ожидания устройства");
          } else {
            return std::string("the total wait time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее время ожидания");
          } else {
            return std::string("the total wait time");
          }
        }
      };

      /** The wait time statistics. */
      class StorageWaitTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания устройства");
          } else {
            return std::string("the wait time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания");
          } else {
            return std::string("the wait time");
          }
        }
      };

      /** The average holding time. */
      class StorageAverageHoldingTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее время удержания устройства");
          } else {
            return std::string("the average holding time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("среднее время удержания");
          } else {
            return std::string("the average holding time");
          }
        }
      };

      /** The current available content. */
      class StorageContentId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущее доступное содержимое");
          } else {
            return std::string("the current available content");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("содержимое");
          } else {
            return std::string("content");
          }
        }
      };

      /** The available content statistics. */
      class StorageContentStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика по доступному содержимому");
          } else {
            return std::string("the available content statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика содержимого");
          } else {
            return std::string("content stats");
          }
        }
      };

      /** The total use count. */
      class StorageUseCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее количество использований");
          } else {
            return std::string("the total use count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество использований");
          } else {
            return std::string("the use count");
          }
        }
      };

      /** The total used content. */
      class StorageUsedContentId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("общее использованное содержимое");
          } else {
            return std::string("the total used content");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("использованное содержимое");
          } else {
            return std::string("the used content");
          }
        }
      };

      /** The current utilisation count. */
      class StorageUtilCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущее используемое количество устройства");
          } else {
            return std::string("the current utilization count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("используемое количество");
          } else {
            return std::string("the utilization count");
          }
        }
      };

      /** The utilisation count statistics. */
      class StorageUtilCountStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика используемого количества устройства");
          } else {
            return std::string("the utilization count statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика используемого количества");
          } else {
            return std::string("the utilization count stats");
          }
        }
      };

      template<typename Item>
      inline ResultSource make_storage_result_source(const ResultContainer<DVCOMPUTE_NS::block::Storage<Item>>& arg) {
        using namespace DVCOMPUTE_NS::block;

        std::vector<ResultProperty> props;

        props.emplace_back(arg.const_prop("capacity", 
          std::shared_ptr<ResultId>(new StorageCapacityId), 
          [](const StoragePtr<Item>& x) { return x->capacity(); }));

        props.emplace_back(arg.integ_prop("empty", 
          std::shared_ptr<ResultId>(new StorageEmptyId), 
          [](const StoragePtr<Item>& x) { return storage_empty(x); }));

        props.emplace_back(arg.integ_prop("full", 
          std::shared_ptr<ResultId>(new StorageFullId), 
          [](const StoragePtr<Item>& x) { return storage_full(x); }));

        props.emplace_back(arg.prop("queue_count", 
          std::shared_ptr<ResultId>(new StorageQueueCountId), 
          [](const StoragePtr<Item>& x) { return storage_queue_count(x); },
          [](const StoragePtr<Item>& x) { return storage_queue_count_changed_(x); }));

        props.emplace_back(arg.prop("queue_count_stats", 
          std::shared_ptr<ResultId>(new StorageQueueCountStatsId), 
          [](const StoragePtr<Item>& x) { return storage_queue_count_stats(x); },
          [](const StoragePtr<Item>& x) { return storage_queue_count_changed_(x); }));

        props.emplace_back(arg.prop("total_wait_time", 
          std::shared_ptr<ResultId>(new StorageTotalWaitTimeId), 
          [](const StoragePtr<Item>& x) { return storage_total_wait_time(x); },
          [](const StoragePtr<Item>& x) { return storage_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("wait_time", 
          std::shared_ptr<ResultId>(new StorageWaitTimeId), 
          [](const StoragePtr<Item>& x) { return storage_wait_time(x); },
          [](const StoragePtr<Item>& x) { return storage_wait_time_changed_(x); }));

        props.emplace_back(arg.integ_prop("average_holding_time", 
          std::shared_ptr<ResultId>(new StorageAverageHoldingTimeId), 
          [](const StoragePtr<Item>& x) { return storage_average_holding_time(x); }));

        props.emplace_back(arg.prop("content", 
          std::shared_ptr<ResultId>(new StorageContentId), 
          [](const StoragePtr<Item>& x) { return storage_content(x); },
          [](const StoragePtr<Item>& x) { return storage_content_changed_(x); }));

        props.emplace_back(arg.prop("content_stats", 
          std::shared_ptr<ResultId>(new StorageContentStatsId), 
          [](const StoragePtr<Item>& x) { return storage_content_stats(x); },
          [](const StoragePtr<Item>& x) { return storage_content_changed_(x); }));

        props.emplace_back(arg.prop("use_count", 
          std::shared_ptr<ResultId>(new StorageUseCountId), 
          [](const StoragePtr<Item>& x) { return storage_use_count(x); },
          [](const StoragePtr<Item>& x) { return storage_use_count_changed_(x); }));

        props.emplace_back(arg.prop("used_content", 
          std::shared_ptr<ResultId>(new StorageUsedContentId), 
          [](const StoragePtr<Item>& x) { return storage_used_content(x); },
          [](const StoragePtr<Item>& x) { return storage_used_content_changed_(x); }));

        props.emplace_back(arg.prop("util_count", 
          std::shared_ptr<ResultId>(new StorageUtilCountId), 
          [](const StoragePtr<Item>& x) { return storage_util_count(x); },
          [](const StoragePtr<Item>& x) { return storage_util_count_changed_(x); }));

        props.emplace_back(arg.prop("util_count_stats", 
          std::shared_ptr<ResultId>(new StorageUtilCountStatsId), 
          [](const StoragePtr<Item>& x) { return storage_util_count_stats(x); },
          [](const StoragePtr<Item>& x) { return storage_util_count_changed_(x); }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new StorageId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }

      template<typename Item>
      inline ResultSource make_storage_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Storage<Item>>& arg) {
        using namespace DVCOMPUTE_NS::block;

        std::vector<ResultProperty> props;

        props.emplace_back(arg.const_prop("capacity", 
          std::shared_ptr<ResultId>(new StorageCapacityId), 
          [](const StoragePtr<Item>& x) { return x->capacity(); }));

        props.emplace_back(arg.prop("queue_count_stats", 
          std::shared_ptr<ResultId>(new StorageQueueCountStatsId), 
          [](const StoragePtr<Item>& x) { return storage_queue_count_stats(x); },
          [](const StoragePtr<Item>& x) { return storage_queue_count_changed_(x); }));

        props.emplace_back(arg.prop("wait_time", 
          std::shared_ptr<ResultId>(new StorageWaitTimeId), 
          [](const StoragePtr<Item>& x) { return storage_wait_time(x); },
          [](const StoragePtr<Item>& x) { return storage_wait_time_changed_(x); }));

        props.emplace_back(arg.integ_prop("average_holding_time", 
          std::shared_ptr<ResultId>(new StorageAverageHoldingTimeId), 
          [](const StoragePtr<Item>& x) { return storage_average_holding_time(x); }));

        props.emplace_back(arg.prop("content_stats", 
          std::shared_ptr<ResultId>(new StorageContentStatsId), 
          [](const StoragePtr<Item>& x) { return storage_content_stats(x); },
          [](const StoragePtr<Item>& x) { return storage_content_changed_(x); }));

        props.emplace_back(arg.prop("use_count", 
          std::shared_ptr<ResultId>(new StorageUseCountId), 
          [](const StoragePtr<Item>& x) { return storage_use_count(x); },
          [](const StoragePtr<Item>& x) { return storage_use_count_changed_(x); }));

        props.emplace_back(arg.prop("used_content", 
          std::shared_ptr<ResultId>(new StorageUsedContentId), 
          [](const StoragePtr<Item>& x) { return storage_used_content(x); },
          [](const StoragePtr<Item>& x) { return storage_used_content_changed_(x); }));

        props.emplace_back(arg.prop("util_count_stats", 
          std::shared_ptr<ResultId>(new StorageUtilCountStatsId), 
          [](const StoragePtr<Item>& x) { return storage_util_count_stats(x); },
          [](const StoragePtr<Item>& x) { return storage_util_count_changed_(x); }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new StorageId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }
    }

    template<typename Item>
    inline ResultSource make_result_source(const ResultContainer<DVCOMPUTE_NS::block::Storage<Item>>& arg) {
      return make_storage_result_source(arg);
    }

    template<typename Item>
    inline ResultSource make_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Storage<Item>>& arg) {
      return make_storage_result_source_summary(arg);
    }

    template<typename Item>
    inline ResultSource result_source(const DVCOMPUTE_NS::block::StoragePtr<Item>& provider, 
      const ResultName& name,
      const std::vector<ResultName>& name_path,
      const std::shared_ptr<ResultId>& id,
      const std::vector<std::shared_ptr<ResultId>>& id_path)
    {
      using namespace DVCOMPUTE_NS::block;

      ResultContainer<DVCOMPUTE_NS::block::Storage<Item>> cont {
        name, name_path, id, id_path, provider,
        std::shared_ptr<std::function<ResultObservable()>>(new std::function<ResultObservable()> {
          [provider]() { return ResultObservable(SpecifiedResultObservable { storage_changed_(provider) }); }
        })
      };

      return make_result_source(cont);
    }
  }
}

#endif /* dvcompute_result_block_storage_h */

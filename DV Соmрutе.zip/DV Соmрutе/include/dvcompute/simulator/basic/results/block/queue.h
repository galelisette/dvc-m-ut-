﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_block_queue_h
#define dvcompute_result_block_queue_h

#include <string>
#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "../result_source.h"
#include "../result_items.h"

namespace DVCOMPUTE_NS {

  namespace results {

    namespace {

      /** The queue identifier. */
      class QueueId : public ResultTypeId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("очередь");
          } else {
            return std::string("queue");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("очередь");
          } else {
            return std::string("queue");
          }
        }
      };

      /** Whether the queue is empty. */
      class QueueEmptyId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("очередь пуста?");
          } else {
            return std::string("is the queue empty?");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("очередь пуста?");
          } else {
            return std::string("empty?");
          }
        }
      };

      /** The current available content. */
      class QueueContentId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("текущее содержимое");
          } else {
            return std::string("the current content");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("содержимое");
          } else {
            return std::string("content");
          }
        }
      };

      /** The available content statistics. */
      class QueueContentStatsId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика по содержимому");
          } else {
            return std::string("the content statistics");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("статистика содержимого");
          } else {
            return std::string("content stats");
          }
        }
      };

      /** The enqueue count. */
      class EnqueueCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество добавлений в очередь");
          } else {
            return std::string("the enqueue count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество добавлений");
          } else {
            return std::string("the enqueue count");
          }
        }
      };

      /** The enqueue zero entry count. */
      class EnqueueZeroEntryCountId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество добавлений в очередь без ожидания");
          } else {
            return std::string("the enqueue zero entry count");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("количество добавлений без ожидания");
          } else {
            return std::string("the enqueue zero entry count");
          }
        }
      };

      /** The wait time statistics. */
      class QueueWaitTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания в очереди");
          } else {
            return std::string("the wait time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания");
          } else {
            return std::string("the wait time");
          }
        }
      };

      /** The non-zero entry wait time statistics. */
      class QueueNonZeroEntryWaitTimeId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания в очереди без учета неожидавших");
          } else {
            return std::string("the non-zero entry wait time");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("время ожидания без учета неожидавших");
          } else {
            return std::string("the non-zero entry wait time");
          }
        }
      };

      /** The queue rate. */
      class QueueRateId : public ResultId {
      public:

        std::optional<ResultDescription> description(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("усреднённая скорость");
          } else {
            return std::string("the queue rate");
          }
        }

        std::optional<ResultDescription> title(ResultLocale loc) const override {
          if (loc == ResultLocale::ru) {
            return std::string("усреднённая скорость");
          } else {
            return std::string("the queue rate");
          }
        }
      };

      inline ResultSource make_queue_result_source(const ResultContainer<DVCOMPUTE_NS::block::Queue>& arg) {
        using namespace DVCOMPUTE_NS::block;

        std::vector<ResultProperty> props;

        props.emplace_back(arg.prop("queue_empty", 
          std::shared_ptr<ResultId>(new QueueEmptyId), 
          [](const QueuePtr& x) { return queue_empty(x); },
          [](const QueuePtr& x) { return queue_content_changed_(x); }));

        props.emplace_back(arg.prop("queue_content", 
          std::shared_ptr<ResultId>(new QueueContentId), 
          [](const QueuePtr& x) { return queue_content(x); },
          [](const QueuePtr& x) { return queue_content_changed_(x); }));

        props.emplace_back(arg.prop("queue_content_stats", 
          std::shared_ptr<ResultId>(new QueueContentStatsId), 
          [](const QueuePtr& x) { return queue_content_stats(x); },
          [](const QueuePtr& x) { return queue_content_changed_(x); }));

        props.emplace_back(arg.prop("enqueue_count", 
          std::shared_ptr<ResultId>(new EnqueueCountId), 
          [](const QueuePtr& x) { return enqueue_count(x); },
          [](const QueuePtr& x) { return enqueue_count_changed_(x); }));

        props.emplace_back(arg.prop("enqueue_zero_entry_count", 
          std::shared_ptr<ResultId>(new EnqueueZeroEntryCountId), 
          [](const QueuePtr& x) { return enqueue_zero_entry_count(x); },
          [](const QueuePtr& x) { return enqueue_zero_entry_count_changed_(x); }));

        props.emplace_back(arg.prop("queue_wait_time", 
          std::shared_ptr<ResultId>(new QueueWaitTimeId), 
          [](const QueuePtr& x) { return queue_wait_time(x); },
          [](const QueuePtr& x) { return queue_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("queue_non_zero_entry_wait_time", 
          std::shared_ptr<ResultId>(new QueueNonZeroEntryWaitTimeId), 
          [](const QueuePtr& x) { return queue_non_zero_entry_wait_time(x); },
          [](const QueuePtr& x) { return queue_non_zero_entry_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("queue_rate", 
          std::shared_ptr<ResultId>(new QueueRateId), 
          [](const QueuePtr& x) { return queue_rate(x); },
          [](const QueuePtr& x) { return queue_rate_changed_(x); }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new QueueId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }

      inline ResultSource make_queue_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Queue>& arg) {
        using namespace DVCOMPUTE_NS::block;

        std::vector<ResultProperty> props;

        props.emplace_back(arg.prop("queue_content_stats", 
          std::shared_ptr<ResultId>(new QueueContentStatsId), 
          [](const QueuePtr& x) { return queue_content_stats(x); },
          [](const QueuePtr& x) { return queue_content_changed_(x); }));

        props.emplace_back(arg.prop("enqueue_count", 
          std::shared_ptr<ResultId>(new EnqueueCountId), 
          [](const QueuePtr& x) { return enqueue_count(x); },
          [](const QueuePtr& x) { return enqueue_count_changed_(x); }));

        props.emplace_back(arg.prop("enqueue_zero_entry_count", 
          std::shared_ptr<ResultId>(new EnqueueZeroEntryCountId), 
          [](const QueuePtr& x) { return enqueue_zero_entry_count(x); },
          [](const QueuePtr& x) { return enqueue_zero_entry_count_changed_(x); }));

        props.emplace_back(arg.prop("queue_wait_time", 
          std::shared_ptr<ResultId>(new QueueWaitTimeId), 
          [](const QueuePtr& x) { return queue_wait_time(x); },
          [](const QueuePtr& x) { return queue_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("queue_non_zero_entry_wait_time", 
          std::shared_ptr<ResultId>(new QueueNonZeroEntryWaitTimeId), 
          [](const QueuePtr& x) { return queue_non_zero_entry_wait_time(x); },
          [](const QueuePtr& x) { return queue_non_zero_entry_wait_time_changed_(x); }));

        props.emplace_back(arg.prop("queue_rate", 
          std::shared_ptr<ResultId>(new QueueRateId), 
          [](const QueuePtr& x) { return queue_rate(x); },
          [](const QueuePtr& x) { return queue_rate_changed_(x); }));

        return ResultSource {
          std::shared_ptr<ResultObject>(new ResultObject {
            arg.name,
            arg.id,
            std::shared_ptr<ResultTypeId>(new QueueId),
            props,
            arg.observable,
            std::shared_ptr<std::function<ResultSource()>> {
              new std::function<ResultSource()>([arg]() {
                return make_result_source_summary(arg);
              })
            }
          })
        };
      }
    }

    template<>
    inline ResultSource make_result_source(const ResultContainer<DVCOMPUTE_NS::block::Queue>& arg) {
      return make_queue_result_source(arg);
    }

    template<>
    inline ResultSource make_result_source_summary(const ResultContainer<DVCOMPUTE_NS::block::Queue>& arg) {
      return make_queue_result_source_summary(arg);
    }

    template<>
    inline ResultSource result_source(const DVCOMPUTE_NS::block::QueuePtr& provider, 
      const ResultName& name,
      const std::vector<ResultName>& name_path,
      const std::shared_ptr<ResultId>& id,
      const std::vector<std::shared_ptr<ResultId>>& id_path)
    {
      using namespace DVCOMPUTE_NS::block;

      ResultContainer<DVCOMPUTE_NS::block::Queue> cont {
        name, name_path, id, id_path, provider,
        std::shared_ptr<std::function<ResultObservable()>>(new std::function<ResultObservable()> {
          [provider]() { return ResultObservable(SpecifiedResultObservable { queue_changed_(provider) }); }
        })
      };

      return make_result_source(cont);
    }
  }
}

#endif /* dvcompute_result_block_queue_h */

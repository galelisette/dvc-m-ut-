/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_result_set_h
#define dvcompute_result_set_h

#include <vector>
#include <functional>
#include <memory>

#include "dvcompute/dvcompute_ns.h"
#include "result_source.h"

namespace DVCOMPUTE_NS {

  namespace results {

    /** It transforms the results of simulation. */
    class ResultTransform;

    /** It contains the results of simulation. */
    class ResultSet {

      /** The sources of simulation results as a map of associated names. */
      ResultSourceMap map;

      /** The sources of simulation results as an ordered vector. */
      std::vector<ResultSource> vec;

      friend inline ResultTransform results_by_name(const ResultName&);

      friend inline ResultTransform filter_results_by_name(std::function<bool(const ResultName&)>&&);

      template<typename Id>
      friend inline ResultTransform results_by_id();

    public:

      /** Create an empty result set. */
      explicit ResultSet() :
        map(), vec()
      {}

      /** Create a result set by the specified sources. */
      explicit ResultSet(std::vector<ResultSource>&& vec_arg) :
        map(), vec(std::move(vec_arg))
      {
        for (const auto& x : vec) {
          map = map.emplace(x.name(), ResultSource(x));
        }
      }

      ResultSet(const ResultSet&) = default;
      ResultSet(ResultSet&&) = default;

      ResultSet& operator=(const ResultSet&) = default;
      ResultSet& operator=(ResultSet&&) = default;

      /** Merge two result sets. */
      ResultSet merge(const ResultSet& other) const {
        std::vector<ResultSource> xs(vec);
        for (const auto& x : other.vec) {
          xs.push_back(x);
        }
        return ResultSet(std::move(xs));
      }

      /**
       * Return a summarised and usually more short version of the result set by expanding
       * the main properties or excluding auxiliary properties if required.
       */
      ResultSet summary() const {
        std::vector<ResultSource> xs;
        for (const auto& x : vec) {
          xs.push_back(x.summary());
        }
        return ResultSet(std::move(xs));
      }

      /** Return an expanded version of the result set while expanding the properties as possible. */
      ResultSet expand() const {
        std::vector<ResultSource> xs;
        for (const auto& x : vec) {
          xs.push_back(x.expand());
        }
        return ResultSet(std::move(xs));
      }

      /** Return a signal emitted by the set. */
      ResultObservable observable() const {
        ResultObservable z(EmptyResultObservable {});
        for (const auto& x : vec) {
          z = std::move(z).merge(x.observable());
        }
        return z;
      }

      /** Get the result sources. */
      std::vector<ResultSource> sources() const {
        return vec;
      }

      /** Represent the result set as integer numbers. */
      std::vector<ResultValue<int>> int_values() const {
        std::vector<ResultValue<int>> ys;
        for (const auto& x : vec) {
          auto zs { x.int_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as vectors of integer numbers. */
      std::vector<ResultValue<std::vector<int>>> int_vector_values() const {
        std::vector<ResultValue<std::vector<int>>> ys;
        for (const auto& x : vec) {
          auto zs { x.int_vector_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as statistics based on integer numbers. */
      std::vector<ResultValue<SamplingStats<int>>> int_stats_values() const {
        std::vector<ResultValue<SamplingStats<int>>> ys;
        for (const auto& x : vec) {
          auto zs { x.int_stats_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as time-persistent statistics based on integer numbers. */
      std::vector<ResultValue<TimingStats<int>>> int_timing_stats_values() const {
        std::vector<ResultValue<TimingStats<int>>> ys;
        for (const auto& x : vec) {
          auto zs { x.int_timing_stats_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as double floating point numbers. */
      std::vector<ResultValue<double>> double_values() const {
        std::vector<ResultValue<double>> ys;
        for (const auto& x : vec) {
          auto zs { x.double_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as vectors of double floating point numbers. */
      std::vector<ResultValue<std::vector<double>>> double_vector_values() const {
        std::vector<ResultValue<std::vector<double>>> ys;
        for (const auto& x : vec) {
          auto zs { x.double_vector_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as statistics based on double floating point numbers. */
      std::vector<ResultValue<SamplingStats<double>>> double_stats_values() const {
        std::vector<ResultValue<SamplingStats<double>>> ys;
        for (const auto& x : vec) {
          auto zs { x.double_stats_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as time-persistent statistics based on double floating point numbers. */
      std::vector<ResultValue<TimingStats<double>>> double_timing_stats_values() const {
        std::vector<ResultValue<TimingStats<double>>> ys;
        for (const auto& x : vec) {
          auto zs { x.double_timing_stats_values() };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }

      /** Represent the result set as `std::string` values. */
      std::vector<ResultValue<std::string>> string_values(ResultLocale loc) const {
        std::vector<ResultValue<std::string>> ys;
        for (const auto& x : vec) {
          auto zs { x.string_values(loc) };
          for (auto& z : zs) {
            ys.emplace_back(std::move(z));
          }
        }
        return ys;
      }
    };

    /** It transforms the results of simulation. */
    class ResultTransform {

      /** The transformating function. */
      std::shared_ptr<std::function<ResultSet(const ResultSet&)>> f;

    public:

      /** Create an empty transform that retains the result set as is. */
      explicit ResultTransform() :
        f(new std::function<ResultSet(const ResultSet&)>([](const ResultSet& xs) {
          return xs;
        }))
      {}

      /** Create a transform by the specified function. */
      explicit ResultTransform(std::function<ResultSet(const ResultSet&)>&& f_arg) :
        f(new std::function<ResultSet(const ResultSet&)>(std::move(f_arg)))
      {}

      ResultTransform(const ResultTransform&) = default;
      ResultTransform(ResultTransform&&) = default;

      ResultTransform& operator=(const ResultTransform&) = default;
      ResultTransform& operator=(ResultTransform&&) = default;

      /** Transform the results. */
      ResultSet operator()(const ResultSet& xs) const {
        return f->operator()(xs);
      }

      /** Merge two result transformations. */
      ResultTransform merge(const ResultTransform& other) const {
        return ResultTransform([f{f}, other](const ResultSet& xs) {
          return (f->operator()(xs)).merge((other.f)->operator()(xs));
        });
      }

      /** Compose two result transformations. */
      ResultTransform and_then(const ResultTransform& other) const {
        return ResultTransform([f{f}, other](const ResultSet& xs) {
          return (other.f)->operator()(f->operator()(xs));
        });
      }
    };


    /**
      * Return a summarised and usually more short version of the result set by expanding
      * the main properties or excluding auxiliary properties if required.
      */
    inline ResultTransform result_summary() {
      return ResultTransform([](const ResultSet& xs) {
        return xs.summary();
      });
    }

    /** Return an expanded version of the result set while expanding the properties as possible. */
    inline ResultTransform expand_results() {
      return ResultTransform([](const ResultSet& xs) {
        return xs.expand();
      });
    }

    /** Take a result by its name. */
    inline ResultTransform results_by_name(const ResultName& name) {
      return ResultTransform([name](const ResultSet& xs) {
        auto it = xs.map.find(name);
        if (it != xs.map.end()) {
          std::vector<ResultSource> xs;
          xs.push_back(it.value());
          return ResultSet(std::move(xs));

        } else {
          std::string msg;
          msg += "Not found result source with name: ";
          msg += name;
          throw ResultException(msg);
        }
      });
    }

    /** Filter the results by their name. */
    inline ResultTransform filter_results_by_name(std::function<bool(const ResultName&)> &&pred) {
      return ResultTransform([pred{std::move(pred)}](const ResultSet& xs) {
        std::vector<ResultSource> ys;
        for (const auto &x : xs.vec) {
          if (pred(x.name())) {
            ys.push_back(x);
          }
        }
        return ResultSet(std::move(ys));
      });
    }

    /** Take the results starting with name. */
    inline ResultTransform results_starting_with_name(const ResultName& name) {
      return filter_results_by_name([=](const ResultName& s) {
        if (s.size() >= name.size()) {
          for (std::size_t i = 0; i < name.size(); ++i) {
            if (s[i] != name[i]) {
              return false;
            }
          }

          return true;

        } else {
          return false;
        }
      });
    }

    namespace {

      /** Find the result source by the specified identifier type. */
      template<typename Id>
      void collect_result_sources_by_id(std::vector<ResultSource>& result, const ResultSource& source) {
        if (const auto *item = std::get_if<std::shared_ptr<ResultItem>>(&source.var)) {
          if (dynamic_cast<const Id*>((*item)->id().get())) {
            result.push_back(source);
          } else {
            throw ResultException("Expected to find item with the specified identifier type");
          }
        
        } else if (auto *obj = std::get_if<std::shared_ptr<ResultObject>>(&source.var)) {
          if (dynamic_cast<const Id*>((*obj)->id.get())) {
            result.push_back(source);

          } else {
            bool found = false;
            for (const auto& prop : (*obj)->props) {
              if (dynamic_cast<const Id*>(prop.id.get())) {
                result.push_back(prop.source);
                found = true;
                break;
              }
            }
            if (!found) {
              throw ResultException("Not found property with the specified identifier type");
            }
          }

        } else if (auto *vec = std::get_if<std::shared_ptr<ResultVector>>(&source.var)) {
          if (dynamic_cast<const Id*>((*vec)->id.get())) {
            result.push_back(source);

          } else {
            for (const auto& item : (*vec)->items) {
              collect_result_sources_by_id<Id>(result, item);
            }
          }
        
        } else if (std::get_if<std::shared_ptr<ResultSeparator>>(&source.var)) {
          throw ResultException("Expected to find either item, object of vector with the specified identifier type");
        
        } else {
          throw "Unexhausted match";
        }
      }
    }

    /** 
     * Take a result from the object with the specified identifier type. 
     * It can identify an item, object property, the object itself, vector
     * or its elements. */
    template<typename Id>
    inline ResultTransform results_by_id() {
      return ResultTransform([](const ResultSet& xs) {
        std::vector<ResultSource> ys;
        for (const auto& x : xs.vec) {
          collect_result_sources_by_id<Id>(ys, x);
        }
        return ResultSet(std::move(ys));
      });
    }
  }
}

#endif /* dvcompute_result_set_h */

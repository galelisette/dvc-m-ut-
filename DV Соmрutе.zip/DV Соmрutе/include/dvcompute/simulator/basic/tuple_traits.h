/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_tuple_traits_h
#define dvcompute_tuple_traits_h

#include <functional>
#include <tuple>

#include "../../dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  template<typename T> 
  struct tuple_traits;  

  template<typename ...Args> 
  struct tuple_traits<std::tuple<Args...>> {

    static const size_t nargs = sizeof...(Args);

    template<size_t i>
    struct arg {
      typedef typename std::tuple_element<i, std::tuple<Args...>>::type type;
    };
  };
}

#endif /* dvcompute_tuple_trats_h */

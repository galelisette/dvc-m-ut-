﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_sampling_stats_h
#define dvcompute_sampling_stats_h

#include <limits>
#include <cmath>
#include <string>
#include <sstream>

#include "../../../dvcompute_ns.h"
#include "../results/result_locale.h"

namespace DVCOMPUTE_NS {

  /** Statistics based upon observations. */
  template<typename Item>
  struct SamplingStats {

    /** The total number of samples. */
    unsigned int count;

    /** The minimum value among samples. */
    Item min;

    /** The maximum value among samples. */
    Item max;

    /** The average value. */
    double mean;

    /** The average square value. */
    double mean2;

    /** Whether the statistics was normalized. */
    bool normalized;

    /** Create a SamplingStats instance. */
    SamplingStats(unsigned int count_arg, Item min_arg, Item max_arg, double mean_arg, double mean2_arg, bool normalized_arg) :
      count(count_arg), min(min_arg), max(max_arg), mean(mean_arg), mean2(mean2_arg), normalized(normalized_arg)
    {}

    /** An empty statistics hat has no samples. */
    explicit SamplingStats() noexcept :
      count(0),
      min(std::numeric_limits<Item>::has_infinity ? 
        std::numeric_limits<Item>::infinity() :
        std::numeric_limits<Item>::max()),
      max(std::numeric_limits<Item>::has_infinity ? 
        - std::numeric_limits<Item>::infinity() :
        std::numeric_limits<Item>::min()),
      mean(NAN),
      mean2(NAN),
      normalized(false)
    {}

    SamplingStats(const SamplingStats&) = default;
    SamplingStats(SamplingStats&&) = default;

    SamplingStats& operator=(const SamplingStats&) = default;
    SamplingStats& operator=(SamplingStats&&) = default;

    /** Create statistics from one sample. */
    static SamplingStats from_sample(Item sample) noexcept {
      double x = static_cast<double>(sample);
      return SamplingStats {
        1, sample, sample, x, x*x, false
      };     
    }

    /** Add a new sample to the statistics. */
    SamplingStats<Item> add(Item sample) const noexcept {
      double x = static_cast<double>(sample);
      if (std::isnan(x)) {
        return *this;
      } else if (count == 0) {
        return SamplingStats::from_sample(sample);
      } else {
        double n  = static_cast<double>(1 + count);
        double k1 = 1.0 / n;
        double k2 = (n - 1.0) / n;
        double m  = k1 * x + k2 * mean;
        double m2 = k1 * x * x + k2 * mean2;

        return SamplingStats<Item> {
          1 + count,
          std::min(sample, min),
          std::max(sample, max),
          m, 
          m2,
          normalized
        };
      }
    }

    /** Combine two statistics. */
    SamplingStats<Item> combine(const SamplingStats<Item>& other) const noexcept {
      unsigned int c1 = count;
      unsigned int c2 = other.count;
      if (c1 == 0) {
        return other;
      } else if (c2 == 0) {
        return *this;
      } else {
        double n1 = static_cast<double>(c1);
        double n2 = static_cast<double>(c2);
        double n  = n1 + n2;
        double k1 = n1 / n;
        double k2 = n2 / n;
        double m  = k1 * mean + k2 * other.mean;
        double m2 = k1 * mean2 + k2 * other.mean2;

        return SamplingStats<Item> {
          c1 + c2,
          std::min(min, other.min),
          std::max(max, other.max),
          m, 
          m2,
          normalized || other.normalized
        };
      }
    }

    /** Return the variance. */
    double variance() const noexcept {
      if (normalized) {
        return (mean2 - mean * mean);
      } else if (count == 1) {
        return 0.0;
      } else {
        double n = static_cast<double>(count);
        return (mean2 - mean * mean) * (n / (n - 1.0));
      }
    }

    /** Return the deviation. */
    double deviation() const noexcept {
      return std::sqrt(variance());
    }

    /** Create statistics by the specified samples. */
    template<typename Iter>
    static SamplingStats from_samples(Iter begin, Iter end) {
      SamplingStats st;
      for (Iter it = begin; it != end; ++it) {
        st = st.add(*it);
      }
      return st;
    }

    /**
     * Convert the statistics to its normalised observations-based representation,
     * where the first argument specifies the number of pseudo-samples.
     */
    SamplingStats<Item> norm(unsigned int sample_count) const noexcept {
      if (sample_count != count) {
        return SamplingStats<Item> {
          sample_count, min, max, mean, mean2, true
        };
      } else {
        return *this;
      }
    }

    operator SamplingStats<double>() const noexcept {
      return SamplingStats<double> {
        count,
        static_cast<double>(min),
        static_cast<double>(max),
        mean,
        mean2,
        normalized
      };
    }
  };

  template<typename Item>
  inline std::string to_string(const SamplingStats<Item>& stats, results::ResultLocale loc) {
    std::ostringstream stream;

    if (loc == results::ResultLocale::ru) {
      stream << "{ кол-во = " << stats.count << ", средн = " << stats.mean
        << ", СКО = " << stats.deviation() << ", мин = " << stats.min 
        << ", макс = " << stats.max << " }"; 

    } else {
      stream << "{ count = " << stats.count << ", mean = " << stats.mean
        << ", std = " << stats.deviation() << ", min = " << stats.min 
        << ", max = " << stats.max << " }"; 
    }

    return std::string(stream.str());
  }
}

#endif /* dvcompute_sampling_stats_h */

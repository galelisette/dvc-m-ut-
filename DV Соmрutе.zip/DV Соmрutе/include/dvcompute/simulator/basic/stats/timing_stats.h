﻿/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_timing_stats_h
#define dvcompute_timing_stats_h

#include <limits>
#include <cmath>
#include <string>
#include <sstream>

#include "../../../dvcompute_ns.h"
#include "../simulation.h"
#include "sampling_stats.h"
#include "../results/result_locale.h"

namespace DVCOMPUTE_NS {

  /** A time persistent variable statistics. */
  template<typename Item>
  struct TimingStats {

    /** The total number of samples. */
    unsigned int count;

    /** The minimum value among samples. */
    Item min;

    /** The maximum value among samples. */
    Item max;

    /** The last value. */
    Item last;

    /** The time at which the minimum is attained. */
    double min_time;

    /** The time at which the maximum is attained. */
    double max_time;

    /** The start time of sampling. */
    double start_time;

    /** The last time of sampling. */
    double last_time;

    /** The sum of values. */
    double sum;

    /** The sum of square values. */
    double sum2;

    /** Create an instance of TimingStats. */
    TimingStats(unsigned int count_arg, Item min_arg, Item max_arg, Item last_arg,
      double min_time_arg, double max_time_arg, double start_time_arg, double last_time_arg,
      double sum_arg, double sum2_arg) :
        count(count_arg), min(min_arg), max(max_arg), last(last_arg),
        min_time(min_time_arg), max_time(max_time_arg), start_time(start_time_arg), last_time(last_time_arg),
        sum(sum_arg), sum2(sum2_arg)
    {}

    /** An empty statistics hat has no samples. */
    explicit TimingStats() noexcept :
      count(0),
      min(std::numeric_limits<Item>::has_infinity ? 
        std::numeric_limits<Item>::infinity() :
        std::numeric_limits<Item>::max()),
      max(std::numeric_limits<Item>::has_infinity ? 
        - std::numeric_limits<Item>::infinity() :
        std::numeric_limits<Item>::min()),
      last(0),
      min_time(std::numeric_limits<double>::infinity()),
      max_time(- std::numeric_limits<double>::infinity()),
      start_time(std::numeric_limits<double>::infinity()),
      last_time(- std::numeric_limits<double>::infinity()),
      sum(NAN),
      sum2(NAN)
    {}

    TimingStats(const TimingStats&) = default;
    TimingStats(TimingStats&&) = default;

    TimingStats& operator=(const TimingStats&) = default;
    TimingStats& operator=(TimingStats&&) = default;

    /** Create statistics from one sample at the specified time. */
    static TimingStats from_sample(double t, Item sample) noexcept {
      return TimingStats {
        1, sample, sample, sample, t, t, t, t, 0.0, 0.0
      };     
    }

    /** Add a new sample to the statistics. */
    TimingStats<Item> add(double t, Item sample) const {
      if (t < last_time) {
        throw SimulationAbort("The current time cannot be less than the previous one");
      } else {
        double x = static_cast<double>(sample);
        if (std::isnan(x)) {
          return *this;
        } else if (count == 0) {
          return TimingStats::from_sample(t, sample);
        } else {
          double x0 = static_cast<double>(last);
          double s  = sum + (t - last_time) * x0;
          double s2 = sum2 + (t - last_time) * x0 * x0;

          return TimingStats<Item> {
            1 + count,
            std::min(sample, min),
            std::max(sample, max),
            sample,
            sample < min ? t : min_time,
            sample > max ? t : max_time,
            start_time,
            t,
            s,
            s2
          };
        }
      }
    }

    /** Return the average value. */
    double mean() const noexcept {
      if (count == 0) {
        return NAN;
      } else if (last_time <= start_time) {
        return min;
      } else {
        return sum / (last_time - start_time);
      }
    }

    /** Return the average square value. */
    double mean2() const noexcept {
      if (count == 0) {
        return NAN;
      } else if (last_time <= start_time) {
        return min * min;
      } else {
        return sum2 / (last_time - start_time);
      }
    }

    /** Return the variance. */
    double variance() const noexcept {
      double e  = mean();
      double e2 = mean2();
      return e2 - e * e;
    }

    /** Return the deviation. */
    double deviation() const noexcept {
      return std::sqrt(variance());
    }

    /**
     * Convert the statistics to its normalised observations-based representation,
     * where the first argument specifies the number of pseudo-samples.
     */
    SamplingStats<Item> norm(unsigned int sample_count) const noexcept {
      return SamplingStats<Item> {
        sample_count, min, max, mean(), mean2(), true
      };
    }

    operator TimingStats<double>() const noexcept {
      return TimingStats<double> {
        count,
        static_cast<double>(min),
        static_cast<double>(max),
        static_cast<double>(last),
        min_time,
        max_time,
        start_time,
        last_time,
        sum,
        sum2
      };
    }
  };

  template<typename Item>
  inline std::string to_string(const TimingStats<Item>& stats, results::ResultLocale loc) {
    std::ostringstream stream;

    if (loc == results::ResultLocale::ru) {
      stream << "{ кол-во = " << stats.count << ", средн = " << stats.mean()
        << ", СКО = " << stats.deviation() << ", мин = " << stats.min
        << " (t = " << stats.min_time << "), макс = " << stats.max
        << " (t = " << stats.max_time << "), t из [" << stats.start_time
        << "; " << stats.last_time << "] }";

    } else {
      stream << "{ count = " << stats.count << ", mean = " << stats.mean()
        << ", std = " << stats.deviation() << ", min = " << stats.min
        << " (t = " << stats.min_time << "), max = " << stats.max
        << " (t = " << stats.max_time << "), t in [" << stats.start_time
        << "; " << stats.last_time << "] }";
    }

    return std::string(stream.str());
  }
}

#endif /* dvcompute_timing_stats_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_parameter_random_h
#define dvcompute_parameter_random_h

#include "../../dvcompute_ns.h"

#include "parameter.h"
#include "generator.h"

namespace DVCOMPUTE_NS {

  /** The `Parameter<double>` computation that generates a new random number distributed uniformly. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_uniform_parameter(double min, double max) {
#else
  inline auto random_uniform_parameter(double min, double max) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_uniform(min, max));
    });
  }

  /** The `Parameter<int>` computation that generates a new integer random number distributed uniformly. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<int> auto random_int_uniform_parameter(int min, int max) {
#else
  inline auto random_int_uniform_parameter(int min, int max) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<int>(r->gen.random_int_uniform(min, max));
    });
  }

  /** The `Parameter<double>` computation that generates a new random number from the triangular distribution. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_triangular_parameter(double min, double median, double max) {
#else
  inline auto random_triangular_parameter(double min, double median, double max) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_triangular(min, median, max));
    });
  }

  /** The `Parameter<double>` computation  that generates a new random number distributed normally. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_normal_parameter(double mu, double nu) {
#else
  inline auto random_normal_parameter(double mu, double nu) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_normal(mu, nu));
    });
  }

  /** The `Parameter<double>` computation  that generates a new random number distributed lognormally. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_log_normal_parameter(double mu, double nu) {
#else
  inline auto random_log_normal_parameter(double mu, double nu) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_log_normal(mu, nu));
    });
  }

  /** 
   * The `Parameter<double>` computation that returns a new exponential random number with 
   * the specified average (the reciprocal of the rate).
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_exponential_parameter(double mu) {
#else
  inline auto random_exponential_parameter(double mu) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_exponential(mu));
    });
  }

  /**
   * The `Parameter<double>` computation that returns a new Erlang random number with 
   * the specified scale (the reciprocal of the rate) and integer shape.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_erlang_parameter(double scale, int shape) {
#else
  inline auto random_erlang_parameter(double scale, int shape) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_erlang(scale, shape));
    });
  }
  
  /** 
   * The `Parameter<int>` computation that returns a new Poisson random number with 
   * the specified average.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<int> auto random_poisson_parameter(double mu) {
#else
  inline auto random_poisson_parameter(double mu) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<int>(r->gen.random_poisson(mu));
    });
  }

  /** 
   * The `Parameter<int>` computation that returns a new binomial random number with 
   * the specified probability and trials.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<int> auto random_binomial_parameter(double prob, int trials) {
#else
  inline auto random_binomial_parameter(double prob, int trials) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<int>(r->gen.random_binomial(prob, trials));
    });
  }
  
  /** The `Parameter<bool>` computation that returns `true` in case of success. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<bool> auto random_true_parameter(double prob) {
#else
  inline auto random_true_parameter(double prob) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<bool>(r->gen.random_uniform(0.0, 1.0) <= prob);
    });
  }

  /** The `Parameter<bool>` computation that returns `false` in case of success. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<bool> auto random_false_parameter(double prob) {
#else
  inline auto random_false_parameter(double prob) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<bool>(r->gen.random_uniform(0.0, 1.0) > prob);
    });
  }

  /** The `Parameter<double>` computation that returns a new random number from the Gamma distribution. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_gamma_parameter(double kappa, double theta) {
#else
  inline auto random_gamma_parameter(double kappa, double theta) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_gamma(kappa, theta));
    });
  }

  /** The `Parameter<double>` computation that returns a new random number from the Beta distribution. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_beta_parameter(double alpha, double beta) {
#else
  inline auto random_beta_parameter(double alpha, double beta) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_beta(alpha, beta));
    });
  }

  /** The `Parameter<double>` computation that returns a new random number from the Weibull distribution. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ParameterLike<double> auto random_weibull_parameter(double alpha, double beta) {
#else
  inline auto random_weibull_parameter(double alpha, double beta) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<double>(r->gen.random_weibull(alpha, beta));
    });
  }

  /** The `Parameter<T>` computation that returns a new random value from the specified discrete distribution. */
  template<typename T>
#ifdef DVCOMPUTE_CONCEPTS
  ParameterLike<T> auto random_discrete_parameter(const SharedPtr<std::vector<std::pair<T, double>>>& dpdf) {
#else
  auto random_discrete_parameter(const SharedPtr<std::vector<std::pair<T, double>>>& dpdf) {
#endif
    return cons_parameter([=](const Run* r) {
      return Result<T>(r->gen.random_discrete(*dpdf));
    });
  }
}

#endif /* dvcompute_parameter_random_h */

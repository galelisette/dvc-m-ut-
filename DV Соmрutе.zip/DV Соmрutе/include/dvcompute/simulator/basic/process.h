/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_process_h
#define dvcompute_process_h

#include <functional>
#include <vector>
#include <exception>
#include <variant>
#include <stdexcept>
#include <string>
#include <optional>
#include <type_traits>

#include "../../dvcompute_ns.h"

#include "macros.h"
#include "types.h"
#include "specs.h"
#include "result.h"
#include "parameter.h"
#include "simulation.h"
#include "event.h"
#include "observable.h"
#include "ref.h"
#include "process_fn.h"
#include "process_id.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace process {

      // /** @private */
      // template<typename Item>
      // using BoxedContFn = std::function<Result<Unit>(Result<Item>&&,
      //   const ProcessIdPtr&,
      //   Point*)>;

      // /** @private */
      // template<typename Item>
      // using BoxedImpl = std::function<Result<Unit>(BoxedContFn<Item>&&,
      //   const ProcessIdPtr&,
      //   Point*)>;

      /** @private */
      template<typename ContFn>
      DVCOMPUTE_NOINLINE Result<Unit> revoke_process(ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        deactivate_process_cancelled(pid, p);
        return std::move(cont_fn)(CancelResult {}, pid, p);
      }

      /** @private */
      template<typename ContFn, typename Item>
      DVCOMPUTE_NOINLINE Result<Unit> error_process(ContFn&& cont_fn,
        Result<Item>&& item,
        const ProcessIdPtr& pid,
        const Point* p)
      {
        if (get_cancel_result_if(&item)) {
          return revoke_process(std::move(cont_fn), pid, p);
        } else if (auto e = get_retry_result_if(&item)) {
          return Result<Unit>(std::move(*e));
        } else {
          throw UnknownResult();
        }
      }

      /** @private */
      template<typename Item, typename ContFn>
      Result<Unit> resume_process(ContFn&& cont_fn,
        const ProcessIdPtr& pid,
        Item&& item,
        const Point* p)
      {
        if (pid->is_cancelled(p)) [[unlikely]] {
          return revoke_process(std::move(cont_fn), pid, p);
        } else {
          return std::move(cont_fn)(Result<Item>(std::move(item)), pid, p);
        }
      }

      /** @private */
      template<typename Item, typename ThenItem, typename Self, typename BindFn>
      class Then {

        Self comp;
        BindFn k;

      public:

        explicit Then(Self&& comp_arg, BindFn&& k_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(BindFn(std::move(k_arg)))) :
          comp(std::move(comp_arg)), k(std::move(k_arg))
        {}

        Then(Then<Item, ThenItem, Self, BindFn>&& other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(Then<Item, ThenItem, Self, BindFn>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Then(const Then<Item, ThenItem, Self, BindFn>& other) = default;
        Then<Item, ThenItem, Self, BindFn>& operator=(const Then<Item, ThenItem, Self, BindFn>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {

            auto fn = [k{std::move(k)}, cont_fn{std::move(cont_fn)}](Result<Item>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
              if (auto *i = get_result_if<Item>(&item)) [[likely]] {
                return k(std::move(*i))(std::move(cont_fn), pid, p);
              } else {
                return error_process(std::move(cont_fn), std::move(item), pid, p);
              }
            };

            return std::move(comp)(std::move(fn), pid, p);
          }
        }
      };

      /** @private */
      template<typename Item>
      class Return {

        Item item;

      public:

        explicit Return(const Item& item_arg) : item(item_arg) {}
        explicit Return(Item&& item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : item(std::move(item_arg)) {}

        Return(Return<Item>&& other) = default;
        Return<Item>& operator=(Return<Item>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Return(const Return<Item>& other) = default;
        Return<Item>& operator=(const Return<Item>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {
            return std::move(cont_fn)(Result<Item>(std::move(item)), pid, p);
          }
        }
      };

      /** @private */
      template<typename Fn>
      class LiftP {

        Fn fn;

      public:

        explicit LiftP(Fn&& fn_arg) noexcept(noexcept(Fn(std::move(fn_arg)))) : fn(std::move(fn_arg)) {}

        LiftP(LiftP<Fn>&& other) = default;
        LiftP<Fn>& operator=(LiftP<Fn>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        LiftP(const LiftP<Fn>& other) = default;
        LiftP<Fn>& operator=(const LiftP<Fn>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {
            return std::move(cont_fn)(std::move(fn)(p), pid, p);
          }
        }
      };

      /** @private */
      template<typename Fn>
      class LiftR {

        Fn fn;

      public:

        explicit LiftR(Fn&& fn_arg) noexcept(noexcept(Fn(std::move(fn_arg)))) : fn(std::move(fn_arg)) {}

        LiftR(LiftR<Fn>&& other) = default;
        LiftR<Fn>& operator=(LiftR<Fn>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        LiftR(const LiftR<Fn>& other) = default;
        LiftR<Fn>& operator=(const LiftR<Fn>& other) = default;

#endif

        template<typename ContFn>
        DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {
            return std::move(cont_fn)(std::move(fn)(p->run), pid, p);
          }
        }
      };

      /** @private */
      template<typename Item, typename Self, typename FinalItem, typename FinalImpl>
      class Finally {

        Self comp;
        FinalImpl final_comp;

      public:

        explicit Finally(Self&& comp_arg, FinalImpl&& final_comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg))) && noexcept(FinalImpl(std::move(final_comp_arg)))) :
          comp(std::move(comp_arg)), final_comp(std::move(final_comp_arg))
        {}

        Finally(Finally<Item, Self, FinalItem, FinalImpl>&& other) = default;
        Finally<Item, Self, FinalItem, FinalImpl>& operator=(Finally<Item, Self, FinalItem, FinalImpl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

        Finally(const Finally<Item, Self, FinalItem, FinalImpl>& other) = default;
        Finally<Item, Self, FinalItem, FinalImpl>& operator=(const Finally<Item, Self, FinalItem, FinalImpl>& other) = default;

#endif

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {

            auto fn = [final_comp{std::move(final_comp)}, cont_fn{std::move(cont_fn)}](Result<Item>&& item, const ProcessIdPtr& pid, const Point* p) mutable {
              auto fn = [cont_fn{std::move(cont_fn)}, item{std::move(item)}](Result<FinalItem>&& anything, const ProcessIdPtr& pid, const Point* p) mutable {

                if (get_result_if<FinalItem>(&anything)) [[likely]] {
                  return std::move(cont_fn)(std::move(item), pid, p);

                } else if (auto e2 = get_cancel_result_if(&anything)) {

                  if (get_result_if<Item>(&item)) {
                    return std::move(cont_fn)(std::move(*e2), pid, p);
                  } else if (auto e = get_retry_result_if(&item)) {
                    return std::move(cont_fn)(std::move(*e), pid, p);   // it has a priority
                  } else {
                    return std::move(cont_fn)(std::move(*e2), pid, p);
                  }

                } else if (auto e2 = get_retry_result_if(&anything)) {
                  return std::move(cont_fn)(std::move(*e2), pid, p);

                } else {
                  throw UnknownResult();
                }
              };

              return std::move(final_comp)(std::move(fn), pid, p);
            };

            return std::move(comp)(std::move(fn), pid, p);
          }
        }
      };

      /** @private */
      template<typename Self>
      class Transfer {

        Self comp;

      public:

        explicit Transfer(Self&& comp_arg)
          noexcept(noexcept(Self(std::move(comp_arg)))) :
          comp(std::move(comp_arg))
        {}

        Transfer(const Transfer<Self>& other) = default;
        Transfer(Transfer<Self>&& other) = default;

        Transfer<Self>& operator=(const Transfer<Self>& other) = default;
        Transfer<Self>& operator=(Transfer<Self>&& other) = default;

        template<typename ContFn>
        Result<Unit> operator()(ContFn&& cont_fn,
          const ProcessIdPtr& pid,
          const Point* p) &&
        {
          if (pid->is_cancelled(p)) [[unlikely]] {
            return revoke_process(std::move(cont_fn), pid, p);
          } else {

            auto fn = [](Result<Unit>&& item, const ProcessIdPtr& pid, const Point* p) {
              return Result<Unit>(std::move(item));
            };

            return std::move(comp)(std::move(fn), pid, p);
          }
        }
      };
    }
  }

  /** Represents a discontinuous process. */
  template<typename Item, typename Impl = internal::process::BoxedImpl<Item>>
  class Process;

#ifdef DVCOMPUTE_CONCEPTS

  namespace internal {

    namespace process {

      /** Whether `F` is a function that takes `Arg` and returns a `Process` computation. */
      template<typename F, typename Arg, typename Item>
      concept ProcessBindFn3 = std::is_invocable_r_v<Process<Item>, F, Arg&&>;

      /** Whether `F` is a function that takes `Arg` and returns a `Process` computation. */
      template<typename F, typename Arg>
      concept ProcessBindFn2 = requires {
        typename std::invoke_result_t<F, Arg&&>::item_type;
        requires ProcessBindFn3<F, Arg, typename std::invoke_result_t<F, Arg&&>::item_type>;
      };

      /** Whether `F` is a function that returns a `Process` computation. */
      template<typename F, typename Item>
      concept ProcessDelayFn2 = std::is_invocable_r_v<Process<Item>, F>;

      /** Whether `F` is a function that returns a `Process` computation. */
      template<typename F>
      concept ProcessDelayFn1 = requires {
        typename std::invoke_result_t<F>::item_type;
        requires ProcessDelayFn2<F, typename std::invoke_result_t<F>::item_type>;
      };
    }
  }

  /** Whether `Self` is actually a `Process<Item>` computation. */
  template<typename Self, typename Item>
  concept ProcessLike = std::is_convertible_v<Self, Process<Item>>;

  /** Whether `F` is a function that takes `Arg` and returns a `Process` computation. */
  template<typename F, typename Arg>
  concept ProcessBindFn = internal::process::ProcessBindFn2<F, Arg>;

  /** Whether `F` is a function that returns a `Process` computation. */
  template<typename F>
  concept ProcessDelayFn = internal::process::ProcessDelayFn1<F>;

#endif /* DVCOMPUTE_CONCEPTS */

  namespace internal {

    namespace process {

      template<typename Item, typename Impl>
      inline Impl&& move_impl(Process<Item, Impl>&& comp);
    }
  }

  /** Represents a discontinuous process. */
  template<typename Item, typename Impl>
  class Process {

    Impl impl;

    template<typename Item2, typename Impl2>
    friend inline Impl2&& internal::process::move_impl(Process<Item2, Impl2>&& comp);

  public:

    using item_type = Item;

    explicit Process(Impl &&impl_arg) noexcept(noexcept(Impl(std::move(impl_arg)))) : impl(std::move(impl_arg)) {}

    Process(Process<Item, Impl>&& other) = default;
    Process<Item, Impl>& operator=(Process<Item, Impl>&& other) = default;

#ifdef DVCOMPUTE_COPY_CTOR

    Process(const Process<Item, Impl>& other) = default;
    Process<Item, Impl>& operator=(const Process<Item, Impl>& other) = default;

    /** Copy the computation. */
    Process<Item, Impl> copy() const {
      return Process<Item, Impl>(*this);
    }

#endif

    /** @private */
    template<typename ContFn>
    DVCOMPUTE_ALWAYS_INLINE Result<Unit> operator()(ContFn&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) &&
    {
      return std::move(impl)(std::move(cont_fn), pid, p);
    }

    /**
     * Bind this with a continuation and return the resulting compound `Process<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Process<ThenItem>` computation.
     */
    template<typename BindFn>
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && requires ProcessBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto and_then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::process::Then<Item, ThenItem, Impl, BindFn>;
      return Process<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Bind this with a continuation and return the resulting compound `Process<ThenItem>`
     * computation, where `BindFn` is a function that takes an `Item` and then returns
     * an intermediate `Process<ThenItem>` computation.
     */
    template<typename BindFn>
    [[deprecated("Use the and_then method instead.")]]
#ifdef DVCOMPUTE_CONCEPTS
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && requires ProcessBindFn<BindFn, Item> {
#else
    DVCOMPUTE_ALWAYS_INLINE auto then(BindFn&& k) && {
#endif
      using ThenItem = typename std::invoke_result_t<BindFn, Item&&>::item_type;
      using ThenImpl = internal::process::Then<Item, ThenItem, Impl, BindFn>;
      return Process<ThenItem, ThenImpl>(ThenImpl(std::move(impl), std::move(k)));
    }

    /**
     * Map the computed value and return the resulting compound `Process<MapItem>`
     * computation, where `MapFn` is a function that takes an `Item` and then transforms it
     * to `MapItem`.
     */
    template<typename MapFn>
    DVCOMPUTE_ALWAYS_INLINE auto map(MapFn&& f) && {
      return std::move(*this).and_then([f{std::move(f)}](Item&& item) mutable {
        using MapItem = std::invoke_result_t<MapFn, Item&&>;
        using MapImpl = internal::process::Return<MapItem>;
        return Process<MapItem, MapImpl>(MapImpl(f(std::move(item))));
      });
    }

    /** Convert this to a boxed representation. */
    Process<Item> into_boxed() && {
      using ResultImpl = internal::process::BoxedImpl<Item>;
      return Process<Item>(ResultImpl(std::move(impl)));
    }

    /** Convert this to a boxed representation. */
    operator Process<Item>() && {
      using ResultImpl = internal::process::BoxedImpl<Item>;
      return Process<Item>(ResultImpl(std::move(impl)));
    }
  };

  namespace internal {

    namespace process {

      /** @private */
      template<typename Item, typename Impl>
      inline Impl&& move_impl(Process<Item, Impl>&& comp) {
        return std::move(comp.impl);
      }
    }
  }

  /** Create a new process identifier within `Simulation<ProcessIdPtr>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline SimulationLike<ProcessIdPtr> auto new_process_id() {
#else
  inline auto new_process_id() {
#endif
    auto fn = [](const Run* r) {
      return internal::process::new_process_id_by_run(r);
    };
    return Simulation<ProcessIdPtr, decltype(fn)>(std::move(fn));
  }

  /** Return the process identifier within `Process<ProcessIdPtr>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<ProcessIdPtr> auto process_id() {
#else
  inline auto process_id() {
#endif
    auto impl = [](internal::process::BoxedContFn<ProcessIdPtr>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      return std::move(cont_fn)(Result<ProcessIdPtr>(pid), pid, p);
    };
    return Process<ProcessIdPtr, decltype(impl)>(std::move(impl));
  }

  /** Run the process by using the specified process identifier within `Event<Unit>` computation. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto run_process_using_id(const ProcessIdPtr& pid, Process<Unit, Impl>&& comp) {
#else
  auto run_process_using_id(const ProcessIdPtr& pid, Process<Unit, Impl>&& comp) {
#endif
    auto impl = [comp{std::move(comp)}, pid{pid}](const Point *p) mutable {
      auto res0 { internal::process::prepare_process_at(pid, p) };
      if (get_result_if<Unit>(&res0)) [[likely]] {
        auto cont_fn = [](Result<Unit>&& unit, const ProcessIdPtr&, const Point*) {
          return Result<Unit>(std::move(unit));
        };
        return std::move(comp)(std::move(cont_fn), pid, p);
      } else {
        return error_result<Unit>(std::move(res0));
      }
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /** Run the process within `Event<Unit>` computation. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  EventLike<Unit> auto run_process(Process<Unit, Impl>&& comp) {
#else
  auto run_process(Process<Unit, Impl>&& comp) {
#endif
    return into_event(new_process_id()).and_then([comp{std::move(comp)}](ProcessIdPtr&& pid) mutable {
        return run_process_using_id(pid, std::move(comp));
      });
  }

  /** Create a `Process<Item>` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Item> auto pure_process(const Item& item) {
#else
  inline auto pure_process(const Item& item) {
#endif
    using ResultImpl = internal::process::Return<Item>;
    return Process<Item, ResultImpl>(ResultImpl(item));
  }

  /** Create a `Process<Item>` computation by the specified pure value. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Item> auto pure_process(Item&& item) {
#else
  inline auto pure_process(Item&& item) {
#endif
    using ResultImpl = internal::process::Return<Item>;
    return Process<Item, ResultImpl>(ResultImpl(std::move(item)));
  }

  /**
   * Delay the `Process` computation and return the resulting compound `Process<Item>`
   * computation, where `DelayFn` is a function that returns an intermediate `Process`
   * computation, but `Item == std::invoke_result_t<DelayFn>::item_type`.
   */
  template<typename DelayFn>
#ifdef DVCOMPUTE_CONCEPTS
  auto delay_process(DelayFn&& f) requires ProcessDelayFn<DelayFn> {
#else
  auto delay_process(DelayFn&& f) {
#endif
    return pure_process(Unit()).and_then([f{std::move(f)}](Unit&& unit) mutable {
      return f();
    });
  }

  /** Convert the specified computation to `Process<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Item> auto into_process(Process<Item, Impl>&& from) {
#else
  inline auto into_process(Process<Item, Impl>&& from) {
#endif
    return std::move(from);
  }

  /** Convert the specified computation to `Process<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Item> auto into_process(Event<Item, Impl>&& from) {
#else
  inline auto into_process(Event<Item, Impl>&& from) {
#endif
    using ResultImpl = internal::process::LiftP<Impl>;
    return Process<Item, ResultImpl>(ResultImpl(internal::event::move_impl(std::move(from))));
  }

  /** Convert the specified computation to `Process<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Item> auto into_process(Simulation<Item, Impl>&& from) {
#else
  inline auto into_process(Simulation<Item, Impl>&& from) {
#endif
    using ResultImpl = internal::process::LiftR<Impl>;
    return Process<Item, ResultImpl>(ResultImpl(internal::simulation::move_impl(std::move(from))));
  }

  /** Convert the specified computation to `Process<Item>`. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Item> auto into_process(Parameter<Item, Impl>&& from) {
#else
  inline auto into_process(Parameter<Item, Impl>&& from) {
#endif
    using ResultImpl = internal::process::LiftR<Impl>;
    return Process<Item, ResultImpl>(ResultImpl(internal::parameter::move_impl(std::move(from))));
  }

  /** The `Process<Item>` computation that never finishes. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Item> auto never_process() {
#else
  auto never_process() {
#endif
    auto impl = [](internal::process::BoxedContFn<Item>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      return Result<Unit>(Unit());
    };
    return Process<Item, decltype(impl)>(std::move(impl));
  }

  /** Cancel the process by the specified identifier within `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto cancel_process_by_id(const ProcessIdPtr& pid) {
#else
  inline auto cancel_process_by_id(const ProcessIdPtr& pid) {
#endif
    return cons_event([=](const Point* p) {
      return internal::process::cancel_process_at(pid, p);
    });
  }

  /** Cancel the current `Process<Item>` computation. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Item> auto cancel_process() {
#else
  auto cancel_process() {
#endif
    auto impl = [](internal::process::BoxedContFn<Item>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      Result<Unit> r = internal::process::cancel_process_at(pid, p);
      if (get_result_if<Unit>(&r)) {
        if (pid->is_cancelled(p)) {
          return internal::process::revoke_process(std::move(cont_fn), pid, p);
        } else {
          return Result<Unit>(Unit());
        }
      } else {
        return r;
      }
    };
    return Process<Item, decltype(impl)>(std::move(impl));
  }

  /** Signal within `Observable<ProcessEvent>` when the process state changes. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ObservableLike<ProcessEvent> auto process_observable(const ProcessIdPtr &pid) {
#else
  inline auto process_observable(const ProcessIdPtr &pid) {
#endif
    return pid->observable();
  };

  /** Signal within `Observable<Unit>` when the process cancellation is initiated. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ObservableLike<Unit> auto process_cancel_initiating(const ProcessIdPtr &pid) {
#else
  inline auto process_cancel_initiating(const ProcessIdPtr &pid) {
#endif
    return pid->cancel_initiating();
  };

  /** Signal within `Observable<Unit>` when the process is preempted. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ObservableLike<Unit> auto process_preemption_initiating(const ProcessIdPtr &pid) {
#else
  inline auto process_preemption_initiating(const ProcessIdPtr &pid) {
#endif
    return pid->preemption_initiating();
  }

  /** Signal within `Observable<Unit>` when the process is proceeded after it was preempted. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ObservableLike<Unit> auto process_preemption_ending(const ProcessIdPtr &pid) {
#else
  inline auto process_preemption_ending(const ProcessIdPtr &pid) {
#endif
    return pid->preemption_ending();
  }

  /** Preempt the process by the specified identifier within `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto begin_process_preemption(const ProcessIdPtr& pid) {
#else
  inline auto begin_process_preemption(const ProcessIdPtr& pid) {
#endif
    return cons_event([=](const Point* p) {
      return internal::process::begin_process_preemption_at(pid, p);
    });
  }

  /** Proceed within `Event<Unit>` computation with the process after it was preempted before. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto end_process_preemption(const ProcessIdPtr& pid) {
#else
  inline auto end_process_preemption(const ProcessIdPtr& pid) {
#endif
    return cons_event([=](const Point* p) {
      return internal::process::end_process_preemption_at(pid, p);
    });
  }

  /** Whether the process specified by its identifier is preempted? Return the result within `Event<bool>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<bool> auto is_process_preempted(const ProcessIdPtr& pid) {
#else
  inline auto is_process_preempted(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      return Result<bool>(internal::process::is_process_preempted_at(pid, p));
    };
    return Event<bool, decltype(impl)>(std::move(impl));
  }

  /** Hold the corresponding process for the specified time interval within `Process<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto hold_process(double dt) {
#else
  inline auto hold_process(double dt) {
#endif
    auto impl = [dt](internal::process::BoxedContFn<Unit>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      internal::process::hold_process_at(dt, std::move(cont_fn), pid, p);
      return Result<Unit>(Unit());
    };
    return Process<Unit, decltype(impl)>(std::move(impl));
  }

  /** Interrupt the process if it is held by computation `hold_process`. Return the `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto interrupt_process(const ProcessIdPtr& pid) {
#else
  inline auto interrupt_process(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      internal::process::interrupt_process_at(pid, p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /** Whether the process specified by its identifier is interrupted? Return the result within `Event<bool>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<bool> auto is_process_interrupted(const ProcessIdPtr& pid) {
#else
  inline auto is_process_interrupted(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      return Result<bool>(internal::process::is_process_interrupted_at(pid, p));
    };
    return Event<bool, decltype(impl)>(std::move(impl));
  }

  /**
   * Return the expected interruption time of finishing the `hold_process` computation,
   * which value may change if the corresponding process is preempted.
   * This is the `Event<std::optional<double>>` computation.
   */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<std::optional<double>> auto process_interruption_time(const ProcessIdPtr& pid) {
#else
  inline auto process_interruption_time(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      return Result<std::optional<double>>(internal::process::process_interruption_time_at(pid, p));
    };
    return Event<std::optional<double>, decltype(impl)>(std::move(impl));
  }

  /** Passivate the current process within `Process<Unit>` computation util another activity will reactivate it. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto passivate_process() {
#else
  inline auto passivate_process() {
#endif
    auto impl = [](internal::process::BoxedContFn<Unit>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      return internal::process::passivate_process_at(std::move(cont_fn), pid, p);
    };
    return Process<Unit, decltype(impl)>(std::move(impl));
  }

  /**
   * Passivate the current process within `Process<Unit>` computation util another activity will reactivate it,
   * but before passiviting the process it performs the specified `Event<Unit>` action.
   */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Unit> auto passivate_process_before(Event<Unit, Impl>&& comp) {
#else
  auto passivate_process_before(Event<Unit, Impl>&& comp) {
#endif
    auto impl = [comp{std::move(comp)}](internal::process::BoxedContFn<Unit>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      return internal::process::passivate_process_before_at(internal::event::move_impl(std::move(comp)), std::move(cont_fn), pid, p);
    };
    return Process<Unit, decltype(impl)>(std::move(impl));
  }

  /** Whether the process specified by its identifier is passivated? Return the result within `Event<bool>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<bool> auto is_process_passivated(const ProcessIdPtr& pid) {
#else
  inline auto is_process_passivated(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      return Result<bool>(internal::process::is_process_passivated_at(pid, p));
    };
    return Event<bool, decltype(impl)>(std::move(impl));
  }

  /** Reactivate the process within `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto reactivate_process(const ProcessIdPtr& pid) {
#else
  inline auto reactivate_process(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      internal::process::reactivate_process_at(pid, p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /** Reactivate the process immediately within `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto reactivate_process_immediately(const ProcessIdPtr& pid) {
#else
  inline auto reactivate_process_immediately(const ProcessIdPtr& pid) {
#endif
    auto impl = [pid](const Point *p) {
      return internal::process::reactivate_process_immediately_at(pid, p);
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /** Reactivate the processes immediately within `Event<Unit>` computation. */
#ifdef DVCOMPUTE_CONCEPTS
  inline EventLike<Unit> auto reactivate_processes_immediately(std::vector<ProcessIdPtr>&& pids) {
#else
  inline auto reactivate_processes_immediately(std::vector<ProcessIdPtr>&& pids) {
#endif
    auto impl = [pids{std::move(pids)}](const Point *p) mutable {
      return internal::process::reactivate_processes_immediately_at(std::move(pids), p);
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /** Proceed with the `Process<Unit>` computation with the specified priority. */
#ifdef DVCOMPUTE_CONCEPTS
  inline ProcessLike<Unit> auto process_with_priority(int priority) {
#else
  inline auto process_with_priority(int priority) {
#endif
    auto impl = [priority](internal::process::BoxedContFn<Unit>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      return internal::process::process_with_priority(priority, std::move(cont_fn), pid, p);
    };
    return Process<Unit, decltype(impl)>(std::move(impl));
  }

  /** Wrap the `Process<Item>` computation so that it would restore its priority. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Item> auto restore_process_priority(int priority, Process<Item, Impl>&& comp) {
#else
  auto restore_process_priority(int priority, Process<Item, Impl>&& comp) {
#endif
    return process_with_priority(priority)
      .and_then([comp{std::move(comp)}](Unit&& unit) mutable {
        return Process<Item, Impl>(std::move(comp));
      });
  }

  /** Spawn the specified child `Process` within the current `Process<Unit>` computation. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Unit> auto spawn_process_using_id_with(ProcessCancellation cancellation, const ProcessIdPtr& child_pid, Process<Unit, Impl>&& child) {
#else
  auto spawn_process_using_id_with(ProcessCancellation cancellation, const ProcessIdPtr& child_pid, Process<Unit, Impl>&& child) {
#endif
    auto impl = [cancellation, child{std::move(child)}, child_pid](internal::process::BoxedContFn<Unit>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      return internal::process::spawn_process(std::move(cont_fn), pid, cancellation, child_pid, internal::process::move_impl(std::move(child)), p);
    };
    return Process<Unit, decltype(impl)>(std::move(impl));
  }

  /** Spawn the specified child `Process` within the current `Process<Unit>` computation. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Unit> auto spawn_process_with(ProcessCancellation cancellation, Process<Unit, Impl>&& child) {
#else
  auto spawn_process_with(ProcessCancellation cancellation, Process<Unit, Impl>&& child) {
#endif
    return into_process(new_process_id())
      .and_then([cancellation, child{std::move(child)}](ProcessIdPtr&& child_pid) mutable {
        return spawn_process_using_id_with(cancellation, child_pid, std::move(child));
      });
  }

  /** Spawn the specified child `Process` within the current `Process<Unit>` computation. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Unit> auto spawn_process_using_id(const ProcessIdPtr& child_pid, Process<Unit, Impl>&& child) {
#else
  auto spawn_process_using_id(const ProcessIdPtr& child_pid, Process<Unit, Impl>&& child) {
#endif
    return spawn_process_using_id_with(ProcessCancellation::CancelTogether, child_pid, std::move(child));
  }

  /** Spawn the specified child `Process` within the current `Process<Unit>` computation. */
  template<typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Unit> auto spawn_process(Process<Unit, Impl>&& child) {
#else
  auto spawn_process(Process<Unit, Impl>&& child) {
#endif
    return spawn_process_with(ProcessCancellation::CancelTogether, std::move(child));
  }

  /** Transfer the control flow to the specified process within `Process<Item>` computation. */
  template<typename Item, typename Impl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Item> auto transfer_process(Process<Unit, Impl>&& comp) {
#else
  auto transfer_process(Process<Unit, Impl>&& comp) {
#endif
    using ResultImpl = internal::process::Transfer<Impl>;
    return Process<Item, ResultImpl>(ResultImpl(internal::process::move_impl(std::move(comp))));
  }

  /** Call the specified finalization block within the resulting compound `Process<Item>` computation. */
  template<typename Item, typename Impl, typename FinalItem, typename FinalImpl>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Item> auto finally_process(Process<Item, Impl>&& comp, Process<FinalItem, FinalImpl>&& final_comp) {
#else
  auto finally_process(Process<Item, Impl>&& comp, Process<FinalItem, FinalImpl>&& final_comp) {
#endif
    using ResultImpl = internal::process::Finally<Item, Impl, FinalItem, FinalImpl>;
    return Process<Item, ResultImpl>(ResultImpl(internal::process::move_impl(std::move(comp)), internal::process::move_impl(std::move(final_comp))));
  }

  /** Embeds the result value within `Process<Item>`, which may lead to canceling the process, for example. */
  template<typename Item>
#ifdef DVCOMPUTE_CONCEPTS
  ProcessLike<Item> auto embed_result_process(Result<Item> &&item) {
#else
  auto embed_result_process(Result<Item> &&item) {
#endif
    auto impl = [item{std::move(item)}](internal::process::BoxedContFn<Item>&& cont_fn,
      const ProcessIdPtr &pid,
      const Point *p) mutable
    {
      if (pid->is_cancelled(p)) [[unlikely]] {
        return revoke_process(std::move(cont_fn), pid, p);
        
      } else {
        if (get_result_if<Item>(&item)) {
          return std::move(cont_fn)(std::move(item), pid, p);

        } else if (get_cancel_result_if(&item)) {
          return cancel_process<Item>()(std::move(cont_fn), pid, p);

        } else {
          return error_process(std::move(cont_fn), std::move(item), pid, p);
        }
      }
    };
    return Process<Item, decltype(impl)>(std::move(impl));
  }
}

#endif /* dvcompute_process_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_command_h
#define dvcompute_command_h

#include <memory>

#include "../../dvcompute_ns.h"
#include "../../dvcompute_api.h"
#include "../basic/simulation.h"
#include "../basic/observable.h"

namespace DVCOMPUTE_NS {

  /** The basic class for representing commands. */
  class DVCOMPUTE_API Command {
  public:
    virtual ~Command() {}
  };

  /** The command sender that accepts commands for executing. */
  class DVCOMPUTE_API CommandSender {
  public:
    virtual ~CommandSender() {}

    /** Send the specified command to be executed within simulation. */
    virtual void send(const std::shared_ptr<Command> &cmd) = 0;
  };

  /** Return the command sender related to the current simulation run. */
  DVCOMPUTE_API Simulation<std::shared_ptr<CommandSender>> simulation_command_sender();

  /** Return the signal that notifies about received commands within simulation. */
  DVCOMPUTE_API Observable<std::shared_ptr<Command>> input_commands();
}

#endif /* dvcompute_command_h */

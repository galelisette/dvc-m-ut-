/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_branch_branch_h
#define dvcompute_branch_branch_h

#include <memory>
#include <vector>
#include <tuple>

#include "dvcompute/dvcompute_ns.h"
#include "../basic/parameter.h"
#include "../basic/event.h"
#include "../basic/log_support.h"
#include "specs.h"

namespace DVCOMPUTE_NS {

  /** 
   * Return the current nested level within `Parameter<int>` computation, 
   * which is started from zero for the root computation and then increased by one
   * for each next nested computation.
   */
  inline auto branch_level() {
    auto fn = [](const Run* r) {
      Branch *branch = r->branch.get();
      return branch ? branch->level : 0;
    };
    return Parameter<int, decltype(fn)>(std::move(fn));
  }

  /** 
   * Branch a new nested computation and return its result within the current 
   * `Event<Item>` by leaving the current computation intact.
   *
   * A new derivative branch with `branch_level` increased by 1 is created at 
   * the current modeling time. Then the result of the specified computation for 
   * derivative branch is returned to the current computation.
   *
   * The state of the current computation including its event queue and mutable 
   * references `Ref` remain intact. In some sense we copy the state of the model 
   * to derivative branch and then proceed with the derived simulation. 
   * Only this copying operation is relatively cheap.
   */
  template<typename Item, typename Impl>
  auto branch_event(Event<Item, Impl>&& comp) {
    auto fn = [comp{std::move(comp)}](const Point* p) mutable {
      std::unique_ptr<Run> r { new Run(*(p->run)) };
      Point p2 { r.get(), p->time, p->priority };
      return std::move(comp)(&p2);
    };
    return Event<Item, decltype(fn)>(std::move(fn));
  }

  /** 
   * Branch a new nested computation and return its result at the desired 
   * time of the future within the current `Event<Item>` by leaving 
   * the current computation intact.
   *
   * A new derivative branch with `branch_level` increased by 1 is created at 
   * the current modeling time. Then the result of the specified computation for 
   * derivative branch is returned to the current computation.
   *
   * The state of the current computation including its event queue and mutable 
   * references `Ref` remain intact. In some sense we copy the state of the model 
   * to derivative branch and then proceed with the derived simulation. 
   * Only this copying operation is relatively cheap.
   */
  template<typename Item, typename Impl>
  auto future_event(double event_time, Event<Item, Impl>&& comp, bool including_current = true) {
    auto fn = [event_time, comp{std::move(comp)}, including_current](const Point* p) mutable {
      if (event_time < p->time) {
        DVCOMPUTELOG_NS::error("t={}: The event time (= {}) cannot be less than the current modeling time",
          p->time, event_time);
        throw SimulationAbort();
      }
      std::unique_ptr<Run> r { new Run(*(p->run)) };
      Point p2 { r.get(), event_time, p->priority };
      internal::event::run_events(including_current, &p2);
      return std::move(comp)(&p2);
    };
    return Event<Item, decltype(fn)>(std::move(fn));
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /** 
   * Branch a new nested computation and return its result at the desired 
   * time of the future within the current `Event<Item>` by leaving 
   * the current computation intact.
   *
   * A new derivative branch with `branch_level` increased by 1 is created at 
   * the current modeling time. Then the result of the specified computation for 
   * derivative branch is returned to the current computation.
   *
   * The state of the current computation including its event queue and mutable 
   * references `Ref` remain intact. In some sense we copy the state of the model 
   * to derivative branch and then proceed with the derived simulation. 
   * Only this copying operation is relatively cheap.
   *
   * The priority parameter specifies which event handlers should be actuated
   * in the derived simulation.
   */
  template<typename Item, typename Impl>
  auto future_event_with_priority(double event_time, int priority, Event<Item, Impl>&& comp, bool including_current = true) {
    auto fn = [event_time, priority, comp{std::move(comp)}, including_current](const Point* p) mutable {
      if (event_time < p->time) {
        DVCOMPUTELOG_NS::error("t={}: The event time (= {}) cannot be less than the current modeling time",
          p->time, event_time);
        throw SimulationAbort();
      }
      std::unique_ptr<Run> r { new Run(*(p->run)) };
      Point p2 { r.get(), event_time, p->priority };
      internal::event::run_events_with_priority(including_current, priority, &p2);
      return std::move(comp)(&p2);
    };
    return Event<Item, decltype(fn)>(std::move(fn));
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

}

#endif /* dvcompute_branch_branch_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_branch_forecast_h
#define dvcompute_branch_forecast_h

#include "dvcompute/dvcompute_ns.h"
#include "branch.h"

namespace DVCOMPUTE_NS {

  /**
   * Forecast the average value of computation by binary branching 
   * nested simulations provided the specified time step (delta) is defined.
   */
  template<typename Impl>
  Event<double> binary_forecast_by_dt(Event<double, Impl>&& comp, double time_dt) {
    return cons_event([comp{std::move(comp)}, time_dt](const Point* p) mutable {
      if (p->time >= p->run->specs->stop_time) {
        return std::move(comp)(p);
      } else {
        double t = p->time;
        return future_event(t + time_dt, binary_forecast_by_dt(comp.copy(), time_dt))
          .and_then([comp{std::move(comp)}, time_dt, t](double x1) mutable {
            return future_event(t + time_dt, binary_forecast_by_dt(std::move(comp), time_dt))
              .map([x1](double x2) {
                return (x1 + x2) / 2.0;
              });
          })(p);
      }
    }).operator Event<double>();
  }

  /**
   * Forecast the average value of computation by binary branching 
   * nested simulations provided the specified branching depth is defined.
   */
  template<typename Impl>
  Event<double> binary_forecast_by_depth(Event<double, Impl>&& comp, unsigned int branching_depth) {
    return cons_event([comp{std::move(comp)}, branching_depth](const Point* p) mutable {
      double time_dt = (p->run->specs->stop_time - p->time) / branching_depth;
      return binary_forecast_by_dt(std::move(comp), time_dt)(p);
    }).operator Event<double>();
  }
}

#endif /* dvcompute_branch_forecast_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_branch_ref_h
#define dvcompute_branch_ref_h

#include <type_traits>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"
#include "dvcompute/simulator/basic/specs.h"
#include "dvcompute/simulator/basic/event.h"
#include "dvcompute/simulator/utils/ordered_int_map.h"

namespace DVCOMPUTE_NS {

#ifdef DVCOMPUTE_CONCEPTS

  /** Whether `F` is a function that takes the `Item` and returns a new `Item`. */
  template<typename Fn, typename Item>
  concept RefModifyFn = std::is_invocable_r_v<Item, Fn, Item>;

#endif /* DVCOMPUTE_CONCEPTS */

  /** A mutable cell synchronized with the event queue. */
  template<typename Item>
  class Ref {

    /// The initial item.
    Item init_item;

    /// The items to store.
    StrongPtr2Alloc<utils::im::OrderedIntMap<int, StrongPtr<Item>>> items;

  public:

    explicit Ref(const Item &item_arg) : init_item(item_arg) {}
    explicit Ref(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : init_item(std::move(item_arg)) {}

    Ref(const Ref<Item> &) = delete;
    Ref<Item>& operator=(const Ref<Item> &) = delete;

    Ref(Ref<Item> &&) = default;
    Ref<Item>& operator=(Ref<Item> &&) = default;

    /** Read the contents of the mutable cell at the specified time point. */
    Item& read_at(const Point *p) { return *get_at(p); }

    /** Read the contents of the mutable cell at the specified time point. */
    const Item& read_at(const Point *p) const { return *get_at(p); }

    /** Swap the contents of the mutable cell at the specified time point. */
    Item swap_at(Item&& value, const Point *p) {
      Item tmp { std::move(read_at(p)) };
      write_at(std::move(value), p);
      return tmp;
    }

    /** Write into the contents of the mutable cell at the specified time point. */
    void write_at(Item&& value, const Point *p) {
      *get_at(p) = std::move(value);
    }

    /** Modify the contents of the mutable cell at the specified time point. */
    template<typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
    void modify_at(Fn&& fn, const Point *p) requires RefModifyFn<Fn, Item> {
#else
    void modify_at(Fn&& fn, const Point *p) {
#endif
      write_at(fn(read_at(p)), p);
    }

    /** Compare for equality. */
    bool operator==(const Ref& other) const noexcept {
      return items.get() == other.items.get();
    }

    /** Compare for inequality. */
    bool operator!=(const Ref& other) const noexcept {
      return !(*this == other);
    }

  private:

    /** @hidden */
    const Item* get_at(const Point *p) const {
      Branch* branch = p->run->branch.get();

      if (branch == nullptr) {
        return &init_item;

      } else {
        while (true) {
          if (branch == nullptr) {
            return &init_item;

          } else if (!items) {
            return &init_item;

          } else {
            auto it = items->find(branch->id);
            if (it != items->end()) {
              return it.value().get();

            } else {
              branch = branch->parent.get();
            }
          }
        }
      }
    }

    /** @hidden */
    Item* get_at(const Point *p) {
      Branch* branch = p->run->branch.get();

      if (branch == nullptr) {
        return &init_item;

      } else {
        Branch* branch0 = branch;

        while (true) {
          if (branch == nullptr) {
            return create_at(branch0->id, init_item, p);

          } else if (!items) {
            return create_at(branch0->id, init_item, p);

          } else {
            auto it = items->find(branch->id);
            if (it != items->end()) {

              if (branch0 == branch) {
                return it.value().get();

              } else {
                return create_at(branch0->id, *it.value(), p);
              }

            } else {
              branch = branch->parent.get();
            }
          }
        }
      }
    }

    /** @hidden */
    Item* create_at(int id, const Item& prev_item, const Point* p) {
      StrongPtr<Item> item { mk_strong(prev_item) };
      Item* ptr = item.get();
      if (!items) {
        items.reset(new utils::im::OrderedIntMap<int, StrongPtr<Item>>());
      }
      *items = items->emplace(id, std::move(item));
      p->run->finalizers.emplace_back([items{items}, id]() { 
        *items = items->erase(id);
      });

      return ptr;
    }
  };

  /** The shared reference of the mutable cell synchronized with the event queue. */
  template<typename Item>
    using RefPtr = SharedPtr<Ref<Item>>;

  /**
   * Read the contents of the mutable cell and return the corresponding
   * `Event<Item>` computation.
   */
  template<typename Item>
  inline auto read_ref(const RefPtr<Item>& r) {
    auto impl = [r](const Point *p) {
      return Result<Item>(r->read_at(p));
    };
    return Event<Item, decltype(impl)>(std::move(impl));
  }

  /**
   * Swap the contents of the mutable cell and return the corresponding
   * `Event<Item>` computation.
   */
  template<typename Item>
  inline auto swap_ref(const RefPtr<Item>& r, Item&& value) {
    auto impl = [r, value{std::move(value)}](const Point *p) mutable {
      return Result<Item>(r->swap_at(std::move(value), p));
    };
    return Event<Item, decltype(impl)>(std::move(impl));
  }

  /**
   * Write the contents of the mutable cell within `Event<Unit>` computation.
   */
  template<typename Item>
  inline auto write_ref(const RefPtr<Item>& r, Item&& value) {
    auto impl = [r, value{std::move(value)}](const Point *p) mutable {
      r->write_at(std::move(value), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /**
   * Modify the contents of the mutable cell within `Event<Unit>` computation.
   */
  template<typename Item, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto modify_ref(const RefPtr<Item>& r, Fn&& fn) requires RefModifyFn<Fn, Item> {
#else
  inline auto modify_ref(const RefPtr<Item>& r, Fn&& fn) {
#endif
    auto impl = [r, fn{std::move(fn)}](const Point *p) mutable {
      r->modify_at(std::move(fn), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }
}

#endif /* dvcompute_branch_ref_h */

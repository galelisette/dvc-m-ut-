/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_seq_ref_h
#define dvcompute_seq_ref_h

#include <type_traits>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"
#include "dvcompute/simulator/basic/specs.h"
#include "dvcompute/simulator/basic/event.h"

namespace DVCOMPUTE_NS {

#ifdef DVCOMPUTE_CONCEPTS

  /** Whether `F` is a function that takes the `Item` and returns a new `Item`. */
  template<typename Fn, typename Item>
  concept RefModifyFn = std::is_invocable_r_v<Item, Fn, Item>;

#endif /* DVCOMPUTE_CONCEPTS */

  /** A mutable cell synchronized with the event queue. */
  template<typename Item>
  class Ref {

    /// The item to store.
    Item item;

  public:

    explicit Ref(const Item &item_arg): item(item_arg) {}
    explicit Ref(Item &&item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : item(std::move(item_arg)) {}

    Ref(const Ref<Item> &) = delete;
    Ref<Item>& operator=(const Ref<Item> &) = delete;

    Ref(Ref<Item> &&) = default;
    Ref<Item>& operator=(Ref<Item> &&) = default;

    /** Read the contents of the mutable cell at the specified time point. */
    Item& read_at(const Point *p) { return item; }

    /** Read the contents of the mutable cell at the specified time point. */
    const Item& read_at(const Point *p) const { return item; }

    // /** Swap the contents of the mutable cell at the specified time point. */
    // Item swap_at(const Item &value, const Point *p) {
    //   Item tmp = item;
    //   item = value;
    //   return tmp;
    // }

    /** Swap the contents of the mutable cell at the specified time point. */
    Item swap_at(Item&& value, const Point *p) {
      Item tmp { std::move(item) };
      item = std::move(value);
      return tmp;
    }

    // /** Write into the contents of the mutable cell at the specified time point. */
    // void write_at(const Item &value, const Point *p) {
    //   item = value;
    // }

    /** Write into the contents of the mutable cell at the specified time point. */
    void write_at(Item&& value, const Point *p) {
      item = std::move(value);
    }

    /** Modify the contents of the mutable cell at the specified time point. */
    template<typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
    void modify_at(Fn&& fn, const Point *p) requires RefModifyFn<Fn, Item> {
#else
    void modify_at(Fn&& fn, const Point *p) {
#endif
      item = fn(std::move(item));
    }

    /** Compare for equality. */
    bool operator==(const Ref& other) const noexcept {
      return &item == &other.item;
    }

    /** Compare for inequality. */
    bool operator!=(const Ref& other) const noexcept {
      return !(*this == other);
    }
  };

  /** The shared reference of the mutable cell synchronized with the event queue. */
  template<typename Item>
    using RefPtr = SharedPtr<Ref<Item>>;

  /**
   * Read the contents of the mutable cell and return the corresponding
   * `Event<Item>` computation.
   */
  template<typename Item>
  inline auto read_ref(const RefPtr<Item>& r) {
    auto impl = [r](const Point *p) {
      return Result<Item>(r->read_at(p));
    };
    return Event<Item, decltype(impl)>(std::move(impl));
  }

  /**
   * Swap the contents of the mutable cell and return the corresponding
   * `Event<Item>` computation.
   */
  template<typename Item>
  inline auto swap_ref(const RefPtr<Item>& r, Item&& value) {
    auto impl = [r, value{std::move(value)}](const Point *p) mutable {
      return Result<Item>(r->swap_at(std::move(value), p));
    };
    return Event<Item, decltype(impl)>(std::move(impl));
  }

  /**
   * Write the contents of the mutable cell within `Event<Unit>` computation.
   */
  template<typename Item>
  inline auto write_ref(const RefPtr<Item>& r, Item&& value) {
    auto impl = [r, value{std::move(value)}](const Point *p) mutable {
      r->write_at(std::move(value), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }

  /**
   * Modify the contents of the mutable cell within `Event<Unit>` computation.
   */
  template<typename Item, typename Fn>
#ifdef DVCOMPUTE_CONCEPTS
  inline auto modify_ref(const RefPtr<Item>& r, Fn&& fn) requires RefModifyFn<Fn, Item> {
#else
  inline auto modify_ref(const RefPtr<Item>& r, Fn&& fn) {
#endif
    auto impl = [r, fn{std::move(fn)}](const Point *p) mutable {
      r->modify_at(std::move(fn), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(impl)>(std::move(impl));
  }
}

#endif /* dvcompute_seq_ref_h */

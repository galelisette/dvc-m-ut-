/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_utils_html_h
#define dvcompute_utils_html_h

#include <iostream>
#include <string>
#include <variant>

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  namespace utils {

    namespace html {

      namespace {

        /** Escape the character. */
        inline std::variant<char, std::string> escape_char(char c) {
          switch (c) {
            case '<' : 
              return std::string("&lt;");

            case '>' :
              return std::string("&gt;");

            case '&' :
              return std::string("&amp;");

            case '"' :
              return std::string("&quot;");

            case '\'' :
              return std::string("&#39;");

            default:
              return c;
          }
        }

        /** Escape the text. */
        inline std::string escape_text(const char* s) {
          std::string res;
          if (s != nullptr) {
            for (char c = *s; c != '\0'; c = *(++s)) {
              auto x { escape_char(c) };
              if (char *c2 = std::get_if<char>(&x)) {
                res += *c2;
              } else if (std::string *s2 = std::get_if<std::string>(&x)) {
                res += *s2;
              }
            }
          }
          return res;
        }

        /** Encode the character. */
        inline std::variant<char, std::string> encode_char(char c) {
          switch (c) {
            case ' ' : 
              return std::string("%20");

            default:
              return c;
          }
        }

        /** Encode the text. */
        inline std::string encode_text(const char* s) {
          std::string res;
          if (s != nullptr) {
            for (char c = *s; c != '\0'; c = *(++s)) {
              auto x { encode_char(c) };
              if (char *c2 = std::get_if<char>(&x)) {
                res += *c2;
              } else if (std::string *s2 = std::get_if<std::string>(&x)) {
                res += *s2;
              }
            }
          }
          return res;
        }
      }

      /** Write the HTML code. */
      inline void write_html(std::ostream& out, const char* str) {
        out << str;
      }

      /** Write the HTML code line. */
      inline void write_html_ln(std::ostream& out, const char* str) {
        out << str << std::endl;
      }

      /** Write the text in HTML. */
      inline void write_html_text(std::ostream& out, const char* str) {
        out << escape_text(str);
      }

      /** Write the HTML link with the specified URI and contents. */
      inline void write_html_link(std::ostream& out, const char* uri, const char* text) {
        write_html(out, "<a href=\"");
        write_html(out, encode_text(uri).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html(out, "</a>");
      }

      /** Write the HTML image by the specified URI. */
      inline void write_html_image(std::ostream& out, const char* uri) {
        write_html(out, "<img src=\"");
        write_html(out, encode_text(uri).c_str());
        write_html(out, "\" />");
      }

      /** Begin the HTML paragraph. */
      inline void begin_html_paragraph(std::ostream& out) {
        write_html_ln(out, "<p>");
      }

      /** Begin the HTML paragraph by the specified identifier. */
      inline void begin_html_paragraph_by_id(std::ostream& out, const char* id) {
        write_html(out, "<p id=\"");
        write_html(out, encode_text(id).c_str());
        write_html_ln(out , "\">");
      }

      /** End the HTML paragraph. */
      inline void end_html_paragraph(std::ostream& out) {
        write_html_ln(out, "</p>");
      }

      /** Write the HTML header of type 1. */
      inline void write_html_header1(std::ostream& out, const char* text) {
        write_html(out, "<h1>");
        write_html_text(out, text);
        write_html_ln(out, "</h1>");
      }

      /** Write the HTML header of type 1 by the specified identifier. */
      inline void write_html_header1_by_id(std::ostream& out, const char* id, const char* text) {
        write_html(out, "<h1 id=\"");
        write_html(out, encode_text(id).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html_ln(out, "</h1>");
      }

      /** Write the HTML header of type 2. */
      inline void write_html_header2(std::ostream& out, const char* text) {
        write_html(out, "<h2>");
        write_html_text(out, text);
        write_html_ln(out, "</h2>");
      }

      /** Write the HTML header of type 2 by the specified identifier. */
      inline void write_html_header2_by_id(std::ostream& out, const char* id, const char* text) {
        write_html(out, "<h2 id=\"");
        write_html(out, encode_text(id).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html_ln(out, "</h2>");
      }

      /** Write the HTML header of type 3. */
      inline void write_html_header3(std::ostream& out, const char* text) {
        write_html(out, "<h3>");
        write_html_text(out, text);
        write_html_ln(out, "</h3>");
      }

      /** Write the HTML header of type 3 by the specified identifier. */
      inline void write_html_header3_by_id(std::ostream& out, const char* id, const char* text) {
        write_html(out, "<h3 id=\"");
        write_html(out, encode_text(id).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html_ln(out, "</h3>");
      }

      /** Write the HTML header of type 4. */
      inline void write_html_header4(std::ostream& out, const char* text) {
        write_html(out, "<h4>");
        write_html_text(out, text);
        write_html_ln(out, "</h4>");
      }

      /** Write the HTML header of type 4 by the specified identifier. */
      inline void write_html_header4_by_id(std::ostream& out, const char* id, const char* text) {
        write_html(out, "<h4 id=\"");
        write_html(out, encode_text(id).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html_ln(out, "</h4>");
      }

      /** Write the HTML header of type 5. */
      inline void write_html_header5(std::ostream& out, const char* text) {
        write_html(out, "<h5>");
        write_html_text(out, text);
        write_html_ln(out, "</h5>");
      }

      /** Write the HTML header of type 5 by the specified identifier. */
      inline void write_html_header5_by_id(std::ostream& out, const char* id, const char* text) {
        write_html(out, "<h5 id=\"");
        write_html(out, encode_text(id).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html_ln(out, "</h5>");
      }

      /** Write the HTML header of type 6. */
      inline void write_html_header6(std::ostream& out, const char* text) {
        write_html(out, "<h6>");
        write_html_text(out, text);
        write_html_ln(out, "</h6>");
      }

      /** Write the HTML header of type 6 by the specified identifier. */
      inline void write_html_header6_by_id(std::ostream& out, const char* id, const char* text) {
        write_html(out, "<h6 id=\"");
        write_html(out, encode_text(id).c_str());
        write_html(out, "\">");
        write_html_text(out, text);
        write_html_ln(out, "</h6>");
      }

      /** Write the HTML break element. */
      inline void write_html_break(std::ostream& out) {
        write_html_ln(out, "<br />");
      }

      /** Begin the HTML list element. */
      inline void begin_html_list(std::ostream& out) {
        write_html_ln(out, "<ul>");
      }

      /** End the HTML list element. */
      inline void end_html_list(std::ostream& out) {
        write_html_ln(out, "</ul>");
      }

      /** Begin the HTML list element item. */
      inline void begin_html_list_item(std::ostream& out) {
        write_html_ln(out, "<li>");
      }

      /** End the HTML list element item. */
      inline void end_html_list_item(std::ostream& out) {
        write_html_ln(out, "</li>");
      }

      /** Write the CSS definition. */
      inline void write_html_css(std::ostream& out) {
        write_html_ln(out, "<style type=\"text/css\">");
        write_html_ln(out, "* { margin: 0; padding: 0 }");
        write_html_ln(out, "");
        write_html_ln(out, "html {");
        write_html_ln(out, "  background-color: white;");
        write_html_ln(out, "  width: 100%;");
        write_html_ln(out, "  height: 100%;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "body {");
        write_html_ln(out, "  background: white;");
        write_html_ln(out, "  color: black;");
        write_html_ln(out, "  text-align: left;");
        write_html_ln(out, "  min-height: 100%;");
        write_html_ln(out, "  width: 90%;");
        write_html_ln(out, "  margin: 0px auto 0px auto;");
        write_html_ln(out, "  position: relative;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "p {");
        write_html_ln(out, "  margin: 0.8em 0;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "ul, ol {");
        write_html_ln(out, "  margin: 0.8em 0 0.8em 2em;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "dl {");
        write_html_ln(out, "  margin: 0.8em 0;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "dt {");
        write_html_ln(out, "  font-weight: bold;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "dd {");
        write_html_ln(out, "  margin-left: 2em;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "a { text-decoration: none; }");
        write_html_ln(out, "a[href]:link { color: rgb(196,69,29); }");
        write_html_ln(out, "a[href]:visited { color: rgb(171,105,84); }");
        write_html_ln(out, "a[href]:hover { text-decoration:underline; }");
        write_html_ln(out, "");
        write_html_ln(out, "body {");
        write_html_ln(out, "  font-size:medium;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "h1 { font-size: 146.5%; /* 19pt */ } ");
        write_html_ln(out, "h2 { font-size: 131%;   /* 17pt */ }");
        write_html_ln(out, "h3 { font-size: 116%;   /* 15pt */ }");
        write_html_ln(out, "h4 { font-size: 100%;   /* 13pt */ }");
        write_html_ln(out, "h5 { font-size: 100%;   /* 13pt */ }");
        write_html_ln(out, "");
        write_html_ln(out, "select, input, button, textarea {");
        write_html_ln(out, "  font:99% sans-serif;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "table {");
        write_html_ln(out, "  font-size:inherit;");
        write_html_ln(out, "  font:100%;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "pre, code, kbd, samp, tt, .src {");
        write_html_ln(out, "  font-family:monospace;");
        write_html_ln(out, "  *font-size:108%;");
        write_html_ln(out, "  line-height: 124%;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, ".links, .link {");
        write_html_ln(out, "  font-size: 85%; /* 11pt */");
        write_html_ln(out, "}");
        write_html_ln(out, ".info  {");
        write_html_ln(out, "  font-size: 85%; /* 11pt */");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, ".caption, h1, h2, h3, h4, h5, h6 { ");
        write_html_ln(out, "  font-weight: bold;");
        write_html_ln(out, "  color: rgb(78,98,114);");
        write_html_ln(out, "  margin: 0.8em 0 0.4em;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "* + h1, * + h2, * + h3, * + h4, * + h5, * + h6 {");
        write_html_ln(out, "  margin-top: 2em;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "h1 + h2, h2 + h3, h3 + h4, h4 + h5, h5 + h6 {");
        write_html_ln(out, "  margin-top: inherit;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "ul.links {");
        write_html_ln(out, "  list-style: none;");
        write_html_ln(out, "  text-align: left;");
        write_html_ln(out, "  float: right;");
        write_html_ln(out, "  display: inline-table;");
        write_html_ln(out, "  margin: 0 0 0 1em;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "ul.links li {");
        write_html_ln(out, "  display: inline;");
        write_html_ln(out, "  border-left: 1px solid #d5d5d5; ");
        write_html_ln(out, "  white-space: nowrap;");
        write_html_ln(out, "  padding: 0;");
        write_html_ln(out, "}");
        write_html_ln(out, "");
        write_html_ln(out, "ul.links li a {");
        write_html_ln(out, "  padding: 0.2em 0.5em;");
        write_html_ln(out, "}");
        write_html_ln(out, "</style>");
      }

      /** Begin the HTML document. */
      inline void begin_html_document(std::ostream& out, const char* title) {
        write_html_ln(out, "<html>");
        write_html_ln(out, "<head>");
        write_html_ln(out, "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />");
        write_html(out, "<title>");
        write_html_text(out, title);
        write_html_ln(out, "</title>");
        write_html_css(out);
        write_html_ln(out, "</head>");
        write_html_ln(out, "<body>");
        write_html_header1(out, title);
      }

      /** End the HTML document. */
      inline void end_html_document(std::ostream& out) {
        write_html_break(out);
        begin_html_paragraph(out);
        write_html(out, "<font size=\"-1\">Automatically generated by ");
        write_html_link(out, "https://www.aivikasoft.com", "DVCompute++ Simulator");
        write_html_ln(out, "</font>");
        end_html_paragraph(out);
        write_html_ln(out, "</body>");
        write_html_ln(out, "</html>");
      }
    }
  }
}

#endif /* dvcompute_utils_html_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_queue_h
#define dvcompute_queue_h

#include <optional>
#include <tuple>
#include <cassert>
#include <variant>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"
#include "list.h"

namespace DVCOMPUTE_NS {

  namespace utils {
  
    namespace im {

      /** 
       * An immutable queue. The very basic idea is described in 
       * "Algorithms: a functional programming approach" by Fethi Rabhi and Guy Lapalme. 
       */
      template<typename T>
      class Queue {

        List<T> first;
        List<T> rest;

        Queue(const List<T>& first_arg, const List<T>& rest_arg) noexcept : 
          first(first_arg), rest(rest_arg) 
        {}

      public:

        class ConstIterator {

          using list_iterator = typename List<T>::const_iterator;
          using maybe_list_iterator = std::variant<list_iterator, List<T>>;

          list_iterator first;
          mutable maybe_list_iterator next;

          friend class Queue<T>;

          ConstIterator(const list_iterator& first_arg, const maybe_list_iterator& next_arg) :
            first(first_arg), next(next_arg)
          {}

        public:

          ConstIterator(const ConstIterator&) = default;
          ConstIterator(ConstIterator&&) = default;

          ConstIterator& operator=(const ConstIterator&) = default;
          ConstIterator& operator=(ConstIterator&&) = default;

          const T* operator->() const noexcept {
            if (first.empty()) {
              return require_next_iterator().operator->();
            } else {
              return first.operator->();
            }
          }

          const T& operator*() const noexcept {
            if (first.empty()) {
              return require_next_iterator().operator*();
            } else {
              return first.operator*();
            }
          }

          const T* get() const noexcept {
            if (first.empty()) {
              return require_next_iterator().get();
            } else {
              return first.get();
            }
          }

          ConstIterator& operator++() {
            if (first.empty()) {
              ++require_next_iterator();
            } else {
              ++first;
            }
            return *this;
          }

          ConstIterator operator++(int) {
            ConstIterator tmp { *this };
            ++(*this);
            return tmp;
          }

          bool operator==(const ConstIterator& other) const noexcept {
            return (first == other.first) && (require_next_iterator() == other.require_next_iterator());
          }

          bool operator!=(const ConstIterator& other) const noexcept {
            return (first != other.first) || (require_next_iterator() != other.require_next_iterator());
          }

        private:

          list_iterator& require_next_iterator() const {
            if (auto *it = std::get_if<0>(&next)) {
              return *it;
            } else {
              next = std::get<1>(next).reversed().begin();
              return require_next_iterator();
            }
          }
        };

        using const_iterator = ConstIterator;

        const_iterator begin() const {
          return ConstIterator(first.begin(), rest);
        }

        const_iterator end() const {
          return ConstIterator(typename List<T>::ConstIterator(), typename List<T>::ConstIterator());
        }

        /** An empty queue. */
        explicit Queue() : first(), rest() {}

        explicit Queue(const std::vector<T>& xs) : first(xs), rest() {}

        Queue(const Queue&) = default;
        Queue(Queue&&) = default;

        Queue& operator=(const Queue&) = default;
        Queue& operator=(Queue&&) = default;

        /** Whether the queue is empty. */
        bool empty() const noexcept {
          return first.empty() && rest.empty();
        }

        /** Return the front element. */
        const T& front() const noexcept {
          return first.head();
        }

        /** Push a new item to the queue. */
        Queue push_back(const T& item) const {
          return Queue(first, List<T>(item, rest)).post_process();
        }

        /** Pop the first item from the queue. */
        Queue pop_front() const {
          return Queue(first.tail(), rest).post_process();
        }

        /** Remove the specified item from the list. */
        std::optional<Queue<T>> erase(const T& item) const {
          auto res { first.append(rest.reversed()).erase(item) };
          if (res) {
            return Queue(res.value(), List<T>());
          } else {
            return std::nullopt;
          }
        }

        /** Remove an item satisfying the specified predicate. */
        template<typename Fn>
        std::optional<std::tuple<T, Queue<T>>> erase_by(const Fn& pred) const {
          auto res { first.append(rest.reversed()).erase_by(pred) };
          if (res) {
            return std::tuple<T, Queue<T>>(std::get<0>(res.value()),
              Queue(std::get<1>(res.value()), List<T>()));
          } else {
            return std::nullopt;
          }
        }

        /** Test whether there is an item satisfying the specified predicate. */
        template<typename Fn>
        bool exists(const Fn& pred) const {
          if (first.exists(pred)) {
            return true;
          } else {
            return rest.reversed().exists(pred);
          }
        }

        /** Find an item satisfying the specified predicate. */
        template<typename Fn>
        const_iterator find(const Fn& pred) const {
          auto it = first.find(pred);
          if (it != first.end()) {
            return ConstIterator(it, rest);
          } else {
            return ConstIterator(first.end(), rest.reversed().find(pred));
          }
        }

      private:

        /** Post-process the queue. */
        Queue<T> post_process() const {
          if (first.empty()) {
            return Queue(rest.reversed(), List<T>());
          } else {
            return *this;
          }
        }
      };
    }
  }
}

#endif /* dvcompute_queue_h */

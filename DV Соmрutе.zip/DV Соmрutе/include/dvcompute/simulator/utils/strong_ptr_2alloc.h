/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_strong_ptr_2alloc_h
#define dvcompute_strong_ptr_2alloc_h

#include <memory>

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  /** A shared cell optimized for single-threaded execution. */
  template<typename Item>
  class StrongPtr2Alloc {
  
    struct Cell {
      int count;
      Item* ptr;
      
      explicit Cell(Item* ptr_arg) : 
        count(1), ptr(ptr_arg) 
      {}

      ~Cell() {
        delete ptr;
      }
    };
    
    Cell* cell;

    Item* cellptr;
    
    Cell* incref() const noexcept {
      if (cell) {
        ++(cell->count);
      }
      return cell;
    }
    
    void decref() {
      if (--(cell->count) == 0) {
        delete cell;
      }
    }
    
  public:
    
    explicit StrongPtr2Alloc() noexcept : cell(nullptr), cellptr(nullptr) {}

    explicit StrongPtr2Alloc(Item* ptr) : cell(ptr ? new Cell(ptr) : nullptr), cellptr(ptr) {}

    StrongPtr2Alloc(const StrongPtr2Alloc<Item>& other) noexcept : cell(other.incref()), cellptr(other.cellptr) {}
    
    StrongPtr2Alloc(StrongPtr2Alloc<Item>&& other) noexcept : cell(other.cell), cellptr(other.cellptr) {

      other.cell = nullptr;
      other.cellptr = nullptr;
    }
    
    StrongPtr2Alloc& operator=(const StrongPtr2Alloc<Item>& other) noexcept {
      StrongPtr2Alloc tmp { other };
      swap(tmp);
      return *this;
    }
    
    StrongPtr2Alloc& operator=(StrongPtr2Alloc<Item>&& other) noexcept {
      StrongPtr2Alloc tmp { std::move(other) };
      swap(tmp);
      return *this;
    }
    
    ~StrongPtr2Alloc() {
      if (cell) decref();
    }
    
    Item* operator->() const noexcept {
      return cellptr ? cellptr : cell->ptr;
    }
    
    Item& operator*() const noexcept {
      return cellptr ? *cellptr : *(cell->ptr);
    }
    
    Item* get() const noexcept {
      return cellptr ? cellptr : (cell ? cell->ptr : nullptr);
    }
      
    void swap(StrongPtr2Alloc<Item>& other) noexcept {
      Cell *tmp = cell;

      cell = other.cell;
      cellptr = other.cellptr;
      
      other.cell = tmp;
      other.cellptr = tmp ? tmp->ptr : nullptr;
    }

    operator bool() const noexcept {
      return (cellptr != nullptr) || ((cell != nullptr) && (cell->ptr != nullptr));
    }

    void reset(Item* ptr) {
      StrongPtr2Alloc<Item> tmp(ptr);
      swap(tmp);
    }
  };

  template<typename Item>
  inline bool operator==(const StrongPtr2Alloc<Item>& lhs, const StrongPtr2Alloc<Item>& rhs) noexcept {
    return lhs.get() == rhs.get();
  }

  template<typename Item>
  inline bool operator!=(const StrongPtr2Alloc<Item>& lhs, const StrongPtr2Alloc<Item>& rhs) noexcept {
    return lhs.get() != rhs.get();
  }
}

#endif /* dvcompute_strong_ptr_2alloc_h */

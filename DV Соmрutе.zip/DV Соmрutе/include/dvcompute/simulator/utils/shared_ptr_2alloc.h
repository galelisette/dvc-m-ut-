/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_shared_ptr_2alloc_h
#define dvcompute_shared_ptr_2alloc_h

#include <memory>
#include <cassert>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/utils/thread_local_storage.h"
#include "dvcompute/simulator/utils/shared_ptr.h"

namespace DVCOMPUTE_NS {

  /** A weak pointer optimized for single-threaded execution. */
  template<typename Item>
  class WeakPtr2Alloc;

  /** A shared pointer optimized for single-threaded execution. */
  template<typename Item>
  class SharedPtr2Alloc {

    friend class WeakPtr2Alloc<Item>;
  
    class Cell : public DVCOMPUTE_NS::utils::ThreadLocalObject  {
    public:

      int use_count;
      int weak_count;
      Item* ptr;
      
      explicit Cell(Item* ptr_arg) noexcept : 
        use_count(1), weak_count(0), ptr(ptr_arg) 
      {}

      explicit Cell(SharedPtrLateInit tag) noexcept : 
        use_count(1), weak_count(0), ptr(nullptr)
      {}

      ~Cell() {
        delete ptr;
      }

      void free_object() noexcept override {
        if (ptr) {
          Item* tmp_ptr = ptr;
          ptr = nullptr;
          delete tmp_ptr;
        }
      }
    };
    
    Cell* cell;

    Item* cellptr;
    
    Cell* incref() const noexcept {
      if (cell) {
        ++(cell->use_count);
      }

      return cell;
    }
    
    void decref() {
      if (--(cell->use_count) == 0) {
        if (cell->weak_count == 0) {
          std::destroy_at(cell);
          DVCOMPUTE_NS::utils::deallocate_thread_local_object(cell);

        } else {
          decref_weak();
        }
      }
    }

    void decref_weak() {
      if (cell->ptr) {

        ++(cell->use_count);
        Item *ptr = cell->ptr;
        cell->ptr = nullptr;
        delete ptr;
        --(cell->use_count);

        if (cell->weak_count == 0) {
          std::destroy_at(cell);
          DVCOMPUTE_NS::utils::deallocate_thread_local_object(cell);
        }
      }
    }

    explicit SharedPtr2Alloc(Cell *cell_arg) noexcept : cell(cell_arg), cellptr(cell_arg ? cell_arg->ptr : nullptr) {
      if (cell) {
        ++(cell->use_count);
      }
    }

  public:
    
    explicit SharedPtr2Alloc() noexcept : cell(nullptr), cellptr(nullptr) {}
    
    explicit SharedPtr2Alloc(SharedPtrLateInit tag) : cell(nullptr), cellptr(nullptr) {
      DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
      if (address) {
        new(address.get()) Cell(tag);
      }
      cell = reinterpret_cast<Cell*>(address.release());
    }

    explicit SharedPtr2Alloc(Item* ptr) : cell(nullptr), cellptr(ptr) {
      if (ptr) {
        DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
        if (address) {
          new(address.get()) Cell(ptr);
        }
        cell = reinterpret_cast<Cell*>(address.release());
      }
    }
    
    SharedPtr2Alloc(const SharedPtr2Alloc<Item>& other) noexcept : cell(other.incref()), cellptr(other.cellptr) {}
    
    SharedPtr2Alloc(SharedPtr2Alloc<Item>&& other) noexcept : cell(other.cell), cellptr(other.cellptr) {

      other.cell = nullptr;
      other.cellptr = nullptr;
    }
    
    SharedPtr2Alloc& operator=(const SharedPtr2Alloc<Item>& other) noexcept {
      SharedPtr2Alloc tmp { other };
      swap(tmp);
      return *this;
    }
    
    SharedPtr2Alloc& operator=(SharedPtr2Alloc<Item>&& other) noexcept {
      SharedPtr2Alloc tmp { std::move(other) };
      swap(tmp);
      return *this;
    }
    
    ~SharedPtr2Alloc() {
      if (cell) decref();
    }
    
    Item* operator->() const noexcept {
      return cellptr ? cellptr : cell->ptr;
    }
    
    Item& operator*() const noexcept {
      return cellptr ? *cellptr : *(cell->ptr);
    }
    
    Item* get() const noexcept {
      return cellptr ? cellptr : (cell ? cell->ptr : nullptr);
    }
      
    void swap(SharedPtr2Alloc<Item>& other) noexcept {
      Cell *tmp = cell;

      cell = other.cell;
      cellptr = other.cellptr;

      other.cell = tmp;
      other.cellptr = tmp ? tmp->ptr : nullptr;
    }

    operator bool() const noexcept {
      return (cellptr != nullptr) || ((cell != nullptr) && (cell->ptr != nullptr));
    }

    void reset(Item* ptr) {
      SharedPtr2Alloc<Item> tmp(ptr);
      swap(tmp);
    }

    void late_init(Item* ptr) {
      if (cell) {
        if (cell->ptr) {
          assert(false && "The object had to be empty.");

          Item *tmp_ptr = cell->ptr;
          cell->ptr = nullptr;
          delete tmp_ptr;
        }

        cell->ptr = ptr;
        cellptr = ptr;

      } else {

        DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
        if (address) { 
          new(address.get()) Cell(ptr); 
        }

        cell = reinterpret_cast<Cell*>(address.release());
        cellptr = ptr;
      }
    }
  };

  /** A weak pointer optimized for single-threaded execution. */
  template<typename Item>
  class WeakPtr2Alloc {

    friend class SharedPtr2Alloc<Item>;
  
    using Cell = typename SharedPtr2Alloc<Item>::Cell;
    
    Cell* cell;
    
    Cell* incref() const noexcept {
      if (cell) {
        ++(cell->weak_count);
      }

      return cell;
    }
    
    void decref() {
      if (--(cell->weak_count) == 0) {
        if (cell->use_count == 0) {
          assert(!(cell->ptr) && "The item must be already destroyed");
          std::destroy_at(cell);
          DVCOMPUTE_NS::utils::deallocate_thread_local_object(cell);
        }
      }
    }
    
    explicit WeakPtr2Alloc() noexcept : cell(nullptr) {}
    
  public:
    
    explicit WeakPtr2Alloc(const SharedPtr2Alloc<Item>& other) noexcept : cell(other.cell) {
      incref();
    }

    WeakPtr2Alloc(const WeakPtr2Alloc<Item>& other) noexcept : cell(other.incref()) {}
    
    WeakPtr2Alloc(WeakPtr2Alloc<Item>&& other) noexcept : cell(other.cell) {
      other.cell = nullptr;
    }
    
    WeakPtr2Alloc& operator=(const WeakPtr2Alloc<Item>& other) noexcept {
      WeakPtr2Alloc tmp { other };
      swap(tmp);
      return *this;
    }
    
    WeakPtr2Alloc& operator=(WeakPtr2Alloc<Item>&& other) noexcept {
      WeakPtr2Alloc tmp { std::move(other) };
      swap(tmp);
      return *this;
    }
    
    ~WeakPtr2Alloc() {
      if (cell) decref();
    }
    
    SharedPtr2Alloc<Item> lock() const noexcept {
      return SharedPtr2Alloc<Item>(cell && cell->ptr ? cell : nullptr);
    }

    void swap(WeakPtr2Alloc<Item>& other) noexcept {
      Cell *tmp = cell;
      cell = other.cell;
      other.cell = tmp;
    }

    bool expired() const noexcept {
      return (cell == nullptr) || (cell->ptr == nullptr);
    }
  };

  template<typename Item>
  inline bool operator==(const SharedPtr2Alloc<Item>& lhs, const SharedPtr2Alloc<Item>& rhs) noexcept {
    return lhs.get() == rhs.get();
  }

  template<typename Item>
  inline bool operator!=(const SharedPtr2Alloc<Item>& lhs, const SharedPtr2Alloc<Item>& rhs) noexcept {
    return lhs.get() != rhs.get();
  }
}

#endif /* dvcompute_shared_ptr_2alloc_h */

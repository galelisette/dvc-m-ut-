/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_ordered_map_h
#define dvcompute_ordered_map_h

#include <optional>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"
#include "dvcompute/simulator/basic/macros.h"

namespace DVCOMPUTE_NS {

  namespace utils {
  
    namespace im {

      /** 
        * An ordered map based on red-black trees, where the very basic idea is described in article
        * "Functional Pearls: Red-Black Trees in a Functional Setting" by Chris Okasaki.
        */
      template<typename K, typename V>
      class OrderedMap {

        enum class OrderedMapColor { red, black };

        struct Node {
          OrderedMapColor color;
          K key;
          V value;
          StrongPtr2Alloc<OrderedMap<K, V>> left;
          StrongPtr2Alloc<OrderedMap<K, V>> right;
        };

        using Tree = std::optional<Node>;

        Tree tree;

        explicit OrderedMap(Tree&& tree_arg) noexcept(noexcept(Tree(std::move(tree_arg)))) :
          tree(std::move(tree_arg)) 
        {}

      public:

        class const_iterator {
          const Node *p;

          explicit const_iterator(const Node* p_arg) noexcept : p(p_arg) {}

          friend class OrderedMap<K, V>;

        public:

          const_iterator(const const_iterator&) = default;
          const_iterator& operator=(const const_iterator&) = default;

          bool operator==(const const_iterator& other) const noexcept {
            return p == other.p;
          }

          bool operator!=(const const_iterator& other) const noexcept {
            return p != other.p;
          }

          const K& key() const noexcept {
            return p->key;
          }

          const V& value() const noexcept {
            return p->value;
          }
        };

        /** An empty tree. */
        explicit OrderedMap() noexcept : tree(std::nullopt) {}

        /** Whether the tree is empty. */
        bool empty() const noexcept {
          return !tree.has_value();
        }

        /** Return the end iterator. */
        const_iterator end() const noexcept {
          return const_iterator(nullptr);
        }

        /** Try to find an item by the specified key. */
        const_iterator find(const K& key) const noexcept {
          const Tree *p = &tree;
          while (true) {
            if (p->has_value()) {
              const Node &node = p->value();
              if (key < node.key) {
                p = &node.left->tree;
              } else if (key > node.key) {
                p = &node.right->tree;
              } else {
                return const_iterator(&node);
              }
            } else {
              return end();
            }
          }
        }

        /** Return the item with the minimal key. */
        const_iterator find_min() const {
          const Tree *p = &tree;
          while (true) {
            if (p->has_value()) {
              const Node &node = p->value();
              if (node.left->empty()) {
                return const_iterator(&node);
              } else {
                p = &node.left->tree;
              }
            } else {
              return end();
            }
          }
        }

        /** Return the item with the maximal key. */
        const_iterator find_max() const {
          const Tree *p = &tree;
          while (true) {
            if (p->has_value()) {
              const Node &node = p->value();
              if (node.right->empty()) {
                return const_iterator(&node);
              } else {
                p = &node.right->tree;
              }
            } else {
              return end();
            }
          }
        }

        /** Add a new key-value pair and return the corresponding new collection. */
        OrderedMap<K, V> emplace(K&& key, V&& value) const {
          return ins(std::move(key), std::move(value)).make_black();
        }

        /** Remove the key-value pair by the specified key value. */
        OrderedMap<K, V> erase(const K& key, bool* found = nullptr) const {
          return rem(key, found).make_black();
        }

        /** Get the depth of the tree (complexity O(n)). */
        std::size_t depth() const {
          if (tree.has_value()) {
            const Node &node = tree.value();
            return 1 + std::max(node.left->depth(), node.right->depth());

          } else {
            return 0;
          }
        }

        /** Get the size of the tree (complexity O(n)). */
        std::size_t size() const {
          if (tree.has_value()) {
            const Node &node = tree.value();
            return 1 + node.left->size() + node.right->size();

          } else {
            return 0;
          }
        }

        /** Transform to the vector. */
        std::vector<const_iterator> to_vector() const {
          std::vector<const_iterator> vec;
          fill_vector(vec);
          return vec;
        }

        /** Fill in the vector. */
        void fill_vector(std::vector<const_iterator>& vec) const {
          if (tree.has_value()) {
            const Node &node = tree.value();

            node.left->fill_vector(vec);
            vec.push_back(const_iterator(&node));
            node.right->fill_vector(vec);
          }
        }

      private:

        OrderedMap<K, V> ins(K&& key, V&& value) const {
          if (tree.has_value()) {
            const Node &node = tree.value();
            if (key < node.key) {
              return balance(node.color, node.key, node.value,
                StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(node.left->ins(std::move(key), std::move(value)))),
                node.right);

            } else if (key > node.key) {
              return balance(node.color, node.key, node.value,
                node.left,
                StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(node.right->ins(std::move(key), std::move(value)))));

            } else {
              return OrderedMap<K, V>(Tree(Node {
                node.color, std::move(key), std::move(value),
                node.left,
                node.right
              }));
            }

          } else {
            return OrderedMap<K, V>(Tree(Node {
              OrderedMapColor::red, std::move(key), std::move(value),
              StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>()),
              StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>())
            }));
          }
        }

        OrderedMap<K, V> rem(const K& key, bool* found) const {
          if (tree.has_value()) {
            const Node &node = tree.value();

            if (key < node.key) {
              return balance(node.color, node.key, node.value,
                StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(node.left->rem(key, found))),
                node.right);

            } else if (key > node.key) {
              return balance(node.color, node.key, node.value,
                node.left,
                StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(node.right->rem(key, found))));

            } else {

              if (found != nullptr) *found = true;
              return behead(key);
            }

          } else {

            if (found != nullptr) *found = false;
            return OrderedMap<K, V>();
          }
        }

        OrderedMap<K, V> behead(const K& key) const {
          if (tree.has_value()) {
            const Node &node = tree.value();

            if (node.left->empty()) {
              return node.right ? *(node.right) : OrderedMap<K, V>();

            } else if (node.right->empty()) {
              return node.left ? *(node.left) : OrderedMap<K, V>();
              
            } else {

              const_iterator it = node.right->find_min();
              if (it != node.right->end()) {

                return balance(node.color, it.key(), it.value(),
                  node.left,
                  StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(node.right->rem(it.key(), nullptr))));

              } else {
                return OrderedMap<K, V>();
              }
            }

          } else {
            return OrderedMap<K, V>();
          }
        }

        OrderedMap<K, V> make_black() const {
          if (tree.has_value()) {
            const Node &node = tree.value();
            return OrderedMap<K, V>(Tree(Node {
              OrderedMapColor::black, node.key, node.value,
              node.left,
              node.right
            }));

          } else {
            return OrderedMap<K, V>();
          }
        }

        static OrderedMap<K, V> balance(OrderedMapColor color, const K& key, const V& value,
          const StrongPtr2Alloc<OrderedMap<K, V>>& left,
          const StrongPtr2Alloc<OrderedMap<K, V>>& right)
        {
          if (color == OrderedMapColor::black) {
            if (left->tree.has_value()) {
              const Node &node2 = left->tree.value();
              if ((node2.color == OrderedMapColor::red) && node2.left->tree.has_value()) {
                const Node &node3 = node2.left->tree.value();
                if (node3.color == OrderedMapColor::red) {
                  return OrderedMap<K, V>(Tree(Node {
                    OrderedMapColor::red, node2.key, node2.value,
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, node3.key, node3.value, node3.left, node3.right
                    }))),
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, key, value, node2.right, right
                    })))
                  }));
                }
              }

              if ((node2.color == OrderedMapColor::red) && node2.right->tree.has_value()) {
                const Node &node3 = node2.right->tree.value();
                if (node3.color == OrderedMapColor::red) {
                  return OrderedMap<K, V>(Tree(Node {
                    OrderedMapColor::red, node3.key, node3.value,
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, node2.key, node2.value, node2.left, node3.left
                    }))),
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, key, value, node3.right, right
                    })))
                  }));
                }
              }
            }

            if (right->tree.has_value()) {
              const Node &node2 = right->tree.value();
              if ((node2.color == OrderedMapColor::red) && node2.left->tree.has_value()) {
                const Node &node3 = node2.left->tree.value();
                if (node3.color == OrderedMapColor::red) {
                  return OrderedMap<K, V>(Tree(Node {
                    OrderedMapColor::red, node3.key, node3.value,
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, key, value, left, node3.left
                    }))),
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, node2.key, node2.value, node3.right, node2.right
                    })))
                  }));
                }
              }

              if ((node2.color == OrderedMapColor::red) && node2.right->tree.has_value()) {
                const Node &node3 = node2.right->tree.value();
                if (node3.color == OrderedMapColor::red) {
                  return OrderedMap<K, V>(Tree(Node {
                    OrderedMapColor::red, node2.key, node2.value,
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, key, value, left, node2.left
                    }))),
                    StrongPtr2Alloc<OrderedMap<K, V>>(new OrderedMap<K, V>(Tree(Node {
                      OrderedMapColor::black, node3.key, node3.value, node3.left, node3.right
                    })))
                  }));
                }
              }
            }
          }

          return OrderedMap<K, V>(Tree(Node {
            color, key, value, left, right
          }));
        }
      };
    }
  }
}

#endif /* dvcompute_ordered_map_h */

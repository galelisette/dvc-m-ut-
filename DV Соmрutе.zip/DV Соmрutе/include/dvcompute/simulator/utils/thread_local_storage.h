/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_thread_local_storage_h
#define dvcompute_thread_local_storage_h

#include <stdlib.h>
#include <optional>

#ifdef USE_MIMALLOC
#include <mimalloc.h>
#include <mimalloc-override.h>
#endif

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  namespace utils {

    /** The thread local state. */
    enum class ThreadLocalState {
      active, free_objects, calling_destructors, reclaiming_memory
    };

    /** The thread local object header. */
    struct ThreadLocalObjectHeader {

      /** The object state. */
      ThreadLocalState state;

      /** The previous object header. */
      ThreadLocalObjectHeader* prev;

      /** The next object header. */
      ThreadLocalObjectHeader* next;
    };

    /** It allows managing the object after the simulation run is over. */
    class ThreadLocalObject {
    public:

      explicit ThreadLocalObject() {}

      virtual ~ThreadLocalObject() {}

      /** Free all the links related to the object. */
      virtual void free_object() noexcept = 0;
    };

    /** Get the header pointer by the object pointer. */
    inline ThreadLocalObjectHeader* header_ptr_from_object(ThreadLocalObject* obj) {
      return reinterpret_cast<ThreadLocalObjectHeader*>(reinterpret_cast<char*>(obj) - sizeof(ThreadLocalObjectHeader));
    }

    /** Get the object header by the header pointer. */
    inline ThreadLocalObject* object_ptr_from_header(ThreadLocalObjectHeader* obj) {
      return reinterpret_cast<ThreadLocalObject*>(reinterpret_cast<char*>(obj) + sizeof(ThreadLocalObjectHeader));
    }

    /** The thread local storage. */
    class ThreadLocalStorage {

      /** The storage state. */
      ThreadLocalState state;

      /** The head of active objects. */
      ThreadLocalObjectHeader* head_active;

      /** The tail of active objects. */
      ThreadLocalObjectHeader* tail_active;

      /** The head of objects which destructors we are going to call. */
      ThreadLocalObjectHeader* head_before_calling_destructors;

      /** The tail of objects which destructors we are going to call. */
      ThreadLocalObjectHeader* tail_before_calling_destructors;

      /** The head of objects which memory we are going to reclaim. */
      ThreadLocalObjectHeader* head_before_reclaiming_memory;

      /** The tail of objects which memory we are going to reclaim. */
      ThreadLocalObjectHeader* tail_before_reclaiming_memory;

      /** Add the object to the list of active objects. */
      void add_to_active(ThreadLocalObjectHeader* obj) {
        assert(obj->state == ThreadLocalState::active);
        assert(obj->prev == nullptr);
        assert(obj->next == nullptr);

        obj->state = ThreadLocalState::free_objects;
        obj->prev = tail_active;
        obj->next = nullptr;

        if (tail_active != nullptr) {
          tail_active->next = obj;

        } else if (head_active == nullptr) {
          head_active = obj;
        }

        tail_active = obj;
      }

      /** Add the object to those ones, which destructors must be called. */
      void add_to_call_destructors(ThreadLocalObjectHeader* obj) {
        assert(obj->state == ThreadLocalState::active);
        assert(obj->prev == nullptr);
        assert(obj->next == nullptr);

        obj->state = ThreadLocalState::calling_destructors;
        obj->prev = tail_before_calling_destructors;
        obj->next = nullptr;

        if (tail_before_calling_destructors != nullptr) {
          tail_before_calling_destructors->next = obj;

        } else if (head_before_calling_destructors == nullptr) {
          head_before_calling_destructors = obj;
        }

        tail_before_calling_destructors = obj;
      }

      /** Add the object to those ones, which memory must be reclaimed. */
      void add_to_reclaim_memory(ThreadLocalObjectHeader* obj) {
        assert(obj->state == ThreadLocalState::active);
        assert(obj->prev == nullptr);
        assert(obj->next == nullptr);

        obj->state = ThreadLocalState::reclaiming_memory;
        obj->prev = tail_before_reclaiming_memory;
        obj->next = nullptr;

        if (tail_before_reclaiming_memory != nullptr) {
          tail_before_reclaiming_memory->next = obj;

        } else if (head_before_reclaiming_memory == nullptr) {
          head_before_reclaiming_memory = obj;
        }

        tail_before_reclaiming_memory = obj;
      }

      /** Remove from the list of active objects. */
      void remove_from_active(ThreadLocalObjectHeader* obj) {
        assert(obj->state == ThreadLocalState::free_objects);

        if (obj->prev != nullptr) {
          obj->prev->next = obj->next;
        } else if (head_active == obj) {
          head_active = obj->next;
        } else {
          assert(false);
        }

        if (obj->next != nullptr) {
          obj->next->prev = obj->prev;
        } else if (tail_active == obj) {
          tail_active = obj->prev;
        } else {
          assert(false);
        }

        obj->state = ThreadLocalState::active;
        obj->prev = nullptr;
        obj->next = nullptr;
      }

      /** Remove from the list of those objects, which destructors we are going to call. */
      void remove_from_calling_destructors(ThreadLocalObjectHeader* obj) {
        assert(obj->state == ThreadLocalState::calling_destructors);

        if (obj->prev != nullptr) {
          obj->prev->next = obj->next;
        } else if (head_before_calling_destructors == obj) {
          head_before_calling_destructors = obj->next;
        } else {
          assert(false);
        }

        if (obj->next != nullptr) {
          obj->next->prev = obj->prev;
        } else if (tail_before_calling_destructors == obj) {
          tail_before_calling_destructors = obj->prev;
        } else {
          assert(false);
        }

        obj->state = ThreadLocalState::active;
        obj->prev = nullptr;
        obj->next = nullptr;
      }

      /** Remove from the list of those objects, which memory we are going to reclaim. */
      void remove_from_reclaiming_memory(ThreadLocalObjectHeader* obj) {
        assert(obj->state == ThreadLocalState::reclaiming_memory);

        if (obj->prev != nullptr) {
          obj->prev->next = obj->next;
        } else if (head_before_reclaiming_memory == obj) {
          head_before_reclaiming_memory = obj->next;
        } else {
          assert(false);
        }

        if (obj->next != nullptr) {
          obj->next->prev = obj->prev;
        } else if (tail_before_reclaiming_memory == obj) {
          tail_before_reclaiming_memory = obj->prev;
        } else {
          assert(false);
        }

        obj->state = ThreadLocalState::active;
        obj->prev = nullptr;
        obj->next = nullptr;
      }

    public:

      explicit ThreadLocalStorage() :
        state(ThreadLocalState::active),
        head_active(nullptr),
        tail_active(nullptr),
        head_before_calling_destructors(nullptr),
        tail_before_calling_destructors(nullptr),
        head_before_reclaiming_memory(nullptr),
        tail_before_reclaiming_memory(nullptr)
      {}

      ThreadLocalStorage(ThreadLocalStorage&&) = default;
      ThreadLocalStorage& operator=(ThreadLocalStorage&&) = default;

      ~ThreadLocalStorage() {
        // free_objects();
      }
      
      /** Free the objects. */
      void free_objects() {
        assert(state == ThreadLocalState::active);

        // free the objects themselves
        state = ThreadLocalState::free_objects;

        while (head_active != nullptr) {
          ThreadLocalObjectHeader* obj = head_active;

          remove_from_active(obj);
          add_to_call_destructors(obj);

          object_ptr_from_header(obj)->free_object();
        }

        // call their destructors
        state = ThreadLocalState::calling_destructors;

        while (head_before_calling_destructors != nullptr) {
          ThreadLocalObjectHeader* obj = head_before_calling_destructors;

          remove_from_calling_destructors(obj);
          add_to_reclaim_memory(obj);

          object_ptr_from_header(obj)->~ThreadLocalObject();
        }

        // reclaim the corresponding memory
        state = ThreadLocalState::reclaiming_memory;

        while (head_before_reclaiming_memory != nullptr) {
          ThreadLocalObjectHeader* obj = head_before_reclaiming_memory;

          remove_from_reclaiming_memory(obj);

          free(obj);
        }

        // return to the active state
        state = ThreadLocalState::active;
      }

      /** Allocate a new object. */
      void* allocate_object(std::size_t count) {
        assert (state == ThreadLocalState::active);

        void* ptr = malloc(count + sizeof(ThreadLocalObjectHeader));

        if (ptr) {
          ThreadLocalObjectHeader* obj = reinterpret_cast<ThreadLocalObjectHeader*>(ptr);
          obj->state = ThreadLocalState::active;
          obj->prev = nullptr;
          obj->next = nullptr;

          add_to_active(obj);

          return object_ptr_from_header(obj);

        } else {
          return nullptr;
        }
      }
      
      /** Deallocate the object. */
      void deallocate_object(void* ptr) {
        if (ptr) {
          ThreadLocalObject* obj0 = reinterpret_cast<ThreadLocalObject*>(ptr);
          ThreadLocalObjectHeader* obj = header_ptr_from_object(obj0);

          if (state == ThreadLocalState::active) {
            remove_from_active(obj);
            free(obj);

          } else if (state == ThreadLocalState::free_objects) {

            if (obj->state == ThreadLocalState::calling_destructors) {
              remove_from_calling_destructors(obj);
              add_to_reclaim_memory(obj);

            } else {
              remove_from_active(obj);
              free(obj);
            }

          } else if (state == ThreadLocalState::calling_destructors) {
            assert(false);

          } else if (state == ThreadLocalState::reclaiming_memory) {
            assert(false);
          
          } else {
            assert(false);
          }
        }
      }
    };
  }

  namespace {

    /** The thread local storage. */
    static thread_local std::optional<DVCOMPUTE_NS::utils::ThreadLocalStorage> thread_local_storage { std::nullopt };
  }

  namespace utils {

    /** Allocate a new thread local object. */
    inline void* allocate_thread_local_object(std::size_t count) {
      if (!thread_local_storage.has_value()) {
        thread_local_storage = std::make_optional<ThreadLocalStorage>(ThreadLocalStorage());
      }
      return thread_local_storage.value().allocate_object(count);
    }

    /** Deallocate the thread local object. */
    inline void deallocate_thread_local_object(void* ptr) {
      if (!thread_local_storage.has_value()) {
        thread_local_storage = std::make_optional<ThreadLocalStorage>(ThreadLocalStorage());
      }
      thread_local_storage.value().deallocate_object(ptr);
    }

    /** Implements RAII for internal pointers. */
    class ThreadLocalObjectPtr {
      void* address;

    public:
      /** Allocate a memory of the specified size. */
      explicit ThreadLocalObjectPtr(std::size_t count) {
        address = allocate_thread_local_object(count);
      }

      ~ThreadLocalObjectPtr() {
        if (address) {
          deallocate_thread_local_object(address);
        }
      }

      /** Test whether the pointer is not null. */
      operator bool() const noexcept {
        return (address != nullptr);
      }

      /** Return the pointer. */
      void* get() const noexcept {
        return address;
      }

      /** Release the pointer. */
      void* release() noexcept {
        void* tmp = address;
        address = nullptr;
        return tmp;
      }
    };
  }

  /** Free the thread local objects. Note that there must be no any alive `SharedPtr` pointer before this call in the current system thread! */
  inline void free_thread_local_objects() {
    if (thread_local_storage.has_value()) {
      thread_local_storage.value().free_objects();
      thread_local_storage = std::nullopt;
    }
  }
}

#endif /* dvcompute_thread_local_storage_h */

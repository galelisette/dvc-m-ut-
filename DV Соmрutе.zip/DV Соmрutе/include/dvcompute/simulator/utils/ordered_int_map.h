/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_ordered_int_map_h
#define dvcompute_ordered_int_map_h

#include <variant>
#include <optional>
#include <vector>
#include <tuple>
#include <climits>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"
#include "dvcompute/simulator/basic/macros.h"

#if defined(DVCOMPUTE_E2K_INTRINSICS)
#include <e2kintrin.h>
#elif defined(DVCOMPUTE_BIT_EMULATION)
#else
#include <bit>
#endif

namespace DVCOMPUTE_NS {

  namespace utils {
  
    namespace im {

      /** Specifies an integer key for the ordered map. */
      template<typename K>
      struct OrderedIntMapKey;

      /** 
       * An ordered map by integer key, where the implementation is based on Patricia tree. 
       * See article "Fast Mergeable Integer Maps" by Chris Okasaki and Andrew Gill.
       */
      template<typename K, typename V>
      class OrderedIntMap {

        struct Br {
          K prefix;
          K bit;
          StrongPtr2Alloc<OrderedIntMap<K, V>> left;
          StrongPtr2Alloc<OrderedIntMap<K, V>> right;
        };

        struct Lf {
          K key;
          V value;

          Lf(K key_arg, V&& value_arg) noexcept(noexcept(V(std::move(value_arg)))) :
            key(key_arg), value(std::move(value_arg))
          {}
        };

        struct Nil {};

        using Tree = std::variant<Br, Lf, Nil>;

        Tree tree;

        explicit OrderedIntMap(Tree&& tree_arg) noexcept(noexcept(Tree(std::move(tree_arg)))) :
          tree(std::move(tree_arg)) 
        {}

      public:

        class const_iterator {
          const Lf *p;

          explicit const_iterator(const Lf* p_arg) noexcept : p(p_arg) {}

          friend class OrderedIntMap<K, V>;

        public:

          const_iterator(const const_iterator&) = default;
          const_iterator& operator=(const const_iterator&) = default;

          bool operator==(const const_iterator& other) const noexcept {
            return p == other.p;
          }

          bool operator!=(const const_iterator& other) const noexcept {
            return p != other.p;
          }

          K key() const noexcept {
            return p->key;
          }

          const V& value() const noexcept {
            return p->value;
          }
        };

        /** An empty tree. */
        explicit OrderedIntMap() noexcept : tree(Tree(Nil())) {}

        bool empty() const noexcept {
          if (std::get_if<Nil>(&tree)) {
            return true;
          } else {
            return false;
          }
        }

        const_iterator end() const noexcept {
          return const_iterator(nullptr);
        }

        const_iterator find(K key) const noexcept {
          const Tree *p = &tree;
          while (true) {
            if (const Br* br = std::get_if<Br>(p)) {
              if (!match_prefix(key, br->prefix, br->bit)) {
                return end();
              } else if (zero_bit(key, br->bit)) {
                p = &br->left->tree;
              } else {
                p = &br->right->tree;
              }

            } else if (const Lf* lf = std::get_if<Lf>(p)) {
              if (key == lf->key) {
                return const_iterator(lf);
              } else {
                return end();
              }

            } else {
              return end();
            }
          }
        }

        const_iterator find_min() const {
          const Tree *p = &tree;
          bool first_br = true;
          while (true) {
            if (const Br* br = std::get_if<Br>(p)) {
              if (first_br && (br->bit < 0)) {
                first_br = false;
                p = &br->right->tree;
              } else {
                p = &br->left->tree;
              }

            } else if (const Lf* lf = std::get_if<Lf>(p)) {
              return const_iterator(lf);

            } else {
              return end();
            }
          }
        }

        const_iterator find_max() const {
          const Tree *p = &tree;
          bool first_br = true;
          while (true) {
            if (const Br* br = std::get_if<Br>(p)) {
              if (first_br && (br->bit < 0)) {
                first_br = false;
                p = &br->left->tree;
              } else {
                p = &br->right->tree;
              }

            } else if (const Lf* lf = std::get_if<Lf>(p)) {
              return const_iterator(lf);

            } else {
              return end();
            }
          }
        }

        template<typename Fn>
        bool traverse(const Fn& fn, bool default_result) const {
          const Tree *p = &tree;
          if (const Br* br = std::get_if<Br>(p)) {
            if (br->bit < 0) {
              bool r1 { br->right->traverse(fn, default_result) };
              if (r1) return r1;

              bool r2 { br->left->traverse(fn, default_result) };
              if (r2) return r2;

            } else {
              bool r1 { br->left->traverse(fn, default_result) };
              if (r1) return r1;

              bool r2 { br->right->traverse(fn, default_result) };
              if (r2) return r2;
            }

          } else if (const Lf* lf = std::get_if<Lf>(p)) {
            bool r { fn(lf->key, lf->value) };
            if (r) return r;
          }

          return default_result;
        }

        template<typename Result, typename Fn>
        const Result* traverse_ptr(const Fn& fn, const Result* default_result) const {
          const Tree *p = &tree;
          if (const Br* br = std::get_if<Br>(p)) {
            if (br->bit < 0) {
              const Result *r1 { br->right->traverse_ptr(fn, default_result) };
              if (r1) return r1;

              const Result *r2 { br->left->traverse_ptr(fn, default_result) };
              if (r2) return r2;

            } else {
              const Result *r1 { br->left->traverse_ptr(fn, default_result) };
              if (r1) return r1;

              const Result *r2 { br->right->traverse_ptr(fn, default_result) };
              if (r2) return r2;
            }

          } else if (const Lf* lf = std::get_if<Lf>(p)) {
            const Result *r { fn(lf->key, lf->value) };
            if (r) return r;
          }

          return default_result;
        }

        template<typename Result, typename Fn>
        std::optional<Result> traverse_opt(const Fn& fn, const std::optional<Result>& default_result) const {
          const Tree *p = &tree;
          if (const Br* br = std::get_if<Br>(p)) {
            if (br->bit < 0) {
              std::optional<Result> r1 { br->right->traverse_opt(fn, default_result) };
              if (r1) return r1;

              std::optional<Result> r2 { br->left->traverse_opt(fn, default_result) };
              if (r2) return r2;

            } else {
              std::optional<Result> r1 { br->left->traverse_opt(fn, default_result) };
              if (r1) return r1;

              std::optional<Result> r2 { br->right->traverse_opt(fn, default_result) };
              if (r2) return r2;
            }

          } else if (const Lf* lf = std::get_if<Lf>(p)) {
            std::optional<Result> r { fn(lf->key, lf->value) };
            if (r) return r;
          }

          return default_result;
        }

        OrderedIntMap<K, V> emplace(K key, V&& value) const {
          if (const Br* br = std::get_if<Br>(&tree)) {
            if (match_prefix(key, br->prefix, br->bit)) {
              if (zero_bit(key, br->bit)) {
                return OrderedIntMap<K, V>(Tree(Br { 
                  br->prefix, br->bit,
                  StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(br->left->emplace(key, std::move(value)))),
                  br->right
                }));
              } else {
                return OrderedIntMap<K, V>(Tree(Br {
                  br->prefix, br->bit, 
                  br->left, 
                  StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(br->right->emplace(key, std::move(value))))
                }));
              }

            } else {
              return join(key, Tree(Lf(key, std::move(value))), br->prefix, tree);
            }

          } else if (const Lf* lf = std::get_if<Lf>(&tree)) {
            if (key == lf->key) {
              return OrderedIntMap<K, V>(Tree(Lf(key, std::move(value))));
            } else {
              return join(key, Tree(Lf(key, std::move(value))), lf->key, tree);
            }

          } else {
            return OrderedIntMap<K, V>(Tree(Lf(key, std::move(value))));
          }
        }

        OrderedIntMap<K, V> erase(K key, bool* found = nullptr) const {
          if (const Br* br = std::get_if<Br>(&tree)) {
            if (match_prefix(key, br->prefix, br->bit)) {
              if (zero_bit(key, br->bit)) {
                return br_left(br->prefix, br->bit,
                  br->left->erase(key, found), br->right);

              } else {
                return br_right(br->prefix, br->bit,
                  br->left, br->right->erase(key, found));
              }

            } else {

              if (found != nullptr) *found = false;
              return OrderedIntMap<K, V>(Tree(tree));
            }

          } else if (const Lf* lf = std::get_if<Lf>(&tree)) {

            if (key == lf->key) {

              if (found != nullptr) *found = true;
              return OrderedIntMap<K, V>();

            } else {

              if (found != nullptr) *found = false;
              return OrderedIntMap<K, V>(Tree(tree));
            }

          } else {

            if (found != nullptr) *found = false;
            return OrderedIntMap<K, V>();
          }
        }

        std::vector<const_iterator> to_vector() const {
          std::vector<const_iterator> vec;
          fill_vector(vec);
          return vec;
        }

        void fill_vector(std::vector<const_iterator>& vec) const {
          fill_vector(vec, true);
        }

      private:

        void fill_vector(std::vector<const_iterator>& vec, bool first_br) const {
          if (const Br* br = std::get_if<Br>(&tree)) {
            if (first_br && (br->bit < 0)) {
              first_br = false;

              br->right->fill_vector(vec, false);
              br->left->fill_vector(vec, false);

            } else {
              br->left->fill_vector(vec, false);
              br->right->fill_vector(vec, false);
            }

          } else if (const Lf* lf = std::get_if<Lf>(&tree)) {
            vec.push_back(const_iterator(lf));
          }
        }

        static OrderedIntMap<K, V> join(K prefix0, Tree&& tree0, K prefix1, const Tree& tree1) {
          K m = branching_bit(prefix0, prefix1);
          if (zero_bit(prefix0, m)) {
            return OrderedIntMap<K, V>(Tree(Br {
              mask(prefix0, m), m,
              StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(Tree(std::move(tree0)))),
              StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(Tree(tree1)))
            }));

          } else {
            return OrderedIntMap<K, V>(Tree(Br {
              mask(prefix0, m), m,
              StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(Tree(tree1))),
              StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(Tree(std::move(tree0))))
            }));
          }
        }

        static OrderedIntMap<K, V> br_left(K prefix, K bit, 
          const OrderedIntMap<K, V>& left,
          const StrongPtr2Alloc<OrderedIntMap<K, V>>& right) {

          if (std::get_if<Nil>(&left.tree)) {
            return *right; 
          } else {
            return OrderedIntMap<K, V>(Tree(Br {
              prefix, bit,
              StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(left)),
              right
            }));
          }
        }

        static OrderedIntMap<K, V> br_right(K prefix, K bit, 
          const StrongPtr2Alloc<OrderedIntMap<K, V>>& left,
          const OrderedIntMap<K, V>& right) {

          if (std::get_if<Nil>(&right.tree)) {
            return *left;
          } else {
            return OrderedIntMap<K, V>(Tree(Br {
              prefix, bit,
              left,
              StrongPtr2Alloc<OrderedIntMap<K, V>>(new OrderedIntMap<K, V>(right))
            }));
          }
        }

        static bool zero_bit(K prefix, K bit) noexcept {
          return OrderedIntMapKey<K>::zero_bit(prefix, bit);
        }

        static K mask(K prefix, K bit) noexcept {
          return OrderedIntMapKey<K>::mask(prefix, bit);
        }

        static K match_prefix(K key, K prefix, K bit) noexcept {
          return OrderedIntMapKey<K>::match_prefix(key, prefix, bit);
        }

        static K branching_bit(K prefix0, K prefix1) noexcept {
          return OrderedIntMapKey<K>::branching_bit(prefix0, prefix1);
        }
      };

      /** An implementation for `int` keys. */
      template<>
      struct OrderedIntMapKey<int> {

        static bool zero_bit(int prefix, int bit) noexcept {
          return (prefix & bit) == 0;
        }

#if defined(DVCOMPUTE_E2K_INTRINSICS)

        static inline int countl_zero(unsigned int x) noexcept {
          return __builtin_e2k_lzcnts(x);
        }

#elif defined(DVCOMPUTE_BIT_EMULATION)

        static int countl_zero(unsigned int x) noexcept {
          int n = 0;
          unsigned int b = 1 << (CHAR_BIT * sizeof(x) - 1);
          
          while (b > 0 && ((b & x) == 0)) {
            b >>= 1;
            ++ n;
          } 

          return n;
        }

#else

        static inline int countl_zero(unsigned int x) noexcept {
          return std::countl_zero(x);
        }

#endif /* DVCOMPUTE_E2K_INTRINSICS || DVCOMPUTE_BIT_EMULATION */

        static int mask(int prefix, int bit) noexcept {
          unsigned int u_prefix = static_cast<unsigned int>(prefix);
          unsigned int u_bit = static_cast<unsigned int>(bit);
          unsigned int u_mask = u_prefix & (static_cast<unsigned int>(- static_cast<int>(u_bit)) ^ u_bit);

          return static_cast<int>(u_mask);
        }

        static int match_prefix(int key, int prefix, int bit) noexcept {
          return mask(key, bit) == prefix;
        }

        static int branching_bit(int prefix0, int prefix1) noexcept {
          unsigned int u_p0 = static_cast<unsigned int>(prefix0);
          unsigned int u_p1 = static_cast<unsigned int>(prefix1);
          unsigned int u_x = u_p0 ^ u_p1;
          unsigned int u_bit = 1 << (CHAR_BIT * sizeof(u_x) - 1 - countl_zero(u_x));

          return static_cast<int>(u_bit);
        }
      };

      /** An implementation for `long` keys. */
      template<>
      struct OrderedIntMapKey<long> {

        static bool zero_bit(long prefix, long bit) noexcept {
          return (prefix & bit) == 0;
        }

#if defined(DVCOMPUTE_E2K_INTRINSICS)

        static inline int countl_zero(unsigned long x) noexcept {
          return __builtin_e2k_lzcntd(x);
        }

#elif defined(DVCOMPUTE_BIT_EMULATION)

        static int countl_zero(unsigned long x) noexcept {
          int n = 0;
          unsigned long b = 1L << (CHAR_BIT * sizeof(x) - 1);
          
          while (b > 0 && ((b & x) == 0)) {
            b >>= 1;
            ++ n;
          } 

          return n;
        }

#else

        static inline int countl_zero(unsigned long x) noexcept {
          return std::countl_zero(x);
        }

#endif /* DVCOMPUTE_E2K_INTRINSICS || DVCOMPUTE_BIT_EMULATION */

        static long mask(long prefix, long bit) noexcept {
          unsigned long u_prefix = static_cast<unsigned long>(prefix);
          unsigned long u_bit = static_cast<unsigned long>(bit);
          unsigned long u_mask = u_prefix & (static_cast<unsigned long>(- static_cast<long>(u_bit)) ^ u_bit);

          return static_cast<long>(u_mask);
        }

        static long match_prefix(long key, long prefix, long bit) noexcept {
          return mask(key, bit) == prefix;
        }

        static long branching_bit(long prefix0, long prefix1) noexcept {
          unsigned long u_p0 = static_cast<unsigned long>(prefix0);
          unsigned long u_p1 = static_cast<unsigned long>(prefix1);
          unsigned long u_x = u_p0 ^ u_p1;
          unsigned long u_bit = 1L << (CHAR_BIT * sizeof(u_x) - 1 - countl_zero(u_x));

          return static_cast<long>(u_bit);
        }
      };

      /** An implementation for `long long` keys. */
      template<>
      struct OrderedIntMapKey<long long> {

        static bool zero_bit(long long prefix, long long bit) noexcept {
          return (prefix & bit) == 0;
        }

#if defined(DVCOMPUTE_E2K_INTRINSICS)

        static inline int countl_zero(unsigned long long x) noexcept {
          return __builtin_e2k_lzcntd(x);
        }

#elif defined(DVCOMPUTE_BIT_EMULATION)

        static int countl_zero(unsigned long long x) noexcept {
          int n = 0;
          unsigned long long b = 1LL << (CHAR_BIT * sizeof(x) - 1);
          
          while (b > 0 && ((b & x) == 0)) {
            b >>= 1;
            ++ n;
          } 

          return n;
        }

#else

        static inline int countl_zero(unsigned long long x) noexcept {
          return std::countl_zero(x);
        }

#endif /* DVCOMPUTE_E2K_INTRINSICS || DVCOMPUTE_BIT_EMULATION */

        static long long mask(long long prefix, long long bit) noexcept {
          unsigned long long u_prefix = static_cast<unsigned long long>(prefix);
          unsigned long long u_bit = static_cast<unsigned long long>(bit);
          unsigned long long u_mask = u_prefix & (static_cast<unsigned long long>(- static_cast<long long>(u_bit)) ^ u_bit);

          return static_cast<long long>(u_mask);
        }

        static long long match_prefix(long long key, long long prefix, long long bit) noexcept {
          return mask(key, bit) == prefix;
        }

        static long long branching_bit(long long prefix0, long long prefix1) noexcept {
          unsigned long long u_p0 = static_cast<unsigned long long>(prefix0);
          unsigned long long u_p1 = static_cast<unsigned long long>(prefix1);
          unsigned long long u_x = u_p0 ^ u_p1;
          unsigned long long u_bit = 1LL << (CHAR_BIT * sizeof(u_x) - 1 - countl_zero(u_x));

          return static_cast<long long>(u_bit);
        }
      };

      /** An implementation for `unsigned int` keys. */
      template<>
      struct OrderedIntMapKey<unsigned int> {

        static bool zero_bit(unsigned int prefix, unsigned int bit) noexcept {
          return (prefix & bit) == 0;
        }

#if defined(DVCOMPUTE_E2K_INTRINSICS)

        static inline int countl_zero(unsigned int x) noexcept {
          return __builtin_e2k_lzcnts(x);
        }

#elif defined(DVCOMPUTE_BIT_EMULATION)

        static int countl_zero(unsigned int x) noexcept {
          int n = 0;
          unsigned int b = 1 << (CHAR_BIT * sizeof(x) - 1);
          
          while (b > 0 && ((b & x) == 0)) {
            b >>= 1;
            ++ n;
          } 

          return n;
        }

#else

        static inline int countl_zero(unsigned int x) noexcept {
          return std::countl_zero(x);
        }

#endif /* DVCOMPUTE_E2K_INTRINSICS || DVCOMPUTE_BIT_EMULATION */

        static unsigned int mask(unsigned int prefix, unsigned int bit) noexcept {
          unsigned int u_prefix = prefix;
          unsigned int u_bit = bit;
          unsigned int u_mask = u_prefix & (static_cast<unsigned int>(- static_cast<int>(u_bit)) ^ u_bit);

          return u_mask;
        }

        static unsigned int match_prefix(unsigned int key, unsigned int prefix, unsigned int bit) noexcept {
          return mask(key, bit) == prefix;
        }

        static unsigned int branching_bit(unsigned int prefix0, unsigned int prefix1) noexcept {
          unsigned int u_p0 = prefix0;
          unsigned int u_p1 = prefix1;
          unsigned int u_x = u_p0 ^ u_p1;
          unsigned int u_bit = 1 << (CHAR_BIT * sizeof(u_x) - 1 - countl_zero(u_x));

          return u_bit;
        }
      };

      /** An implementation for `unsigned long` keys. */
      template<>
      struct OrderedIntMapKey<unsigned long> {

        static bool zero_bit(unsigned long prefix, unsigned long bit) noexcept {
          return (prefix & bit) == 0;
        }

#if defined(DVCOMPUTE_E2K_INTRINSICS)

        static inline int countl_zero(unsigned long x) noexcept {
          return __builtin_e2k_lzcntd(x);
        }

#elif defined(DVCOMPUTE_BIT_EMULATION)

        static int countl_zero(unsigned long x) noexcept {
          int n = 0;
          unsigned long b = 1L << (CHAR_BIT * sizeof(x) - 1);
          
          while (b > 0 && ((b & x) == 0)) {
            b >>= 1;
            ++ n;
          } 

          return n;
        }

#else

        static inline int countl_zero(unsigned long x) noexcept {
          return std::countl_zero(x);
        }

#endif /* DVCOMPUTE_E2K_INTRINSICS || DVCOMPUTE_BIT_EMULATION */

        static unsigned long mask(unsigned long prefix, unsigned long bit) noexcept {
          unsigned long u_prefix = prefix;
          unsigned long u_bit = bit;
          unsigned long u_mask = u_prefix & (static_cast<unsigned long>(- static_cast<long>(u_bit)) ^ u_bit);

          return u_mask;
        }

        static unsigned long match_prefix(unsigned long key, unsigned long prefix, unsigned long bit) noexcept {
          return mask(key, bit) == prefix;
        }

        static unsigned long branching_bit(unsigned long prefix0, unsigned long prefix1) noexcept {
          unsigned long u_p0 = prefix0;
          unsigned long u_p1 = prefix1;
          unsigned long u_x = u_p0 ^ u_p1;
          unsigned long u_bit = 1L << (CHAR_BIT * sizeof(u_x) - 1 - countl_zero(u_x));

          return u_bit;
        }
      };

      /** An implementation for `unsigned long long` keys. */
      template<>
      struct OrderedIntMapKey<unsigned long long> {

        static bool zero_bit(unsigned long long prefix, unsigned long long bit) noexcept {
          return (prefix & bit) == 0;
        }

#if defined(DVCOMPUTE_E2K_INTRINSICS)

        static inline int countl_zero(unsigned long long x) noexcept {
          return __builtin_e2k_lzcntd(x);
        }

#elif defined(DVCOMPUTE_BIT_EMULATION)

        static int countl_zero(unsigned long long x) noexcept {
          int n = 0;
          unsigned long long b = 1LL << (CHAR_BIT * sizeof(x) - 1);
          
          while (b > 0 && ((b & x) == 0)) {
            b >>= 1;
            ++ n;
          } 

          return n;
        }

#else

        static inline int countl_zero(unsigned long long x) noexcept {
          return std::countl_zero(x);
        }

#endif /* DVCOMPUTE_E2K_INTRINSICS || DVCOMPUTE_BIT_EMULATION */

        static unsigned long long mask(unsigned long long prefix, unsigned long long bit) noexcept {
          unsigned long long u_prefix = prefix;
          unsigned long long u_bit = bit;
          unsigned long long u_mask = u_prefix & (static_cast<unsigned long long>(- static_cast<long long>(u_bit)) ^ u_bit);

          return u_mask;
        }

        static unsigned long long match_prefix(unsigned long long key, unsigned long long prefix, unsigned long long bit) noexcept {
          return mask(key, bit) == prefix;
        }

        static unsigned long long branching_bit(unsigned long long prefix0, unsigned long long prefix1) noexcept {
          unsigned long long u_p0 = prefix0;
          unsigned long long u_p1 = prefix1;
          unsigned long long u_x = u_p0 ^ u_p1;
          unsigned long long u_bit = 1LL << (CHAR_BIT * sizeof(u_x) - 1 - countl_zero(u_x));

          return u_bit;
        }
      };
    }
  }
}

#endif /* dvcompute_ordered_int_map_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_utils_path_h
#define dvcompute_utils_path_h

#ifdef DVCOMPUTE_CXX_FILESYSTEM
#include <filesystem>
#else
#include <sys/stat.h>
#include <sys/types.h>
#include <fstream>
#endif

#include <string>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/macros.h"

namespace DVCOMPUTE_NS {

  namespace utils {

    namespace path {

#ifdef DVCOMPUTE_CXX_FILESYSTEM

      /** The file path. */
      using FilePath = std::filesystem::path;

      /** Convert the path to string. */
      inline std::string path_to_string(const FilePath& path) {
        return path.string();
      }

      /** Resolve the file path. */
      inline FilePath resolve_file_path(const FilePath& path) {
        if (std::filesystem::exists(path)) {
          FilePath path0 { path };
          FilePath filename0 { path0.filename() };
          int i = 2;
          while (true) {
            path0.replace_filename(path_to_string(filename0) + " (" + std::to_string(i) + ")");
            if (std::filesystem::exists(path0)) {
              ++i;
            } else {
              return path0;
            }
          }

        } else {
          return path;
        }
      }

      /** Make a new directory by the specified file path. */
      inline bool make_directory(const FilePath& path) {
        return std::filesystem::create_directory(path);
      }

      /** Append a new file path. */
      inline FilePath append_path(const FilePath& path, const FilePath& next) {
        return path / next;
      }

      /** Get the file name. */
      inline FilePath path_file_name(const FilePath& path) {
        return path.filename();
      }

#else

      /** The file path. */
      using FilePath = std::string;

      namespace {

        /** Test whether the file exists. */
        inline bool file_exists(const FilePath& path) {
          std::fstream file(path.c_str(), std::ios_base::in);
          return file.good();
        }
      }

      /** Convert the path to string. */
      inline std::string path_to_string(const FilePath& path) {
        return path;
      }

      /** Resolve the file path. */
      inline FilePath resolve_file_path(const FilePath& path) {
        if (file_exists(path)) {
          FilePath filename0 { path };
          int i = 2;
          while (true) {
            FilePath path0 { filename0 + " (" + std::to_string(i) + ")" };
            if (file_exists(path0)) {
              ++i;
            } else {
              return path0;
            }
          }

        } else {
          return path;
        }
      }

      inline bool make_directory(const FilePath& path) {
        return (mkdir(path.c_str(), S_IRWXU | S_IRWXG | S_IROTH) == 0);
      }

      /** Append a new file path. */
      inline FilePath append_path(const FilePath& path, const FilePath& next) {
        return path + '/' + next;
      }

      /** Get the file name. */
      inline FilePath path_file_name(const FilePath& path) {
        auto i = path.rfind("/");
        if (i == std::string::npos) {
          return path;
        } else {
          return path.substr(1 + i);
        }
      }

#endif /* DVCOMPUTE_CXX_FILESYSTEM */
    }
  }
}

#endif /* dvcompute_utils_path_h */

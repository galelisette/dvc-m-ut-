/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_src_strong_ptr_h
#define dvcompute_src_strong_ptr_h

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  /** A shared container optimized for single-threaded execution. */
  template<typename Item>
  class StrongPtr {
  
    struct Cell {
      int count;
      Item item;
      
      explicit Cell(const Item& item_arg) : count(1), item(item_arg) {}
      explicit Cell(Item&& item_arg) : count(1), item(std::move(item_arg)) {}
    };
    
    Cell* cell;
    
    Cell* incref() const noexcept {
      if (cell) {
        ++(cell->count);
      }
      return cell;
    }
    
    void decref() {
      if (--(cell->count) == 0) {
        delete cell;
      }
    }
    
    explicit StrongPtr(const Item& item_arg) : cell(new Cell(item_arg)) {}
    
    explicit StrongPtr(Item&& item_arg) : cell(new Cell(std::move(item_arg))) {}

    template<typename Item2>
    friend inline StrongPtr<Item2> mk_strong(const Item2& item_arg);

    template<typename Item2>
    friend inline StrongPtr<Item2> mk_strong(Item2&& item_arg);
    
  public:
    
    explicit StrongPtr() noexcept : cell(nullptr) {}

    StrongPtr(const StrongPtr<Item>& other) noexcept : cell(other.incref()) {}
    
    StrongPtr(StrongPtr<Item>&& other) noexcept : cell(other.cell) {
      other.cell = nullptr;
    }

    StrongPtr& operator=(const StrongPtr<Item>& other) noexcept {
      StrongPtr tmp { other };
      swap(tmp);
      return *this;
    }
    
    StrongPtr& operator=(StrongPtr<Item>&& other) noexcept {
      StrongPtr tmp { std::move(other) };
      swap(tmp);
      return *this;
    }
    
    ~StrongPtr() {
      if (cell) decref();
    }
    
    Item* operator->() const noexcept {
      return &cell->item;
    }
    
    Item& operator*() const noexcept {
      return cell->item;
    }
    
    Item* get() const noexcept {
      return cell ? &cell->item : nullptr;
    }

    void swap(StrongPtr<Item>& other) noexcept {
      Cell *tmp = cell;
      cell = other.cell;
      other.cell = tmp;
    }

    void reset(Item&& item) {
      StrongPtr<Item> tmp(std::move(item));
      swap(tmp);
    }
  };

  template<typename Item>
  inline bool operator==(const StrongPtr<Item>& lhs, const StrongPtr<Item>& rhs) noexcept {
    return lhs.get() == rhs.get();
  }

  template<typename Item>
  inline bool operator!=(const StrongPtr<Item>& lhs, const StrongPtr<Item>& rhs) noexcept {
    return lhs.get() != rhs.get();
  }

  template<typename Item>
  inline StrongPtr<Item> mk_strong(const Item& item) {
    return StrongPtr<Item>(item);
  }

  template<typename Item>
  inline StrongPtr<Item> mk_strong(Item&& item) {
    return StrongPtr<Item>(std::move(item));
  }
}

#endif /* dvcompute_src_strong_ptr_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_shared_ptr_h
#define dvcompute_shared_ptr_h

#include <memory>
#include <utility>
#include <cassert>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/utils/thread_local_storage.h"

namespace DVCOMPUTE_NS {

  /** Allows creating objects in place. */
  class SharedPtrFn {};

  /** Allows creating objects later. */
  class SharedPtrLateInit {};

  /** A weak pointer optimized for single-threaded execution. */
  template<typename Item>
  class WeakPtr;

  /** A shared pointer optimized for single-threaded execution. */
  template<typename Item>
  class SharedPtr {

    friend class WeakPtr<Item>;
  
    class Cell : public DVCOMPUTE_NS::utils::ThreadLocalObject {
    public:

      int use_count;
      int weak_count;

      bool non_empty;

      union {
        Item item;
      };

      explicit Cell(const Item& item_arg) : 
        use_count(1), weak_count(0), non_empty(false), item(item_arg) 
      {
        non_empty = true;
      }

      explicit Cell(Item&& item_arg) noexcept(noexcept(Item(std::move(item_arg)))) : 
        use_count(1), weak_count(0), non_empty(false), item(std::move(item_arg)) 
      {
        non_empty = true;
      }

      template<typename Fn>
      Cell(SharedPtrFn tag, Fn&& fn) : 
        use_count(1), weak_count(0), non_empty(false)
      {
        fn(&item);
        non_empty = true;
      }

      Cell(SharedPtrLateInit tag) : 
        use_count(1), weak_count(0), non_empty(false)
      {}

      ~Cell() {
        if (non_empty) {
          std::destroy_at(&item);
        }
      }

      void free_object() noexcept override {
        if (non_empty) {
          non_empty = false;
          std::destroy_at(&item);
        }
      }
    };
    
    Cell* cell;
    
    Cell* incref() const noexcept {
      if (cell) {
        ++(cell->use_count);
      }

      return cell;
    }
    
    void decref() {
      if (--(cell->use_count) == 0) {
        if (cell->weak_count == 0) {
          std::destroy_at(cell);
          DVCOMPUTE_NS::utils::deallocate_thread_local_object(cell);

        } else {
          decref_weak();
        }
      }
    }

    void decref_weak() {
      if (cell->non_empty) {

        ++(cell->use_count);
        cell->non_empty = false;
        std::destroy_at(&(cell->item));
        --(cell->use_count);

        if (cell->weak_count == 0) {
          std::destroy_at(cell);
          DVCOMPUTE_NS::utils::deallocate_thread_local_object(cell);
        }
      }
    }
    
    explicit SharedPtr(Cell *cell_arg) noexcept : cell(cell_arg) {
      if (cell) {
        ++(cell->use_count);
      }
    }

    explicit SharedPtr(const Item& item) : cell(nullptr) {
      DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
      if (address) {
        new(address.get()) Cell(item);
      }
      cell = reinterpret_cast<Cell*>(address.release());
    }
    
    explicit SharedPtr(Item&& item) : cell(nullptr) {
      DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
      if (address) {
        new(address.get()) Cell(std::move(item));
      }
      cell = reinterpret_cast<Cell*>(address.release());
    }
    
    template<typename Item2>
    friend inline SharedPtr<Item2> mk_shared(const Item2& item_arg);

    template<typename Item2>
    friend inline SharedPtr<Item2> mk_shared(Item2&& item_arg);

    public:

    explicit SharedPtr() noexcept : cell(nullptr) {}
    
    template<typename Fn>
    SharedPtr(SharedPtrFn tag, Fn&& fn) : cell(nullptr) {
      DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
      if (address) {
        new(address.get()) Cell(tag, std::move(fn));
      }
      cell = reinterpret_cast<Cell*>(address.release());
    }

    explicit SharedPtr(SharedPtrLateInit tag) : cell(nullptr) {
      DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
      if (address) {
        new(address.get()) Cell(tag);
      }
      cell = reinterpret_cast<Cell*>(address.release());
    }

    SharedPtr(const SharedPtr<Item>& other) noexcept : cell(other.incref()) {}
    
    SharedPtr(SharedPtr<Item>&& other) noexcept : cell(other.cell) {
      other.cell = nullptr;
    }
    
    SharedPtr& operator=(const SharedPtr<Item>& other) noexcept {
      SharedPtr tmp { other };
      swap(tmp);
      return *this;
    }
    
    SharedPtr& operator=(SharedPtr<Item>&& other) noexcept {
      SharedPtr tmp { std::move(other) };
      swap(tmp);
      return *this;
    }
    
    ~SharedPtr() {
      if (cell) decref();
    }
    
    Item* operator->() const noexcept {
      return &(cell->item);
    }
    
    Item& operator*() const noexcept {
      return cell->item;
    }
    
    Item* get() const noexcept {
      return cell && cell->non_empty ? &(cell->item) : nullptr;
    }
      
    void swap(SharedPtr<Item>& other) noexcept {
      Cell *tmp = cell;
      cell = other.cell;
      other.cell = tmp;
    }

    operator bool() const noexcept {
      return (cell != nullptr) && cell->non_empty;
    }

    void reset(Item&& item) {
      SharedPtr<Item> tmp { mk_shared(std::move(item)) };
      swap(tmp);
    }
    
    void late_init(Item&& item) {
      if (cell) {
        if (cell->non_empty) {
          assert(false && "The object had to be empty.");
          std::destroy_at(&(cell->item));
        }

        new(&(cell->item)) Item(std::move(item));
        cell->non_empty = true;

      } else {
        DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
        if (address) { 
          new(address.get()) Cell(std::move(item)); 
        }
        cell = reinterpret_cast<Cell*>(address.release());
      }
    }

    template<typename Fn>
    void late_init(SharedPtrFn tag, Fn&& fn) {
      if (cell) {
        if (cell->non_empty) {
          assert(false && "The object had to be empty.");
          std::destroy_at(&(cell->item));
        }

        fn(&(cell->item));
        cell->non_empty = true;

      } else {
        DVCOMPUTE_NS::utils::ThreadLocalObjectPtr address(sizeof(Cell));
        if (address) { 
          new(address.get()) Cell(tag, std::move(fn)); 
        }
        cell = reinterpret_cast<Cell*>(address.release());
      }
    }
  };

  /** A weak pointer optimized for single-threaded execution. */
  template<typename Item>
  class WeakPtr {

    friend class SharedPtr<Item>;
  
    using Cell = typename SharedPtr<Item>::Cell;
    
    Cell* cell;
    
    Cell* incref() const noexcept {
      if (cell) {
        ++(cell->weak_count);
      }

      return cell;
    }
    
    void decref() {
      if (--(cell->weak_count) == 0) {
        if (cell->use_count == 0) {
          assert(!(cell->non_empty) && "The item must be already destroyed");
          std::destroy_at(cell);
          DVCOMPUTE_NS::utils::deallocate_thread_local_object(cell);
        }
      }
    }

    explicit WeakPtr() noexcept : cell(nullptr) {}
    
  public:
    
    explicit WeakPtr(const SharedPtr<Item>& other) noexcept : cell(other.cell) {
      incref();
    }

    WeakPtr(const WeakPtr<Item>& other) noexcept : cell(other.incref()) {}
    
    WeakPtr(WeakPtr<Item>&& other) noexcept : cell(other.cell) {
      other.cell = nullptr;
    }
    
    WeakPtr& operator=(const WeakPtr<Item>& other) noexcept {
      WeakPtr tmp { other };
      swap(tmp);
      return *this;
    }
    
    WeakPtr& operator=(WeakPtr<Item>&& other) noexcept {
      WeakPtr tmp { std::move(other) };
      swap(tmp);
      return *this;
    }
    
    ~WeakPtr() {
      if (cell) decref();
    }
    
    SharedPtr<Item> lock() const noexcept {
      return SharedPtr<Item>(cell && cell->non_empty ? cell : nullptr);
    }

    void swap(WeakPtr<Item>& other) noexcept {
      Cell *tmp = cell;
      cell = other.cell;
      other.cell = tmp;
    }

    bool expired() const noexcept {
      return (cell == nullptr) || !(cell->non_empty);
    }
  };

  template<typename Item>
  inline bool operator==(const SharedPtr<Item>& lhs, const SharedPtr<Item>& rhs) noexcept {
    if (lhs) {
      if (rhs) {
        return lhs.get() == rhs.get();
      } else {
        return false;
      }

    } else {
      if (rhs) {
        return false;
      } else {
        return true;
      }
    }
  }

  template<typename Item>
  inline bool operator!=(const SharedPtr<Item>& lhs, const SharedPtr<Item>& rhs) noexcept {
    return !(lhs == rhs);
  }

  template<typename Item>
  inline SharedPtr<Item> mk_shared(const Item& item) {
    return SharedPtr<Item>(item);
  }

  template<typename Item>
  inline SharedPtr<Item> mk_shared(Item&& item) {
    return SharedPtr<Item>(std::move(item));
  }
}

#endif /* dvcompute_shared_ptr_h */

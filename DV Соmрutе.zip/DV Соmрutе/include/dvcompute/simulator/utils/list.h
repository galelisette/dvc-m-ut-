/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_list_h
#define dvcompute_list_h

#include <optional>
#include <tuple>
#include <cassert>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/basic/types.h"

namespace DVCOMPUTE_NS {

  namespace utils {
  
    namespace im {

      /** An immutable list. */
      template<typename T>
      class List {

        struct Cell {
          T head;
          List<T> tail;
        };

        StrongPtr2Alloc<Cell> cell;

        List(StrongPtr2Alloc<Cell>&& cell_arg) noexcept : cell(std::move(cell_arg)) {}

      public:

        class ConstIterator {

          StrongPtr2Alloc<Cell> cell;

          friend class List<T>;

          ConstIterator(const StrongPtr2Alloc<Cell>& cell_arg) noexcept : cell(cell_arg) {}

        public:

          explicit ConstIterator() : cell() {}
          
          ConstIterator(const ConstIterator&) = default;
          ConstIterator(ConstIterator&&) = default;

          ConstIterator& operator=(const ConstIterator&) = default;
          ConstIterator& operator=(ConstIterator&&) = default;

          const T* operator->() const noexcept {
            return &cell->head;
          }

          const T& operator*() const noexcept {
            return cell->head;
          }

          const T* get() const noexcept {
            return &cell->head;
          }

          bool empty() const noexcept {
            return cell.get() == nullptr;
          }

          ConstIterator& operator++() {
            assert(cell && "The cell cannot be empty");
            cell = cell->tail.cell;
            return *this;
          }

          ConstIterator operator++(int) {
            assert(cell && "The cell cannot be empty");
            ConstIterator tmp { cell };
            cell = cell->tail.cell;
            return tmp;
          }

          bool operator==(const ConstIterator& other) const noexcept {
            return cell == other.cell;
          }

          bool operator!=(const ConstIterator& other) const noexcept {
            return cell != other.cell;
          }
        };

        using const_iterator = ConstIterator;

        const_iterator begin() const {
          return ConstIterator(cell);
        }

        const_iterator end() const {
          return ConstIterator();
        }

        /** An empty list. */
        explicit List() : cell() {}

        explicit List(const std::vector<T>& xs) {
          List<T> res;
          for (size_t i = 0; i < xs.size(); ++ i) {
            size_t j = (xs.size() - 1) - i;
            res = std::move(List<T>(StrongPtr2Alloc<Cell>(new Cell {
              xs[j], res
            })));
          }
          *this = res;
        }

        explicit List(const T& item_arg, const List<T>& tail_arg) :
          List(StrongPtr2Alloc<Cell>(new Cell {
            item_arg, tail_arg
          }))
        {}

        List(const List&) = default;
        List(List&&) = default;

        List& operator=(const List&) = default;
        List& operator=(List&&) = default;

        bool empty() const noexcept {
          return cell.get() == nullptr;
        }

        const T& head() const {
          return cell->head;
        }

        List<T> tail() const {
          return cell->tail;
        }

        /** Return a singleton. */
        static List singleton(const T& item) {
          return List(item, List());
        }

        /** Remove the specified item from the list. */
        std::optional<List<T>> erase(const T& item) const {
          List<T> first;
          List<T> curr { *this };
          while (true) {
            if (curr.empty()) {
              return std::nullopt;
            } else if (curr.cell->head == item) {
              return first.append_rev(curr.cell->tail);
            } else {
              first = std::move(List<T>(StrongPtr2Alloc<Cell>(new Cell {
                curr.cell->head, first
              })));
              curr = curr.cell->tail;
            }
          }
        }

        /** Remove an item satisfying the specified predicate. */
        template<typename Fn>
        std::optional<std::tuple<T, List<T>>> erase_by(const Fn& pred) const {
          List<T> first;
          List<T> curr { *this };
          while (true) {
            if (curr.empty()) {
              return std::nullopt;
            } else if (pred(curr.cell->head)) {
              return std::tuple<T, List<T>>(curr.cell->head, first.append_rev(curr.cell->tail));
            } else {
              first = std::move(List<T>(StrongPtr2Alloc<Cell>(new Cell {
                curr.cell->head, first
              })));
              curr = curr.cell->tail;
            }
          }
        }

        /** Test whether there is an item satisfying the specified predicate. */
        template<typename Fn>
        bool exists(const Fn& pred) const {
          List<T> curr { *this };
          while (true) {
            if (curr.empty()) {
              return false;
            } else if (pred(curr.cell->head)) {
              return true;
            } else {
              curr = curr.cell->tail;
            }
          }
        }

        /** Find an item satisfying the specified predicate. */
        template<typename Fn>
        const_iterator find(const Fn& pred) const {
          List<T> curr { *this };
          while (true) {
            if (curr.empty()) {
              return ConstIterator();
            } else if (pred(curr.cell->head)) {
              return ConstIterator(curr.cell);
            } else {
              curr = curr.cell->tail;
            }
          }
        }

        /** Revert the items of the list. */
        List<T> reversed() const {
          return append_rev(List<T>());
        }

        /** Append the current list to another one. */
        List<T> append(const List<T>& other) const {
          return reversed().append_rev(other);
        }

      private:

        /** Append the reversed items to the list tail. */
        List<T> append_rev(List<T> tail) const {
          List<T> result { tail };
          List<T> curr { *this };
          while (true) {
            if (curr.empty()) {
              return result;
            } else {
              List<T> x { StrongPtr2Alloc<Cell>( new Cell {
                curr.cell->head, result
              })};
              curr = curr.cell->tail;
              if (curr.empty()) {
                return x;
              } else {
                result = std::move(x);
              }
            }
          }
        }
      };
    }
  }
}

#endif /* dvcompute_list_h */

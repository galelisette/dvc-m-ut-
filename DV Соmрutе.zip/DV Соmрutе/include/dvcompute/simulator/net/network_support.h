/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_net_network_support_h
#define dvcompute_net_network_support_h

#include <vector>
#include <optional>
#include <memory>

#include "../../dvcompute_ns.h"
#include "../../dvcompute_api.h"

namespace DVCOMPUTE_NS {

  /** The network exception. */
  class DVCOMPUTE_API NetworkSupportError : public std::exception {
  public:
    
    explicit NetworkSupportError() {}
  };

  /** Represents an asynchronous request. */
  class DVCOMPUTE_API NetworkSupportRequest {
  public:
    
    /** The data buffer. */
    std::vector<char> buf;
    
    explicit NetworkSupportRequest(std::vector<char>&& buf_arg) noexcept : buf(std::move(buf_arg)) {}
    
    NetworkSupportRequest(const NetworkSupportRequest&) = delete;
    NetworkSupportRequest(NetworkSupportRequest&&) = delete;

    NetworkSupportRequest& operator=(const NetworkSupportRequest&) = delete;
    NetworkSupportRequest& operator=(NetworkSupportRequest&&) = delete;
    
    virtual ~NetworkSupportRequest() {}
  };

  /** Supports some network such as MPI. */
  class DVCOMPUTE_API NetworkSupport {
  public:

    virtual ~NetworkSupport() {}
    
    /** Get the size */
    virtual int size() = 0;
    
    /** Get the rank. */
    virtual int rank() = 0;
    
    /** Probes for incomming messages. */
    virtual bool iprobe() = 0;

    /** Returns a special value that designates any source. */
    virtual int any_source() = 0;
    
    /** Receive the incomming data, the rank of the sender's logical process and a flag whether the operation is successful. */
    virtual bool recv(std::vector<char>& buf, int* src) = 0;
    
    /** Abort the simulation with the specified code. */
    virtual void abort(int32_t code) = 0;
    
    /** Make an asynchronous request to the specfied destination. */
    virtual std::unique_ptr<NetworkSupportRequest> isend(int dest, std::vector<char>&& buf) = 0;
    
    /** Send the message synchronously to the specified destination. */
    virtual void send(int dest, const std::vector<char>& buf) = 0;
    
    /** Test whether the asynchronous request has been completed. */
    virtual bool test(NetworkSupportRequest* req) = 0;

    /** Wait until the asynchronous request has been completed. */
    virtual void wait(NetworkSupportRequest* req) = 0;

    /** Cancel the asynchronous request. */
    virtual void cancel(NetworkSupportRequest* req) = 0;

    /** Block until the barrier has passed by all logical processes. */
    virtual void barrier() = 0;
  };
}

#endif /* dvcompute_net_network_support */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_net_messaging_h
#define dvcompute_net_messaging_h

#include <memory>
#include <vector>

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/dvcompute_api.h"
#include "dvcompute/simulator/basic/result.h"
#include "dvcompute/simulator/basic/observer.h"
#include "dvcompute/simulator/basic/observable.h"
#include "dvcompute/simulator/basic/specs.h"
#include "dvcompute/simulator/net/serialize.h"
#include "dvcompute/simulator/net/lp_id.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace messaging {

      /** @private */
      DVCOMPUTE_API void enqueue_message(LogicalProcessId pid, double receive_time, std::vector<char>&& buf, const Point* p);

      /** @private */
      DVCOMPUTE_API Observable<std::shared_ptr<std::vector<char>>> input_messages(const Run *r);

      /** @private */
      template<typename Message>
      class InputMessages {
      public:
        
        explicit InputMessages() {}

        InputMessages(const InputMessages& other) = default;
        InputMessages(InputMessages&& other) = default;

        InputMessages& operator=(const InputMessages& other) = default;
        InputMessages& operator=(InputMessages&& other) = default;

        template<typename Obs>
        auto operator()(Obs &&obs) {
          return cons_event([obs{std::move(obs)}](const Point* p) mutable {
            const Run *r = p->run;
            auto observer = cons_observer([obs{std::move(obs)}](const std::shared_ptr<std::vector<char>>* msg, const Point* p) {

              Message msg2;
              try {
                std::vector<char> &buf = *(msg->get());
                deserialize(&buf[0], &buf[0] + buf.size(), msg2);
              
              } catch (UnexpectedEndOfMessageError&) {
                // we don't allow such errors
                throw;
                
              } catch (DeserializerError&) {
                // this is not a message we want to receive
                return Result<Unit>(Unit());
              }
              
              return obs(&msg2, p);
            });
            
            return input_messages(r).subscribe(std::move(observer))(p);
          });
        }
      };
    }
  }

  /**
   * Enqueue within `Event<Unit>` computaton the specified message that
   * should be triggered at the specified modeling time in the provided logical process.
   */
  template<typename Message>
  auto enqueue_message(LogicalProcessId pid, double receive_time, Message&& msg) {
    auto fn = [pid, receive_time, msg{std::move(msg)}](const Point *p) mutable {
      internal::messaging::enqueue_message(pid, receive_time, std::move(serialize(msg)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Send within `Event<Unit>` computaton the specified message that
   * should be delivered to the logical process with the given time delay.
   */
  template<typename Message>
  auto send_message(LogicalProcessId pid, double dt, Message&& msg) {
    auto fn = [pid, dt, msg{std::move(msg)}](const Point *p) mutable {
      internal::messaging::enqueue_message(pid, p->time + dt, std::move(serialize(msg)), p);
      return Result<Unit>(Unit());
    };
    return Event<Unit, decltype(fn)>(std::move(fn));
  }

  /**
   * Return an `Observable<Message>` computation for incoming messages that
   * come from other logical processes.
   */
  template<typename Message>
  auto input_messages() {
    internal::messaging::InputMessages<Message> impl;
    return Observable<Message, decltype(impl)>(std::move(impl));
  }
}

#endif /* dvcompute_net_messaging_h */

/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_net_serialize_h
#define dvcompute_net_serialize_h

#include <cstddef>
#include <vector>
#include <exception>
#include <optional>
#include <memory>

#include "../../dvcompute_ns.h"
#include "../../dvcompute_api.h"

namespace DVCOMPUTE_NS {

  /** To add the object consistency. */
  struct ExpectedUUID {
    
    /** The expected identifier. */
    uint64_t expected_uuid;
    
    /** The possible error message. */
    const char* error_message;
  };

  namespace uuids {
  
    constexpr ExpectedUUID optional_uuid { 879554914ULL, "Expeced the optional value" };
    constexpr ExpectedUUID vector_uuid { 1252176671ULL, "Expected the vector of objects" };
    constexpr ExpectedUUID shared_ptr_uuid { 1418935124ULL, "Expected a pointer to object" };
  }

  /** The exception that may occur during serialization. */
  class SerializerError : public std::exception {
  public:
    
    SerializerError() {}
  };

  /** Serializer */
  class Serializer {
  
    /** The buffer of date. */
    std::vector<char> buf;
    
  public:
    
    Serializer() : buf() {}

    /** Take the data. */
    void take_data(std::vector<char>& data) noexcept {
      data = std::move(buf);
    }
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, char x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, int16_t x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, int32_t x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, int64_t x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, uint16_t x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, uint32_t x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, uint64_t x);

    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, double x);
    
    friend DVCOMPUTE_API Serializer& operator<<(Serializer& ser, bool x);
  };

  inline Serializer& operator<<(Serializer& ser, char x) {
    ser.buf.push_back(x);
    return ser;
  }

  inline Serializer& operator<<(Serializer& ser, const ExpectedUUID& x) {
    return ser << x.expected_uuid;
  }

  template<typename Item>
  Serializer& operator<<(Serializer& ser, const std::optional<Item>& x) {
    ser << uuids::optional_uuid;
    if (x.has_value()) {
      return ser << static_cast<char>(1) << x;
    } else {
      return ser << static_cast<char>(0);
    }
  }

  template<typename Item>
  Serializer& operator<<(Serializer& ser, const std::vector<Item>& xs) {
    ser << uuids::vector_uuid;
    ser << static_cast<uint64_t>(xs.size());
    for (const Item &item : xs) {
      ser << item;
    }
    return ser;
  }

  template<typename Item>
  Serializer& operator<<(Serializer& ser, const std::shared_ptr<Item>& x) {
    ser << uuids::shared_ptr_uuid;
    if (x.get() != nullptr) {
      const Item &item = *x;
      return ser << static_cast<char>(1) << item;
    } else {
      return ser << static_cast<char>(0);
    }
  }

  /** The exception that may occur during deserialization. */
  class DeserializerError : public std::exception {
    const char* msg;
    
  public:
    
    DeserializerError() : msg(nullptr) {}
    
    explicit DeserializerError(const char* msg_arg) : msg(msg_arg) {}
    
    const char* what() const noexcept override { return msg; }
  };

  /** The exception that indicates that an unexpected end of message has received. */
  class UnexpectedEndOfMessageError : public DeserializerError {
  public:
    
    UnexpectedEndOfMessageError() {}
    
    explicit UnexpectedEndOfMessageError(const char* msg_arg) : DeserializerError(msg_arg) {}
  };

  /** Deserializer */
  class Deserializer {
    
    /** The end of the buffer. */
    const char *end;
    
    /** The position. */
    const char *pos;
    
  public:
    
    Deserializer(const char *begin_arg, const char *end_arg) noexcept :
      end(end_arg),
      pos(begin_arg)
    {}

    /** Peek the data without changing the position. */
    char peek() const {
      require_data(1);
      return *pos;
    }
    
    /** Whether there is data. */
    operator bool() const noexcept {
      return (pos < end);
    }
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, char& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, int16_t& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, int32_t& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, int64_t& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, uint16_t& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, uint32_t& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, uint64_t& x);

    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, double& x);
    
    friend DVCOMPUTE_API Deserializer& operator>>(Deserializer& ser, bool& x);

  private:

    /** Require that there is the specified amount of data. */
    void require_data(size_t len) const {
      if (pos + len > end) {
        throw DeserializerError("There is no required data");
      }
    }
  };

  inline Deserializer& operator>>(Deserializer& deser, char& x) {
    deser.require_data(1);
    x = *(deser.pos++);
    return deser;
  }

  inline Deserializer& operator>>(Deserializer& deser, ExpectedUUID x) {
    uint64_t uuid;
    deser >> uuid;
    if (uuid != x.expected_uuid) {
      throw DeserializerError(x.error_message);
    }
    return deser;
  }

  template<typename Item>
  Deserializer& operator>>(Deserializer& deser, std::optional<Item>& x) {
    char ch;
    deser >> uuids::optional_uuid >> ch;
    if (ch == 0) {
      x = std::nullopt;
    } else if (ch == 1) {
      deser >> *x;
    } else {
      throw DeserializerError();
    }
    return deser;
  }

  template<typename Item>
  Deserializer& operator>>(Deserializer& deser, std::vector<Item>& xs) {
    uint64_t len;
    deser >> uuids::vector_uuid >> len;
    xs.clear();
    for (uint64_t i = 0; i < len; ++ i) {
      Item item;
      deser >> item;
      xs.emplace_back(std::move(item));
    }
    return deser;
  }

  template<typename Item>
  Deserializer& operator>>(Deserializer& deser, std::shared_ptr<Item>& x) {
    char ch;
    deser >> uuids::shared_ptr_uuid >> ch;
    if (ch == 0) {
      x.reset();
    } else if (ch == 1) {
      Item item;
      deser >> item;
      x.reset(new Item { std::move(item) });
    } else {
      throw DeserializerError();
    }
    return deser;
  }

  /** Serialize or throw SerializerError. */
  template<typename Item>
  std::vector<char> serialize(const Item& item) {
    Serializer ser;
    ser << item;
    std::vector<char> result;
    ser.take_data(result);
    return result;
  }

  /** Deserialize or throw DeserializerError. */
  template<typename Item>
  void deserialize(const char *begin, const char *end, Item& item) {
    Deserializer deser(begin, end);
    deser >> item;
    if (deser) {
      throw UnexpectedEndOfMessageError("The buffer remains non-empty");
    }
  }
}

#endif /* dvcompute_net_serialize_h */

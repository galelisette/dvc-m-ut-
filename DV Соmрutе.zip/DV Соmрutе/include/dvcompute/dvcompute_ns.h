/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_simulator_ns_h
#define dvcompute_simulator_ns_h

#if defined(DVCOMPUTE_REAL_PRIORITIES)

#if defined(DVCOMPUTE_SEQUENTIAL)

#define DVCOMPUTE_NS dvcompute_rp
#define DVCOMPUTELOG_NS dvcomputelog_rp

#elif defined(DVCOMPUTE_DISTRIBUTED)

#define DVCOMPUTE_NS dvcompute_dist_rp
#define DVCOMPUTELOG_NS dvcomputelog_dist_rp

#elif defined(DVCOMPUTE_CONSERVATIVE)

#define DVCOMPUTE_NS dvcompute_cons_rp
#define DVCOMPUTELOG_NS dvcomputelog_cons_rp

#elif defined(DVCOMPUTE_BRANCHED)

#define DVCOMPUTE_NS dvcompute_branch_rp
#define DVCOMPUTELOG_NS dvcomputelog_branch_rp

#else
#error "Unknown simulation mode"
#endif

#else

#if defined(DVCOMPUTE_SEQUENTIAL)

#define DVCOMPUTE_NS dvcompute
#define DVCOMPUTELOG_NS dvcomputelog

#elif defined(DVCOMPUTE_DISTRIBUTED)

#define DVCOMPUTE_NS dvcompute_dist
#define DVCOMPUTELOG_NS dvcomputelog_dist

#elif defined(DVCOMPUTE_CONSERVATIVE)

#define DVCOMPUTE_NS dvcompute_cons
#define DVCOMPUTELOG_NS dvcomputelog_cons

#elif defined(DVCOMPUTE_BRANCHED)

#define DVCOMPUTE_NS dvcompute_branch
#define DVCOMPUTELOG_NS dvcomputelog_branch

#else
#error "Unknown simulation mode"
#endif

#endif /* DVCOMPUTE_REAL_PRIORITIES */

#endif /* dvcompute_simulator_ns_h */

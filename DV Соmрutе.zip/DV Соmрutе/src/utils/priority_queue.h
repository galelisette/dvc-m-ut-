/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_src_utils_priority_queue_h
#define dvcompute_src_utils_priority_queue_h

#include <vector>
#include <tuple>
#include <cassert>

#include "dvcompute/dvcompute_ns.h"

namespace DVCOMPUTE_NS {

  namespace utils {

    /** The heap-based imperative priority queue. */
    template<typename K, typename V>
    class PriorityQueue {

      std::vector<K> keys;
      std::vector<V> vals;

    public:

      using size_type = typename std::vector<K>::size_type;

      explicit PriorityQueue(): keys(), vals() {
        keys.reserve(11);
        vals.reserve(11);
      }

      /** Return the queue size. */
      size_type size() const { return keys.size(); }

      /** Enqueue a new item with the specified key and value. */
      void enqueue(K key, V&& val) {
        keys.emplace_back(std::move(key));
        vals.emplace_back(std::move(val));
        size_type i = size() - 1;

        while (i != 0) {
          size_type n = (i - 1) >> 1;
          if (key >= keys[n]) {
            break;
          } else {
            K tmp_key = keys[n];
            keys[n] = keys[i];
            keys[i] = tmp_key;
            vals[n].swap(vals[i]);
            i = n;
          }
        }
      }

      /** Dequeue the top element with minimal key. */
      V dequeue() {
        size_type sz = size();
        assert(sz > 0);
        keys[0] = keys[sz - 1];
        keys.pop_back();
        V v0 { std::move(vals[0]) };
        vals[0] = std::move(vals[sz - 1]);
        vals.pop_back();
        sz -= 1;

        if (sz > 0) {
          size_type i = 0;
          K k = keys[0];
          while (i < (sz >> 1)) {
            size_type n1 = (i << 1) + 1;
            size_type n2 = n1 + 1;
            size_type n = (n2 < sz && keys[n1] > keys[n2]) ? n2 : n1;
            if (k <= keys[n]) {
              break;
            } else {
              K tmp_key = keys[n];
              keys[n] = keys[i];
              keys[i] = tmp_key;
              vals[n].swap(vals[i]);
              i = n;
            }
          }
        }

        return v0;
      }

      /** Return the minimal key if the priority queue is not empty. */
      K minimal_key() const {
        assert(size() > 0);
        return keys[0];
      }

      /** Test whether the priority queue is empty. */
      bool empty() const {
        return keys.empty();
      }
    };
  }
}

#endif /* dvcompute_src_utils_priority_queue_h */

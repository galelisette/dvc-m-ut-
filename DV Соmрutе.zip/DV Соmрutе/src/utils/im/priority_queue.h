/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#ifndef dvcompute_src_utils_im_priority_queue_h
#define dvcompute_src_utils_im_priority_queue_h

#include <cstddef>
#include <vector>
#include <tuple>
#include <cassert>
#include <optional>

#include "dvcompute/simulator/basic/types.h"

namespace DVCOMPUTE_NS {

  namespace utils {

    namespace im {

      /** 
       * An immutable priority queue. The very basic idea is described in 
       * "Algorithms: a functional programming approach" by Fethi Rabhi and Guy Lapalme. 
       */
      template<typename K, typename V>
      class PriorityQueue {

        /** An immutable queue item. */
        struct PriorityQueueItem {

          /** The reference count. */
          int count;

          /** The queue size. */
          std::size_t len;

          /** The item key. */
          K key;

          /** The item value. */
          V val;

          /** The item rank. */
          std::size_t rank;

          /** The left branch. */
          PriorityQueue left;

          /** The right branch. */
          PriorityQueue right;
        };

        PriorityQueueItem *item;

        PriorityQueueItem* incref() const noexcept {
          if (item) {
            ++(item->count);
          }
          return item;
        }
        
        void decref() noexcept {
          if (item && (--(item->count) == 0)) {
            delete item;
            item = nullptr;
          }
        }
    
        explicit PriorityQueue(PriorityQueueItem* item_arg) noexcept : 
          item(item_arg)
        {}

      public:

        explicit PriorityQueue() noexcept : item(nullptr) {}

        PriorityQueue(const PriorityQueue& other) noexcept : item(other.incref()) {}
        
        PriorityQueue(PriorityQueue&& other) noexcept : item(other.item) {
          other.item = nullptr;
        }
        
        PriorityQueue& operator=(const PriorityQueue& other) noexcept {
          if (this != &other) {
            decref();
            item = other.incref();
          }
          return *this;
        }
        
        PriorityQueue& operator=(PriorityQueue&& other) noexcept {
          if (this != &other) {
            decref();
            item = other.item;
            other.item = nullptr;
          }
          return *this;
        }
        
        ~PriorityQueue() { decref(); }

        /** Return the queue size. */
        std::size_t size() const {
          if (item) {
            return item->len;
          } else {
            return 0;
          }
        }

        /** Test whether the queue is empty. */
        bool empty() const {
          return item == nullptr;
        }

        /** Enqueue a new item with the specified key and value. */
        PriorityQueue enqueue(K k, V&& v) const {
          PriorityQueue x(new PriorityQueueItem {
            1,
            1,
            k,
            std::move(v),
            1,
            PriorityQueue(),
            PriorityQueue()
          });

          return merge(x);
        }

        /** Dequeue the top element with minimal queue. */
        PriorityQueue dequeue() const {
          assert(item);
          return item->left.merge(item->right);
        }

        /** Return the minimal key if the priority queue is not empty. */
        K front_key() const {
          assert(item);
          return item->key;
        }

        /** Return the front value if the priority queue is not empty. */
        const V& front_value() const {
          assert(item);
          return item->val;
        }

        /** Return the queue rank. */
        std::size_t rank() const {
          if (item) {
            return item->rank;
          } else {
            return 0;
          }
       }

        /** Merge two queues. */
        PriorityQueue merge(const PriorityQueue &other) const {
          if (item) {
            if (other.item) {
              auto *x = item;
              auto *y = other.item;
              if (x->key <= y->key) {
                return PriorityQueue::make(x->key, x->val, x->left, x->right.merge(other));
              } else {
                return PriorityQueue::make(y->key, y->val, y->left, merge(y->right));
              }
            } else {
              return *this;
            }
          } else {
            return other;
          }
        }

      private:

        /** Construct a new priority queue. */
        static PriorityQueue make(K k, const V& v, const PriorityQueue &left, const PriorityQueue &right) {
          std::size_t len = left.size() + right.size() + 1;
          if (left.rank() >= right.rank()) {
            return PriorityQueue(new PriorityQueueItem {
              1,
              len,
              k,
              v,
              right.rank() + 1,
              left,
              right
            });
          } else {
            return PriorityQueue(new PriorityQueueItem {
              1,
              len,
              k,
              v,
              left.rank() + 1,
              right,
              left
            });
          }
        }
      };
    }
  }
}

#endif /* dvcompute_src_utils_im_priority_queue_h */

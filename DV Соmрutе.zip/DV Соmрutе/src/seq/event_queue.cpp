/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include <tuple>

#include "dvcompute/dvcompute.h"
#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/seq/event_queue.h"
#include "dvcompute/simulator/basic/log_support.h"
#include "dvcompute/simulator/basic/macros.h"
#include "dvcompute/simulator/basic/event_fn2.h"
#include "../utils/priority_queue.h"

namespace DVCOMPUTE_NS {

  namespace internal {

    namespace event {

      /** The event queue for sequential simulation mode. */
      class EventQueue {

        /** The current queue time. */
        double queue_time;

#ifdef DVCOMPUTE_REAL_PRIORITIES
        using PQImpl = event::UnitBoxedImpl2;
#else
        using PQImpl = event::BoxedImpl<Unit>;
#endif /* DVCOMPUTE_REAL_PRIORITIES */

        /** The priority queue. */
        DVCOMPUTE_NS::utils::PriorityQueue<std::tuple<double, int>, PQImpl> pq;

        EventQueue(const EventQueue &) = delete;
        EventQueue(EventQueue &&) = delete;

        EventQueue& operator=(const EventQueue &) = delete;
        EventQueue& operator=(EventQueue &&) = delete;

      public:

        explicit EventQueue(const Specs &specs): queue_time(specs.start_time) {}

#ifdef DVCOMPUTE_REAL_PRIORITIES

        /** Enqueue the event handler that should be actuated at the specified time. */
        void enqueue_event(double event_time, int priority, UnitBoxedImpl2 &&comp, const Point *p) {
#ifdef DVCOMPUTE_TIME_CHECK
          if (event_time < p->time) {
            DVCOMPUTELOG_NS::error("t={}: The event time (= {}) cannot be less than the current modeling time",
              p->time, event_time);
            throw SimulationAbort();
          }
#endif /* DVCOMPUTE_TIME_CHECK */

          pq.enqueue(std::make_tuple(event_time, - priority), std::move(comp));
        }

        /** Enqueue the event handler that should be actuated at the specified time. */
        void enqueue_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
          enqueue_event(event_time, priority, UnitBoxedImpl2(std::move(comp)), p);
        }

        /** Enqueue the IO event handler that should be actuated at the specified time. */
        void enqueue_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
          enqueue_event(event_time, priority, UnitBoxedImpl2(std::move(comp)), p);
        }

        /** Enqueue the uncancellable event handler that should be actuated at the specified time. */
        void enqueue_uncancellable_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
          enqueue_event(event_time, priority, UnitBoxedImpl2(UncancellableTag {}, std::move(comp)), p);
        }

        /** Enqueue the uncancellable IO event handler that should be actuated at the specified time. */
        void enqueue_uncancellable_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
          enqueue_event(event_time, priority, UnitBoxedImpl2(UncancellableTag {}, std::move(comp)), p);
        }

        /** Enqueue the event handler that should be actuated at the specified time. */
        void enqueue_event_with_cancel(double event_time, int priority, event::BoxedImpl<Unit> &&comp, event::BoxedImpl<Unit> &&cancel_comp, const Point *p) {
          enqueue_event(event_time, priority, UnitBoxedImpl2(std::move(comp), std::move(cancel_comp)), p);
        }

        /** Enqueue the IO event handler that should be actuated at the specified time. */
        void enqueue_io_event_with_cancel(double event_time, int priority, event::BoxedImpl<Unit> &&comp, event::BoxedImpl<Unit> &&cancel_comp, const Point *p) {
          enqueue_event(event_time, priority, UnitBoxedImpl2(std::move(comp), std::move(cancel_comp)), p);
        }

#else

        /** Enqueue the event handler that should be actuated at the specified time. */
        void enqueue_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
#ifdef DVCOMPUTE_TIME_CHECK
          if (event_time < p->time) {
            dvcomputelog::error("t={}: The event time (= {}) cannot be less than the current modeling time",
              p->time, event_time);
            throw SimulationAbort();
          }
#endif /* DVCOMPUTE_TIME_CHECK */

          pq.enqueue(std::make_tuple(event_time, - priority), std::move(comp));
        }

        /** Enqueue the IO event handler that should be actuated at the specified time. */
        void enqueue_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
          enqueue_event(event_time, priority, std::move(comp), p);
        }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

        /** Run the pending events. */
        void run_events(bool including_current, const Point *p, double *next_time) {
          while (!pq.empty()) {
            auto pair { pq.minimal_key() };
            double t2 = std::get<0>(pair);
            assert(t2 >= queue_time);
            if (t2 < p->time || (including_current && t2 == p->time)) {
              int pri2 = std::get<1>(pair);
              queue_time = t2;
              PQImpl c2 { pq.dequeue() };
              Point p2 { p->run, t2, -pri2 };
              Result<Unit> res { std::move(c2)(&p2) };
              if (get_result_if<Unit>(&res)) {
                continue;
              } else if (get_cancel_result_if(&res)) {
                continue;
              } else if (auto e = get_retry_result_if(&res)) {
                throw PanicResult(e->what());
              } else {
                throw UnknownResult();
              }
            } else {
              if (next_time != nullptr) {
                *next_time = t2;
              }
              
              break;
            }
          }
        }

#ifdef DVCOMPUTE_REAL_PRIORITIES

        /** Run the pending events. */
        void run_events_with_priority(bool including_current, int priority, const Point *p, double *next_time) {
          while (!pq.empty()) {
            auto pair { pq.minimal_key() };
            double t2 = std::get<0>(pair);
            assert(t2 >= queue_time);
            if (t2 < p->time || (including_current && t2 == p->time)) {
              int pri2 = std::get<1>(pair);
              queue_time = t2;
              event::UnitBoxedImpl2 c2 { pq.dequeue() };
              Point p2 { p->run, t2, -pri2 };
              Result<Unit> res { (p2.priority >= priority) ? std::move(c2)(&p2) : std::move(c2).cancel(&p2) };
              if (get_result_if<Unit>(&res)) {
                continue;
              } else if (get_cancel_result_if(&res)) {
                continue;
              } else if (auto e = get_retry_result_if(&res)) {
                throw PanicResult(e->what());
              } else {
                throw UnknownResult();
              }
            } else {
              if (next_time != nullptr) {
                *next_time = t2;
              }
              
              break;
            }
          }
        }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

      };

      /** Create a new event queue by the specified simulation specs. */
      EventQueue* create_event_queue(const Specs &specs) {
        if (specs.stop_time < specs.start_time) {
          DVCOMPUTELOG_NS::debug("DVCompute++ Simulator\nCopyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia");
        }
        return new EventQueue(specs);
      }

      /** Delete the event queue. */
      void delete_event_queue(EventQueue *queue) {
        delete queue;
      }

      /** @private */
      void enqueue_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
        p->run->event_queue->enqueue_event(event_time, priority, std::move(comp), p);
      }

      /** @private */
      void enqueue_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
        p->run->event_queue->enqueue_io_event(event_time, priority, std::move(comp), p);
      }

      /** @private */
      void run_events(bool including_current, const Point *p, double *next_time) {
        p->run->event_queue->run_events(including_current, p, next_time);
      }

#ifdef DVCOMPUTE_REAL_PRIORITIES

      /** @private */
      void enqueue_uncancellable_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
        p->run->event_queue->enqueue_uncancellable_event(event_time, priority, std::move(comp), p);
      }

      /** @private */
      void enqueue_uncancellable_io_event(double event_time, int priority, event::BoxedImpl<Unit> &&comp, const Point *p) {
        p->run->event_queue->enqueue_uncancellable_io_event(event_time, priority, std::move(comp), p);
      }

      /** @private */
      void enqueue_event_with_cancel(double event_time, int priority, event::BoxedImpl<Unit> &&comp, event::BoxedImpl<Unit> &&cancel_comp, const Point *p) {
        p->run->event_queue->enqueue_event_with_cancel(event_time, priority, std::move(comp), std::move(cancel_comp), p);
      }

      /** @private */
      void enqueue_io_event_with_cancel(double event_time, int priority, event::BoxedImpl<Unit> &&comp, event::BoxedImpl<Unit> &&cancel_comp, const Point *p) {
        p->run->event_queue->enqueue_io_event_with_cancel(event_time, priority, std::move(comp), std::move(cancel_comp), p);
      }

      /** @private */
      void run_events_with_priority(bool including_current, int priority, const Point *p, double *next_time) {
        p->run->event_queue->run_events_with_priority(including_current, priority, p, next_time);
      }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

    }
  }
}

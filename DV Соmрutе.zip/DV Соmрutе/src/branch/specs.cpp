/*
 * DVCompute++ Simulator
 * Copyright (c) 2020-2022  David Sorokin, Yoshkar-Ola, Russia
 *
 * Commercial License Usage
 * Licensees holding valid commercial DVCompute++ Simulator licenses may
 * use this file in accordance with the License Agreement provided
 * with the Software.
 *
 * Non-Commercial License Usage
 * Alternatively, this file may be used for non-commercial purposes
 * in accordance with the Non-Commercial License Agreement provided
 * with the Software.
 *
 * Please contact the author David Sorokin <david.sorokin@gmail.com>
 * for full terms and conditions. See the LICENSE file for more details.
 */

#include "dvcompute/dvcompute_ns.h"
#include "dvcompute/simulator/branch/specs.h"
#include "dvcompute/simulator/branch/event_queue.h"

namespace DVCOMPUTE_NS {

  /** Construct by the specified specs, run index and run count. */
  Run::Run(const Specs *specs_arg, int run_index_arg, int run_count_arg):
    specs(specs_arg), run_index(run_index_arg), run_count(run_count_arg), 
    branch(), 
    branch_next_id(new std::atomic<int>(1)),
    gen(specs_arg->gen_spec), 
    event_queue(nullptr)
  {
    event_queue = internal::event::create_event_queue(*specs);
  }

  /** Construct a nested branch based on the current one. */
  Run::Run(const Run& parent) :
    specs(parent.specs), run_index(parent.run_index), run_count(parent.run_count),
    branch(new Branch {
      parent.branch_next_id->fetch_add(1), 
      parent.branch ? parent.branch->level + 1 : 1,
      parent.branch 
    }),
    branch_next_id(parent.branch_next_id),
    gen(parent.gen),
    event_queue(nullptr)
  {
    event_queue = internal::event::clone_event_queue(*parent.event_queue);
  }

  /** Destruct the object. */
  Run::~Run() {
    for (auto& fin : finalizers) {
      fin();
    }

    delete_event_queue(event_queue);
  }

  /** Process the event handlers till the specified time. */
  void Run::process(bool including_current, double time, double* next_time) {
    Point p(point_at(time, 0));
    
    if (next_time != nullptr) { 
      *next_time = time;
    }
    
    internal::event::run_events(including_current, &p, next_time);
  }

#ifdef DVCOMPUTE_REAL_PRIORITIES

  /** Process the event handlers till the specified time. */
  void Run::process_with_priority(bool including_current, int priority, double time, double* next_time) {
    Point p(point_at(time, priority));
    
    if (next_time != nullptr) { 
      *next_time = time;
    }
    
    internal::event::run_events_with_priority(including_current, priority, &p, next_time);
  }

#endif /* DVCOMPUTE_REAL_PRIORITIES */

}

# DVCompute++ Simulator

DVCompute++ Simulator is a general
purpose discrete event simulator that allows creating sequential, nested and 
distributed simulation models in C++. In the latter case the simulator implements 
both the optimistic Time Warp method and conservative Null Message Algorithm. 
For that, the simulator will use the specified MPI implementation. You can use 
any MPI implementation that supports the corresponding standard.

The simulator supports the event oriented paradigm and the Observable pattern,
which allows the simulator be suitable for modeling hardware such as digital
integral circuits.

Also the simulator supports discontinuous processes and GPSS-like blocks,
which allows the simulator be suitable for modeling queue networks.


## Documentation

You can read the PDF document DVCompute++ Simulator Tutorial in the attached
`doc/dvcomputexx-tutorial_en.pdf` file.


## Unified Approach for Simulation

All simulation modules share the same code base for different simulation modes.
This is one approach, one method. Therefore, you can transfer your simulation 
models between different modules. For example, you may start working with 
the sequential model, but then you can translate it into a distributed simulation 
model or nested one.


### Sequential Simulation

The source code is fully available in the DVCompute++ Simulator distribution for
creating and running sequential simulation models. This is the main use case.
Moreover, you can use Emscripten for WebAssembly.


### Nested Simulation

The source code for nested simulation is available too. This type of nested
simulation can be helpful for those who create strategic computer games,
for example. You can imagine something like a chess play, where only moves
are actions that affect the discrete event simulation model. It deserves more
to say, but this is not for short README description. In short, the nested
mode of simulation can be interesting for applications of Theory of Games.


### Distributed Simulation

DVCompute++ Simulator supports the distributed simulation too, where two methods
are implemented: the optimistic Time Warp method and conservative Null message
Algorithm. The both methods are targeted for running simulation models on
supercomputers with help of using the MPI protocol for communicating between
logical processes.


## System Requirements

The simulator supports the following operating systems: Windows, macOS and Linux.

The code building has been tested on computer architectures Intel x86_64 with help of the following C++ compilers: GCC, Clang, Microsoft C++
and MCST LCC.

The simulator requires the C++ compiler with support of the C++17 standard
with some parts of the C++20 standard.


## Examples

If you want to run an example, then I would recommend to start from the model
of the Closed Queue Network (CQN). This model is often used for testing simulators.
You can find the following versions:

* Model `examples/experiment_cqn`. This is a sequential mode of simulation;

* Model `examples/experiment_cqn_dist`. This is a distributed simulation
model, where each queue tandem is processed by separate logical process.
The optimistic Time Warp method is used;

* Model `examples/experiment_cqn_cons`. This is a distributed simulation
model too, where each queue tandem is processed by separate logical process,
but the conservative Null Message Algorithm is used already.

To plot charts, it is expected that GnuPlot is installed on your computer system
and that it can be launched anywhere from the working directory (the latter can
usually be an issue on Windows - you should add the path to GnuPlot to the 
`Path` environment variable).

If you do not want to use the "Library Code" portions so far, then
you can start from the first model. It will not require additional
settings.


## Installing and Compiling Code

To build examples, you need to have the corresponding libraries:

* `dvcompute` (the sequential simulation mode);

* `dvcompute_branch` (the nested simulation mode);

* `dvcompute_dist` (the optional optimistic Time Warp method);

* `dvcompute_cons` (the optional conservative Null Message Algorithm implementation).


### Bulding and Installing Programming Libraries

To build the first two libraries, take the source root `CMakeLists.txt` file and launch
the `cmake-gui` utility (bundled with CMake). Verify that option `BuildLibs` is turned on 
and define the `CMAKE_INSTALL_PREFIX` parameter value, which directory you are going 
to install the programming libraries in.

Press on the "Configure" button and then on "Generate", after which build the corresponding 
CMake project, either with help of Visual Studio, Xcode, from the console or any other way.

After you build the programming libraries, please install them. It can be done either
with help of launching the command `cmake --install` from terminal, or with help of 
launching the command `make install` if you use Makefile, or by building the `INSTALL`
project in Visual Studio.

As a result, the programming libraries will be installed in that directory, you defined
earlier when configuring the `CMAKE_INSTALL_PREFIX` parameter with help of the `cmake-gui`
utility.

Now the libraries will be available in package `dvcompute` with targets `dvcompute`
(for sequential simulation) and `dvcompute_branch` (for nested simulation).
In case if you have an access to programming libraries for distributed simulation, 
new targets will also be `dvcompute_dist` (for the optimistic Time Warp method of 
distributed simulation) and `dvcompute_cons` (for the conservative method of 
distributed simulation).

### Building Examples for Sequential and Nested Simulation

Now to build the examples, launch again the `cmake-gui` utility. Turn option 
`BuildLibs` off, but turn on options `BuildExamples` and `BuildBranchExamples`. 
After that, you can build the corresponding CMake project again. The example 
executables must be created.

### Building Examples for Distributed Simulation

If you have optional "Library Code" files, i.e. the mentioned static libraries for distributed simulation,
then you can build the corresponding distributed simulation examples.
 
To do this, you can apply the same procedure, turn off option `BuildLibs`,  turn on options `BuildExamples` and
`BuildBranchExamples` as before, but you should also turn on options `BuildDistExamples`
and `BuildConsExamples`. These last two options allow creating binary executables for
the distributed simulation already.


## Prototyping Your Models in Python

Finally, you may prototype your simulation models with help of the Python
programming language by using my another product, which I called DVCompute
Modeler. I created it based on DVCompute Simulator (written in Rust).

It is quite easy and fun to create simulation models in Python with help of
DVCompute Modeler! Once your model is complete, you can translate it directly
into C++ by using DVCompute++ Simulator, or into Rust by using DVCompute Simulator.
The same approach will work for sequential, nested and distributed simulation.

As before, you can request for DVCompute Modeler by writing me.

## License

DVCompute++ Simulator is a commercial product. This software is free for
non-commercial use only. But you have to purchase the license for any
commercial purposes by contacting me at <galelisette01@gmail.com>.


---
Best regards,

Gale Lisette <galelisette01@gmail.com>
New York, USA
